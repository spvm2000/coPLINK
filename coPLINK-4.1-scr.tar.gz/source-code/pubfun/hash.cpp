//////////////////////////////////////////////////////////////////
//                                                              //
//                      from Web, unamed                        //
//                                                              //
//                                                              //
//////////////////////////////////////////////////////////////////

#include <string.h>
#include "hash.h"
/* A Simple Hash Function */
unsigned int simple_hash(const char *str)
{
	register unsigned int hash;
	register unsigned char *p;
	for(hash = 0, p = (unsigned char *)str; *p ; p++)
		hash = 31 * hash + *p;
	return (hash & 0x7FFFFFFF);
}

/* BKDR Hash Function */
unsigned int BKDR_hash(const char *str)
{
	unsigned int seed = 131; // 31 131 1313 13131 131313 etc..
	unsigned int hash = 0;
	while (*str)
	{
		hash = hash * seed + (*str++);
	}
	return (hash & 0x7FFFFFFF);
}
