//////////////////////////////////////////////////////////////////
//                                                              //
//           coPLINK (c) 2020-2024 Han-Ming LIU                 //
//                                                              //
// This file is distributed under the GNU General Public        //
// License, Version 3.  Please see the file COPYING for more    //
// details                                                      //
//                                                              //
//////////////////////////////////////////////////////////////////

#ifndef _PUBLIC_FUNCTIONS_H_
#define _PUBLIC_FUNCTIONS_H_

//#include <conio.h>
#include <sys/io.h>
#include <stdio.h>
#include <iostream>
#include <sstream>
#include <fstream>
#include <string>
#include <map>
#include <vector>
#include <math.h>
#include <time.h>
#include <limits>
#include <string.h>
#include <dirent.h>
#include <cstdlib>
#include <unistd.h>
#include <sys/types.h>
#include <sys/stat.h>
#include <errno.h>

using namespace std;

typedef unsigned int uint;
typedef map<int,int> iMap;
typedef map<string, string> mString; 

typedef vector<char>	vChar;
typedef vector<vChar>	vvChar;
typedef vector<int> vInt;
typedef vector<vInt> vvInt;
typedef vector<double> vDouble;
typedef vector<float> vFloat;
typedef vector<vFloat> vvFloat;
typedef vector<vDouble> vvDouble;
typedef vector<string> vString;
typedef vector<vString> vvString;

#define LOW2UP				('A' - 'a')	//大小写字母之间的差

#define C2I(c)				(c-48)		//一位数字字符转整型
#define I2C(i)				(i+48)		//一位整数转字符
#define C2UPPER(c)			(c + LOW2UP)//小写字符转大写

#define TIME_REC_FN			"TimeRecord.csv"	//记录程序运行时间的文件之文件名

#define STR_LENGTH			128		//一般字符串最大长度
#define SHORT_LEN			10		//短字串长度
#define MID_ROW_LENGTH		16384	//文件数据每行最大长度（中等）
#define MAX_ROW_LENGTH		65536	//文件数据每行最大长度（大）

#define EPSILON				0.000001	//极小值

#define	EVEN_NUMBER(x)		((float)x / 2 == x / 2)

/********** fileExsit 函数检查文件时，若文件存在，用户选择之常量******/
#define OVERWRITE			1
#define APPEND				2
#define ABORT				3
#define NOT_EXIST			4		//目标文件不存在
/********************************************************************/

FILE* openFile(const char* fn, const char* model);		
void openStreamFile(fstream &fp, const char* fn, ios_base::openmode mode);
void getFileList(string path, string exd, vector<string>& files);
string getPath(string &fn);
void timeRecorder(const char *prefix, const char *field, double t);
double round(double _x,int decimalnum = 0);
double __attribute__((__stdcall__)) Round(const double Value, const short int ADigit=0, const short int RoundMark=0);
void trimString(char *line, int length);
void trimString(string &str);
void trimRedundance(string &s, bool repl = false);
void trimRoundDelim(string &s, const char cDelim);
void trimRedundance(char *s, bool repl = false);
void string2Upper(string &str);
void string2Lower(string &str);
char c2Upper(char c);
string double2string(double);
void double2string(char *result, double src, int NumOfDigits, bool positiveSign);
int fileExsit(const char *fn, bool bSilent);
string getDT(void);
void getNumbers(const char *src, char *des, int iStart = 0);
void stringSplit(string &str, vector<string> &res, const char* c = " ");					// 忽略空串
int stringSplit(std::vector<std::string> &vec, const std::string &src, const char &delim);	// 保留空串，但string.find实现，理论上速度慢
void stringSplit(const char *str, vector<string> &res, const char c = ',');					// 保留空串
void stringSplit(const char *str, vector<char*> &res, const char c = ',');					// 保留空串
string& replace_all_distinct(string& str, const string& old_value, const string& new_value);
string& replaceChar(string& str, const char cOld, const char cNew);
int stringCount(string &str1, string &str2);
int charCount(string &str, const char c);
void getStringN(string &str1, string &str2, int n, string &ret);
void getStringN(const char *str, const char c, int n, string &ret);
void getStringN(int n, string &str1, const char *cstr2, string &ret);
char* sub_str(const char *str, int start, int len = -1);
size_t stringRFind(const string& strContent, const string& strToFind, size_t nStartPos = string::npos);
size_t stringFind(const string& strContent, const string& strToFind, size_t nStartPos = 0);
int charNfind(const char *str, const char c, int n);
int charNfind(const char *str, const char *cs, int n);
void delayInSecond(int sec);
void insStr(char *str, const char separator, const char *ins);
bool copyFile(char *desFile, char *srcFile);
int stringCmp(const string &str1, const string &str2, char cDelimiter);
//unsigned long int getFreeMemory();	// windows
/***********linux *************/
typedef struct MEMPACKED
{
	char name1[20];
	unsigned long MemTotal;
	char name2[20];
	unsigned long MemFree;
	char name3[20];
	unsigned long Buffers;
	char name4[20];
	unsigned long Cached;

}MEM_OCCUPY;

typedef struct os_line_data
{
	char * val;
	int    len;
} os_line_data;

static char * os_getline(char *sin, os_line_data * line, char delim);
int Parser_EnvInfo(char * buffer, int size, MEM_OCCUPY * lpMemory);
int  get_procmeminfo(MEM_OCCUPY * lpMemory);
/***********************************/

unsigned long int getFileSize(string &fn, bool *ret);
#endif
