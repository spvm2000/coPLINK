#include "specifyFunctions.h"

/*
// This function implements an exact SNP test of Hardy-Weinberg
// Equilibrium as described in Wigginton, JE, Cutler, DJ, and
// Abecasis, GR (2005) A Note on Exact Tests of Hardy-Weinberg
// Equilibrium. American Journal of Human Genetics. 76: 000 - 000
//
// Written by Jan Wigginton
*/

double SNPHWE(uint obs_hets, uint obs_hom1, uint obs_hom2)
{

	if (obs_hom1 + obs_hom2 + obs_hets == 0 ) return 1;

	if (obs_hom1 < 0 || obs_hom2 < 0 || obs_hets < 0) 
	{
		cout << "Negative count in HWE test: " << obs_hets << " " << obs_hom1 << " " << obs_hom2 << endl;;
	}

	int obs_homc = obs_hom1 < obs_hom2 ? obs_hom2 : obs_hom1;
	int obs_homr = obs_hom1 < obs_hom2 ? obs_hom1 : obs_hom2;

	int rare_copies = 2 * obs_homr + obs_hets;
	int genotypes   = obs_hets + obs_homc + obs_homr;

	double * het_probs = (double *) malloc((size_t) (rare_copies + 1) * sizeof(double));
	if (het_probs == NULL) 
		cout << "FATAL ERROR - SNP-HWE: Unable to allocate array for heterozygote probabilities" << endl;

	int i;
	for (i = 0; i <= rare_copies; i++)
		het_probs[i] = 0.0;

	/* start at midpoint */
	int mid = rare_copies * (2 * genotypes - rare_copies) / (2 * genotypes);

	/* check to ensure that midpoint and rare alleles have same parity */
	if ((rare_copies & 1) ^ (mid & 1))
		mid++;

	int curr_hets = mid;
	int curr_homr = (rare_copies - mid) / 2;
	int curr_homc = genotypes - curr_hets - curr_homr;

	het_probs[mid] = 1.0;
	double sum = het_probs[mid];
	for (curr_hets = mid; curr_hets > 1; curr_hets -= 2)
	{
		het_probs[curr_hets - 2] = het_probs[curr_hets] * curr_hets * (curr_hets - 1.0)
			/ (4.0 * (curr_homr + 1.0) * (curr_homc + 1.0));
		sum += het_probs[curr_hets - 2];

		/* 2 fewer heterozygotes for next iteration -> add one rare, one common homozygote */
		curr_homr++;
		curr_homc++;
	}

	curr_hets = mid;
	curr_homr = (rare_copies - mid) / 2;
	curr_homc = genotypes - curr_hets - curr_homr;
	for (curr_hets = mid; curr_hets <= rare_copies - 2; curr_hets += 2)
	{
		het_probs[curr_hets + 2] = het_probs[curr_hets] * 4.0 * curr_homr * curr_homc
			/((curr_hets + 2.0) * (curr_hets + 1.0));
		sum += het_probs[curr_hets + 2];

		/* add 2 heterozygotes for next iteration -> subtract one rare, one common homozygote */
		curr_homr--;
		curr_homc--;
	}

	for (i = 0; i <= rare_copies; i++)
		het_probs[i] /= sum;

	/* alternate p-value calculation for p_hi/p_lo
	double p_hi = het_probs[obs_hets];
	for (i = obs_hets + 1; i <= rare_copies; i++)
	p_hi += het_probs[i];

	double p_lo = het_probs[obs_hets];
	for (i = obs_hets - 1; i >= 0; i--)
	p_lo += het_probs[i];

	double p_hi_lo = p_hi < p_lo ? 2.0 * p_hi : 2.0 * p_lo;
	*/

	double p_hwe = 0.0;
	/*  p-value calculation for p_hwe  */
	for (i = 0; i <= rare_copies; i++)
	{
		if (het_probs[i] > het_probs[obs_hets])
			continue;
		p_hwe += het_probs[i];
	}

	p_hwe = p_hwe > 1.0 ? 1.0 : p_hwe;

	free(het_probs);

	return p_hwe;
}

double chiprobP(double chi, double df)
{
	double zero = 0;
	if (chi<0 || chi != chi || chi == -1/zero || chi == 1/zero ) return -9;
	else if (chi==0) return 1;
	else if (chi>500) return 0;


	double df2 = df/2;
	double chi2 = chi/2;
	return 1-gammp(df2, chi2);

}

double gammp(double a, double x)
{
	void gcf(double *gammcf, double a, double x, double *gln);
	void gser(double *gamser, double a, double x, double *gln);
	double gamser, gammcf, gln;

	if (x<0 || a<=0) cout << "Invalid arguments in routine gammp" << endl;
	if (x < (a+1))
	{
		gser(&gamser,a,x,&gln);
		return gamser;
	} else
	{
		gcf(&gammcf,a,x,&gln);
		return 1-gammcf;
	}
}

void gser(double *gamser, double a, double x, double *gln)
{
	double gammln(double xx);
	int n;
	double sum, del, ap;

	*gln = gammln(a);
	if(x<=0)
	{
		if (x<0) cout << "x less than 0 in routine gser" << endl;
		*gamser=0;
		return;
	} else
	{
		ap = a;
		del=sum=1/a;
		for (n=1; n<=ITMAX; n++)
		{
			++ap;
			del *= x/ap;
			sum += del;
			if (fabs(del)<fabs(sum)*CHIEPS)
			{
				*gamser=sum*exp(-x+a*log(x)-(*gln));
				return;
			}
		}
		cout << "a too large, ITMAX too small in routine gser" << endl;
		return;
	}
}

void gcf(double *gammcf, double a, double x, double *gln)
{
	double gammln(double xx);
	int i;
	double an, b, c, d, del, h;

	*gln=gammln(a);
	b=x+1-a;
	c=1/FPMIN;
	d=1/b;
	h=d;
	for (i=1; i<=ITMAX; i++)
	{
		an = -i*(i-a);
		b += 2;
		d = an*d+b;
		if (fabs(d) < FPMIN) d=FPMIN;
		c=b+an/c;
		if (fabs(c) < FPMIN) c=FPMIN;
		d=1/d;
		del=d*c;
		h*=del;
		if (fabs(del-1) < CHIEPS) break;
	}
	if (i > ITMAX) cout << "a too large, ITMAX too small in gcf" << endl;
	*gammcf=exp(-x+a*log(x)-(*gln))*h;
}

double gammln(double xx)
{
	double x, y, tmp, ser;
	static double cof[6]={76.18009172947146, -86.50532032941677,
		24.01409824083091, -1.231739572450155,
		0.1208650973866179e-2, -0.5395239384953e-5};
	int j;

	y=x=xx;
	tmp=x+5.5;
	tmp -= (x+0.5)*log(tmp);
	ser=1.000000000190015;
	for (j=0; j<=5; j++) ser += cof[j]/++y;
	return -tmp+log(2.5066282746310005*ser/x);
}