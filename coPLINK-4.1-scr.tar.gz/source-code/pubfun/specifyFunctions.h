#ifndef _SPECIFY_FUNCTIONS_H_
#define _SPECIFY_FUNCTIONS_H_
#include "publicFunctions.h"

#define FPMIN	1.0e-30
#define ITMAX	100
#define CHIEPS	3.0e-7

/*******************************************************
* 计算HWE这P值
* 使用文献：A Note on Exact Tests of Hardy-Weinberg Equilibrium所描述之方法
* obs_hets = 杂合基因型个数 
* obs_hom1、obs_hom2 = 两个纯合基因型个数   
********************************************************/
double SNPHWE(uint obs_hets, uint obs_hom1, uint obs_hom2);

/*******************************************************
* 计算卡方分布的单尾概率
* 等同于EXCEL的CHIDIST函数，可用于根据HWE的卡方值计算HWE的P值
* chi = 卡方值
* df = 自由度   
********************************************************/
double chiprobP(double chi, double df);

double gammp(double a, double x);
void gser(double *gamser, double a, double x, double *gln);
void gcf(double *gammcf, double a, double x, double *gln);
double gammln(double xx);

#endif