/****************************************************************
*                                                              *
*           coPLINK (c) 2020-2024 Han-Ming LIU                 *
*                                                              *
* This file is distributed under the GNU General Public        *
* License, Version 3.  Please see the file COPYING for more    *
* details                                                      *
*                                                              *
****************************************************************/

#ifndef _HELPER_H_
#define	_HELPER_H_

#include "coPLINK.h"

/*********** Ped6Map4 constant ***********/
// cannot change the string order in the constant
#define	PED4MAP4	\
	"fam",\
	"ind",\
	"pat",\
	"mat",\
	"sex",\
	"phe",\
	"chr",\
	"snp",\
	"gen",\
	"pos"

/*****************************************/

/********* Ped6Map4 ID constants *********/
// the values of the following 10 constants cannot be changed
#define	FAMILY_ID			0
#define	INDIVIDUAL_ID		1
#define	PATERNAL_ID			2
#define	MATERNAL_ID			3
#define	SEX_ID				4
#define	PHENOTYPE_ID		5
#define	CHROMOSOME_ID		6
#define	RS_NO_ID			7
#define	GENETIC_DIS_ID		8
#define	BASE_PAIR_POS_ID	9	
/*****************************************/

// [row/col. No.] in section [VECTOR]
#define	NEXT_ALLELES		'a'		// indicates the [row/col. No.] of the  current line following Area of alleles

// 节名
#define	SECTION_VECTOR		"[VECTOR BEGIN]"
#define	SECTION_MATRIX		"[MATRIX BEGIN]"
#define	SECTION_INSERT		"[INSERT BEGIN]"
#define	SECTION_VECTOR_END	"[VECTOR END]"
#define	SECTION_MATRIX_END	"[MATRIX END]"
#define	SECTION_INSERT_END	"[INSERT END]"

// escape character
#define	ESC_COMMA			'\a'	// must be a non-printed character
#define	ESC_COMMA_STR		"\a\a"	// must be TWO ESC_COMMAs

// wildcards
#define	WILDCARD_ALLELE_NO	'#'		// allele序号
#define	WILDCARD_ALTER_AB	'^'		// 跟在^后的两个字符交替，--ped2other两个allele
#define	WILDCARD_SNP_NO		'$'		// SNP序号
#define	WILDCARD_SAMPLE_NO	'@'		// SNP序号
// wildcard escape chars
#define	ESC_ALLELE_STR		"\\#"		// #	
#define	ESC_SNP_STR			"\\$"		// $
#define	ESC_SAMPLE_STR		"\\@"		// @
#define	ESC_ALTER_STR		"\\^"		// ^

#define	SINGLE_ROW			1
#define	DOUBLE_ROW			2

#define	SNP_2_COL			0	// each SNP consist of 2 col.s
#define	SNP_1_COL			1
#define	SNP_2_ROW			2
#define	SNP_1_ROW			3

#define	OTHER2PED_ARGS(op_code)	\
"# "VERSION"\n\n# Arguments for parameter \""op_code"\"\n\
# Note: \n\
# 1. Start with \"#\" comments a row.\n\
# 2. Section names need be enclosed by a pair of [].\n\
# 3. A null line will be ignored.\n\
# 4. It represents absent if an argument line is not given.\n\
# 5. All spaces/tabs in the argument line will be ignored, except for a delimiter.\n\
# 6. The section names cannot be deleted or renamed, even if it is null.\n\
# 7. To \""OP_PED2OTHER"\", the genotype matrix in PED must be stored as a whole into\n\
#    \"other\" file, that is, it cannot have other rows or columns in its area, but\n\
#    it can be transposed.\n\
# 8. To \""OP_PED2OTHER"\", the column in the MAP must be stored as an entire row or\n\
#    column into \"other\" file, that is, there cannot be other rows or columns in\n\
#    the middle of it, but it can be turned into a row, and each column does not need\n\
#    to be stored continuously.\n\
\n\
# This section specifies the top 6 columns in PED and the whole 4 columns in MAP.\n\
# Each argument line specifies a column in PED/MAP.\n\
# Format:\n\
#   <type>,[row/col. No.],[begin],[delimiter],[direction],[filename]\n\
#   type - Type of a column. It may be \"fam\"(Family ID), \"ind\"(Individual ID), \"pat\"\n\
#      (Paternal ID), \"mat\"(Maternal ID), \"sex\"(Sex), \"phe\"(Phenotype), \"chr\"(Chromosome), \n\
#      \"snp\"(rs# or snp identifier), \"gen\"(Genetic distance) and \"pos\"(Base-pair position).\n\
#      If the type \"sex\" is not given, will generate randomly.\n\
#   row/col. No. - Row/column No. in [filename]. 0, null or a nonnumeric character represents\n\
#      being next the row/col. from above line. A negative number means inverse order.\n\
#   begin - Beginning position of the row/column in [filename]. Null, 0 or a negative number\n\
#      indicates the head of the row/column.\n\
#   delimiter - Delimiter of columns in [filename]. Null means a space/tab will be used,\n\
#      and \"\\,\" represents a comma while \"\\t\" is a tab (tab is used to \""OP_PED2OTHER"\").\n\
#      Only the first character is valid when meeting more than 1.\n\
#   direction - Direction of the data in [filename]. 0 or null means in column,\n\
#      otherwise in row.\n\
#   filename - Filename including the type (including the path if need). Null means\n\
#      using the filename specified in the nearest line from above.\n\
#   CAUTIONS:\n\
#      a. There are 10 argument lines at most in this section. The excess will be ignored.\n\
#      b. The <type> cannot be null.\n\
#      c. The [filename] in the first line cannot be null.\n\
#      d. It is case insensitive.\n\
#      e. To \""OP_OTHER2PED"\", the null rows in [filename] will be skipped, but needs be counted\n\
#         in argument lines.\n\
#      f. To \""OP_PED2OTHER"\", the null rows in \"other\" file(s) need be counted in argument\n\
#         lines.\n\
#Example:\n\
#   We have two files as follows,\n\
#     Alleles.txt:\n\
#     Family Individual Paternal Maternal Sex A1 A2 A1 A2 Phenotype\n\
#     1 1 0 0 1 A A G T 1\n\
#     <--- null line\n\
#     2 1 0 0 1 A C T G 2\n\
#     3 1 0 0 1 C C - G 2\n\
#     End\n\
#   and,\n\
#     Snps.dat:\n\
#     Platform,Illumina,Agilent\n\
#     Chr,1,1\n\
#     Rs#,snp1,snp2\n\
#     Material,lung,musle\n\
#     <--- null line\n\
#     Genetic distance,0,0\n\
#     Position,5000650,5000830\n\
#   Then, 10 argument lines may be coded as\n\
#     Fam,1,2,,,alleles.txt\n\
#     Ind,2,2\n\
#     Pat,3,2\n\
#     Mat,4,2\n\
#     Sex,5,2\n\
#     Phe,10,2\n\
#     Chr,2,2,\\,,1,snps.dat\n\
#     Snp,3,2,\\,,1\n\
#     Gen,6,2,\\,,1\n\
#     Pos,7,2,\\,,1\n\
#   Or,\n\
#     Fam,1,2,,,alleles.txt\n\
#     Ind,0,2\n\
#     Pat,0,2\n\
#     Mat,0,2\n\
#     Sex,0,2\n\
#     Phe,-1,2\n\
#     Chr,2,2,\\,,1,snps.dat\n\
#     Snp,0,2,\\,,1\n\
#     Gen,6,2,\\,,1\n\
#     Pos,0,2,\\,,1\n\
#   At last, we put the 10 lines at the next line of [VECTOR BEGIN].\n\
\n\
[VECTOR BEGIN]\n\
   Fam,\n\
   Ind,\n\
   Pat,\n\
   Mat,\n\
   Sex,\n\
   Phe,\n\
   Chr,\n\
   Snp,\n\
   Gen,\n\
   Pos,\n\
\n\
[VECTOR END]\n\
\n\
# This section specifies the rectangle area of the genotypes.\n\
# Format:\n\
#   <filename>,[left],[top],[delimiter],[SNP rows/col.s],[character count],[missing],[case],[ctrl],[male],[female],[AA],[Aa],[aa]\n\
#   filename - Filename including the genotypes (adding the path if need). It cannot be null.\n\
#   left - Left column No. of the rectangle in the source file. 1 will be used while meeting\n\
#      null, 0 or a negative number.\n\
#   top - Top row No. of the rectangle in the source file. 1 will be used while meeting null,\n\
#      0 or a negative number.\n\
#   delimiter - Delimiter of columns in <filename>. Null means a space, and \"\\,\" represents\n\
#      a comma while \"\\t\" is a tab(tab is used to \""OP_PED2OTHER"\").\n\
#   SNP rows/col.s - Number of rows/col.s in <filename>. 0, null or out of 0~3 means\n\
#      every two columns is a SNP; 1 is each column a SNP; 2 is every two rows a SNP;\n\
#      and 3 is each row a SNP.\n\
#   character count - Number of characters in a genotype. 1 or 2 is allowed. 0, null or\n\
#      out of 1 and 2 means 2. Its value will be fixed to 2 when[SNP rows/col.s] = 0 or 2.\n\
#   missing - String representing missing alleles. Null means PLINK's missing characters.\n\
#   case - Character of cases. The first character will be used only. Null means using PLINK's.\n\
#   ctrl - Character of controls. The first character will be used only. Null means using PLINK's.\n\
#   male - Character of males. The first character will be used only. Null means using PLINK's.\n\
#   female - Character of females. The first character will be used only. Null means using\n\
#      PLINK's.\n\
#   AA - Characters of genotype AA. When [character count] = 1, only the first character\n\
#      is valid and null is 0. When[character count] = 2, only the first 2 characters are\n\
#      valid and null or only one character means the two characters are the same as\n\
#      the first character in[Aa]. The item is case sensitive.\n\
#   Aa - Characters of genotype Aa. When [character count] = 1, only the first character is\n\
#      valid and null is 1. When[character count] = 2, only the first 2 character are valid\n\
#      and the first one is major allele, the other is minor allele; And, null or only one\n\
#      character means the characters in source are used. The item is case sensitive.\n\
#   aa - Characters of genotype aa. When [character count] = 1, only the first character\n\
#      is valid and null is 2. When[character count] = 2, only the first 2 characters are\n\
#      valid and null or only one character means the two characters are the same as\n\
#      the second character in[Aa]. The item is case sensitive.\n\
#   CAUTION:\n\
#      a. This section cannot be null, and only the first line is valid while being more than 1.\n\
#      b. To \""OP_OTHER2PED"\", the null rows in [filename] will be skipped, but needs be counted\n\
#         in argument lines.\n\
#      c. To \""OP_PED2OTHER"\", the null rows in \"other\" file(s) need be counted in argument\n\
#         lines.\n\
#      d. The [AA], [Aa] and [aa] are used to specify the characters for the destination.\n\
#\n\
# Example:\n\
#   Let Alleles.txt listed in section [VECTOR] as the source file, we may code like this:\n\
#     alleles.txt,6,2,,0,2,-,2,1,1,2\n\
#   At last, we put the line at the next line of [MATRIX BEGIN].\n\
\n\
[MATRIX BEGIN]\n\
\n\
[MATRIX END]\n"

#define	INSERT_ARGS	\
"# This section is for \""OP_PED2OTHER"\" and \""OP_INSERT"\", which gives the row(s)/col.(s) inserted into\n\
#   the destination file(s).\n\
# Format:\n\
#   <row/col. No.>,[filename],[begin],[delimiter],[direction],[item1],[item2],...\n\
#   row/col.No. - Position in <filename>.It cannot be null. 0, null or a nonnumeric\n\
#      character represents being next the row/col. from above line. A negative number \n\
#      means inverse order.  When the specified position exceeds the maximum row/col. No.,\n\
#      the inserted text will be appended to the end.\n\
#   filename - Filename of the inserted file. (including the path if need).Null means\n\
#      using the filename specified in the nearest line from above (for \""OP_PED2OTHER"\")\n\
#      or the first one (for \""OP_INSERT"\").\n\
#   begin - Beginning position of the row/column in \"other\" file(s). Null, 0 or a negative\n\
#      number indicates the head of the row/column.\n\
#   delimiter - Delimiter of the columns. Null means a space, and \"\\,\"represents a comma\n\
#       \"\\t\" a tab.\n\
#   direction - Direction of the inserted texts in <filename>. 0 or null means in column,\n\
#      otherwise in row.\n\
#   item1, item2, ... - Inserted items. Their number may be or not limited, and a\n\
#      regular expression may be used here.\n\
#   CAUTION:\n\
#      a. This section may be null and be allowed any number of lines.\n\
#      b. The null lines in destination needs be counted in [begin].\n\
#      c. The [filename] cannot be null in the first argument line, and the first one is\n\
#         accepted only for \""OP_INSERT"\".\n\
#      d. For an argument line here, only ONE wildcard can be included in ONE item.\n\
#\n\
# Example:\n\
#   Let Alleles.txt listed in section [VECTOR] as the \"other\" file, we may code like this:\n\
#     1,alleles.txt,1, ,1,Family,Individual,Paternal,Maternal,Sex,A1,A2,A3,A4,Phenotype\n\
#     3,,1,,1\n\
#   Or,\n\
#     1,alleles.txt,1,,1,Family,Individual,Paternal,Maternal,Sex,A#,Phenotype\n\
#     3,,1,,1\n\
#   At last, we put the lines at the next line of [INSERT BEGIN].\n\
\n\
[INSERT BEGIN]\n\
\n\
[INSERT END]\n"


#endif // !_HELPER_H_
