//////////////////////////////////////////////////////////////////
//                                                              //
//           coPLINK (c) 2020-2024 Han-Ming LIU                 //
//                                                              //
// This file is distributed under the GNU General Public        //
// License, Version 3.  Please see the file COPYING for more    //
// details                                                      //
//                                                              //
//////////////////////////////////////////////////////////////////

#ifndef _H_FORMATS_H
#define	_H_FORMATS_H

/************* Prettybase文件格式参数 *************/
// 运行模式
#define	PRET_SAMPLE_NOREP	0		// 认为一个SNP中样本ID不重复
#define	PRET_POSITION_NOREP	1		// 认为一个SNP中positon不重复
// 文件格式
#define	PRET_Slider			0		// 2020.2.18网上找到的版本的格式代号
#define	PRET_SeattleSNPs 	1		// 早期版本格式代号
#define	PRET_NULL			-1		// 文件内容为空
// 基本信息在数组中的列号
#define PRET_POS			0		// pos. 列号
#define PRET_NAME			1		// HUGO_NAME列号
#define PRET_CHR			2		// 染色体号列号
#define PRET_SAMPLE_OLD		3		//样本ID列号（早期版本的列号）
#define PRET_SAMPLE_NEW		1		//样本ID列号（2020.2.18网上找到的版本的列号）
#define PRET_ALLELE1		2		// allele1列号（2020.2.18网上找到的版本的列号）
#define PRET_ALLELE2		3		// allele2列号（2020.2.18网上找到的版本的列号）
#define	PRET_MISSING_A1		'-'		// old format
#define	PRET_MISSING_A2		'N'		// old and new format
#define	PRET_MISSING_A3		'?'		// new format
/**************************************************/

/*************** Plink ped文件格式参数 ****************/
#define PLNK_PED_UNKNOWN_SEX		'0'				//未知性别代码
#define PLNK_PED_UNKNOWN_PHENOTYPE	'0'				//未知表型代码
#define PLNK_PED_MALE				'1'				//男性
#define PLNK_PED_FEMALE				'2'
#define PLNK_PED_CASE_PHENOTYPE		'2'				//CASE表型代码
#define PLNK_PED_CTRL_PHENOTYPE		'1'				//CONTROL表型代码
#define PLNK_PED_MISSING_ALLELE1	'-'				//缺失等基因符号1
#define PLNK_PED_MISSING_ALLELE2	'N'				//缺失等基因符号2
#define PLNK_PED_MISSING_ALLELE3	'0'				//缺失等基因符号3
#define PLNK_PED_MISSING_ALLELE4	'n'				//缺失等基因符号4
#define PLNK_PED_A					'D'				//major等位基因
#define PLNK_PED_a					'd'				//minor等位基因
#define PLNK_PED_Aa_aA				"d D"			//杂合子基因型

#define PLNK_PED_FAMILY_COL			0				// family id 所在列号（从0开始编号）
#define PLNK_PED_INDIVIDUAL_COL		1				// individual id 所在列号（从0开始编号）
#define PLNK_PED_PATERNAL_COL		2				// paternal id 所在列号（从0开始编号）
#define PLNK_PED_MATERNAL_COL		3				// maternal id 所在列号（从0开始编号）
#define PLNK_PED_SEX_COL			4				//性别所在列号（从0开始编号）
#define PLNK_PED_PHENOTYPE_COL		5				//case/control所在列号（从0开始编号）
#define PLNK_PED_GENOTYPE_COL		6				//等位基因开始的列号（从0开始编号）
/**************************************************/

/*************** Plink map文件格式参数 ****************/
#define PLNK_MAP_CHR_COL		0					//染色体号所在列号（从0开始编号）
#define PLNK_MAP_SNP_ID_COL		1					//SNP ID所在列号（从0开始编号）
#define PLNK_MAP_POS_COL		3					//位置所在列号（从0开始编号）
/**************************************************/

/******************** Plink bed 格式文件参数 *************************/
#define PLNK_BED_HD_CNT			3				//文件头所占字节数
#define PLNK_BED_AA				3				//基因型AA(二进制：11）
#define PLNK_BED_Aa_aA			2				//基因型Aa或aA（二进制：01，因逆序存放，所以为2）
#define PLNK_BED_aa				0				//基因型aa（二进制：00）
#define PLNK_BED_MISSING		1				//缺失值（二进制：10，因逆序存放，所以为1）
/*********************************************************************/

/******************** Plink tped 格式文件参数 *************************/
#define	TPED_NORMAL			0		// 标准.tped文件格式
#define	TPED_USR_DEF		1		// 自定义.tped文件格式（tped中的基因型用0、1、2分别表示AA、Aa/aA、aa，其余同标准tped）
/*********************************************************************/

/******************** Plink tfam 格式文件参数 *************************/
/* tfam 文件格式：
* 每行一个sample
* 如：
FAM_CAD	WTCCC79589	0	0	1	0
FAM_CAD	WTCCC64372	0	0	2	0
FAM_CAD	WTCCC79286	0	0	1	0
...

*  各列含义：
*  1 - 家系ID
*  2 - sample ID
*  3 - 父亲ID
*  4 - 母亲ID
*  5 - 性别（1=男、2=女、0=未知）
*  6 - 表型（1=对照、2=疾病、0=未知）
*/

#define	PLNK_TFAM_COL_CNT			6				//列数
// 列号：
#define PLNK_TFAM_FAMILY_ID			0				//
#define PLNK_TFAM_INDIVIDUAL_ID		1				//
#define PLNK_TFAM_PATERNAL_ID		2				//
#define PLNK_TFAM_MATERNAL_ID		3				//
#define PLNK_TFAM_GENDER			4				//
#define PLNK_TFAM_PHENOTYPE			5				//
/*********************************************************************/

/**************** MDR文件格式参数 *****************/
#define MDR_CASE_PHENOTYPE		'1'					//CASE表型代码
#define MDR_CTRL_PHENOTYPE		'0'					//CONTROL表型代码
#define	MDR_AA					'0'					// genotype AA
#define	MDR_Aa_aA				'1'					// genotype Aa
#define	MDR_aa					'2'					// genotype aa
#define	MDR_MISSING_STR			"-1"
/**************************************************/

/*************** BOOST文件格式参数 ****************/
#define BOOST_CASE_PHENOTYPE		'1'				//CASE表型代码
#define BOOST_CTRL_PHENOTYPE		'0'				//CONTROL表型代码
#define	BOOST_MISSING_ALLELE_NUM	-1				//missing（数值）
#define	BOOST_MISSING_ALLELE_STR	"-1"			//missing（string）
#define	BOOST_AA					'0'				
#define	BOOST_Aa_aA					'1'
#define	BOOST_aa					'2'
/**************************************************/

/************* LogicReg文件格式参数 ***************/
#define LOGREG_CASE_PHENOTYPE		'1'				//CASE表型代码
#define LOGREG_CTRL_PHENOTYPE		'0'				//CONTROL表型代码
#define	LOGREG_LOGIT				1				// 指定转LogicReg格式时是否对因变量（即表型）作logit变换：0=否（默认），1=是
#define	LOGREG_MISSING				'-'
/**************************************************/

/**************** ME文件格式参数 ******************/
#define ME_CASE_PHENOTYPE		'2'					//CASE表型代码
#define ME_CTRL_PHENOTYPE		'1'					//CONTROL表型代码
#define ME_ALLELE_A				'1'					//基因型A代码
#define ME_ALLELE_A1			'0'					//基因型A代码1
#define ME_ALLELE_a				'2'					//基因型a代码
#define	ME_ALLELE_MISSING_NUM	-1					//缺失等基因符号
/**************************************************/

/*************** BEAM文件格式参数 *****************/
#define BEAM_CASE_PHENOTYPE		'1'					//CASE表型代码
#define BEAM_CTRL_PHENOTYPE		'0'					//CONTROL表型代码
#define BEAM_MISSING_ALLELE_STR	"-"				//缺失等基因符号（字串）
#define	BEAM_ALLELE_AA			'2'					//基因型AA代号
#define	BEAM_ALLELE_Aa_aA		'0'					//基因型Aa及aA代号
#define	BEAM_ALLELE_aa			'1'					//基因型aa代号
/**************************************************/

/************** SVMSNP文件格式参数 ****************/
#define SEEK_MODE_LETTER			0				//查找主要等位基因时的方式1
#define SEEK_MODE_FRQ				1				//查找主要等位基因时的方式0
#define SVMSNP_CASE_PHENOTYPE		'0'				//CASE表型代码
#define SVMSNP_CTRL_PHENOTYPE		'1'				//CONTROL表型代码
#define	SVMSNP_GENOTYPE0			'0'				// genotype code0
#define	SVMSNP_GENOTYPE1			'1'				// genotype code1
#define	SVMSNP_GENOTYPE2			'2'				// genotype code2
#define	SVMSNP_MISSING_GENOTYPE		"-1"
/**************************************************/

/************** other文件格式参数 ****************/
#define OTHER_MODE_OUT				0				// 模式代码0，输出“other”文件
#define OTHER_MODE_LST				1				// 模式代码1，列出源ped文件的SNP、样本信息，以帮助设计“other”格式
/**************************************************/

#endif // !_H_FORMATS_H
