/****************************************************************
*                                                              *
*           coPLINK (c) 2020-2024 Han-Ming LIU                 *
*                                                              *
* This file is distributed under the GNU General Public        *
* License, Version 3.  Please see the file COPYING for more    *
* details                                                      *
*                                                              *
****************************************************************/

#include "coPLINK.h"
#include "../random/randomc.h"
#include "../pubfun/specifyFunctions.h"

namespace coPLINK
{
	/********************************************
	* 根据输入文件名fn判断有否扩展名，没有则返回带扩展名extFn的字串
	* extFn = 文件扩展名，需带“.”，如“.ped”
	*********************************************/
	string addExt(string &fn, string extFn)
	{
		int	i;						// 不能定义为uint，否则在linux 64位平台因为不是-1而导致不认为是string::npos
		string	sFn;
		bool	bCur = false, bFat = false;

		if (fn.substr(0, 3) == "../") {	//输入文件名包含父路径
			bFat = true;
			sFn = fn.substr(3);
		}
		else if (fn.substr(0, 2) == "./") {	//输入文件名包含current path
			bCur = true;
			sFn = fn.substr(2);
		}
		else{
			sFn = fn;
		}

		i = sFn.find_last_of('.');
		if (i == string::npos) {
			if (bCur){ sFn = "./" + sFn; }
			else if (bFat){ sFn = "../" + sFn; }

			return sFn + extFn;
		}

		return fn;
	}

	/********************************************
	* 根据输入文件名fn判断有否扩展名extFn，并返回带扩展名extFn的字串
	* extFn = 文件扩展名，需带“.”，如“.ped”
	* bRpl = 是否替换扩展名。
	* 例：getFn("xx.ped", ".map", true) = "xx.map"
	*     getFn("xx.ped", ".map", fale) = "xx.ped.map"
	*********************************************/
	string getFn(string &fn, string extFn, bool bRpl)
	{
		int	i;						// 不能定义为uint，否则在linux 64位平台因为不是-1而导致不认为是string::npos
		string	sTmp, sExt, sFn, sSufix;
		bool	bCur = false;

		if (fn.substr(0, 3) == "../") {	//输入文件名包含父路径
			bCur = true;
			sSufix = "../";
			sFn = fn.substr(3);
		}
		else if (fn.substr(0, 2) == "./") {	//输入文件名包含current path
			bCur = true;
			sSufix = "./";
			sFn = fn.substr(2);
		}
		else{
			sFn = fn;
		}

		sExt = extFn;
		string2Upper(sExt);
		i = sFn.find_last_of('.');

		if (bRpl) sFn = sFn.substr(0, i);

		if (i == string::npos) {
			if (bCur){ sFn = sSufix + sFn; }

			return sFn + extFn;
		}
		else {
			sTmp = sFn.substr(i);
			string2Upper(sTmp);

			if (bCur){ sFn = sSufix + sFn; }

			if (sTmp == sExt){ return sFn; }
			else{ return sFn + extFn; }
		}
	}

	/********************************************
	* 按行读取PLINK ped文本格式文件(结果仅保留一个分隔符)
	* vsPed = 输出的Plink格式的数据(ped文件内容，每行一个sample)
	* clsParas = 类参数指针
	* cDelimeter = 指定替换分隔符（对于Ped只能是空格或TAB）
	*********************************************
	* PED文件, N-missing（本程序定义）：
	* 1	 1	0	0	1	1	A	A	G	T ...
	* 2	 1	0	0	1	1	A	C	T	G ...
	* 3	 1	0	0	1	1	C	C	G	G ...
	* ...
	*
	* 前6列：Family ID, Individual ID, Paternal ID, Maternal ID, Sex (1=male; 2=female; other=unknown), Phenotype (1=unaffect; 2=affect)
	*********************************************/
	void readPed(vString& vsPed, coPLINK::parameters *clsParas, char cDelimeter)
	{
		fstream	fp;
		string	sLine;
		int		i, j, k, m;

		sLine = addExt(clsParas->sInputFilename, ".ped");

#ifdef TEST_PERFORMANCE
		bool	b;
		clsParas->uInSize = getFileSize(sLine, &b);
#endif

		cout << "Reading file " << sLine << ". Please wait ..." << endl;

		openStreamFile(fp, sLine.c_str(), ios::in);
		m = 0;
		while (!fp.eof() && fp.good()) {
			sLine = "";
			getline(fp, sLine);							//取一行
			trimString(sLine);							//删除前后空格及TAB
			trimRedundance(sLine);						//删除中间多余空格及TAB（只保留一个）

			//分隔符替换
			if (cDelimeter == '\t'){ replaceChar(sLine, ' ', '\t'); }
			else{ replaceChar(sLine, '\t', ' '); }

			if (sLine.length() == 0) continue;

			vsPed.push_back(sLine);
			cout << '\t' << ++m << "...\r";
		}
		sLine = "";
		fp.close();
		cout << endl;

		if (clsParas->bNormalize) {
			if (!NormalizePed(vsPed, PLNK_PED_GENOTYPE_COL, sLine)){	//归一化
				fetalError(sLine, clsParas);
			}
		}

		// 统计表型
		m = 0;
		for (i = 0; i < (int)vsPed.size(); i++) {
			j = 0;
			for (k = 0; k < (int)vsPed[i].length(); k++) {
				if (vsPed[i][k] == cDelimeter) {
					j++;
					if (j == PLNK_PED_PHENOTYPE_COL) break;
				}
			}

			if (PLNK_PED_CASE_PHENOTYPE == vsPed[i][++k]){ m++; }		// 只取首字符统计casse
		}

		// 统计SNP
		j = 0;
		for (i = 0; i < (int)vsPed[0].size(); i++) {
			if (vsPed[0][i] == cDelimeter){ j++; }
		}
		j = (j - PLNK_PED_PHENOTYPE_COL) / 2;

		if (vsPed.empty()) {
			fetalError("Source file " + clsParas->sInputFilename + "has no any valid data.", clsParas);
		}

		clsParas->fpStat << ',' << clsParas->sInputFilename << ',' << m << ',' << (vsPed.size() - m) << ',' << j << endl;	// 记录case、ctrl、SNP数

		cout << endl << "The PED file read successfully as a vector. Includes " << m << " cases, "
			<< (vsPed.size() - m) << " controls and " << j << " SNPs" << endl;
		clsParas->fpLog << "The PED file " << clsParas->sInputFilename << " read successfully as a vector." << endl;
	}

	/*************重载*******************
	* 结果为空格分隔的字符矩阵（多字符基因型只保留首字符）
	* vvcPed = 基因型矩阵（样本数行*2倍的SNP数列）
	* vsPed6 = PED文件的前6列
	* clsParas = 类参数指针
	* repl = whether replace allele chars with specified chars
	*************************************/
	void readPed(vvChar& vvcPed, vString& vsPed6, coPLINK::parameters *clsParas, bool repl)
	{
		fstream	fp;
		string	sLine, sTmp;
		vString	vs;
		vChar	vc;
		int		i, j, k, m;
		char	c1, c2;

		sLine = addExt(clsParas->sInputFilename, ".ped");

#ifdef TEST_PERFORMANCE
		bool	b;
		clsParas->uInSize = getFileSize(sLine, &b);
#endif

		cout << "Reading file " << sLine << ". Please wait ..." << endl;

		if (clsParas->bFixPhenotype) {
			cout << "\tPhenotypes were specified as " << clsParas->cPhenotype << endl;
			clsParas->fpLog << "\tPhenotypes were specified as " << clsParas->cPhenotype << endl;
		}
		else {
			cout << "\t1 is control, otherwise case." << endl;
			clsParas->fpLog << "\t1 is control, otherwise case." << endl;
		}

		openStreamFile(fp, sLine.c_str(), ios::in);
		m = 0;
		while (getline(fp, sLine)) {
			trimString(sLine);							//删除前后空格及TAB
			trimRedundance(sLine, true);				//删除中间多余空格及TAB（只保留一个），并把TAB用空格替换

			if (sLine.length() == 0) continue;

			//分隔符替换
			//replaceChar(sLine, '\t', ' ');
			j = 0;

			for (i = 0; i < (int)sLine.size(); i++){
				if (sLine[i] == DELIMITER3) j++;

				if (j == PLNK_PED_GENOTYPE_COL) break;

				if (j == PLNK_PED_PHENOTYPE_COL) k = i;	// 取表型位置
			}

			if (j < PLNK_PED_GENOTYPE_COL) continue;
			
			sTmp = sLine.substr(0, k);

			if (clsParas->bFixPhenotype) sTmp += clsParas->cPhenotype;
			else{
				if (sLine[k] == PLNK_PED_CTRL_PHENOTYPE){ sTmp += PLNK_PED_CTRL_PHENOTYPE; }
				else{ sTmp += PLNK_PED_CASE_PHENOTYPE; }
			}

			i++;
			sLine = sLine.substr(i, k - i + 1);		// 删除前PLNK_PED_GENOTYPE_COL列
			stringSplit(sLine, vs);
			k = vs.size();

			if (k < 2) continue;					// 最少一个SNP

			vsPed6.push_back(sTmp);
			vc.resize(k);

			for (i = 0; i < k; i++) {
				if ((vs[i][0] == PLNK_PED_MISSING_ALLELE1)
					|| (vs[i][0] == PLNK_PED_MISSING_ALLELE2)
					|| (vs[i][0] == PLNK_PED_MISSING_ALLELE3)
					|| (vs[i][0] == PLNK_PED_MISSING_ALLELE4))
				{
					vc[i] = MISSING_ALLELE_CHR;
				}
				else{
					vc[i] = vs[i][0];	// 只保留首字符
				}
			}
			vvcPed.push_back(vc);
			cout << '\t' << ++m << " ...\r";
		}
		sLine = "";
		fp.close();
		fp.clear();
		vString().swap(vs);			// 清空vs
		vChar().swap(vc);
		cout << endl;

		if (!EVEN_NUMBER(vvcPed[0].size())){
			fetalError("The number of alleles in SNPs is not a even number.", clsParas);
		}

		// 等位基因符号数检验（不能超过2个）
		m = vvcPed.size();
		for (i = 0; i < (int)vvcPed[0].size(); i += 2){
			c1 = vvcPed[0][i];
			j = 1;

			if (vvcPed[0][i + 1] == c1) {
				for (; j < m; j++){
					if (vvcPed[j][i] != c1 && vvcPed[j][i] != MISSING_ALLELE_CHR){
						c2 = vvcPed[j][i];
						break;
					}

					if (vvcPed[j][i + 1] != c1 && vvcPed[j][i + 1] != MISSING_ALLELE_CHR){
						c2 = vvcPed[j][i + 1];
						break;
					}
				}
			}
			else{
				c2 = vvcPed[0][i + 1];
			}

			for (; j < m; j++){
				if ((vvcPed[j][i] != MISSING_ALLELE_CHR && vvcPed[j][i] != c1 && vvcPed[j][i] != c2)
					|| (vvcPed[j][i + 1] != MISSING_ALLELE_CHR && vvcPed[j][i + 1] != c1 && vvcPed[j][i + 1] != c2))
				{
					vvChar().swap(vvcPed);
					char cs[200];

					sprintf(cs, "The SNP %d has more than 2 allele characters.", i / 2 + 1);
					fetalError((string)cs, clsParas);
				}
			}
		}

		if (clsParas->bNormalize) {
			if (!NormalizeAlleles2Col(vvcPed, clsParas, sTmp, repl)){	//归一化
				fetalError(sTmp, clsParas);
			}
		}

		
		// 统计表型
		m = 0;
		for (i = 0; i < (int)vsPed6.size(); i++) {
			j = 0;
			for (k = 0; k < (int)vsPed6[i].length(); k++) {
				if (vsPed6[i][k] == ' ') {
					j++;
					if (j == PLNK_PED_PHENOTYPE_COL) break;
				}
			}

			if (PLNK_PED_CASE_PHENOTYPE == vsPed6[i][++k]){ m++; }		// 只取首字符统计casse
		}

		if (vsPed6.empty()) {
			fetalError("Source file " + clsParas->sInputFilename + "has no any valid data.", clsParas);
		}

		clsParas->fpStat << ',' << clsParas->sInputFilename << ',' << m << ',' << (vsPed6.size() - m) << ',' << (vvcPed[0].size() / 2) << endl;	// 记录file, case、ctrl、SNP数

		cout << endl << "The PED file has been read successfully as a matrix. Includes " << m << " cases, "
			<< (vsPed6.size() - m) << " controls and " << (vvcPed[0].size() / 2) << " SNPs." << endl;

		clsParas->fpLog << endl << "The PED file has been read successfully as a matrix. Includes " << m << " cases, "
			<< (vsPed6.size() - m) << " controls and " << (vvcPed[0].size() / 2) << " SNPs." << endl;
	}

	/************************************
	* if codes include ACGT, replce them with 1234
	*************************************/
	void clsLinkage::correctCodes(void)
	{
		char	code[] = { MISSING_ALLELE_CHR, 'A', 'C', 'G', 'T' };
		bool	b[] = { false, false, false, false, false };
		int		i, j, k;

		for (i = 0; i < (int)codePair.size(); i++){	// correct
			if (codePair[i][0] == MISSING_ALLELE_CHR) continue;

			for (j = 1; j < 5; j++){
				if (codePair[i][0] == code[j]) {
					codePair[i][1] = I2C(j);
					b[j] = true;	// set flag
					break;
				}
			}

		}

		for (i = 0; i < (int)codePair.size(); i++){	// check duplication
			if (codePair[i][0] == MISSING_ALLELE_CHR) continue;

			for (j = i + 1; j < (int)codePair.size(); j++){
				if (codePair[i][1] == codePair[j][1]){
					for (k = 1; k < 5; k++){
						if (!b[k]) {
							if (codePair[j][0] == code[C2I(codePair[j][1])]){ codePair[i][1] = I2C(k); }
							else{ codePair[j][1] = I2C(k); }

							b[k] = true;
							break;
						}
					}
				}
			}
		}
	}

	/************************************
	* add a pair of allele chars for Linkage
	* c1 = the allele char of a SNP which is the first meeting
	* c2 = the allele char of the SNP which is the second meeting
	*************************************/
	bool clsLinkage::addPair(char c1, char c2)
	{
		char	code1, code2;
		int		iSize, i;
		vChar	vc(2);
		bool	b1, b2;

		iSize = codePair.size();

		if (iSize >= 4) return	false;	// 4 bases at most

		if (c1 != MISSING_ALLELE_CHR){
			code1 = findCode(c1);

			if (code1 == MISSING_ALLELE_CHR){	// not found
				vc[0] = c1;

				// the char meeted firstly has a higher priority to code either 1 or 2 
				b1 = b2 = false;
				for (i = 0; i < iSize; i++){
					if (codePair[i][1] == '1'){ b1 = true; }

					if (codePair[i][1] == '2'){ b2 = true; }
				}

				if (b1){
					if (b2){
						b1 = false;
						for (i = 0; i < iSize; i++){
							if (codePair[i][1] == '3'){ b1 = true; }
						}
						vc[1] =  b1 ? '4' : '3';
					}
					else{
						vc[1] = '2';
					}
				}
				else{
					vc[1] = '1';
				}

				codePair.push_back(vc);
			}
		}

		if (c2 != MISSING_ALLELE_CHR){
			code2 = findCode(c2);

			if (code2 == MISSING_ALLELE_CHR){	// not found
				vc[0] = c2;

				// the char meeted secondly  has a higher priority to code either 3 or 4 
				b1 = b2 = false;
				for (i = 0; i < iSize; i++){
					if (codePair[i][1] == '3'){ b1 = true; }

					if (codePair[i][1] == '4'){ b2 = true; }
				}

				if (b1){
					if (b2){
						b1 = false;
						for (i = 0; i < iSize; i++){
							if (codePair[i][1] == '1'){ b1 = true; }
						}
						vc[1] = b1 ? '2' : '1';
					}
					else{
						vc[1] = '4';
					}
				}
				else{
					vc[1] = '3';
				}

				codePair.push_back(vc);
			}
		}

		// if the size of Pair is 3, check whether 1,2 and 3,4 are pairs respectively
		if (codePair.size() == 3){
			if (code2 != MISSING_ALLELE_CHR){
				codePair[2][1] = '4';
			}
		}

		return true;
	}

	/************************************
	* find the code of c from vector Pair
	* c = searched allele char
	* return = the code if found, otherwise MISSING_ALLELE_CHAR
	*************************************/
	char clsLinkage::findCode(char c)
	{
		int i;
		
		for (i = 0; i < (int)codePair.size(); i++){
			if (c == codePair[i][0]){ return codePair[i][1]; }
		}

		return MISSING_ALLELE_CHR;
	}

	/************************************
	* Exit program while encountering a fetal error
	* sErrInfo = Error information
	* clsParas = class pointer of parameters
	* dispInfo = whether displays error information
	*************************************/
	void fetalError(string sErrInfo, parameters *clsParas, bool dispInfo)
	{
		if (dispInfo){ 
			cout << "Error: " << sErrInfo << endl;
		}

		clsParas->fpLog << "Error: " << sErrInfo << endl;
		clsParas->fpLog.close();
		clsParas->fpStat.close();
#ifdef _DEBUG
		system("pause");
#endif // DEBUG

		exit(1);
	}

	/********************************************
	* 把由空格或TAB分隔的字串向量（如PED格式的基因型数据）在uStartCol列对齐，返回对齐后的start column
	* vsData = 基因数据
	* uStartCol = 起始列号（从0起编号）
	* 方法：在uStartCol列前插入空格，以使所有行的uStartCol列均处于字串中的同一个位置uMyStart
	* 如以下数据，uMyStart = 16
	* 1 1 0 0 1  1  A A  Ggs T
	* 2 1sf 0 0 1  1  A Csf  T G
	* 3 1 0 0 1  1  Crr Cww  Grr Gww
	* 4 1ffsf 0 0 1  2  Asf C  T T
	* 5 1 0 0 1  2  C C  G Tsdf
	* 6 1 0 0 1  2  Cwe C  T T
	* 对齐后：
	* 1 1 0 0 1  1      A A  Ggs T
	* 2 1sf 0 0 1  1    A Csf  T G
	* 3 1 0 0 1  1      Crr Cww  Grr Gww
	* 4 1ffsf 0 0 1  2  Asf C  T T
	* 5 1 0 0 1  2      C C  G Tsdf
	* 6 1 0 0 1  2      Cwe C  T T
	*********************************************/
	int AlignPedPos(vString &vsData, int uStartCol)
	{
		int			i, j, k, m, uMyStart;
		string		sTmp;

		/************ vsData 格式 **************
		* 每行一个sample
		* 每两列组成一个SNP
		****************************************/

		if (uStartCol == 0) uMyStart = 0;
		else {
			//找出最大的uMyStart
			uMyStart = 0;
			for (i = 0; i < (int)vsData.size(); i++) {
				k = 0;
				for (j = 0; j < (int)vsData[i].length(); j++) {
					if (vsData[i][j] == ' ' || vsData[i][j] == '\t'){ k++; }

					if (k == uStartCol) {
						if (uMyStart < j + 1){ uMyStart = j + 1; }

						break;
					}
				}
			}

			//插入空格，使各行uMyStart对齐
			for (i = 0; i < (int)vsData.size(); i++) {
				k = 0;
				for (j = 0; j < (int)vsData[i].length(); j++) {
					if (vsData[i][j] == ' ' || vsData[i][j] == '\t'){ k++; }

					if (k == uStartCol) {
						if (uMyStart > j + 1) {
							k = uMyStart - (j + 1);
							sTmp.resize(k);

							for (m = 0; m < k; m++){ sTmp[m] = ' '; }

							vsData[i] = vsData[i].substr(0, j + 1) + sTmp + vsData[i].substr(j + 1);
						}
						break;
					}
				}
			}
		}

		return uMyStart;
	}

	/********************************************
	* 归一化。即，把PED格式的基因型数据转换“D”与“d”的组合形式
	* vsData = 空格分隔的基因数据（前若干列可以不是基因数据）
	* uStartCol = 基因数据的起始列号（从0起编号）
	* ret = 返回信息
	* 正常返回true，否则返回错误信息ret
	*********************************************/
	bool NormalizePed(vString &vsData, int uStartCol, string &ret)
	{
		char	c, cA1, cA2, cs[10];
		int		i, i1, j, m, uLen, uMyStart, uA1, uA2;
		bool	bOk;

		/************ vsData 格式 **************
		* 每行一个sample
		* 每两列组成一个SNP
		****************************************/

		cout << "Normalizing ..." << endl;

		uMyStart = AlignPedPos(vsData, uStartCol);		//对齐等位基因数据

		//修正vsData，即把等位基因字符数多于1个者视为缺失；同时作等位基因个数检查（检查每个个体的等位基因个数是否为偶数）
		bOk = true;
		for (i = 0; i < (int)vsData.size(); i++) {
			uLen = vsData[i].length();

			for (j = uMyStart; j < uLen; j += 4) {
				if (j + 1 < uLen && vsData[i][j + 1] != ' ' && vsData[i][j + 1] != '\t')		//vsData[i][j]处的等位基因字符数>1
				{
					for (m = j + 1; m < (int)vsData[i].length(); m++){
						if (vsData[i][m] == ' ' || vsData[i][m] == '\t') break;
					}

					vsData[i] = vsData[i].substr(0, j + 1) + vsData[i].substr(m);	//去除多于1的字符
					uLen -= m - (j + 1);

					if (j + 2 >= uLen) {
						bOk = false;
						break;
					}

					vsData[i][j] = PLNK_PED_MISSING_ALLELE2;
					vsData[i][j + 2] = PLNK_PED_MISSING_ALLELE2;
				}

				if (j + 3 < uLen && vsData[i][j + 3] != ' ' && vsData[i][j + 3] != '\t')		//vsData[i][j+2]处的等位基因字符数>1
				{
					for (m = j + 3; m < (int)vsData[i].length(); m++){
						if (vsData[i][m] == ' ' || vsData[i][m] == '\t') break;
					}

					vsData[i] = vsData[i].substr(0, j + 3) + vsData[i].substr(m);	//去除多于1的字符
					uLen -= m - (j + 3);

					if (j + 2 >= uLen) {
						bOk = false;
						break;
					}

					vsData[i][j] = PLNK_PED_MISSING_ALLELE2;
					vsData[i][j + 2] = PLNK_PED_MISSING_ALLELE2;
				}
			}

			if (!bOk) {
				sprintf(cs, "%d", i + 1);
				ret = "The number of alleles in the ";
				ret += cs;
				ret += "-th individual is not even while normalizing.";
				cout << "The number of alleles in the " << i + 1 << "-th individual is not even." << endl;
				return false;
			}

		}

		//数据有效性检查（前一步只做了部分检查）。数据已“对齐”且已把多于1个字符的等位基因改为MISSING（只一个字符），所以只要简单地检查各行长度即可
		m = vsData.size();		//行数，即个体数
		j = vsData[0].length();
		for (i = 0; i < m; i++) {
			if (vsData[i].length() != j) 
			{
				sprintf(cs, "%d", i + 1);
				ret = "The number of alleles in the ";
				ret += cs;
				ret += "-th individual does not equal to the first.";
				cout << "The number of alleles in the " << i + 1 << "-th individual does not equal to the first." << endl;
				return false;
			}
		}

		//转换等位基因符号为显、隐性形式（次等位基因为隐性）

		for (i = uMyStart; i < (int)vsData[0].length(); i += 4) {		//逐列（即逐SNP）扫描
			uA1 = uA2 = 0;
			i1 = i + 2;
			c = MISSING_ALLELE_CHR;
			for (j = 0; j < m; j++) {	//扫描一个SNP，查找两个ALLELE均非MISSING的首位置
				if ((vsData[j][i] == PLNK_PED_MISSING_ALLELE1)
					|| (vsData[j][i] == PLNK_PED_MISSING_ALLELE2)
					|| (vsData[j][i] == PLNK_PED_MISSING_ALLELE3)
					|| (vsData[j][i] == PLNK_PED_MISSING_ALLELE4)
					|| (vsData[j][i] == MISSING_ALLELE_CHR))
				{
					vsData[j][i] = PLNK_PED_MISSING_ALLELE2;	// 设为MISSING
				}
				else {
					if (c == MISSING_ALLELE_CHR){
						uA1++;
						c = vsData[j][i];
					}
					else if (vsData[j][i] == c){
						uA1++;
					}
					else{
						uA2++;
					}
				}

				if ((vsData[j][i1] == PLNK_PED_MISSING_ALLELE1)
					|| (vsData[j][i1] == PLNK_PED_MISSING_ALLELE2)
					|| (vsData[j][i1] == PLNK_PED_MISSING_ALLELE3)
					|| (vsData[j][i1] == PLNK_PED_MISSING_ALLELE4)
					|| (vsData[j][i1] == MISSING_ALLELE_CHR))
				{
					vsData[j][i1] = PLNK_PED_MISSING_ALLELE2;	// 设为MISSING
				}
				else {
					if (c == MISSING_ALLELE_CHR){
						uA1++;
						c = vsData[j][i1];
					}
					else if (vsData[j][i1] == c){
						uA1++;
					}
					else{
						uA2++;
					}
				}
			}

			if (uA1 < uA2) {
				cA1 = PLNK_PED_a;
				cA2 = PLNK_PED_A;
			}
			else {
				cA1 = PLNK_PED_A;
				cA2 = PLNK_PED_a;
			}

			for (j = 0; j < m; j++) {	//重新扫描该SNP，把等位基因替换成显、隐性形式
				if (vsData[j][i] != PLNK_PED_MISSING_ALLELE2){
					vsData[j][i] = vsData[j][i] == c ? cA1 : cA2;
				}

				if (vsData[j][i1] != PLNK_PED_MISSING_ALLELE2){
					vsData[j][i1] = vsData[j][i1] == c ? cA1 : cA2;
				}
			}
		}

		//把“对齐”操作中加入的多余空格删除
		for (i = 0; i < (int)vsData.size(); i++){ trimRedundance(vsData[i]); }

		return true;
	}

	/****************************
	* Use the specified genotypes to normalize a allele matrix with each SNP including two columns.
	* vvcData = genotype matrix with size of sample count (rows) * double SNP count (col.s), excludeing genotype col.
	* clsParas = pointer of class of the parameters
	* ret = returned info. ( true means no errors)
	* repl = whether replace the genotypes with a group of user-defined chars in global variable struGenotype
	* bPed = whether do normalizing for PED
	************************************/
	bool NormalizeAlleles2Col(vvChar &vvcData, parameters *clsParas, string &ret, bool repl, bool bPed)
	{
		char	c, cA1, cA2, cs[10];
		int		i, i1, j, uSampleCnt, uSNP, uA1, uA2;

		/************ vvsData 格式 **************
		* 每行一个sample
		* 每两列组成一个SNP
		****************************************/

		cout << "Normalizing ..." << endl;

		uSampleCnt = vvcData.size();
		uSNP = vvcData[0].size();		// SNP数*2

		// 等位基因个数检查（检查每个个体的等位基因个数是否为偶数且个数是否相等）
		if ((float)(uSNP / 2) != (float)uSNP / 2) {		// 个体基因数非偶数
			cout << "The SNPs of individual 1 are not in pairs." << endl;
			ret = "The SNPs of individual 1 are not in pairs.";
			return false;
		}
		else{
			for (i = 0; i < uSampleCnt; i++){
				if (vvcData[i].size() != uSNP)
				{
					cout << "The number of SNPs of individual " << i << " is not identical." << endl;
					sprintf(cs, "%d", i);
					ret = "The number of SNPs of individual ";
					ret += cs;
					ret += " is not identical.";
					return false;
				}
			}
		}

		//转换等位基因符号为显、隐性形式（次等位基因为隐性）
		for (i = 0; i < uSNP; i += 2) {	//逐两列（即逐SNP）扫描
			uA1 = uA2 = 0;
			i1 = i + 1;
			c = MISSING_ALLELE_CHR;
			for (j = 0; j < uSampleCnt; j++) {	
				if (bPed && ((vvcData[j][i] == PLNK_PED_MISSING_ALLELE1)
					|| (vvcData[j][i] == PLNK_PED_MISSING_ALLELE2)
					|| (vvcData[j][i] == PLNK_PED_MISSING_ALLELE3)
					|| (vvcData[j][i] == PLNK_PED_MISSING_ALLELE4)
					|| (vvcData[j][i] == MISSING_ALLELE_CHR)))
				{
					vvcData[j][i] = MISSING_ALLELE_CHR;	// 设为MISSING
				}
				else {
					if (c == MISSING_ALLELE_CHR){
						uA1++;
						c = vvcData[j][i];
					}
					else if (vvcData[j][i] == c){
						uA1++;
					}
					else{
						uA2++;
					}
				}

				if (bPed && ((vvcData[j][i1] == PLNK_PED_MISSING_ALLELE1)
					|| (vvcData[j][i1] == PLNK_PED_MISSING_ALLELE2)
					|| (vvcData[j][i1] == PLNK_PED_MISSING_ALLELE3)
					|| (vvcData[j][i1] == PLNK_PED_MISSING_ALLELE4)
					|| (vvcData[j][i1] == MISSING_ALLELE_CHR)))
				{
					vvcData[j][i1] = MISSING_ALLELE_CHR;	// 设为MISSING
				}
				else {
					if (c == MISSING_ALLELE_CHR){
						uA1++;
						c = vvcData[j][i1];
					}
					else if (vvcData[j][i1] == c){
						uA1++;
					}
					else{
						uA2++;
					}
				}
			}

			if (uA1 < uA2) {
				cA1 = PLNK_PED_a;
				cA2 = PLNK_PED_A;
			}
			else {
				cA1 = PLNK_PED_A;
				cA2 = PLNK_PED_a;
			}

			for (j = 0; j < uSampleCnt; j++) {	//重新扫描该SNP，把等位基因替换成显、隐性形式
				if (vvcData[j][i] != MISSING_ALLELE_CHR) {
					vvcData[j][i] = vvcData[j][i] == c ? cA1 : cA2;
				}

				if (vvcData[j][i1] != MISSING_ALLELE_CHR) {
					vvcData[j][i1] = vvcData[j][i1] == c ? cA1 : cA2;
				}
			}

			if (repl) {
				for (j = 0; j < uSampleCnt; j++) {	// scan the SNP again to replace alleles with AA, Aa or aa
					if (vvcData[j][i] == MISSING_ALLELE_CHR && vvcData[j][i1] == MISSING_ALLELE_CHR) continue;

					if (vvcData[j][i] == PLNK_PED_A && vvcData[j][i1] == PLNK_PED_A) {
						vvcData[j][i] = clsParas->struGenotype.AA[0];
						vvcData[j][i1] = clsParas->struGenotype.AA[1];
					}
					else if (vvcData[j][i] == PLNK_PED_A && vvcData[j][i1] == PLNK_PED_a) {
						vvcData[j][i] = clsParas->struGenotype.Aa[0];
						vvcData[j][i1] = clsParas->struGenotype.Aa[1];
					}
					else if (vvcData[j][i] == PLNK_PED_a && vvcData[j][i1] == PLNK_PED_A) {
						vvcData[j][i] = clsParas->struGenotype.Aa[1];
						vvcData[j][i1] = clsParas->struGenotype.Aa[0];
					}
					else if (vvcData[j][i] == PLNK_PED_a && vvcData[j][i1] == PLNK_PED_a) {
						vvcData[j][i] = clsParas->struGenotype.aa[0];
						vvcData[j][i1] = clsParas->struGenotype.aa[1];
					}
					else if (vvcData[j][i] != MISSING_ALLELE_CHR) {
						vvcData[j][i] = vvcData[j][i] == PLNK_PED_A ? clsParas->struGenotype.Aa[0] : clsParas->struGenotype.Aa[1];
					}
					else if (vvcData[j][i1] != MISSING_ALLELE_CHR) {
						vvcData[j][i1] = vvcData[j][i1] == PLNK_PED_A ? clsParas->struGenotype.Aa[0] : clsParas->struGenotype.Aa[1];
					}
				}
			}
		}

		return true;
	}

	/****************************
	* Use the specified genotypes to normalize a allele matrix with each SNP including 1 columns.
	* vvcData = genotype matrix with size of double sample count (rows) * SNP count (col.s), excludeing genotype col.
	* clsParas = pointer of class of the parameters
	* ret = returned info. ( true means no errors)
	* repl = whether replace the genotypes with a group of user-defined chars in global variable struGenotype
	* bPed = whether do normalizing for PED
	************************************/
	bool NormalizeAlleles1Col(vvChar &vvcData, parameters *clsParas, string &ret, bool repl, bool bPed)
	{
		char	c, cA1, cA2, cs[10];
		int		i, j, j1, uSampleCnt, uSNP, uA1, uA2;

		/************ vvsData format **************
		* a sample including two rows
		* a SNP per col.
		*******************************************/

		cout << "Normalizing ..." << endl;

		uSampleCnt = vvcData.size();	// sample size * 2
		uSNP = vvcData[0].size();		// SNP size

		// check even number of double sample size
		if (!EVEN_NUMBER(uSampleCnt)) {
			cout << "The SNPs of individuals are not in pairs." << endl;
			ret = "The SNPs of individuals are not in pairs.";
			return false;
		}

		// check the number of SNPs for each sample
		for (i = 0; i < uSampleCnt; i++){
			if (vvcData[i].size() != uSNP){
				cout << "The number of SNPs of individual " << i / 2 << " does not match the first." << endl;
				sprintf(cs, "%d", i / 2);
				ret = "The number of SNPs of individual ";
				ret += cs;
				ret += " does not match the first.";
				return false;
			}
		}

		//转换等位基因符号为显、隐性形式（次等位基因为隐性）
		for (i = 0; i < uSNP; i++) {	//逐列（即逐SNP）扫描
			uA1 = uA2 = 0;
			for (j = 0; j < uSampleCnt; j++) {		// scan the SNP to find the first non-missing allele
				if (bPed && ((vvcData[j][i] == PLNK_PED_MISSING_ALLELE1)
					|| (vvcData[j][i] == PLNK_PED_MISSING_ALLELE2)
					|| (vvcData[j][i] == PLNK_PED_MISSING_ALLELE3)
					|| (vvcData[j][i] == PLNK_PED_MISSING_ALLELE4)
					|| (vvcData[j][i] == MISSING_ALLELE_CHR)))
				{
					vvcData[j][i] = MISSING_ALLELE_CHR;
					continue;
				}

				break;
			}

			if (j == uSampleCnt) continue;

			uA1++;
			c = vvcData[j][i];
			j++;
			for (; j < uSampleCnt; j++) {		//继续扫描
				if (bPed && ((vvcData[j][i] == PLNK_PED_MISSING_ALLELE1)
					|| (vvcData[j][i] == PLNK_PED_MISSING_ALLELE2)
					|| (vvcData[j][i] == PLNK_PED_MISSING_ALLELE3)
					|| (vvcData[j][i] == PLNK_PED_MISSING_ALLELE4)
					|| (vvcData[j][i] == MISSING_ALLELE_CHR)))
				{
					vvcData[j][i] = MISSING_ALLELE_CHR;
					continue;
				}

				if (vvcData[j][i] == c){
					uA1++;
				}
				else{
					uA2++;
				}
			}

			if (uA1 < uA2) {
				cA1 = PLNK_PED_a;
				cA2 = PLNK_PED_A;
			}
			else {
				cA1 = PLNK_PED_A;
				cA2 = PLNK_PED_a;
			}

			for (j = 0; j < uSampleCnt; j++) {	//重新扫描该SNP，把等位基因替换成显、隐性形式
				if (vvcData[j][i] != MISSING_ALLELE_CHR) {
					vvcData[j][i] = vvcData[j][i] == c ? cA1 : cA2;
				}
			}

			if (repl) {
				for (j = 0; j < uSampleCnt; j += 2) {	// scan the SNP again to replace alleles with AA, Aa or aa
					j1 = j + 1;
					if (vvcData[j][i] == MISSING_ALLELE_CHR && vvcData[j1][i] == MISSING_ALLELE_CHR) continue;

					if (vvcData[j][i] == PLNK_PED_A && vvcData[j1][i] == PLNK_PED_A) {
						vvcData[j][i] = clsParas->struGenotype.AA[0];
						vvcData[j1][i] = clsParas->struGenotype.AA[1];
					}
					else if (vvcData[j][i] == PLNK_PED_A && vvcData[j1][i] == PLNK_PED_a) {
						vvcData[j][i] = clsParas->struGenotype.Aa[0];
						vvcData[j1][i] = clsParas->struGenotype.Aa[1];
					}
					else if (vvcData[j][i] == PLNK_PED_a && vvcData[j1][i] == PLNK_PED_A) {
						vvcData[j][i] = clsParas->struGenotype.Aa[1];
						vvcData[j1][i] = clsParas->struGenotype.Aa[0];
					}
					else if (vvcData[j][i] == PLNK_PED_a && vvcData[j1][i] == PLNK_PED_a) {
						vvcData[j][i] = clsParas->struGenotype.aa[0];
						vvcData[j1][i] = clsParas->struGenotype.aa[1];
					}
					else if (vvcData[j][i] != MISSING_ALLELE_CHR) {
						vvcData[j][i] = vvcData[j][i] == PLNK_PED_A ? clsParas->struGenotype.Aa[0] : clsParas->struGenotype.Aa[1];
					}
					else if (vvcData[j1][i] != MISSING_ALLELE_CHR) {
						vvcData[j1][i] = vvcData[j1][i] == PLNK_PED_A ? clsParas->struGenotype.Aa[0] : clsParas->struGenotype.Aa[1];
					}
				}
			}
		}

		return true;
	}

	/****************************
	* Use the specified genotypes to normalize a allele matrix with each SNP including two rows.
	* vvcData = Space-separated genotype matrix with size of double SNP count (rows) * sample count (col.s) , excludeing genotype col.
	* clsParas = pointer of class of the parameters
	* ret = returned info. ( true means no errors)
	* repl = whether replace the genotypes with a group of user-defined chars in global variable struGenotype
	* bPed = whether do normalizing for PED
	************************************/
	bool NormalizeAlleles2Row(vvChar &vvcData, parameters *clsParas, string &ret, bool repl, bool bPed)
	{
		char	c, cA1, cA2, cs[10];
		int		i, i1, j, uSampleCnt, uSNP, uA1, uA2;

		/************ vvsData format **************
		* a SNP occupies two rows
		* a sample per col.
		*******************************************/

		cout << "Normalizing ..." << endl;

		uSampleCnt = vvcData[0].size();
		uSNP = vvcData.size();				// SNP count * 2

		// 等位基因个数检查（SNP数是否为偶数且每个SNP的样本数是否相等）
		if (!EVEN_NUMBER(uSNP)) {		// 个体基因数非偶数
			cout << "The column number of SNPs are not in pairs." << endl;
			ret = "The column number of SNPs are not in pairs.";
			return false;
		}
		else{
			for (i = 0; i < uSNP; i++){	// check sample cnt for each SNP
				if (vvcData[i].size() != uSampleCnt){
					cout << "The number of individuals of SNP " << i << " does not match the first." << endl;
					sprintf(cs, "%d", i);
					ret = "The number of individuals of SNP ";
					ret += cs;
					ret += " does not match the first.";
					return false;
				}
			}
		}

		//转换等位基因符号为显、隐性形式（次等位基因为隐性）
		for (i = 0; i < uSNP; i += 2) {	//逐两行（即逐SNP）扫描
			uA1 = uA2 = 0;
			i1 = i + 1;
			c = MISSING_ALLELE_CHR;

			for (j = 0; j < uSampleCnt; j++) {		// scan the SNP to count alleles
				if (bPed && ((vvcData[i][j] == PLNK_PED_MISSING_ALLELE1)
					|| (vvcData[i][j] == PLNK_PED_MISSING_ALLELE2)
					|| (vvcData[i][j] == PLNK_PED_MISSING_ALLELE3)
					|| (vvcData[i][j] == PLNK_PED_MISSING_ALLELE4)
					|| (vvcData[i][j] == MISSING_ALLELE_CHR)))
				{
					vvcData[i][j] = MISSING_ALLELE_CHR;
				}
				else {
					if (c == MISSING_ALLELE_CHR){
						uA1++;
						c = vvcData[i][j];
					}
					else if (vvcData[i][j] == c){
						uA1++;
					}
					else{
						uA2++;
					}
				}

				if (bPed && ((vvcData[i1][j] == PLNK_PED_MISSING_ALLELE1)
					|| (vvcData[i1][j] == PLNK_PED_MISSING_ALLELE2)
					|| (vvcData[i1][j] == PLNK_PED_MISSING_ALLELE3)
					|| (vvcData[i1][j] == PLNK_PED_MISSING_ALLELE4)
					|| (vvcData[i1][j] == MISSING_ALLELE_CHR)))
				{
					vvcData[i1][j] = MISSING_ALLELE_CHR;
				}
				else {
					if (c == MISSING_ALLELE_CHR){
						uA1++;
						c = vvcData[i1][j];
					}
					else if (vvcData[i1][j] == c){
						uA1++;
					}
					else{
						uA2++;
					}
				}
			}

			if (uA1 < uA2) {
				cA1 = PLNK_PED_a;
				cA2 = PLNK_PED_A;
			}
			else {
				cA1 = PLNK_PED_A;
				cA2 = PLNK_PED_a;
			}
			for (j = 0; j < uSampleCnt; j++) {	//重新扫描该SNP，把等位基因替换成显、隐性形式
				if (vvcData[i][j] != MISSING_ALLELE_CHR) {
					vvcData[i][j] = vvcData[i][j] == c ? cA1 : cA2;
				}

				if (vvcData[i1][j] != MISSING_ALLELE_CHR) {
					vvcData[i1][j] = vvcData[i1][j] == c ? cA1 : cA2;
				}
			}

			if (repl) {
				for (j = 0; j < uSampleCnt; j++) {	// scan the SNP again to replace alleles with AA, Aa or aa
					if (vvcData[i][j] == MISSING_ALLELE_CHR && vvcData[i1][j] == MISSING_ALLELE_CHR) continue;

					if (vvcData[i][j] == PLNK_PED_A && vvcData[i1][j] == PLNK_PED_A) {
						vvcData[i][j] = clsParas->struGenotype.AA[0];
						vvcData[i1][j] = clsParas->struGenotype.AA[1];
					}
					else if (vvcData[i][j] == PLNK_PED_A && vvcData[i1][j] == PLNK_PED_a) {
						vvcData[i][j] = clsParas->struGenotype.Aa[0];
						vvcData[i1][j] = clsParas->struGenotype.Aa[1];
					}
					else if (vvcData[i][j] == PLNK_PED_a && vvcData[i1][j] == PLNK_PED_A) {
						vvcData[i][j] = clsParas->struGenotype.Aa[1];
						vvcData[i1][j] = clsParas->struGenotype.Aa[0];
					}
					else if (vvcData[i][j] == PLNK_PED_a && vvcData[i1][j] == PLNK_PED_a) {
						vvcData[i][j] = clsParas->struGenotype.aa[0];
						vvcData[i1][j] = clsParas->struGenotype.aa[1];
					}
					else if (vvcData[i][j] != MISSING_ALLELE_CHR) {
						vvcData[i][j] = vvcData[i][j] == PLNK_PED_A ? clsParas->struGenotype.Aa[0] : clsParas->struGenotype.Aa[1];
					}
					else if (vvcData[i1][j] != MISSING_ALLELE_CHR) {
						vvcData[i1][j] = vvcData[i1][j] == PLNK_PED_A ? clsParas->struGenotype.Aa[0] : clsParas->struGenotype.Aa[1];
					}
				}
			}
		}

		return true;
	}

	/****************************
	* Use the specified genotypes to normalize a allele matrix with each SNP including 1 row.
	* vvcData = genotype matrix with size of SNP count (rows) * double sample count (col.s), excludeing genotype col.
	* clsParas = pointer of class of the parameters
	* ret = returned info. ( true means no errors)
	* repl = whether replace the genotypes with a group of user-defined chars in global variable struGenotype
	* bPed = whether do normalizing for PED
	************************************/
	bool NormalizeAlleles1Row(vvChar &vvcData, parameters *clsParas, string &ret, bool repl, bool bPed)
	{
		char	c, cA1, cA2, cs[10];
		int		i, j, j1, uSampleCnt, uSNP, uA1, uA2;

		/************ vvsData format **************
		* a sample including two col.s
		* a SNP per row
		*******************************************/

		cout << "Normalizing ..." << endl;

		uSampleCnt = vvcData[0].size();	// sample size * 2
		uSNP = vvcData.size();			// SNP size

		// check even number of double sample size
		if (!EVEN_NUMBER(uSampleCnt)) {
			cout << "The SNPs of the first individual are not in pairs." << endl;
			ret = "The SNPs of the first individual are not in pairs.";
			return false;
		}

		// check the number of samples for each SNP
		for (i = 1; i < uSNP; i++){
			if (vvcData[i].size() != uSampleCnt){
				cout << "The number of individuals of SNP " << i << " does not match the first." << endl;
				sprintf(cs, "%d", i);
				ret = "The number of individuals of SNP ";
				ret += cs;
				ret += " does not match the first.";
				return false;
			}
		}

		//转换等位基因符号为显、隐性形式（次等位基因为隐性）
		for (i = 0; i < uSNP; i++) {	//逐行（即逐SNP）扫描
			uA1 = uA2 = 0;
			for (j = 0; j < uSampleCnt; j++) {		// scan the SNP to find the first non-missing allele
				if (bPed && ((vvcData[i][j] == PLNK_PED_MISSING_ALLELE1)
					|| (vvcData[i][j] == PLNK_PED_MISSING_ALLELE2)
					|| (vvcData[i][j] == PLNK_PED_MISSING_ALLELE3)
					|| (vvcData[i][j] == PLNK_PED_MISSING_ALLELE4)
					|| (vvcData[i][j] == MISSING_ALLELE_CHR)))
				{
					vvcData[i][j] = MISSING_ALLELE_CHR;
					continue;
				}

				break;
			}

			if (j == uSampleCnt) continue;

			uA1++;
			c = vvcData[i][j];
			j++;
			for (; j < uSampleCnt; j++) {		//继续扫描
				if (bPed && ((vvcData[i][j] == PLNK_PED_MISSING_ALLELE1)
					|| (vvcData[i][j] == PLNK_PED_MISSING_ALLELE2)
					|| (vvcData[i][j] == PLNK_PED_MISSING_ALLELE3)
					|| (vvcData[i][j] == PLNK_PED_MISSING_ALLELE4)
					|| (vvcData[i][j] == MISSING_ALLELE_CHR)))
				{
					vvcData[i][j] = MISSING_ALLELE_CHR;
					continue;
				}

				if (vvcData[i][j] == c){
					uA1++;
				}
				else{
					uA2++;
				}
			}

			if (uA1 < uA2) {
				cA1 = PLNK_PED_a;
				cA2 = PLNK_PED_A;
			}
			else {
				cA1 = PLNK_PED_A;
				cA2 = PLNK_PED_a;
			}

			for (j = 0; j < uSampleCnt; j++) {	//重新扫描该SNP，把等位基因替换成显、隐性形式
				if (vvcData[i][j] != MISSING_ALLELE_CHR) {
					vvcData[i][j] = vvcData[i][j] == c ? cA1 : cA2;
				}
			}

			if (repl) {
				for (j = 0; j < uSampleCnt; j += 2) {	// scan the SNP again to replace alleles with AA, Aa or aa
					j1 = j + 1;

					if (vvcData[i][j] == MISSING_ALLELE_CHR && vvcData[i][j1] == MISSING_ALLELE_CHR) continue;

					if (vvcData[i][j] == PLNK_PED_A && vvcData[i][j1] == PLNK_PED_A) {
						vvcData[i][j] = clsParas->struGenotype.AA[0];
						vvcData[i][j1] = clsParas->struGenotype.AA[1];
					}
					else if (vvcData[i][j] == PLNK_PED_A && vvcData[i][j1] == PLNK_PED_a) {
						vvcData[i][j] = clsParas->struGenotype.Aa[0];
						vvcData[i][j1] = clsParas->struGenotype.Aa[1];
					}
					else if (vvcData[i][j] == PLNK_PED_a && vvcData[i][j1] == PLNK_PED_A) {
						vvcData[i][j] = clsParas->struGenotype.Aa[1];
						vvcData[i][j1] = clsParas->struGenotype.Aa[0];
					}
					else if (vvcData[i][j] == PLNK_PED_a && vvcData[i][j1] == PLNK_PED_a) {
						vvcData[i][j] = clsParas->struGenotype.aa[0];
						vvcData[i][j1] = clsParas->struGenotype.aa[1];
					}
					else if (vvcData[i][j] != MISSING_ALLELE_CHR) {
						vvcData[i][j] = vvcData[i][j] == PLNK_PED_A ? clsParas->struGenotype.Aa[0] : clsParas->struGenotype.Aa[1];
					}
					else if (vvcData[i][j1] != MISSING_ALLELE_CHR) {
						vvcData[i][j1] = vvcData[i][j1] == PLNK_PED_A ? clsParas->struGenotype.Aa[0] : clsParas->struGenotype.Aa[1];
					}
				}
			}
		}

		return true;
	}

	/********************************************
	* 把字串向量拆分成字符矩阵，并得到每个SNP的主、次等基因字符矩阵
	* vsSNP = 输入SNP字串向量（每个字串为一个SNP）
	* vvcSNP = 输出SNP字符矩阵（每行一个SNP）
	* vvcAllele = 输出各SNP主、次等基因字符矩阵（每行对应一个SNP的主、次等基因，次等位基因在前，MISSING为N）
	* bNorOn = 是否需要统计主、次等位基因（已归一化数据不要，如从归一化的PED转的TPED）
	*********************************************/
	void analyzeSNP(vString &vsSNP, vvChar &vvcSNP, vvChar &vvcAllele, bool bNorOn)
	{
		vString	vsTmp;
		int		i, j, k;
		vChar	vcTmp, vcAllele(2);
		int		uA[2];
		char	c, cMissing;
		bool	bMissing;

		// 拆分vsSNP
		cout << "Spliting tped ..." << endl;

		vvcSNP.clear();
		vvcAllele.clear();
		for (i = 0; i < (int)vsSNP.size(); i++){
			stringSplit(vsSNP[i], vsTmp, " ");				//以空格为分隔符分拆vsPed
			j = vsTmp.size();

			vcTmp.resize(j);

			for (k = 0; k < j; k++) vcTmp[k] = vsTmp[k][0];	//只取首字符

			vvcSNP.push_back(vcTmp);
		}
		vString().swap(vsSNP);
		vString().swap(vsTmp);
		vChar().swap(vcTmp);

		// 获得各SNP等位基因组成（次等位基因在前）
		cout << "Analyzing ..." << endl;

		if (bNorOn){
			for (i = 0; i < (int)vvcSNP.size(); i++){
				vcAllele[0] = vcAllele[1] = '0';	// 若只有一种等位基因，那么另一个标示为‘0’或missing
				uA[0] = uA[1] = 0;
				bMissing = false;

				for (j = 0; j < (int)vvcSNP[0].size(); j += 2){	// 每两列一个SNP
					if (vvcSNP[i][j] != PLNK_PED_MISSING_ALLELE1
						&& vvcSNP[i][j] != PLNK_PED_MISSING_ALLELE2
						&& vvcSNP[i][j] != PLNK_PED_MISSING_ALLELE3
						&& vvcSNP[i][j] != PLNK_PED_MISSING_ALLELE4
						&& vvcSNP[i][j] != MISSING_ALLELE_CHR)
					{
						if (vcAllele[0] == '0') {
							vcAllele[0] = vvcSNP[i][j];
							uA[0]++;
						}
						else if (vcAllele[0] == vvcSNP[i][j]){
							uA[0]++;
						}
						else if (vcAllele[1] == '0') {
							vcAllele[1] = vvcSNP[i][j];
							uA[1]++;
						}
						else{
							uA[1]++;
						}
					}
					else {
						cMissing = vvcSNP[i][j] == MISSING_ALLELE_CHR ? PLNK_PED_MISSING_ALLELE2 : vvcSNP[i][j];
						vvcSNP[i][j] = PLNK_PED_MISSING_ALLELE2;	// 统一修改缺失值
						bMissing = true;
					}


					if (vvcSNP[i][j + 1] != PLNK_PED_MISSING_ALLELE1
						&& vvcSNP[i][j + 1] != PLNK_PED_MISSING_ALLELE2
						&& vvcSNP[i][j + 1] != PLNK_PED_MISSING_ALLELE3
						&& vvcSNP[i][j + 1] != PLNK_PED_MISSING_ALLELE4
						&& vvcSNP[i][j + 1] != MISSING_ALLELE_CHR)
					{
						if (vcAllele[0] == '0') {
							vcAllele[0] = vvcSNP[i][j + 1];
							uA[0]++;
						}
						else if (vcAllele[0] == vvcSNP[i][j + 1]){
							uA[0]++;
						}
						else if (vcAllele[1] == '0') {
							vcAllele[1] = vvcSNP[i][j + 1];
							uA[1]++;
						}
						else{
							uA[1]++;
						}
					}
					else {
						cMissing = vvcSNP[i][j + 1] == MISSING_ALLELE_CHR ? PLNK_PED_MISSING_ALLELE2 : vvcSNP[i][j + 1];
						vvcSNP[i][j + 1] = PLNK_PED_MISSING_ALLELE2;	// 统一修改缺失值
						bMissing = true;
					}

				}

				if ((uA[0] > uA[1]) || ((uA[0] == uA[1]) && (vcAllele[0] > vcAllele[1]))) {
					c = vcAllele[0];
					vcAllele[0] = vcAllele[1];
					vcAllele[1] = c;
				}

				if (vcAllele[1] == '0'){	// 若只有一种等基因，'0'放在前面
					vcAllele[1] = vcAllele[0];
					vcAllele[0] = '0';
				}

				if (bMissing && vcAllele[0] == '0'){ vcAllele[0] = cMissing; }

				vvcAllele.push_back(vcAllele);
			}
		}
		else{	// 已归一化数据，如从归一化的PED转的TPED。仅用于测试模式
			for (i = 0; i < (int)vvcSNP.size(); i++){
				vcAllele[0] = vcAllele[1] = '0';	// 若只有一种等位基因，那么另一个标示为‘0’或missing
				uA[0] = uA[1] = 0;
				bMissing = false;

				for (j = 0; j < (int)vvcSNP[0].size(); j += 2){	// 每两列一个SNP
					if (vvcSNP[i][j] != PLNK_PED_MISSING_ALLELE1
						&& vvcSNP[i][j] != PLNK_PED_MISSING_ALLELE2
						&& vvcSNP[i][j] != PLNK_PED_MISSING_ALLELE3
						&& vvcSNP[i][j] != PLNK_PED_MISSING_ALLELE4
						&& vvcSNP[i][j] != MISSING_ALLELE_CHR)
					{
						if (vcAllele[0] == '0' && vvcSNP[i][j]==PLNK_PED_a) {
							vcAllele[0] = vvcSNP[i][j];
						}
						else if (vcAllele[1] == '0' && vvcSNP[i][j] == PLNK_PED_A) {
							vcAllele[1] = vvcSNP[i][j];
						}
					}
					else {
						vvcSNP[i][j] = PLNK_PED_MISSING_ALLELE2;	// 统一修改缺失值
						bMissing = true;
					}


					if (vvcSNP[i][j + 1] != PLNK_PED_MISSING_ALLELE1
						&& vvcSNP[i][j + 1] != PLNK_PED_MISSING_ALLELE2
						&& vvcSNP[i][j + 1] != PLNK_PED_MISSING_ALLELE3
						&& vvcSNP[i][j + 1] != PLNK_PED_MISSING_ALLELE4
						&& vvcSNP[i][j + 1] != MISSING_ALLELE_CHR)
					{
						if (vcAllele[0] == '0' && vvcSNP[i][j + 1] == PLNK_PED_a) {
							vcAllele[0] = vvcSNP[i][j + 1];
						}
						else if (vcAllele[1] == '0' && vvcSNP[i][j + 1] == PLNK_PED_A) {
							vcAllele[1] = vvcSNP[i][j + 1];
						}
					}
					else {
						vvcSNP[i][j + 1] = PLNK_PED_MISSING_ALLELE2;	// 统一修改缺失值
						bMissing = true;
					}

				}

				if (bMissing){
					if (vcAllele[0] == '0') vcAllele[0] = PLNK_PED_MISSING_ALLELE2;
					else if (vcAllele[1] == '0') {
						vcAllele[1] = vcAllele[0];
						vcAllele[0] = PLNK_PED_MISSING_ALLELE2;
					}
				}
				else if (vcAllele[1] == '0') {
					vcAllele[1] = vcAllele[0];
					vcAllele[0] = '0';
				}

				vvcAllele.push_back(vcAllele);
			}
		}
	}

	/********************************************
	* 把vvsRS置换成标准的“rsxxxxxx”的形式
	* 对于某些MAP文件，存在类似“XXXXX__rsxxxxx”的RS ID
	* 此函数用于处理此类RS ID
	*********************************************/
	void normalizeRS_ID(vvString &vvsRS)
	{
		int	i, k;
		int		j;
		char	cs[STR_LENGTH];

		for (i = 0; i < (int)vvsRS.size(); i++) {
			j = vvsRS[i][PLNK_MAP_SNP_ID_COL].find("_rs");

			if (j == string::npos) continue;

			k = 2;
			j += 3;
			cs[0] = 'r';
			cs[1] = 's';

			while (vvsRS[i][PLNK_MAP_SNP_ID_COL][j] != '\0') {
				if (vvsRS[i][PLNK_MAP_SNP_ID_COL][j] >= '0' && vvsRS[i][PLNK_MAP_SNP_ID_COL][j] <= '9'){ cs[k++] = vvsRS[i][PLNK_MAP_SNP_ID_COL][j++]; }
				else break;
			}

			cs[k] = '\0';
			vvsRS[i][PLNK_MAP_SNP_ID_COL] = cs;
		}
	}

	/********************************************
	* 检查ped格式数据之样本有效性（对于任一样本，其所有等位基因缺失率不能高于上限）。
	* vsPed = 输入/输出基因数据
	* clsParas = 参数类指针
	*********************************************/
	bool chkSample4Ped(vString &vsPed, parameters *clsParas)
	{
		if (vsPed.size() == 0) return false;

		int						i, j, uPos, uLen, uMissing, uOffset;
		vector<string>::iterator	itr;
		//fstream						fp;
		string						sTmp;

		cout << "There are " << vsPed.size() << " sample(s) before alleles missing rates of samples checking." << endl;
		clsParas->fpLog << "There are " << vsPed.size() << " sample(s) before alleles missing rates of samples checking." << endl;
		clsParas->fpLog << "\tThreshold of alleles missing rates of samples checking: " << clsParas->dMafSnpCutoff << endl;

		uPos = AlignPedPos(vsPed, PLNK_PED_GENOTYPE_COL);	//把各行对齐到PLNK_PED_GENOTYPE_COL
		uOffset = 0;
		itr = vsPed.begin();

		for (i = 0; i < (int)vsPed.size(); i++) {
			uLen = vsPed[i].length();
			uMissing = 0;

			for (j = uPos; j < uLen; j += 2) {
				if ((vsPed[i][j] == PLNK_PED_MISSING_ALLELE1)
					|| (vsPed[i][j] == PLNK_PED_MISSING_ALLELE2)
					|| (vsPed[i][j] == PLNK_PED_MISSING_ALLELE3)
					|| (vsPed[i][j] == PLNK_PED_MISSING_ALLELE4)
					|| (vsPed[i][j] == MISSING_ALLELE_CHR))
				{
					uMissing++;
				}
			}

			uLen = uLen - uPos - 1;
			if ((float)uMissing / uLen > clsParas->dMafSnpCutoff) {	//缺失率高于上限
				vsPed.erase(itr + uOffset);
				if (uOffset == 0) itr = vsPed.begin();			//删除了首行，需重新指向首行

				cout << "\tSample " << i + 1 << " failed in alleles missing rate checking." << endl;

				i--;
			}
			else uOffset++;
		}

		j = vsPed.size();

		if (j == 0){
			cout << "It has not any sample after alleles missing rate checking." << endl;
			clsParas->fpLog << "It has not any sample after alleles missing rate checking." << endl;
			return false;
		}

		//把“对齐”操作中加入的多余空格删除
		for (i = 0; i < j; i++){ trimRedundance(vsPed[i]); }

		cout << "There are " << j << " sample(s) after alleles missing rates of samples checking." << endl;
		clsParas->fpLog << "There are " << j << " sample(s) after alleles missing rates of samples checking." << endl;

		return true;
	}

	/********************************************
	* 检查ped格式数据之样本有效性（对于任一样本，其所有等位基因缺失率不能高于上限,重载+1）。
	* vsPed = 输入/输出基因数据
	* clsParas = 参数类指针
	*********************************************/
	bool chkSample4Ped(vvChar &vvcPed, vString& vsPed6, parameters *clsParas, string &ret)
	{
		if (vvcPed.size() == 0) {
			ret = "The number of samples is 0.";
			return false;
		}

		int					i, j, uLen, uMissing, uOffset;
		vvChar::iterator	itr;
		vString::iterator	itr6;
		string				sTmp;

		cout << "There are " << vvcPed.size() << " sample(s) before alleles missing rates of samples checking." << endl;
		clsParas->fpLog << "There are " << vvcPed.size() << " sample(s) before alleles missing rates of samples checking." << endl;
		clsParas->fpLog << "\tThreshold of alleles missing rates of samples checking: " << clsParas->dMafSnpCutoff << endl;

		uOffset = 0;
		itr = vvcPed.begin();
		itr6 = vsPed6.begin();
		for (i = 0; i < (int)vvcPed.size(); i++) {
			uLen = vvcPed[i].size();
			uMissing = 0;
			for (j = 0; j < uLen; j++) {
				if ((vvcPed[i][j] == PLNK_PED_MISSING_ALLELE1)
					|| (vvcPed[i][j] == PLNK_PED_MISSING_ALLELE2)
					|| (vvcPed[i][j] == PLNK_PED_MISSING_ALLELE3)
					|| (vvcPed[i][j] == PLNK_PED_MISSING_ALLELE4)
					|| (vvcPed[i][j] == MISSING_ALLELE_CHR)) 
				{
					uMissing++;
				}
			}
			if ((float)uMissing / uLen > clsParas->dMafSnpCutoff) {	//缺失率高于上限
				vvcPed.erase(itr + uOffset);
				vsPed6.erase(itr6 + uOffset);

				if (uOffset == 0) {								//删除了首行，需重新指向首行
					itr = vvcPed.begin();
					itr6 = vsPed6.begin();
				}

				cout << "\tSample " << i + 1 << " failed in alleles missing rate checking." << endl;

				i--;
			}
			else{
				uOffset++;
			}
		}

		i = vsPed6.size();

		if (i == 0){
			ret = "It has not any sample after alleles missing rate checking.";
			return false;
		}

		cout << "There are " << i << " sample(s) after alleles missing rates of samples checking." << endl;

		clsParas->fpLog << "There are " << i << " sample(s) after alleles missing rates of samples checking." << endl;

		return true;
	}

	/********************************************
	* HWE和MAF检验
	* snp = 一个SNP数据（两个字符表示一个基因型，#、-，N或0 = missing。每个字符之间用空格或TAB分隔）
	* clsParas = 参数类指针
	* clsParas->bHWEexact = （隐含参数）HWE检验方法：false - 标准方法；true - 精确方法
	* 返回：TEST_PASS = 无错；HWE_ERR = HWE检验错；MAF_ERR = MAF检验错；MISSING_ERR = SNP缺失等位基因数占比超限；NULL_ERR = 原始数据空
	*********************************************/
	int testHWE_MAF(string &snp, parameters *clsParas)
	{
		trimString(snp);
		trimRedundance(snp, true);		// 删除多于2个的连续空格和TAB，只保留一个，并把TAB用空格替换

		if (snp.length() == 0) return NULL_ERR;

		//SNP格式：两个字符表示一个基因型，#、-，N或0 = missing。每个字符之间用空格或TAB分隔
		int	uObsHeterozygosis, uObsHomozygosisAA, uObsHomozygosisaa;		//分别表示杂合和两个纯合基因型之个数（观察频数）
		int	i, uA1, uA2;
		int		iFirst;
		double	dPval, dMAF;
		char	cAllele1, cAllele2;

		//找出首个非缺失值的位置并计算缺失基因个数
		iFirst = -1;
		uA1 = 0;
		for (i = 0; i < (int)snp.length(); i += 2) {
			if (snp[i] != PLNK_PED_MISSING_ALLELE1
				&& snp[i] != PLNK_PED_MISSING_ALLELE2
				&& snp[i] != PLNK_PED_MISSING_ALLELE3
				&& snp[i] != PLNK_PED_MISSING_ALLELE4
				&& snp[i] != MISSING_ALLELE_CHR
				&& snp[i] != DELIMITER3
				&& snp[i] != DELIMITER2
				&& iFirst < 0) 
			{
				iFirst = i;
				break;
			}
			//统计缺失数
			if ((snp[i] == PLNK_PED_MISSING_ALLELE1)
				|| (snp[i] == PLNK_PED_MISSING_ALLELE2)
				|| (snp[i] == PLNK_PED_MISSING_ALLELE3)
				|| (snp[i] == MISSING_ALLELE_CHR)) 
			{
				uA1++;
			}
		}

		if (iFirst < 0) return MISSING_ERR;			//无非缺失值

		uA2 = (snp.length() + 1) / 2;			//总等位基因个数

		if ((double)uA1 / uA2 > clsParas->dMafSnpCutoff) return MISSING_ERR;		//缺失超过上限

		uObsHeterozygosis = uObsHomozygosisAA = uObsHomozygosisaa = 0;
		cAllele1 = snp[iFirst];
		uA1 = 1;
		uA2 = 0;
		iFirst += 2;
		cAllele2 = PLNK_PED_MISSING_ALLELE2;

		for (i = iFirst; i < (int)snp.length(); i += 2) {
			if (snp[i] != PLNK_PED_MISSING_ALLELE1
				&& snp[i] != PLNK_PED_MISSING_ALLELE2
				&& snp[i] != PLNK_PED_MISSING_ALLELE3
				&& snp[i] != PLNK_PED_MISSING_ALLELE4
				&& snp[i] != MISSING_ALLELE_CHR
				&& snp[i] != DELIMITER3
				&& snp[i] != DELIMITER2) 
			{
				if (snp[i] != cAllele1 && cAllele2 == PLNK_PED_MISSING_ALLELE2){ cAllele2 = snp[i]; }

				if (snp[i] == cAllele1){ uA1++; }
				else if (snp[i] == cAllele2){ uA2++; }
			}
		}

		if (uA2 == 0) return MAF_ERR;					//只有一种基因型

		//计算MAF
		if (uA1 > uA2){ dMAF = (double)uA2 / (uA1 + uA2); }
		else{ dMAF = (double)uA1 / (uA1 + uA2); }

		if (dMAF < clsParas->dMafSnpCutoff) return MAF_ERR;		//MAF小于最低限


		//统计观察频数
		for (i = 0; i < (int)snp.size(); i += 4) {
			if (snp[i] == cAllele1 && snp[i + 2] == cAllele1){ uObsHomozygosisAA++; }
			else if ((snp[i] == cAllele1 && snp[i + 2] == cAllele2) || (snp[i] == cAllele2 && snp[i + 2] == cAllele1)){ uObsHeterozygosis++; }
			else if (snp[i] == cAllele2 && snp[i + 2] == cAllele2){ uObsHomozygosisaa++; }
		}

		if (clsParas->bHWEexact) {		//“精确”法计算P值
			dPval = SNPHWE(uObsHeterozygosis, uObsHomozygosisAA, uObsHomozygosisaa);

			if (dPval > clsParas->dHweCutoff){ return TEST_PASS; }
			else{ return HWE_ERR; }
		}

		//“标准”法计算P值
		double	dObsFreqA, dObsFreqa;				//等位基因频率观察值
		double	dExpFreqAA, dExpFreqAa, dExpFreqaa;	//基因型频率期望值
		double	dExpHeterozygosis, dExpHomozygosisAA, dExpHomozygosisaa;		//分别表示杂合和两个纯合基因型之期望频数
		int	uObsGenotypes;						//基因型总数（观察值）
		double	chi;

		uObsGenotypes = uObsHeterozygosis + uObsHomozygosisAA + uObsHomozygosisaa;
		dObsFreqA = (double)(uObsHomozygosisAA * 2 + uObsHeterozygosis) / (uObsGenotypes * 2);	//等位基因A观察频率
		dObsFreqa = (double)(uObsHomozygosisaa * 2 + uObsHeterozygosis) / (uObsGenotypes * 2);	//等位基因a观察频率

		dExpFreqAA = dObsFreqA * dObsFreqA;		//基因型AA频率期望值
		dExpFreqaa = dObsFreqa * dObsFreqa;		//基因型aa频率期望值
		dExpFreqAa = 2 * dObsFreqA * dObsFreqa;	//基因型Aa频率期望值

		dExpHeterozygosis = dExpFreqAa * uObsGenotypes;		//基因型Aa之期望频数
		dExpHomozygosisAA = dExpFreqAA * uObsGenotypes;		//基因型AA之期望频数
		dExpHomozygosisaa = dExpFreqaa * uObsGenotypes;		//基因型aa之期望频数

		chi = (uObsHomozygosisAA - dExpHomozygosisAA) * (uObsHomozygosisAA - dExpHomozygosisAA) / dExpHomozygosisAA
			+ (uObsHomozygosisaa - dExpHomozygosisaa) * (uObsHomozygosisaa - dExpHomozygosisaa) / dExpHomozygosisaa
			+ (uObsHeterozygosis - dExpHeterozygosis) * (uObsHeterozygosis - dExpHeterozygosis) / dExpHeterozygosis;

		dPval = chiprobP(chi, 2);

		if (dPval > clsParas->dHweCutoff){ return TEST_PASS; }
		else{ return HWE_ERR; }
	}

	/********************************************
	* 从vvc中以cDelim为分隔符删除从uStart（含）到uEnd（含）
	* 之间的若干列（列号从0开始）（重载+1）
	* vvc = in & out (matrix)
	* cDelim = delimeter
	* uStart, uEnd = beginning and ending col. No.s (inclusive)
	* 返回：删除是否成功
	*********************************************/
	bool deleteCols(vvChar &vvc, char cDelim, int iStart, int iEnd)
	{
		if (iEnd < iStart) {
			cout << "Ending column No. can not be greater than the beginnings." << endl;
			return false;
		}

		if (vvc.empty()) {
			cout << "Not any data to delete." << endl;
			return false;
		}

		int				i, j;
		vChar::iterator it;

		// check data
		for (i = 0; i < (int)vvc.size(); i++) {
			j = vvc[i].size();

			if (iStart >= j) {
				cout << "The number of columns at row " << i << " is less than " << iStart + 1 << endl;
				return false;
			}

			if (iEnd >= j) {
				cout << "The number of columns at row " << i << " is less than " << iEnd + 1 << endl;
				return false;
			}
		}

		for (i = 0; i < (int)vvc.size(); i++) {
			it = vvc[i].begin();

			j = iEnd;
			while (true)
			{
				vvc[i].erase(it + j);

				if (--j < iStart) break;
			}
		}

		return true;
	}

	/********************************************
	* 从vStr中以cDelim为分隔符删除从uStart（含）到uEnd（含）
	* 之间的若干列（列号从0开始）（重载+2）
	* vStr = in & out (vector)
	* cDelim = delimeter
	* uStart, uEnd = beginning and ending col. No.s (inclusive)
	* 返回：删除是否成功
	*********************************************/
	bool deleteCols(vString &vStr, char cDelim, int uStart, int uEnd)
	{
		if (uEnd < uStart) {
			cout << "Ending column No. can not be greater than the beginnings." << endl;
			return false;
		}

		if (vStr.empty()) {
			cout << "Not any data to delete." << endl;
			return false;
		}

		int	i, uS, uE, uCnt, uLen;

		for (i = 0; i < (int)vStr.size(); i++) {
			uLen = vStr[i].length();
			uCnt = 0;
			//找出起始字符
			uS = 0;
			while (1) {
				if (uCnt == uStart) break;

				if (uS >= uLen) {
					cout << "The number of columns at row " << i << " is less than " << uStart + 1 << endl;
					return false;
				}
				else if (vStr[i][uS] == cDelim){
					uCnt++;
				}

				uS++;
			}
			//找出结束字符
			uE = uS + 1;
			while (1) {
				if (uCnt == uEnd + 1) break;

				if (uE > uLen + 1) {
					cout << "The number of columns at row " << i << " is less than " << uEnd + 1 << endl;
					return false;
				}
				else if (vStr[i][uE] == cDelim || vStr[i][uE] == '\n' || vStr[i][uE] == '\0'){
					uCnt++;
				}

				uE++;
			}

			uE--;
			if (uE > uLen || (uE == uLen && vStr[i][uE - 1] == cDelim)) {
				cout << "The number of columns at row " << i << " is not enough." << endl;
				return false;
			}

			if (uS == 0) uS = 1;

			vStr[i] = vStr[i].substr(0, uS - 1) + vStr[i].substr(uE);
		}

		return true;
	}

	/********************************************
	* 在str中以cDelim为分隔符取出第iCol列的字符（列号从0开始）
	* 若列号超范围，则返回'\0'
	* 注：只取一个字符，若被提取列有多个字符，只取首字符
	* 如：
	* str = "A B C wD E", cSep = ' ', iCol = 3
	* 结果为：'w'，即D不被提取
	*********************************************/
	char getAllele(string &str, char cDelim, int iCol)
	{
		if (iCol < 0) return '\0';

		int	i;
		int		iCnt;

		iCnt = 0;
		for (i = 0; i < (int)str.length(); i++) {
			if (iCnt == iCol) return str[i];

			if (str[i] == cDelim) iCnt++;
		}

		return '\0';
	}


	/********************************************
	* 读取BEAM格式的文本文件
	* vvsBEAM3 = （输出）文件中的前3列内容（字串矩阵）
	* vvcData = （输出）文件中的第4列及以后的数据（字符矩阵）
	* clsParas = 参数类指针
	****************************************************
	BEAM格式：
	ID	Chr  Pos		1 1 0 1 0 1 0 1 …
	rs0	chr1 738547		2 2 1 2 0 0 0 0 …
	rs1	chr1 5597094	0 1 0 0 2 2 0 0 …
	rs2	chrX 9424115	0 2 2 0 0 0 0 0 …
	rs3	chrY 13879818	0 0 0 0 0 2 2 0 …
	第1行第4列以后：case/control，0-control；1-case
	第2行及以后行的第4列以后：每行一个SNP：0-Aa 1-aa 2-AA <0-missing
	前3列：说明性内容
	*****************************************************/
	void readBEAM(vvString& vvsBEAM3, vvChar& vvcData, coPLINK::parameters *clsParas)
	{
		string	sLine;
		vChar	vcTmp;
		vString vsTmp, vsSplit;
		int		i, uErr, j;
		int		k;
		fstream	fp;
		bool	bFirstLine;
		char	c;

		//sLine = getFn(clsParas->sInputFilename, ".txt", true);
		sLine = clsParas->sInputFilename;

#ifdef TEST_PERFORMANCE
		clsParas->uInSize = getFileSize(sLine, &bFirstLine);
#endif

		openStreamFile(fp, sLine.c_str(), ios::in);

		cout << "Reading the file " << sLine << ". Please wait ..." << endl;
		cout << "\t0 is control, otherwise case; Out of 0~2 is missing." << endl;
		clsParas->fpLog << "\t0 is control, otherwise case; Out of 0~2 is missing." << endl;

		bFirstLine = true;
		uErr = 0;
		j = 0;
		while (!fp.eof() && fp.good()) {
			sLine = "";
			getline(fp, sLine);							//取一行
			trimString(sLine);							//删除前后空格及TAB
			trimRedundance(sLine, true);				//删除中间多余空格及TAB（只保留一个）,所有TAB用空格替换掉（为分拆作准备）

			if (sLine.length() == 0) continue;

			//sLine = replaceChar(sLine, DELIMITER2, DELIMITER3);	//把所有TAB用空格替换掉（为分拆作准备）
			stringSplit(sLine, vsSplit, " ");					//以空格为分隔符分拆sLine

			if (vsSplit.size() < 4) continue;					//不足4列, one SNP needs

			for (i = 3; i < (int)vsSplit.size(); i++) {				//从第4列起为基因数据
				k = atoi(vsSplit[i].c_str());

				if (k < 0 || k > 2){ c = MISSING_ALLELE_CHR; }		//missing
				else{ c = vsSplit[i][0]; }							// first char

				vcTmp.push_back(c);
			}

			if (clsParas->bPreprocess && !bFirstLine) {
				sLine = "";
				for (i = 0; i < (int)vcTmp.size(); i++){
					if (vcTmp[i] == BEAM_ALLELE_AA){ sLine += " D D"; }
					else if (vcTmp[i] == BEAM_ALLELE_Aa_aA){ sLine += " d D"; }
					else if (vcTmp[i] == BEAM_ALLELE_aa){ sLine += " d d"; }
					else{ sLine += " N N"; }
				}

				k = testHWE_MAF(sLine, clsParas);

				if (k != TEST_PASS) {	//HWE、MAF等检验失败
					vcTmp.clear();

					switch (k)
					{
					case HWE_ERR:
					{
						clsParas->fpLog << "The " << j << "-th SNP HWE tests error." << endl;
						break;
					}
					case MAF_ERR:
					{
						clsParas->fpLog << "The " << j << "-th SNP MAF tests error." << endl;
						break;
					}
					case MISSING_ERR:
					{
						clsParas->fpLog << "The missing allele rate of " << j << "-th SNP tests error." << endl;
						break;
					}
					case NULL_ERR:
					{
						clsParas->fpLog << "The " << j << "-th SNP has not any alleles." << endl;
						break;
					}
					default:
						break;
					}
					
					uErr++;
					cout << '\t' << ++j << "...\r";
					continue;
				}
			}

			vvcData.push_back(vcTmp);
			vcTmp.clear();
			vsTmp.reserve(3);

			for (i = 0; i < 3; i++){ vsTmp.push_back(vsSplit[i]); }	//前3列

			vvsBEAM3.push_back(vsTmp);
			vsTmp.clear();

			vsSplit.clear();
			bFirstLine = false;
			cout << '\t' << ++j << "...\r";
		}
		sLine = "";
		fp.close();
		fp.clear();
		cout << endl;

		if (clsParas->bPreprocess) {
			cout << "Total " << uErr << " error(s) found after test (see Log file for details)." << endl;
			clsParas->fpLog << "Total " << uErr << " error(s) found after test." << endl;
		}

		k = vvsBEAM3[0].size();
		for (i = 1; i < (int)vvsBEAM3.size(); i++) {	//所有行的列数需一致
			if (vvsBEAM3[i].size() != k) {
				char cs[100];
				sprintf(cs, "The structure of the top 3 columns has error in row %d.", i);
				fetalError(cs, clsParas);
			}
		}

		k = vvcData[0].size();
		for (i = 1; i < (int)vvcData.size(); i++) {	//所有行的列数需一致
			if (vvcData[i].size() != k) {
				char cs[100];
				sprintf(cs, "The structure of the columns begining 4 has error in row %d.", i);
				fetalError(cs, clsParas);
			}
		}

		//统计case个数
		k = 0;
		for (i = 0; i < (int)vvcData[0].size(); i++){
			if (vvcData[0][i] == BEAM_CASE_PHENOTYPE) k++;
		}

		if (vvcData.empty()) {
			fetalError("Source file " + clsParas->sInputFilename + "has no any valid data.", clsParas);
		}

		clsParas->fpStat << ',' << clsParas->sInputFilename << ',' << k << ',' << vvcData[0].size() - k << ',' << vvcData.size() - 1 << endl;

		cout << endl << "The BEAM file " << clsParas->sInputFilename << " read successfully." << endl;
		cout << "Summary: " << k << " cases; " << vvcData[0].size() - k << " controls and " << vvcData.size() - 1 << " SNPs." << endl;

		clsParas->fpLog << "The BEAM file " << clsParas->sInputFilename << " read successfully." << endl;
	}

	/********************************************
	* 读取GEO格式的文本文件
	* vvcGeo = （输出）文件字串矩阵
	* clsParas = 参数类指针
	****************************************************
	geo文件：
	1,1,0,1,0,1,0,1,…
	2,2,1,2,0,0,0,0,…
	0,1,0,0,2,2,0,0,…
	0,2,2,0,0,0,0,0,…
	0,0,0,0,0,2,2,0,…
	第1行：case/control，0-control；1-case（非0也改为1）
	第2行及以后行：每行一个SNP：0-Aa 1-aa 2-AA <0及超出0~2范围-missing
	本质上是BEAM格式去除前三列并用逗号分隔。
	*****************************************************/
	void readGeo(vvChar& vvcGeo, coPLINK::parameters *clsParas)
	{
		string	sLine;
		vChar	vcTmp;
		vString vsTmp, vsSplit;
		int		i, k, m;
		fstream	fp;
		bool	bRow1;

		sLine = getFn(clsParas->sInputFilename, ".geo");

#ifdef TEST_PERFORMANCE
		bool	b;
		clsParas->uInSize = getFileSize(sLine, &b);
#endif

		openStreamFile(fp, sLine.c_str(), ios::in);

		cout << "Reading the file " << sLine << ". Please wait ..." << endl;
		cout << "\t0 is control, otherwise case; Out of 0~2 is missing." << endl;
		clsParas->fpLog << "\t0 is control, otherwise case; Out of 0~2 is missing." << endl;

		m = 0;
		bRow1 = true;

		while (getline(fp, sLine)) {
			if (sLine.length() == 0) continue;

			stringSplit(sLine.c_str(), vsSplit, ',');					//以,为分隔符分拆sLine
			k = vsSplit.size();
			vcTmp.resize(k);

			if (bRow1){
				for (i = 0; i < k; i++) {
					vcTmp[i] = vsSplit[i][0] == '0' ? '0' : '1';	// first char. only
				}
				bRow1 = false;
			}
			else {
				for (i = 0; i < k; i++) {
					vcTmp[i] = (vsSplit[i][0] >= '0' &&  vsSplit[i][0] <= '2') ? vsSplit[i][0] : MISSING_ALLELE_CHR;	// first char. only
				}
			}

			vvcGeo.push_back(vcTmp);
			vsSplit.clear();
			cout << '\t' << ++m << "...\r";
		}
		sLine = "";
		fp.close();
		fp.clear();
		cout << endl;

		k = vvcGeo[0].size();
		for (i = 1; i < (int)vvcGeo.size(); i++) {	//所有行的列数需一致
			if (vvcGeo[i].size() != k) {
				char	cs[100];
				sprintf(cs, "The length of row %d does not match the first row.", i);
				fetalError(cs, clsParas);
			}
		}

		if (vvcGeo.empty()) {
			fetalError("Source file " + clsParas->sInputFilename + "(.geo) has no any valid data.", clsParas);
		}

		//统计case个数
		k = 0;
		for (i = 0; i < (int)vvcGeo[0].size(); i++) {
			if (vvcGeo[0][i] == BEAM_CASE_PHENOTYPE) k++;
		}


		clsParas->fpStat << ',' << clsParas->sInputFilename << ',' << k << ',' << vvcGeo[0].size() - k << ',' << vvcGeo.size() - 1 << endl;

		cout << endl << "The GEO file " << clsParas->sInputFilename << " read successfully." << endl;
		cout << "Summary: " << k << " cases; " << vvcGeo[0].size() - k << " controls and " << vvcGeo.size() - 1 << " SNPs." << endl;

		clsParas->fpLog << "The GEO file " << clsParas->sInputFilename << " read successfully." << endl;
	}


	/********************************************
	* 读取PLINK二进制格式文件(包括三个文件：bed、bim、fam文件)
	* sData = 输出的Plink格式的数据(ped文件内容)
	* clsParas = 参数类指针
	* 各文件格式见函数实现
	*********************************************/
	void readBed(InData *sData, coPLINK::parameters *clsParas)
	{
		char			c, c1;
		char			sp[SHORT_LEN];
		string			s;
		int				i;		// i要表示查找的字符位置，不能uint
		uint			j, k, m;
		uint			uBytes;
		vector<uint>	vu;
		ifstream		fIn;


		//二进制的bed文件格式（Plink v0.99以后，之前版本无前两个字节）：
		/*若ped文件内容是：
		1 1 0 0 1  1  A A  G T
		2 1 0 0 1  1  A C  T G
		3 1 0 0 1  1  C C  G G
		4 1 0 0 1  2  A C  T T
		5 1 0 0 1  2  C C  G T
		6 1 0 0 1  2  C C  T T
		其中前6列：
		Family ID
		Individual ID
		Paternal ID, Maternal ID
		Sex (1=male; 2=female; other=unknown)
		Phenotype (1=unaffect; 2=affect)

		map文件的内容是：
		1 snp1 0 1
		1 snp2 0 2

		则对应的bed文件是（前3个字节是固定的）：
		十六进制：	6C			1B			01			B8			0F			CA			0E
		二进制：	01101100	00011011	00000001	10111000	00001111	11001010	00001110

		从第四个字节开始是基因数据。基因数据编码方式：
		1. 每一个SNP中minor allele用0表示，major allele则用1表示。则有此等价
		表示：
		00 - aa		01 - Aa aA		11 - AA		10 - Missing
		2. 每个SNP用整数个字节不足补0。
		如上例之第二个SNP：G是minor allele、T是major allele，则表示为：01010011 01110000
		注意第二组“TG”也应表示为“01”，第二字节尾部补4个0以形成一个整
		字节
		3. 最后把每个字节逆序存放。
		*/

		//fam文件格式。
		/*
		bed文件仅记录了基因数据（即ped文件的从第7列开始的内容），fam文件则记录的是前6列
		*/

		//bim文件格式。
		/*
		bim文件是ped格式中的map文件的扩展，与上述map文件对应的bim文件：
		1	snp1	0	1	A	C
		1	snp2	0	2	G	T
		各列：
		0 - chromosome (1-22, X, Y or 0 if unplaced)
		1 - rs# or snp identifier
		2 - Genetic distance (morgans)
		3 - Base-pair position (bp units)
		4 - allele 1（minor allele）
		5 - allele 2（major allele）
		注：（1）若两个等位基因个数相同，则按字母序分别是minor allele和major allele
		（2）若只有一种等位基因，则用0标示缺失并作为minor allele
		（3）不判断缺失等位基因符号（如 0、-、N等），所有符号都作为正常符号处理
		*/

		//读取fam文件，取表型数据。
		cout << "Reading .fam ..." << endl;
		cout << "\t1 is control, otherwise case." << endl;
		clsParas->fpLog << "\t1 is control, otherwise case." << endl;

		s = getFn(clsParas->sInputFilename, ".fam", true);
		while (1) {
			fIn.open(s.c_str());

			if (fIn.is_open()) break;          //文件打开成功,说明曾经写入过东西

			cout << "\nError, file " << s << " opened fail.\n Press r to retry, others abort." << endl;
			i = system("stty raw");
			c = getchar();
			i = system("stty -raw");

			if (c == 'r' || c == 'R') continue;

			clsParas->fpLog.close();
			clsParas->fpStat.close();
			exit(1);
		}

		while (getline(fIn, s)) {
			trimString(s);			//去除前后空格及TAB
			i = s.length();

			if (i == 0 || s == "\n") continue;

			c = s[i - 1] == PLNK_PED_CTRL_PHENOTYPE ? PLNK_PED_CTRL_PHENOTYPE : PLNK_PED_CASE_PHENOTYPE;
			sData->vcPhenotypes.push_back(c);
		}
		fIn.close();

		//读取bim文件，取SNP ID及对应的染色体号。
		s = getFn(clsParas->sInputFilename, ".bim", true);
		fIn.clear();		//释放原有指针
		while (1) {
			fIn.open(s.c_str());

			if (fIn.is_open()) break;          //文件打开成功,说明曾经写入过东西

			cout << "\nError, file " << s << " opened fail.\n Press r to retry, others abort." << endl;
			i = system("stty raw");
			c = getchar();
			i = system("stty -raw");

			if (c == 'r' || c == 'R') continue;

			clsParas->fpLog.close();
			clsParas->fpStat.close();
			exit(1);
		}

		while (!fIn.eof() && fIn.good()) {
			fIn >> s;
			if (!fIn.eof() && fIn.good()) {
				//取染色体号（1~25，CHR_X_CODE = X，CHR_Y_CODE = Y）
				getNumbers(s.c_str(), sp);
				i = atoi(sp);

				if (i == 0) {
					string2Upper(s);		//转大写
					i = s.find('X', 0);

					if (i == string::npos) {
						i = s.find('Y', 0);
						if (i == string::npos){
							i = CHR_NONE_CODE;
						}
						else{
							i = CHR_Y_CODE;
						}
					}
					else i = CHR_X_CODE;
				}
				else if (i > 23){
					i = CHR_NONE_CODE;
				}

				sData->vuChrNo.push_back(i);

				s = "";
				fIn >> s;	//取第2列
			}
			else continue;

			if (s.length() > 0){ sData->vsSNPlabels.push_back(s); }	//取SNP ID

			fIn >> s;		//第3列
			s = "";

			if (!fIn.eof() && fIn.good()){ fIn >> s; }		//第4列
			else{ continue; }

			if (s.length() > 0){ sData->vuPos.push_back(atoi(s.c_str())); }		//取位置

			getline(fIn, s);							//读取本行剩余部分，并丢弃
		}
		fIn.close();

		//读取bed文件。
		//计算每个SNP包含的字节数
		i = sData->vcPhenotypes.size();				//样本数
		uBytes = (uint)ceil((double)i / sizeof(uint));	//每个字节可存放4对Allele（每对Allele对应一个样本）

		s = getFn(clsParas->sInputFilename, ".bed", true);

#ifdef TEST_PERFORMANCE
		bool	b;
		clsParas->uInSize = getFileSize(s, &b);
#endif

		fIn.clear();		//释放原有指针
		while (1) {
			fIn.open(s.c_str(), ios_base::binary);

			if (fIn.is_open()) break;          //文件打开成功,说明曾经写入过东西

			cout << "\nError, file " << s << " opened fail.\n Press r to retry, others abort." << endl;
			i = system("stty raw");
			c = getchar();
			i = system("stty -raw");

			if (c == 'r' || c == 'R') continue;

			clsParas->fpLog.close();
			clsParas->fpStat.close();
			exit(1);
		}

		k = 0;
		fIn.read(&c, sizeof(char));
		fIn.read(&c1, sizeof(char));
		if (c != 0x6c && c1 != 0x1b){		// bed文件前两个字节固定
			fIn.close();
			fetalError("The input file " + s + " is not Binary.", clsParas);
		}

		fIn.read(&c, sizeof(char));

		if (c != 0x1){						// 只支持SNP-majar格式
			fIn.close();
			fetalError("The input file " + s + " is not SNP-majar.", clsParas);
		}

		// 每个uint中是对原二进制内容按字节逆序存放，以便后续处理
		while (!fIn.eof() && fIn.good()) {
			j = 0;
			for (i = 0; i < sizeof(uint); i++) {
				fIn.read(&c, sizeof(char));

				if (fIn.eof() || !fIn.good()) break;

				m = ((uint)c) << (8 * i);		//左移若干字节
				//当c表示的是负数时，m前面可能有很多0xf，以下两行是去除这些无意义的0xf
				m = m << (8 * (sizeof(uint) - i - 1));
				m = m >> (8 * (sizeof(uint) - i - 1));
				j |= m;												//拼入j
				k++;

				if (k >= uBytes) break;
			}
			if (k > 0){ vu.push_back(j); }

			if (k >= uBytes) {
				sData->vvuSNP.push_back(vu);
				k = 0;
				vu.clear();
			}
		}
		fIn.close();
		fIn.clear();

		//数据有效性检查
		if (sData->vvuSNP.size() != sData->vsSNPlabels.size()) {
			fetalError("The number of SNP in file bed doesn't match to bim in label column.", clsParas);
		}

		if (sData->vvuSNP.size() != sData->vuPos.size()) {
			fetalError("The number of SNP in file bed doesn't match to bim in position column.", clsParas);
		}

		j = sData->vcPhenotypes.size();	//样本数
		for (i = 0; i < (int)sData->vvuSNP.size(); i++)
		{
			if (sData->vvuSNP[i].size() * sizeof(uint) * 4 < j)	//每个uint有sizeof(uint)字节，每字节存4个基因型
			{
				char	cs[100];
				sprintf(cs, "The length of SNP data are different. SNP %d-th <= %d.", i, sData->vvuSNP.size() * sizeof(uint) * 4);
				fetalError(cs, clsParas);
			}
		}

		// 统计case
		m = 0;
		for (i = 0; i < (int)j; i++){
			if (sData->vcPhenotypes[i] == PLNK_PED_CASE_PHENOTYPE) m++;
		}

		if (sData->vvuSNP.empty()) {
			fetalError("Source file " + clsParas->sInputFilename + "has no any valid data.", clsParas);
		}

		clsParas->fpStat << ',' << clsParas->sInputFilename << ',' << m << ',' << j - m << ',' << sData->vsSNPlabels.size() << endl;

		cout << "Read OK. Includes " << m << " cases, " << j - m << " controls and " << sData->vsSNPlabels.size() << " SNPs." << endl;

		clsParas->fpLog << "Read " << clsParas->sInputFilename << " OK." << endl;
	}

	/********************************************
	* 读取BOOST格式文件
	* vvcData = 读取的BOOST格式的数据
	* clsParas = 参数类指针
	* BOOST格式：
	* 第1列：0=control、1=case
	* 第2列以后：0 = AA, 1 = Aa, 2 = aa
	*********************************************
	BOOST格式(每行一个个体)：
	1 2 2 0 0 0 0 2 2 1 2 0 2 2 0 1 …
	0 1 2 0 1 0 0 2 2 0 2 0 1 2 2 1 …
	0 2 1 0 0 0 1 0 2 0 2 1 1 2 0 2 …
	1 2 1 1 1 0 1 0 2 1 2 0 2 2 0 1 …
	第1列：0=control、1=case
	第2列以后：0 = AA, 1 = Aa/aA, 2 = aa, -9 = missing
	************************************************/
	void readBOOST(vvChar& vvcData, coPLINK::parameters *clsParas)
	{
		vChar	vcTmp;
		fstream	fp;
		string	sLine;
		vString	vsTmp;
		int		i, j;
		int		k;
		char	c, cs[10];

		//sLine = addExt(clsParas->sInputFilename, ".txt");
		sLine = clsParas->sInputFilename;

#ifdef TEST_PERFORMANCE
		bool	b;
		clsParas->uInSize = getFileSize(sLine, &b);
#endif

		//以流方式打开输入文件
		openStreamFile(fp, sLine.c_str(), ios::in);

		cout << "Reading file " << sLine << "..." << endl;
		cout << "\t0 is control, otherwise case; Out of 0~2 is missing." << endl;
		clsParas->fpLog << "\t0 is control, otherwise case; Out of 0~2 is missing." << endl;

		j = 0;
		while (!fp.eof() && fp.good()) {
			sLine = "";
			getline(fp, sLine);							//取一行
			trimString(sLine);							//删除前后空格及TAB
			trimRedundance(sLine, true);				//删除中间多余空格及TAB（只保留一个）,所有TAB用空格替换掉

			if (sLine.length() == 0) continue;

			vsTmp.clear();
			//sLine = replaceChar(sLine, DELIMITER2, DELIMITER3);		//把所有TAB用空格替换掉（为分拆作准备）
			stringSplit(sLine, vsTmp, " ");				//以空格为分隔符分拆sLine

			c = vsTmp[0][0] == BOOST_CTRL_PHENOTYPE ? BOOST_CTRL_PHENOTYPE : BOOST_CASE_PHENOTYPE;
			vcTmp.push_back(c);				// 表型

			for (i = 1; i < (int)vsTmp.size(); i++) {
				k = atoi(vsTmp[i].c_str());

				if (k < 0 || k > 2){ c = MISSING_ALLELE_CHR; }	//从第2列起，missing
				else{ c = I2C(k); }

				vcTmp.push_back(c);
			}

			if (vcTmp.size() > 0) vvcData.push_back(vcTmp);

			vcTmp.clear();
			cout << '\t' << ++j << "...\r";
		}
		sLine = "";
		fp.close();
		fp.clear();
		cout << endl;

		//数据有效性检查

		k = vvcData[0].size();
		j = 0;		// case 数
		for (i = 0; i < (int)vvcData.size(); i++) {
			if (vvcData[i].size() != k) {
				sprintf(cs, "%d", i);
				sLine = cs;
				fetalError("The columns of row " + sLine + " does not match the first row while reading file " + clsParas->sInputFilename + "(.txt).", clsParas);
			}

			if (vvcData[i][0] == BOOST_CASE_PHENOTYPE) j++;
		}

		if (vvcData.empty()) {
			fetalError("Source file " + clsParas->sInputFilename + "has no any valid data.", clsParas);
		}

		clsParas->fpStat << ',' << clsParas->sInputFilename << "(.txt)," << j << ',' << (vvcData.size() - j)
			<< ',' << (k - 1) << endl;	// 文件名、记录case、ctrl、SNP数

		cout << endl << "The BOOST file " << clsParas->sInputFilename << "(.txt) read successfully. Includes "
			<< j << "cases, " << (vvcData.size() - j) << " controls and " << (k - 1) << " SNPs" << endl;

		clsParas->fpLog << "The BOOST file " << clsParas->sInputFilename << "(.txt) read successfully." << endl;

	}

	/********************************************
	* 读取MDR格式的文本文件
	* vvsMap = MAP文件内容，字串矩阵
	* vvcData = dat文件内容（字符矩阵，第一列是表型）
	* clsParas = 参数类
	*******************************************************
	MDR格式：
	X1	X2 …	X20	Class
	0	1 …	1	1
	0	1 …	0	0
	1	1 …	2	1
	0	1 …	1	0
	所有字符用tab分隔；
	第1到n-1列：每列为一个SNP；
	第n列：Class：0-control, 1-case；
	基因型数据：0-AA, 1-Aa, 2-aa, -1 = missing；
	第1行为表头，其余每行为一个个体。
	******* 以上是早期自定义这样的格式（也许当时的资料这样描述），以下是2020.3.8查找到的格式 ************
	The data file is a required document with a default of .dat as its extension, which looks like this:
	0	1 	…	1	1
	0	1 	…	0	0
	1	1 	…	2	1
	0	1 	…	1	0
		* The delimiter in a MDR file is a TAB.
		* The first column: Phenotypes. Here we use 0 - control, 1 - case.
		* The additional columns: Genotypes. Each column is a SNP. 
		   These values range from 0 to the MAXLOCIVALUE defined by MDR confiures. 
		   Here we use 0 - AA, 1 - Aa or aA, 2 - aa, -1 - missing.
		* Each row is a separate individual.
	Except for the .dat file, a .map file may be included as an optional. 
	It allows names to be specified for the variables in the data file. 
	Usually, the first column is the chromosome number, second column the name and 
	third column the base-pair position of the SNP.
	程序按新格式作了修改
	********************************************************/
	void readMDR(vvString& vvsMap, vvChar& vvcData, coPLINK::parameters *clsParas)
	{
		string	sLine, sIn;
		vString	vsTmp;
		vChar	vcTmp;
		bool	bFirstRow = true;
		int		i, m;
		int		k;
		fstream	fp;
		char	c, cs[10];

		//以流方式打开输入文件
		sIn = addExt(clsParas->sInputFilename, ".dat");

#ifdef TEST_PERFORMANCE
		bool	b;
		clsParas->uInSize = getFileSize(sIn, &b);
#endif

		openStreamFile(fp, sIn.c_str(), ios::in);

		cout << "Reading file " << sIn << "..." << endl;
		cout << "\t0 is control, otherwise case; Out of 0~2 is missing." << endl;
		clsParas->fpLog << "\t0 is control, otherwise case; Out of 0~2 is missing." << endl;

		m = 0;
		while (getline(fp, sLine)) {
			trimString(sLine);							//删除前后空格及TAB
			trimRedundance(sLine, true);				//删除中间多余空格及TAB（只保留一个）,所有TAB用空格替换掉（为分拆作准备）

			if (sLine.length() == 0) continue;

			vsTmp.clear();
			//sLine = replaceChar(sLine, DELIMITER2, DELIMITER3);	//把所有TAB用空格替换掉（为分拆作准备）
			stringSplit(sLine, vsTmp, " ");					//以空格为分隔符分拆sLine

			c = vsTmp[0][0] == MDR_CTRL_PHENOTYPE ? MDR_CTRL_PHENOTYPE : MDR_CASE_PHENOTYPE;
			vcTmp.push_back(c);

			for (i = 1; i < (int)vsTmp.size(); i++) {
					k = atoi(vsTmp[i].c_str());

					if (k < 0 || k > 2){ c = MISSING_ALLELE_CHR; }	// missing
					else{ c = vsTmp[i][0]; }					// the first char only

					vcTmp.push_back(c);
			}

			vvcData.push_back(vcTmp);
			vcTmp.clear();
			cout << '\t' << ++m << "...\r";
		}
		sLine = "";
		fp.close();
		fp.clear();
		cout << endl;

		if (vvcData.empty()) {
			fetalError("Source file " + clsParas->sInputFilename + "has no any valid data.", clsParas);
		}

		//数据有效性检查
		k = vvcData[0].size();
		for (i = 0; i < (int)vvcData.size(); i++){
			if (k != vvcData[i].size()) {
				sprintf(cs, "%d", i + 1);
				fetalError("The length of row " + (string)cs + " does not match  the first one.", clsParas);
			}
		}

		//以流方式打开输入文件
		sIn = addExt(clsParas->sInputFilename, ".map");

		if (access(sIn.c_str(), 0) != -1){	// 存在MAP文件
			openStreamFile(fp, sIn.c_str(), ios::in);

			cout << "Reading file " << sIn << "..." << endl;
			m = 0;
			while (getline(fp, sLine)) {
				trimString(sLine);							//删除前后空格及TAB
				trimRedundance(sLine, true);				//删除中间多余空格及TAB（只保留一个）,所有TAB用空格替换掉（为分拆作准备）

				if (sLine.length() == 0) continue;

				vsTmp.clear();
				//sLine = replaceChar(sLine, DELIMITER2, DELIMITER3);	//把所有TAB用空格替换掉（为分拆作准备）
				stringSplit(sLine, vsTmp, " ");					//以空格为分隔符分拆sLine

				vvsMap.push_back(vsTmp);

				cout << '\t' << ++m << "...\r";
			}
			sLine = "";
			fp.close();
			fp.clear();
			cout << endl;
		}

		if (vvsMap.empty()){
			cout << "There has no MPA file" << endl;
			clsParas->fpLog	<< "There has no MPA file" << endl;
		}
		else if (vvsMap.size() != vvcData[0].size() - 1){
				fetalError("The numbers of DAT and of MAP are not the same.", clsParas);
		}
		else {
			k = vvsMap[0].size();
			for (i = 0; i < (int)vvsMap.size(); i++){
				if (k != vvsMap[i].size()) {
					sprintf(cs, "%d", i + 1);
					fetalError("The length of row " + (string)cs + " does not match  the first one.", clsParas);
				}
			}
		}

		k = 0;
		for (i = 0; i < (int)vvcData.size(); i++) {
			if (vvcData[i][0] == MDR_CASE_PHENOTYPE) k++;	// 统计case
		}

		clsParas->fpStat << ',' << sIn << ',' << k << ',' << (vvcData.size() - k) << ',' << (vvcData[0].size() - 1) << endl;

		cout << endl << "The MDR file " << sIn << " read successfully. Includes "
			<< k << " cases, " << (vvcData.size() - k) << " controls and " << (vvcData[0].size() - 1) << " SNPs" << endl;

		clsParas->fpLog << "The MDR file " << sIn << " read successfully." << endl;
	}

	/********************************************
	* 读取ME(最大熵法)格式的文本文件
	* viNo = No. 列向量
	* vcPhenotypes = 表型列向量
	* vvcData = 读取的除一、二列外的文件内容（基因型矩阵，字符矩阵）
	* clsParas = 参数类
	**********************************************************
	ME格式(每行一个个体)：
	No.	Case/Control	Allele0	Allele1	Allele0 …
	1		1 			1 		1 		1 	...
	2    	2 			1 		1 		2 	...
	第1列：样本序号
	第2列：1=control 2=case
	第3列以后每两列组成一个SNP：0/0和1/1=AA、1/2和2/1=Aa、2/2=aa（本程序定义missing = -1）

	vviData = 读取的文件内容
	***********************************************************/
	void readME(vInt &viNo, vChar &vcPhenotypes, vvChar& vvcData, coPLINK::parameters *clsParas)
	{
		vChar	vcTmp;
		fstream	fp;
		string	sLine;
		vString	vsTmp;
		int		i, m;
		int		k;
		char	c;

#ifdef TEST_PERFORMANCE
		bool	b;
		clsParas->uInSize = getFileSize(clsParas->sInputFilename, &b);
#endif

		//以流方式打开输入文件
		openStreamFile(fp, clsParas->sInputFilename.c_str(), ios::in);

		cout << "Reading file " << clsParas->sInputFilename << "..." << endl;
		cout << "\t1 is control, otherwise case; Out of 0~2 is missing." << endl;
		clsParas->fpLog << "\t1 is control, otherwise case; Out of 0~2 is missing." << endl;

		m = 0;
		while (getline(fp, sLine)) {
			trimString(sLine);							//删除前后空格及TAB
			trimRedundance(sLine, true);				//删除中间多余空格及TAB（只保留一个）,所有TAB用空格替换掉（为分拆作准备）

			if (sLine.length() == 0) continue;

			vsTmp.clear();
			//sLine = replaceChar(sLine, DELIMITER2, DELIMITER3);	//把所有TAB用空格替换掉（为分拆作准备）
			stringSplit(sLine, vsTmp, " ");				//以空格为分隔分拆sLine

			if (vsTmp.size() < 4) continue;				// One SNP needs.

			vcTmp.reserve(vsTmp.size() - 1);
			k = atoi(vsTmp[0].c_str());					// No.
			viNo.push_back(k);

			c = vsTmp[1][0] == ME_CTRL_PHENOTYPE ? ME_CTRL_PHENOTYPE : ME_CASE_PHENOTYPE;
			vcPhenotypes.push_back(c);					// 表型

			for (i = 2; i < (int)vsTmp.size(); i++) {			// 基因型
				k = atoi(vsTmp[i].c_str());

				if (k < 0 || k > 2){ c = MISSING_ALLELE_CHR; }	// missing
				else{ c = I2C(k); }

				vcTmp.push_back(c);
			}

			if (vcTmp.size() > 0) vvcData.push_back(vcTmp);
			vcTmp.clear();
			cout << '\t' << ++m << "...\r";
		}
		sLine = "";
		fp.close();
		fp.clear();
		cout << endl;

		//数据有效性检查
		k = vvcData[0].size();
		if (!EVEN_NUMBER(k)){
			fetalError("The number of columns of the genotypes is not an even number.", clsParas);
		}

		for (i = 1; i < (int)vvcData.size(); i++) {	//所有行的列数是否相同
			if (vvcData[i].size() != k) {
				char cs[100];
				sprintf(cs, "The size of row %d does not match the first one.", i);
				fetalError(cs, clsParas);
			}
		}

		if (clsParas->bSwap) {		// 交换矩形（lt, rb)间的等位基因数相同的major和minor alleles
			Point	lt, rb;

			lt.x = 0; lt.y = 0;
			rb.x = vvcData[0].size() - 1; rb.y = vvcData.size() - 1;
			if (!swapAllelsInColDouble(vvcData, &lt, &rb)){
				fetalError("The number of columns of SNPs is not even.", clsParas);
			}
		}
		/*
		if (clsParas->bNormalize){	// 归一化（ME数据是归一化数据，无需此步）
			int j;

			k = vvcData[0].size();
			for (i = 0; i < (int)vvcData.size(); i++){	// 把0用1替换
				for (j = 0; j < k; j++){
					if (vvcData[i][j] == ME_ALLELE_A1) vvcData[i][j] = ME_ALLELE_A;
				}
			}

			// 设置等位基因符号
			sGenotype sg;

			sg = clsParas->struGenotype;
			clsParas->struGenotype.AA[0] = clsParas->struGenotype.AA[1] = ME_ALLELE_A;
			clsParas->struGenotype.Aa[0] = ME_ALLELE_A; clsParas->struGenotype.Aa[1] = ME_ALLELE_a;
			clsParas->struGenotype.aa[0] = clsParas->struGenotype.aa[1] = ME_ALLELE_a;

			if (!NormalizeAlleles2Col(vvcData, clsParas, sLine, true)){
				fetalError(sLine, clsParas);
			}
			clsParas->struGenotype = sg;
		}
		*/

		//统计CASE数
		k = 0;
		for (i = 0; i < (int)vvcData.size(); i++){
			if (vvcData[i][0] == ME_CASE_PHENOTYPE) k++;
		}

		if (vvcData.empty()) {
			fetalError("Source file " + clsParas->sInputFilename + "has no any valid data.", clsParas);
		}

		clsParas->fpStat << ',' << clsParas->sInputFilename << "(.me)," << k << ',' << vvcData.size() - k << ','
			<< (vvcData[0].size() - 1) / 2 << endl;

		cout << "Read " << clsParas->sInputFilename << "(.me) is OK.\nSummary: " << k << " cases; "
			<< vvcData.size() - k << " controls and " << (vvcData[0].size() - 1) / 2 << " SNPs." << endl;

		clsParas->fpLog << "Read " << clsParas->sInputFilename << "(.me) is OK." << endl;
	}


	/********************************************
	* 读取Prettybase格式的文本文件（早期版本）重载+1
	* vvsInfo = 文件的前两列转换成4列：chromosome position、HUGO_NAME、chromosome、PGA Sample ID
	* vvcAlleles = 等位基因数据（文件中的后两列）
	* clsParas = 参数类
	*********************************************
	Prettybase格式：-或N = missing
	This is a tab delimited text file in our "prettybase" format,
	which describes all SNP sites discovered by the SeattleSNPs PGA.
	The format of this file is:

	Line format:
	<chromosome position-HUGO_NAME-chromosome> <PGA Sample ID> <Allele1> <Allele2>

	Example: 74772592-PLAU-10 D001 G T
	注： <Allele1> <Allele2>可能包含多个字母，遇此情况，仅取首字母
	The 'chromosome position' is generated from mapping to the most
	recent genome assembly available from the UCSC Genome Assembly

	Prettybase格式：
	1. 用TAB分隔
	2. 每行组成：<chromosome position-HUGO_NAME-chromosome> <PGA Sample ID> <Allele1> <Allele2>
	3. 可将“HUGO_NAME-chromosome position”视作SNP ID
	4. 缺失用“-”或“N”表示
	2020.2.18：经过观察SeattleSNPs数据，发现一组样本有序重复，每个重复是一个SNP（可能存在不同SNP的pos相同的情况）。
	PED转pretty时，HUGO_NAME可指定，未指定使用NO_NAME。
	***********************************************************/
	void readPrettybase(vvString &vvsInfo, vvChar& vvcAlleles, coPLINK::parameters *clsParas)// 早期版本的pretty格式重载+1（保存所有数据，占用内存过大）支持有重复样本ID
	{
		vChar	vcTmp(2);
		vString	vsTmp, vsInfoTmp, vsInf(4);
		string	sLine;
		int		m;
		fstream	fp;

#ifdef TEST_PERFORMANCE
		bool	b;
		clsParas->uInSize = getFileSize(clsParas->sInputFilename, &b);
#endif

		openStreamFile(fp, clsParas->sInputFilename.c_str(), ios::in);

		cout << "Reading the file " << clsParas->sInputFilename << " at " << getDT() << ". Please wait ..." << endl;//显示读取开始时间
		m = 0;
		while (getline(fp, sLine)) {
			trimString(sLine);							//删除前后空格及TAB
			trimRedundance(sLine, true);				//删除中间多余空格及TAB（只保留一个）,所有TAB用空格替换掉（为分拆作准备）

			if (sLine.length() == 0) continue;

			vsTmp.clear();
			//sLine = replaceChar(sLine, DELIMITER2, DELIMITER3);	//把所有TAB用空格替换掉（为分拆作准备）
			stringSplit(sLine, vsTmp, " ");					//以空格为分隔符分拆sLine

			if (vsTmp.size() < 4) continue;						//不足4列

			vsInfoTmp.clear();
			stringSplit(vsTmp[0], vsInfoTmp, "-");				//分成三项：chromosome position、HUGO_NAME、chromosome

			if (vsInfoTmp.size() < 3) continue;					//不足3项

			vsInf[PRET_POS] = vsInfoTmp[0];						//chromosome position
			vsInf[PRET_NAME] = vsInfoTmp[1];					//HUGO_NAME
			vsInf[PRET_CHR] = vsInfoTmp[2];						//chromosome
			vsInf[PRET_SAMPLE_OLD] = vsTmp[1];						//sample ID
			vvsInfo.push_back(vsInf);

			vcTmp[0] = vsTmp[2][0];								//只取首字符
			vcTmp[1] = vsTmp[3][0];

			if ((vcTmp[0] == PRET_MISSING_A1) || (vcTmp[0] == PRET_MISSING_A2) || (vcTmp[0] == PRET_MISSING_A3))
			{
				vcTmp[0] = MISSING_ALLELE_CHR;
			}

			if ((vcTmp[1] == PRET_MISSING_A1) || (vcTmp[1] == PRET_MISSING_A2) || (vcTmp[1] == PRET_MISSING_A3))
			{
				vcTmp[1] = MISSING_ALLELE_CHR;
			}

			vvcAlleles.push_back(vcTmp);						//保存Allele值

			cout << '\t' << ++m << "...\r";
		}

		sLine = "";
		fp.close();
		fp.clear();
		cout << endl;

		//数据有效性检查(提取过程已作检查）

		if (vvcAlleles.empty()) {
			fetalError("Source file " + clsParas->sInputFilename + "has no any valid data.", clsParas);
		}

		clsParas->fpStat << ',' << clsParas->sInputFilename << ",-,-,-" << endl;	// 记录case、ctrl、SNP数

		cout << endl << "The Prettybase file " << clsParas->sInputFilename << " read successfully." << endl;
		cout << "Read ends at " << getDT() << endl;		//读取结束时间

		clsParas->fpLog << "The Prettybase file " << clsParas->sInputFilename << " read successfully." << endl;
	}

	/********************************************
	* 以样本ID（即样本ID不重复）读取Prettybase格式的文本文件 重载+2
	* viPos = 文件的第1列数值向量（不重复）
	* vsChr = SNP的染色体号（不重复）
	* vsSaId = 一组样本（第2列）字串向量
	* vvcAlleles = 等位基因数据（文件中的后两列，字符矩阵）
	* clsParas = 参数类
	* 返回Pretty格式类型
	*********************************************
	Prettybase格式：-或N = missing
	This is a tab delimited text file in our "prettybase" format,
	which describes all SNP sites discovered by the SeattleSNPs PGA.
	The format of this file is:

	Line format:
	<chromosome position-HUGO_NAME-chromosome> <PGA Sample ID> <Allele1> <Allele2>

	Example: 74772592-PLAU-10 D001 G T
	注： <Allele1> <Allele2>可能包含多个字母，遇此情况，仅取首字母
	The 'chromosome position' is generated from mapping to the most
	recent genome assembly available from the UCSC Genome Assembly

	Prettybase格式：
	1. 用TAB分隔
	2. 每行组成：<chromosome position-HUGO_NAME-chromosome> <PGA Sample ID> <Allele1> <Allele2>
	3. 可将“HUGO_NAME-chromosome position”视作SNP ID
	4. 缺失用“-”或“N”表示
	2020.2.18：经过观察SeattleSNPs数据，发现一组样本有序重复，每个重复是一个SNP（可能存在不同SNP的pos相同的情况）。
	PED转pretty时，HUGO_NAME可指定，未指定使用NO_NAME。
	***********************************************************/
	int readPrettybaseSample(vInt &viPos, vString &vsChr, vString &vsSampleId, vvChar& vvcAlleles, parameters *clsParas)
	{
		int		m, iSampleCnt, i, iPos, iRet;

#ifdef TEST_PERFORMANCE
		bool	b;
		clsParas->uInSize = getFileSize(clsParas->sInputFilename, &b);
#endif

		cout << "Reading the file " << clsParas->sInputFilename << " at " << getDT() << ". Please wait ..." << endl;//显示读取开始时间

		iRet = getPrettyFormat(clsParas->sInputFilename);
		if (iRet == PRET_NULL){
			fetalError(clsParas->sInputFilename + " has nothing.", clsParas);
		}

		vChar	vcTmp(2);
		vString	vsTmp, vsInfoTmp;
		string	sLine, sPos, sFirst;
		fstream	fp;
		bool	bNoExit, bSample, bSeattleSNPs;

		/*********************************************
		Prettybase格式：
		1. 用TAB分隔
		2. Slider格式每行组成：<position> <PGA Sample ID> <Allele1> <Allele2>；
		   SeattleSNPs格式每行组成：<chromosome position-HUGO_NAME-chromosome> <PGA Sample ID> <Allele1> <Allele2>
		   注： <Allele1> <Allele2>可能包含多个字母，遇此情况，仅取首字母
		3. 一个“position”代表一个SNP
		4. 缺失用“ - ”或“N”表示（早期的），新的从其sample可以发现用 ? 和N表示MISSING（这里支持三种）
		**********************************************/
		openStreamFile(fp, clsParas->sInputFilename.c_str(), ios::in);

		// 2020.2.18：经过观察SeattleSNPs数据，发现一组样本有序重复，每个重复是一个SNP（可能存在不同SNP的pos相同的情况）。
		// 样本ID虽然有序重复，但实际数据中的ID可能多一个或少一个或改一个字符：如D001改成DY001

		m = 0;
		bNoExit = true;
		bSample = true;
		bSeattleSNPs = iRet == PRET_SeattleSNPs;

		while (getline(fp, sLine)) {
			trimString(sLine);							//删除前后空格及TAB
			trimRedundance(sLine, true);				//删除中间多余空格及TAB（只保留一个）,所有TAB用空格替换掉（为分拆作准备）

			if (sLine.length() == 0) continue;

			stringSplit(sLine, vsTmp, " ");					//以空格为分隔符分拆sLine

			if (vsTmp.size() < 4) continue;						//不足4列

			if (bSeattleSNPs) {
				stringSplit(vsTmp[0], vsInfoTmp, "-");				//分成三项：chromosome position、HUGO_NAME、chromosome

				if (vsInfoTmp.size() < 3) continue;					//不足3项

				sPos = vsInfoTmp[PRET_POS];
			}
			else{
				sPos = vsTmp[PRET_POS];
			}

			if (bSample){	//sample ID
				if (vsSampleId.size() == 0) {
					vsSampleId.push_back(vsTmp[1]);
					iPos = atoi(sPos.c_str());					//chromosome position
					viPos.push_back(iPos);

					if (bSeattleSNPs) {
						sFirst = vsInfoTmp[PRET_CHR];
						vsChr.push_back(sFirst);
					}
				}
				else if (vsSampleId[0] != vsTmp[1]) vsSampleId.push_back(vsTmp[1]);
				else {
					bSample = false;	// sample ID completed
					iSampleCnt = vsSampleId.size();		// 样本数。
					i = 0;

					iPos = atoi(sPos.c_str());					//chromosome position
					if (bSeattleSNPs) {
						sFirst = vsInfoTmp[PRET_CHR];
					}
				}
			}
			else{
				i++;
				if (i == iSampleCnt) {			// 样本ID虽然有序重复，但实际数据中的ID可能多一个或少一个或改一个字符：如D001改成DY001,所以比较ID重复不现实。
												// 但完全按计数也不行
					viPos.push_back(iPos);

					if (bSeattleSNPs) {
						vsChr.push_back(sFirst);
					}

					if (vsSampleId[0] != vsTmp[1]) {
						cout << "The " << ++m << "-th sample ID (" << vsTmp[1] << ") is different from the first one (" << vsSampleId[0] << ")." << endl;
						bNoExit = false;
						break;	// 与第一个SNP样本数相同，但新的SNP的第一个样本ID与第一个SNP不同，退出
					}

					iPos = atoi(sPos.c_str());					//chromosome position
					i = 0;

					if (bSeattleSNPs) {
						sFirst = vsInfoTmp[PRET_CHR];
					}
				}
			}

			vcTmp[0] = vsTmp[2][0];								//只取首字符
			vcTmp[1] = vsTmp[3][0];

			if ((vcTmp[0] == PRET_MISSING_A1) || (vcTmp[0] == PRET_MISSING_A2) || (vcTmp[0] == PRET_MISSING_A3))
			{
				vcTmp[0] = MISSING_ALLELE_CHR;
			}

			if ((vcTmp[1] == PRET_MISSING_A1) || (vcTmp[1] == PRET_MISSING_A2) || (vcTmp[1] == PRET_MISSING_A3))
			{
				vcTmp[1] = MISSING_ALLELE_CHR;
			}

			vvcAlleles.push_back(vcTmp);						//保存Allele值

			cout << '\t' << ++m << "...\r";
		}

		if (bNoExit){
			viPos.push_back(iPos);

			if (bSeattleSNPs) {
				vsChr.push_back(sFirst);
			}
		}

		fp.close();
		fp.clear();
		cout << endl;

		//数据有效性检查(提取过程已作检查）

		if (vvcAlleles.empty()) {
			fetalError("Source file " + clsParas->sInputFilename + "has no any valid data.", clsParas);
		}

		cout << "Valid numbers of SNPs, genotypes and samples are " << viPos.size() << ", " << vvcAlleles.size() << ", " << vsSampleId.size() << endl;

		clsParas->fpLog << "Valid numbers of SNPs, genotypes and samples are " << viPos.size() << ", " << vvcAlleles.size() << ", " << vsSampleId.size() << endl;
		clsParas->fpStat << ',' << clsParas->sInputFilename << ",-,-," << viPos.size() << endl;	// 记录case、ctrl、SNP数

		cout << endl << "The Prettybase file " << clsParas->sInputFilename << " read successfully." << endl;
		cout << "Read ends at " << getDT() << endl;		//读取结束时间

		clsParas->fpLog << "The Prettybase file " << clsParas->sInputFilename << " read successfully." << endl;

		return iRet;
	}

	/********************************************
	* 以POSITION为基准（即认为每个SNP的POSTION不同）读取Prettybase格式的文本文件
	* viPos = 文件的第1列数值向量（不重复）
	* vsChr = SNP的染色体号（不重复）
	* vsSaId = 一组样本（第2列）字串向量
	* vvcAlleles = 等位基因数据（文件中的后两列，字符矩阵）
	* clsParas = 参数类
	* 返回Pretty格式类型
	***********************************************************/
	int readPrettybasePosition(vInt &viPos, vString &vsChr, vString &vsSaId, vvChar& vvcAlleles, coPLINK::parameters *clsParas)
	{
		int		m, n, p, iSampleCnt, iFirst, iRet;

#ifdef TEST_PERFORMANCE
		bool	b;
		clsParas->uInSize = getFileSize(clsParas->sInputFilename, &b);
#endif

		cout << "Reading the file " << clsParas->sInputFilename << " at " << getDT() << ". Please wait ..." << endl;//显示读取开始时间

		iRet = getPrettyFormat(clsParas->sInputFilename);
		if (iRet == PRET_NULL){
			fetalError(clsParas->sInputFilename + " has nothing.", clsParas);
		}

		vChar	vcTmp(2);
		vString	vsAll, vs;
		string	sLine, sPos, sFirst;
		fstream	fp;
		bool	bSNP, bNoExit, bSeattleSNPs;

		m = 0;
		bSNP = true;
		bNoExit = true;
		bSeattleSNPs = iRet == PRET_SeattleSNPs;

		/*********************************************
		Prettybase格式：
		1. 用TAB分隔
		2. Slider格式每行组成：<position> <PGA Sample ID> <Allele1> <Allele2>；
		   SeattleSNPs格式每行组成：<chromosome position-HUGO_NAME-chromosome> <PGA Sample ID> <Allele1> <Allele2>
		   注： <Allele1> <Allele2>可能包含多个字母，遇此情况，仅取首字母
		3. 一个“position”代表一个SNP
		4. 缺失用“ - ”或“N”表示（早期的），新的从其sample可以发现用 ? 和N表示MISSING（这里支持三种）
		**********************************************/
		openStreamFile(fp, clsParas->sInputFilename.c_str(), ios::in);

		while (getline(fp, sLine)) {
			trimString(sLine);							//删除前后空格及TAB
			trimRedundance(sLine, true);				//删除中间多余空格及TAB（只保留一个）,所有TAB用空格替换掉（为分拆作准备）

			if (sLine.length() == 0) continue;

			stringSplit(sLine, vsAll, " ");				//以空格为分隔符分拆sLine

			if (vsAll.size() < 4) continue;				//不足4列

			if (bSeattleSNPs) {
				stringSplit(vsAll[0], vs, "-");

				if (vs.size() < 3) continue;

				sPos = vs[PRET_POS];
			}
			else{
				sPos = vsAll[PRET_POS];
			}

			if (bSNP){	//SNP pos.
				p = atoi(sPos.c_str());
				if (viPos.size() == 0) {
					iFirst = p;
					viPos.push_back(p);

					if (bSeattleSNPs) {
						sFirst = vs[PRET_CHR];
						vsChr.push_back(sFirst);
					}

					vsSaId.push_back(vsAll[1]);		// sample ID
				}
				else if (viPos[0] != p)	{
					bSNP = false;	// SNP pos. completed
					iFirst = p;

					if (bSeattleSNPs) {
						sFirst = vs[PRET_CHR];
					}

					n = 0;
					iSampleCnt = vsSaId.size();
				}
				else{
					vsSaId.push_back(vsAll[1]);		// sample ID
				}
			}
			else{
				n++;
				if (iFirst != atoi(sPos.c_str())) {
					viPos.push_back(iFirst);

					if (bSeattleSNPs) {
						vsChr.push_back(sFirst);
					}

					// 但完全按计数也不行
					if (n != iSampleCnt) {
						cout << "The " << ++m << "-th position (" << sPos << ") is different from the first one (" << iFirst << ")." << endl;
						bNoExit = false;
						break;	// 与第一个SNP样本数相同，但新的SNP的第一个样本ID与第一个SNP不同，退出
					}

					iFirst = atoi(sPos.c_str());

					if (bSeattleSNPs) {
						sFirst = vs[PRET_CHR];
					}

					n = 0;
				}
			}

			vcTmp[0] = vsAll[PRET_ALLELE1][0];				// Allele值，只取首字符
			vcTmp[1] = vsAll[PRET_ALLELE2][0];

			if ((vcTmp[0] == PRET_MISSING_A1) || (vcTmp[0] == PRET_MISSING_A2) || (vcTmp[0] == PRET_MISSING_A3))
			{
				vcTmp[0] = MISSING_ALLELE_CHR;
			}

			if ((vcTmp[1] == PRET_MISSING_A1) || (vcTmp[1] == PRET_MISSING_A2) || (vcTmp[1] == PRET_MISSING_A3))
			{
				vcTmp[1] = MISSING_ALLELE_CHR;
			}

			vvcAlleles.push_back(vcTmp);
			cout << '\t' << ++m << "...\r";
		}

		if (bNoExit){
			viPos.push_back(iFirst);

			if (bSeattleSNPs) {
				vsChr.push_back(sFirst);
			}
		}

		fp.close();
		fp.clear();
		cout << endl;
		
		//数据有效性检查(提取过程已作检查）

		if (vvcAlleles.empty()) {
			fetalError("Source file " + clsParas->sInputFilename + "has no any valid data.", clsParas);
		}

		cout << "Valid numbers of SNPs, genotypes and samples are " << viPos.size() << ", " << vvcAlleles.size() << ", " << iSampleCnt << endl;

		clsParas->fpLog << "Valid numbers of SNPs, genotypes and samples are " << viPos.size() << ", " << vvcAlleles.size() << ", " << iSampleCnt << endl;

		clsParas->fpStat << ',' << clsParas->sInputFilename << ",-,-," << viPos.size() << endl;	// 记录case、ctrl、SNP数

		cout << endl << "The Prettybase file " << clsParas->sInputFilename << " read successfully." << endl;
		cout << "Reading ends at " << getDT() << endl;		//读取结束时间

		clsParas->fpLog << "The Prettybase file " << clsParas->sInputFilename << " read successfully." << endl;

		return iRet;
	}

	/********************************************
	* 判断Pretty文件格式
	* fn = 文件名
	*********************************************/
	int getPrettyFormat(string fn)
	{
		fstream	fp;
		string	sLine;
		vString	vs;
		int		ret;

		openStreamFile(fp, fn.c_str(), ios::in);

		ret = PRET_NULL;

		while (getline(fp, sLine)) {
			trimString(sLine);							//删除前后空格及TAB
			trimRedundance(sLine, true);				//删除中间多余空格及TAB（只保留一个）,所有TAB用空格替换掉（为分拆作准备）

			if (sLine.length() == 0) continue;

			stringSplit(sLine, vs, " ");				//以空格为分隔符分拆sLine

			if (vs.size() < 4) continue;				// 不少于4列

			if (vs[PRET_POS].find('-') == string::npos){
				ret = PRET_Slider;
			}
			else{
				ret = PRET_SeattleSNPs;
			}

			break;
		}

		fp.close();
		fp.clear();
		vString().swap(vs);

		return ret;
	}

	/********************************************
	* 从给定的字串中提取SNP Position
	* sIn = 输入：“chromosome position-HUGO_NAME”
	*    其中“chromosome position”为需提取这内容
	*********************************************/
	string getSnpPos(string sIn)
	{
		int i;

		i = sIn.find('-', 0);
		if (i == string::npos){ return ""; }
		else{ return sIn.substr(0, i); }
	}

	/********************************************
	* 读取SVMSNPs文件
	* vvcDAT = DAT文件基因型字符矩阵（样本数行*SNP数列）
	* vcLAB = LAB文件表型字符向量（虽然文件有两列，但第2列只是序号，无需保存）
	* vsSNP = NAME文件字符串向量（SNP label）
	* clsParas = 类参数指针
	********************************************************************
	SVMSNP格式（包含三个文件）(文献作者在网站与README中说明的SVMSNPs格式不同!!!!!。2020.3.17发现本质应该一样的，网站对数据文件编码说“也可以简单地用Major allele的个数表示”）：
	数据文件（本程序定义扩展名为dat）：每行一个个体，每列一个SNP。
	标签文件（本程序定义扩展名为lab）：每行一个个体，共两列：第1列0表示case，1表示control（网站说明这两列刚好相反，但其示例文件是按这种方式，这里用此方式）；
	第2列表示个体编号（即数据文件中的行号，从0开始编号）。
	SNP名称文件（可选）（本程序定义扩展名为snp）：每行一个SNP，只一列（字符串：SNP的名称）。
	各行与数据文件行对应。
	seekMode = 查找方式（0 - 基于等位基因字母序查找，字母序最后者为主要等位基因（README文件说明）。
	1 - 基于等位基因频率查找，频率高者为主要等位基因（网站说明）。
	数据文件编码规则：
	1. 作者网站上的编码规则：主要等位基因个数。
	2. 作者README文件中的编码规则（以下为README中的内容）：
	This encoding is produced as follows: if the SNP is
	A/B, where A and B denote nucleotides in sorted order, then the encoded
	genotype of AA is 0, AB or BA is 1, and BB is 2. For example if we have
	two cases (or controls) genotypes for 3 SNPs A/C, C/G, and C/T, then the
	encoding would be

	AA CC CT => 0 0 1 
	AC GG CC => 1 2 0
	本程序用-1表示missing
	*********************************************************************/
	void readSVMSNPs(vvChar &vvcDAT, vChar &vcLAB, vString &vsSNP, parameters *clsParas)
	{
		fstream	fp;
		string	sLine;
		vString	vs;
		vChar	vc;
		char	c;
		int		i, j, k;
		bool	b;

		// 读取DAT
		sLine = addExt(clsParas->sInputFilename, ".dat");

#ifdef TEST_PERFORMANCE
		clsParas->uInSize = getFileSize(sLine, &b);
#endif

		cout << "Reading file " << sLine << ". Please wait ..." << endl;
		cout << "\tOut of 0~2 is missing." << endl;
		clsParas->fpLog << "\tOut of 0~2 is missing." << endl;

		openStreamFile(fp, sLine.c_str(), ios::in);
		j = 0;
		while (getline(fp, sLine)) {
			trimString(sLine);							//删除前后空格及TAB
			trimRedundance(sLine, true);				//删除中间多余空格及TAB（只保留一个），并把TAB更换成空格

			if (sLine.length() == 0) continue;

			stringSplit(sLine, vs);
			k = vs.size();
			vc.resize(k);

			for (i = 0; i < k; i++){
				vc[i] = (vs[i][0] >= '0' && vs[i][0] <= '2') ? vs[i][0] : MISSING_ALLELE_CHR;	// 只保留首字符
			}

			vvcDAT.push_back(vc);
			cout << '\t' << ++j << "...\r";
		}

		sLine = "";
		fp.close();
		vString().swap(vs);			// 清空vs
		vChar().swap(vc);
		cout << endl;

		if (vvcDAT.empty()) {
			fetalError("Source file " + clsParas->sInputFilename + " (.dat) has no any valid data.", clsParas);
		}

		// 读取LAB
		sLine = addExt(clsParas->sInputFilename, ".lab");
		cout << "Reading file " << sLine << ". Please wait ..." << endl;
		cout << "\t1 is control, otherwise case." << endl;
		clsParas->fpLog << "\t1 is control, otherwise case." << endl;

		openStreamFile(fp, sLine.c_str(), ios::in);
		i = 0;
		while (getline(fp, sLine)) {
			trimString(sLine);							//删除前后空格及TAB

			if (sLine.length() == 0) continue;

			c = sLine[0] == SVMSNP_CTRL_PHENOTYPE ? SVMSNP_CTRL_PHENOTYPE : SVMSNP_CASE_PHENOTYPE;
			vcLAB.push_back(c);		// save the first col. (phenotypes)

			cout << '\t' << ++i << "...\r";
		}
		sLine = "";
		fp.close();
		cout << endl;

		// 读取NAME
		sLine = addExt(clsParas->sInputFilename, ".snp");
		b = false;
		if (access(sLine.c_str(), 0) != -1) {	//存在name文件
			cout << "Reading file " << sLine << ". Please wait ..." << endl;

			openStreamFile(fp, sLine.c_str(), ios::in);

			b = true;		// exists .name file
			while (getline(fp, sLine)) {
				trimString(sLine);							//删除前后空格及TAB

				if (sLine.length() == 0) continue;

				vsSNP.push_back(sLine);
			}

			sLine = "";
			fp.close();
		}
		else {
			cout << "The NAME file does not exist." << endl;
			clsParas->fpLog << "The NAME file does not exist." << endl;
		}

		// veify data
		if (vvcDAT.size() != vcLAB.size()){
			fetalError("The number of samples in DAT file is different from that in the LAB file.", clsParas);
		}

		j = vvcDAT[0].size();
		for (i = 0; i < (int)vvcDAT.size(); i++){
			if (vvcDAT[i].size() != j){
				char cs[100];
				sprintf(cs, "The number of SNPs in DAT file at row %d does not match the first.", i);
				fetalError(cs, clsParas);
			}
		}

		if (b){
			if (j != vsSNP.size()){
				fetalError("The number of SNPs in DAT file is different from that in the NAME file.", clsParas);
			}
		}

		// 统计表型
		j = 0;
		for (i = 0; i < (int)vcLAB.size(); i++) {
			if (SVMSNP_CASE_PHENOTYPE == vcLAB[i]) k++;		
		}

		clsParas->fpStat << ',' << clsParas->sInputFilename << ',' << j << ',' << (vcLAB.size() - j) << ',' << vsSNP.size() << endl;	// 记录case、ctrl、SNP数

		cout << endl << "The PED file read successfully as a matrix. Includes " << j << "cases, "
			<< (vcLAB.size() - j) << " controls and " << vsSNP.size() << " SNPs" << endl;

		clsParas->fpLog << "The PED file read successfully as a matrix." << endl;
	}

	/********************************************
	* 按行行读文本文件，并删除各行多余的空格或TAB（只保留一个)
	* vsData = 读取的文件内容
	* fIn = 输入文件名
	*********************************************/
	void readTextByRow(vString& vsData, string fIn)
	{
		vString vsTmp;
		fstream	fp;
		string	sLine;
		int		m;

		openStreamFile(fp, fIn.c_str(), ios::in);

		cout << "Reading file " << fIn << "..." << endl;
		m = 0;
		while (!fp.eof() && fp.good()) {
			sLine = "";
			getline(fp, sLine);							//取一行
			trimString(sLine);							//删除前后空格及TAB
			trimRedundance(sLine, true);				//删除中间多余空格及TAB（只保留一个）,所有TAB用空格替换掉（为分拆作准备）

			if (sLine.length() == 0) continue;

			//sLine = replaceChar(sLine, DELIMITER2, DELIMITER3);		//把所有TAB用空格替换掉（为分拆作准备）
			vsData.push_back(sLine);
			cout << '\t' << ++m << "...\r";
		}

		fp.close();
		fp.clear();
		cout << endl;

		cout << endl << "The file " << fIn << " read successfully as a vector." << endl;
	}


	/********************************************
	* 用指定分隔符字串保存文本文件
	* vvsData = 输入的数据
	* fOut = 输出文件名
	* cDelimeter ＝ 分隔符字串（默认“，”）
	*********************************************/
	void saveWithDelimeter(vvString& vvsData, string fOut, const char* cDelimeter)
	{
		string	strCsv;
		int	i, j, k;
		string	sLine;
		fstream	fp;

		openStreamFile(fp, fOut.c_str(), ios::out);

		for (i = 0; i < (int)vvsData.size(); i++) {
			sLine = "";
			k = vvsData[i].size();

			for (j = 0; j < k; j++) {
				sLine += vvsData[i][j];
				if (j < k - 1){
					sLine += cDelimeter;		//最后一个不要cDelimeter
				}
			}

			fp << sLine << endl;
		}
		fp.close();
		fp.clear();

		cout << "The file has been saved as " << fOut << endl;
	}


	/********************************************
	* 拆分行读取用指定分隔符字串分隔的文本文件(默认空格或TAB分隔符。Plink的map文件也用此函数读取)
	* vvsData = 读取的文件内容
	* fIn = 输入文件名
	* clsParas = 参数类指针
	* verify = 是否校验结果为矩阵
	* byChar = 是否按字符拆分
	* cDelimeter = 分隔符字串（若按字符拆分，则首字符有效）
	*********************************************/
	void readWithDelimeter(vvString& vvsData, string fIn, coPLINK::parameters *clsParas, const char* cDelimeter, bool byChar, bool verify)
	{
		vString vsTmp;
		fstream	fp;
		string	sLine;
		int		i, k;

		openStreamFile(fp, fIn.c_str(), ios::in);

		cout << "Reading file " << fIn << "..." << endl;
		i = 0;
		while (!fp.eof() && fp.good()) {
			sLine = "";
			getline(fp, sLine);							//取一行
			trimString(sLine);							//删除前后空格及TAB
			trimRedundance(sLine, true);				//删除中间多余空格及TAB（只保留一个）,所有TAB用空格替换掉（为分拆作准备）

			if (sLine.length() == 0) continue;

			//sLine = replaceChar(sLine, DELIMITER2, DELIMITER3);				//把所有TAB用空格替换掉（为分拆作准备）
			if (byChar){ stringSplit(sLine.c_str(), vsTmp, cDelimeter[0]); }	//以分隔符分拆sLine（此函数会保留空串）
			else{ stringSplit(sLine, vsTmp, cDelimeter); } 						//以分隔符分拆sLine（此函数会忽略空串）

			if (vsTmp.size() > 0) vvsData.push_back(vsTmp);

			vsTmp.clear();
			cout << '\t' << ++i << "...\r";
		}

		fp.close();
		fp.clear();
		cout << endl;

		//数据有效性检查
		if (verify){
			k = vvsData[0].size();
			for (i = 1; i < (int)vvsData.size(); i++) {
				if (vvsData[i].size() != k) {
					char cs[100];

					sprintf(cs, "The number of columns does not match to the first in row %d.", i);
					fetalError(cs, clsParas);
				}
			}
		}

		cout << endl << "The file " << fIn << " has been read successfully." << endl;
		clsParas->fpLog << "The file " << fIn << " has been read successfully." << endl;
	}

	/********************************************
	* 从vStr中以sSep为分隔符取从uStart（含）到uEnd（含）
	* 之间的若干列（列号从0开始）
	* 返回：一个字符串（长度为0的字串表示错误）。
	* 如：
	* A B C D E
	* F G H I J
	* 取出从2列到3列，结果为：C D H I
	*********************************************/
	string getCols(vString &vStr, char cSep, int uStart, int uEnd)
	{
		if (uEnd < uStart) return "";

		int		i, uS, uE, uCnt, uLen;
		string	sRet = "", sTmp;

		for (i = 0; i < (int)vStr.size(); i++) {
			uLen = vStr[i].length();
			uCnt = 0;

			//找出起始字符
			uS = 0;
			while (1) {
				if (uCnt == uStart) break;

				if (uS >= uLen) {
					return "";
				}
				else if (vStr[i][uS] == cSep){
					uCnt++;
				}

				uS++;
			}
			//找出结束字符
			uE = uS + 1;
			while (1) {
				if (uCnt == uEnd + 1) break;

				if (uE > uLen + 1) {
					return "";
				}
				else if (vStr[i][uE] == cSep || vStr[i][uE] == '\n' || vStr[i][uE] == '\0'){
					uCnt++;
				}

				uE++;
			}

			uE--;

			if (uE > uLen || (uE == uLen && vStr[i][uE - 1] == cSep)) return "";

			sTmp.resize(uE - uS);
			uCnt = 0;

			for (; uS < uE; uS++){ sTmp[uCnt++] = vStr[i][uS]; }

			sRet += sTmp + cSep;
		}

		sRet = sRet.substr(0, sRet.length() - 1);		//去除最后一个分隔符

		return sRet;
	}

	/********************************************
	* vvChar 矩阵转置
	*********************************************/
	void vvcTranspose(vvChar &In, vvChar &Out)
	{
		int		row, col, i, j;
		vChar	vc;

		row = In.size();
		col = In[0].size();

		vc.resize(row);
		for (i = 0; i < col; i++) {
			for (j = 0; j < row; j++) {
				vc[j] = In[j][i];
			}
			Out.push_back(vc);
		}
		vChar().swap(vc);
	}

	/********************************************
	* 预处理ped格式数据（重载+1）。
	* vvcPed = 输入/输出基因型矩阵（样本数行*2SNP列，不含表型列）
	* vvsMap = 输入/输出MAP数据
	* clsParas = 程序参数
	* bMap = 是否同时处理MAP数据
	* ret = 返回信息（无错为true，false表示致命性错误）
	* 注： 函数不做归一化
	*********************************************/
	bool preprocessPed(vvChar &vvcPed, vvString &vvsMap, coPLINK::parameters *clsParas, bool bMap, string &ret)
	{
		int					i, j, m, uSNP, uSampleCnt, uOffset;
		string				sTmp;
		vvString::iterator	itr;
		sHWE_MAF_err		sErr = { 0, 0, 0 };
		int					iErr;
		char				cs[10];

		uSampleCnt = vvcPed.size();
		uSNP = vvcPed[0].size();		// SNP数*2

		if (!clsParas->bNormalize) {
			// 等位基因个数检查（检查每个个体的等位基因个数是否为偶数且个数是否相等）
			if ((float)(uSNP / 2) != (float)uSNP / 2) {		// 个体基因数非偶数
				cout << "The SNPs of individual 1 are not in pairs." << endl;
				ret = "Fatal error in preprocessing: The SNPs of individual 1 are not in pairs.";
				return false;
			}
			else{
				for (i = 0; i < uSampleCnt; i++){
					if (vvcPed[i].size() != uSNP){
						cout << "The number of SNPs of individual " << i << " does not match the first." << endl;
						sprintf(cs, "%d", i);
						ret = "Fatal error in preprocessing: The number of SNPs of individual ";
						ret += cs;
						ret += " does not match the firs.";
						return false;
					}
				}
			}
		}

		uSNP /= 2;	//SNP个数
		if (bMap) {
			if (vvsMap.size() != uSNP) {
				cout << "The SNP counts of ped and map does not match." << endl;
				ret = "Fatal error in preprocessing: The SNP counts of ped and map does not match.";
				return false;
			}

			itr = vvsMap.begin();	//指向vvsMap第一行
		}
		
		cout << "It is total " << uSNP << " SNPs before HWE and MAF test." << endl;
		clsParas->fpLog << "Start HWE and MAF test:\n\tIt is total " << uSNP << " SNPs before HWE and MAF test." << endl;

		uOffset = 0;
		sTmp.reserve(uSampleCnt * 4 - 1);
		m = 1;

		for (i = 0; i < uSNP; i++, m++) {
			// 组装SNP字串
			sTmp = "";
			for (j = 0; j < uSampleCnt - 1; j++) {
				sTmp += vvcPed[j][2 * i];
				sTmp += DELIMITER3;
				sTmp += vvcPed[j][2 * i + 1];
				sTmp += DELIMITER3;
			}

			sTmp += vvcPed[j][2 * i];
			sTmp += DELIMITER3;
			sTmp += vvcPed[j][2 * i + 1];

			iErr = testHWE_MAF(sTmp, clsParas);
			if (iErr) {						//HWE或MAF检验错误
				switch (iErr) {
				case HWE_ERR:
				{
					sErr.iHWEerr++;
					clsParas->fpLog << "The " << m << "-th SNP HWE test error." << endl;
					break;
				}
				case MAF_ERR:
				{
					sErr.iMAFerr++;
					clsParas->fpLog << "The " << m << "-th SNP MAF test error." << endl;
					break;
				}
				case MISSING_ERR:	
				{
					sErr.iMISSINGerr++;
					clsParas->fpLog << "The missing allele rate of " << m << "-th SNP in HWE test error." << endl;
					break;
				}
				case NULL_ERR:
				{
					clsParas->fpLog << "The " << m << "-th SNP has not any alleles." << endl;
					break;
				}
				default:
					break;
				}

				deleteCols(vvcPed, ' ', 2 * i, 2 * i + 1);	// delete erring SNP
				cout << "\tSNP " << m << " failed in MAF and HWE testing." << endl;

				i--;
				uSNP--;

				if (bMap) {
					vvsMap.erase(itr + uOffset);	//删除itr + uOffset行
					if (uOffset == 0){
						itr = vvsMap.begin();		//删除了首行，需重新指向首行
					}
				}
			}
			else{
				uOffset++;
			}

			cout << '\t' << ceil((float)i * 100 / uSNP) << "% completed.\r";
		}

		cout << "\t100% completed." << endl;
		uSNP = vvcPed[0].size() / 2;
		
		if (uSNP == 0){
			ret = "It has not any SNP after preprocessing.";
			return false;
		}

		cout << "It is total " << uSNP << " SNPs after HWE and MAF test." << endl;
		clsParas->fpLog << "\tIt is total " << uSNP << " SNPs after HWE and MAF test." << endl;
		clsParas->fpLog << "\tHWE Err. with threshold " << clsParas->dHweCutoff << ": " << sErr.iHWEerr << endl;
		clsParas->fpLog << "\tMAF Err. with threshold " << clsParas->dMafSnpCutoff << ": " << sErr.iMAFerr << endl;
		clsParas->fpLog << "\tAlleles Missing Rate of SNP Err. with threshold " << clsParas->dMafSnpCutoff << ": " << sErr.iMISSINGerr << endl;
		clsParas->fpLog << "HWE and MAF test End." << endl;

		return true;
	}


	/********************************************
	* 为ped格式数据随机生成性别。
	* vsPed = 输入/输出基因数据
	* uSeed = 随机数种子
	*********************************************/
	void sexPed(vString &vsPed, uint uSeed)
	{
		CRandomMersenne crnd(uSeed);
		int				i, uSexPos;

		uSexPos = AlignPedPos(vsPed, PLNK_PED_SEX_COL);

		for (i = 0; i < (int)vsPed.size(); i++){
			vsPed[i][uSexPos] = I2C((int)crnd.IRandom(1, 2));		//sex。随机生成
		}

		//把“对齐”操作中加入的多余空格删除
		for (i = 0; i < (int)vsPed.size(); i++){ trimRedundance(vsPed[i]); }
	}

	/********************************************
	* 预处理ped格式数据。
	* vsPed = 输入/输出基因数据
	* vvsMap = 输入/输出MAP数据
	* clsParas = 程序参数
	* bMap = 是否同时处理MAP数据
	* ret = 返回信息（无错为true）
	*********************************************/
	bool preprocessPed(vString &vsPed, vvString &vvsMap, coPLINK::parameters *clsParas, bool bMap, string &ret)
	{
		int				i, j, m, uSNP, uOffset, uLen, uMyStart;
		string				sTmp;
		vvString::iterator	itr;
		vString::iterator	itrPed;
		sHWE_MAF_err		sErr = { 0, 0, 0 };
		int					iErr;
		vString				vsHD, vsTmp;
		bool				bOk;
		char				cs[10];

		//之前的操作（读文件操作）已把多个连续的分隔符（空格或TAB）变成只有一个！！！

		for (i = 0; i < (int)vsPed.size(); i++){
			vsPed[i] = replaceChar(vsPed[i], DELIMITER2, DELIMITER3);		//把所有TAB替换成空格
		}

		if (!clsParas->bNormalize) {
			//修正vsData，即把等位基因字符数多于1个者视为缺失；同时作等位基因个数检查（检查每个个体的等位基因个数是否为偶数）
			uMyStart = AlignPedPos(vsPed, PLNK_PED_GENOTYPE_COL);		//对齐等位基因数据
			bOk = true;
			for (i = 0; i < (int)vsPed.size(); i++) {
				uLen = vsPed[i].length();

				for (j = uMyStart; j < uLen; j += 4) {
					if (j + 1 < uLen && vsPed[i][j + 1] != DELIMITER3)		//vsPed[i][j]处的等位基因字符数>1
					{
						for (m = j + 1; m < (int)vsPed[i].length(); m++){
							if (vsPed[i][m] == DELIMITER3) break;
						}

						vsPed[i] = vsPed[i].substr(0, j + 1) + vsPed[i].substr(m);	//去除多于1的字符
						uLen -= m - (j + 1);

						if (j + 2 >= uLen) {
							bOk = false;
							break;
						}

						vsPed[i][j] = PLNK_PED_MISSING_ALLELE2;
						vsPed[i][j + 2] = PLNK_PED_MISSING_ALLELE2;
					}

					if (j + 3 < uLen && vsPed[i][j + 3] != DELIMITER3)		//vsPed[i][j+2]处的等位基因字符数>1
					{
						for (m = j + 3; m < (int)vsPed[i].length(); m++){
							if (vsPed[i][m] == DELIMITER3) break;
						}

						vsPed[i] = vsPed[i].substr(0, j + 3) + vsPed[i].substr(m);	//去除多于1的字符
						uLen -= m - (j + 3);

						if (j + 2 >= uLen) {
							bOk = false;
							break;
						}

						vsPed[i][j] = PLNK_PED_MISSING_ALLELE2;
						vsPed[i][j + 2] = PLNK_PED_MISSING_ALLELE2;
					}
				}
				if (!bOk) {
					cout << "The number of alleles in the " << i + 1 << "-th individual is not even." << endl;
					sprintf(cs, "%d", i + 1);
					ret = "The number of alleles in the ";
					ret += cs;
					ret += "-th individual is not even in preprocessing ped.";
					return false;
				}
			}

			//数据有效性检查（前一步只做了部分检查）。数据已“对齐”且已把多于1个字符的等位基因改为MISSING（只一个字符），所以只要简单地检查各行长度即可
			m = vsPed.size();		//行数，即个体数
			j = vsPed[0].length();
			for (i = 0; i < m; i++) {
				if (vsPed[i].length() != j) {
					cout << "The number of alleles in the " << i + 1 << "-th individual does not equal to the first." << endl;
					sprintf(cs, "%d", i + 1);
					ret = "The number of alleles in the ";
					ret += cs;
					ret += "-th individual does not equal to the first in preprocessing ped.";
					return false;
				}
			}

			//把“对齐”操作中加入的多余空格删除
			for (i = 0; i < (int)vsPed.size(); i++){ trimRedundance(vsPed[i]); }
		}
		else {
			if (!NormalizePed(vsPed, PLNK_PED_GENOTYPE_COL, ret)) return false;
		}

		sTmp = DELIMITER3;
		i = stringCount(vsPed[0], sTmp);				//vsPed[0]中空格的个数
		uSNP = ((i - PLNK_PED_GENOTYPE_COL) + 1) / 2;	//SNP个数

		if (bMap) {
			if (vvsMap.size() != uSNP) {
				cout << "The structure of ped does not match map." << endl;
				ret = "Fatal error: The structure of ped does not match map.";
				return false;
			}

			itr = vvsMap.begin();					//指向vvsMap第一行
		}

		/*************************************************/
		//取出前PLNK_PED_GENOTYPE_COL列
		for (i = 0; i < (int)vsPed.size(); i++) {
			sTmp = "";
			uOffset = j = 0;
			for (uOffset = 0; uOffset < (int)vsPed[i].length(); uOffset++) {
				if (vsPed[i][uOffset] == DELIMITER3){ j++; }

				if (j == PLNK_PED_GENOTYPE_COL) {
					uOffset++;
					sTmp = vsPed[i].substr(0, uOffset);
					vsPed[i] = vsPed[i].substr(uOffset);
					vsHD.push_back(sTmp);
					break;
				}
			}
		}
		//vsPed转置

		for (i = 0; i < (int)vsPed[0].length(); i += 4) {
			sTmp = "";
			for (j = 0; j < (int)vsPed.size(); j++) {
				sTmp += DELIMITER3;
				sTmp += vsPed[j][i];
				sTmp += DELIMITER3;
				sTmp += vsPed[j][i + 2];
			}
			vsTmp.push_back(sTmp);
		}
		vsPed.clear();
		vString().swap(vsPed);

		uOffset = 0;
		itrPed = vsTmp.begin();
		cout << "There are " << uSNP << " SNPs before HWE and MAF test." << endl;
		clsParas->fpLog << "Start HWE and MAF test:\n\tThere are " << uSNP << " SNPs before HWE and MAF test." << endl;

		m = 1;
		for (i = 0; i < uSNP; i++, m++) {
			iErr = testHWE_MAF(vsTmp[i], clsParas);
			if (iErr) {						//HWE或MAF检验错误
				switch (iErr) {
				case HWE_ERR:
				{
					sErr.iHWEerr++;
					clsParas->fpLog << "The " << m << "-th SNP HWE test error." << endl;
					break;
				}
				case MAF_ERR:
				{
					sErr.iMAFerr++;
					clsParas->fpLog << "The " << m << "-th SNP MAF test error." << endl;
					break;
				}
				case MISSING_ERR:
				{
					sErr.iMISSINGerr++;
					clsParas->fpLog << "The missing allele rate of " << m << "-th SNP HWE test error." << endl;
					break;
				}
				case NULL_ERR:
				{
					clsParas->fpLog << "The " << m << "-th SNP has not any alleles." << endl;
					break;
				}
				default:
					break;
				}

				vsTmp.erase(itrPed + uOffset);
				cout << "\tSNP " << m << " failed in MAF and HWE testing." << endl;

				if (uOffset == 0){
					itrPed = vsTmp.begin();	//删除了首行，需重新指向首行
				}

				i--;
				uSNP--;

				if (bMap) {
					vvsMap.erase(itr + uOffset);			//删除itr + uOffset行
					if (uOffset == 0){
						itr = vvsMap.begin();	//删除了首行，需重新指向首行
					}
				}
			}
			else{
				uOffset++;
			}

			cout << '\t' << ceil((float)i * 100 / uSNP) << "% completed.\r";
		}
		cout << "\t100% completed." << endl;
		uSNP = vsTmp.size();

		if (uSNP == 0){
			ret = "It has not any SNP after preprocessing.";
			return false;
		}

		//重新生成vsPed
		uOffset = 0;

		for (i = 0; i < (int)vsTmp[0].length(); i += 4) {
			sTmp = vsHD[uOffset++];

			for (j = 0; j < uSNP; j++) {
				sTmp += DELIMITER3;
				sTmp += vsTmp[j][i];
				sTmp += DELIMITER3;
				sTmp += vsTmp[j][i + 2];
			}

			vsPed.push_back(sTmp);
		}
		vsTmp.clear();

		/***********以下写法比上述写法略慢****************/
		//uOffset = 0;
		//cout << "There are " << uSNP << " SNPs before HWE and MAF test." << endl;
		//fp << "Start HWE and MAF test:\n\tThere are " << uSNP << " SNPs before HWE and MAF test." << endl;
		//for(i = PLNK_PED_GENOTYPE_COL; i < PLNK_PED_GENOTYPE_COL + uSNP * 2; i += 2) {		//逐列处理（以空格作为列分隔符）
		//	sTmp = getCols(vsPed, DELIMITER3, i, i + 1);
		//	iErr = testHWE_MAF(sTmp);
		//	if(iErr) {						//HWE或MAF检验错误
		//		switch(iErr) {
		//			case HWE_ERR:
		//				sErr.uHWEerr++;
		//				break;
		//			case MAF_ERR:
		//				sErr.uMAFerr++;
		//				break;
		//			case MISSING_ERR:
		//				sErr.uMISSINGerr++;
		//				break;
		//		}
		//		deleteCols(vsPed, DELIMITER3, i, i+1);
		//		i -= 2;
		//		uSNP--;
		//		if(bMap) {
		//			vvsMap.erase(itr + uOffset);			//删除itr行
		//			if(uOffset == 0) itr = vvsMap.begin();	//删除了首行，需重新指向首行
		//		}
		//	}else uOffset++;
		//	cout << "                                       \r";
		//	cout << "i = " << i << ";uSNP= " << uSNP << ";uOffset= " << uOffset;
		//}
		//sTmp = DELIMITER3;
		//i = stringCount(vsPed[0], sTmp);					//vsPed[0]中空格的个数
		//uSNP = ((i - PLNK_PED_GENOTYPE_COL) + 1) / 2;		//SNP个数

		cout << "There are " << uSNP << " SNPs after HWE and MAF test." << endl;
		clsParas->fpLog << "\tThere are " << uSNP << " SNPs after HWE and MAF test." << endl;
		clsParas->fpLog << "\tHWE Err. with threshold " << clsParas->dHweCutoff << ": " << sErr.iHWEerr << endl;
		clsParas->fpLog << "\tMAF Err. with threshold " << clsParas->dMafSnpCutoff << ": " << sErr.iMAFerr << endl;
		clsParas->fpLog << "\tMISSING Err. with threshold " << clsParas->dMafSnpCutoff << ": " << sErr.iMISSINGerr << endl;
		clsParas->fpLog << "HWE and MAF test End." << endl;

		return true;
	}

	/********************************************
	* 读取PLINK tped格式
	* vsTped = tped文件内容（不含前4列）
	* vsMap = map文件内容（tped文件的前4列）
	* vsTfam = tfam文件内容
	* clsParas = 程序输入参数类指针
	* ********************************************
	* tped格式包含三个文件：tped、tfam和tsnp文件（可选）
	* tped 文件格式：
	* 每行一个SNP
	* 如：(N-missing)
	*	1	snp1	0	1	A	A	G	T
	*	1	snp2	0	2	A	C	T	G
	*	1	snp3	0	3	C	C	G	G
	*	...
	*
	* 前4列即是ped格式中的map文件所包含的4列:
	*  map文件各列含义：
	*  1 - chromosome (1-22, X, Y or 0 if unplaced)
	*  2 - rs# or snp identifier
	*  3 - Genetic distance (morgans)
	*  4 - Base-pair position (bp units)
	* 从第5列起为samples的基因型（samples的信息由tfam文件说明）
	*
	* tfam 文件格式：
	* 每行一个sample
	* 如：
	*	FAM_CAD	WTCCC79589	0	0	1	0
	*	FAM_CAD	WTCCC64372	0	0	2	0
	*	FAM_CAD	WTCCC79286	0	0	1	0
	*	...
	*
	*  各列含义：
	*  1 - 家系ID
	*  2 - sample ID
	*  3 - 父亲ID
	*  4 - 母亲ID
	*  5 - 性别（1=男、2=女、0=未知）
	*  6 - 表型（1=对照、2=疾病、0=未知）
	*
	* tsnp 文件格式：
	* 每行一个SNP
	*	 如：
	*		1	15385344	EGAV00000562210	SNP_A-1938722	rs761296
	*		1	243847383	EGAV00007281350	SNP_A-4217222	rs11582843
	*		...
	*	  各列含义（本程序不关心前3列）：
	*	  1 - chr. No.
	*	  2 - base-pair position
	*     3 - 应该是叫“EGAV”号，可能是检测芯片的一个代号
	*	  4 - SNP LABEL
	*	  5 - RS#
	*************************************/
	void readTped(vString &vsTped, vString &vsMap, vString &vsTfam, parameters *clsParas)
	{
		string			sLine, sTmp, fn, s;
		int				i, j, k, uErr, m;
		fstream			fp;
		vString			vsPed;
		sHWE_MAF_err	sErr = { 0, 0, 0 };
		int				iErr;
		bool			bAlt;


		//读取tped文件。
		/********* tped 文件格式 ************
		* 每行一个SNP
		* 如：(N-missing)
		1	snp1	0	1	A	A	G	T
		1	snp2	0	2	A	C	T	G
		1	snp3	0	3	C	C	G	G
		...

		* 前4列即是ped格式中的map文件所包含的4列:
		*  map文件各列含义：
		*  1 - chromosome (1-22, X, Y or 0 if unplaced)
		*  2 - rs# or snp identifier
		*  3 - Genetic distance (morgans)
		*  4 - Base-pair position (bp units)
		* 从第5列起为samples的基因型（samples的信息由tfam文件说明）
		*************************************/

		if (clsParas->bFixPhenotype) {
			cout << "\tPhenotypes were specified as " << clsParas->cPhenotype << endl;
			clsParas->fpLog << "\tPhenotypes were specified as " << clsParas->cPhenotype << endl;
		}

		sLine = getFn(clsParas->sInputFilename, ".tped");

#ifdef TEST_PERFORMANCE
		bool	b;
		clsParas->uInSize = getFileSize(sLine, &b);
#endif

		openStreamFile(fp, sLine.c_str(), ios::in);
		uErr = 0;
		m = 0;
		while (!fp.eof() && fp.good()) {
			sTmp = "";

			//取前4列
			for (i = 0; i < 3; i++) {
				sLine = "";
				if (!fp.eof() && fp.good()){ fp >> sLine; }
				else{ break; }

				if (sLine.length() > 0){ sTmp += sLine + DELIMITER3; }
			}

			sLine = "";
			if (!fp.eof() && fp.good()){ fp >> sLine; }
			else{ break; }

			if (sLine.length() > 0){ sTmp += sLine; }	//最后一个不要空格

			if (fp.eof() || !fp.good()) break;

			if (sLine.length() == 0) continue;

			sLine = "";
			getline(fp, sLine);							//剩余部分（基因型数据）
			trimString(sLine);							//删除前后空格及TAB
			trimRedundance(sLine);						//删除中间多余空格及TAB（只保留一个）

			if (sLine.length() == 0) continue;

			//查找MISSING。两个（含）以上字符被认为是MISSING。基因数据可能存在用两个或更多字符表示MISSING的情况
			j = sLine.length();
			bAlt = true;
			for (i = 1; i < j; i++) {
				if (sLine[i] != DELIMITER3 && sLine[i] != DELIMITER2 && bAlt) {
					for (k = i; k < j; k++){
						if (sLine[k] == DELIMITER3 || sLine[k] == DELIMITER2) break;	//下一个分隔符
					}

					sLine = sLine.substr(0, i - 1) + PLNK_PED_MISSING_ALLELE2 + sLine.substr(k);
					j -= k - i;
				}
				bAlt = !bAlt;
			}

			if (clsParas->bPreprocess) {
				iErr = testHWE_MAF(sLine, clsParas);
				if (iErr) {				//HWE或MAF错误
					uErr++;
					switch (iErr) {
					case HWE_ERR:
					{
						sErr.iHWEerr++;
						clsParas->fpLog << "The " << m + 1 << "-th SNP HWE test error." << endl;
						break;
					}
					case MAF_ERR:
					{
						sErr.iMAFerr++;
						clsParas->fpLog << "The " << m + 1 << "-th SNP MAF test error." << endl;
						break;
					}
					case MISSING_ERR:
					{
						sErr.iMISSINGerr++;
						clsParas->fpLog << "The missing allele rate of " << m + 1 << "-th SNP HWE test error." << endl;
						break;
					}
					case NULL_ERR:
					{
						clsParas->fpLog << "The " << m + 1 << "-th SNP has not any alleles." << endl;
						break;
					}
					default:
						break;
					}

					cout << '\t' << ++m << "...\r";
					continue;
				}
			}
			vsTped.push_back(sLine);
			vsMap.push_back(sTmp);						//保存用于生成MAP文件的各行
			cout << '\t' << ++m << "...\r";
		}
		sLine = "";
		fp.close();
		fp.clear();
		cout << endl;

		if (clsParas->bPreprocess) {
			cout << "There are " << uErr << " errors to HWE and MAF test." << endl;
			clsParas->fpLog << "There are " << uErr + vsTped.size() << " SNPs before HWE and MAF test." << endl;
			clsParas->fpLog << "There are " << vsTped.size() << " SNPs after HWE and MAF test." << endl;
			clsParas->fpLog << "\tHWE Err. with threshold " << clsParas->dHweCutoff << ": " << sErr.iHWEerr << endl;
			clsParas->fpLog << "\tMAF Err. with threshold " << clsParas->dMafSnpCutoff << ": " << sErr.iMAFerr << endl;
			clsParas->fpLog << "\tMISSING Err. with threshold " << clsParas->dMafSnpCutoff << ": " << sErr.iMISSINGerr << endl;
		}
		else{
			clsParas->fpLog << "There are " << vsTped.size() << " SNPs in total." << endl;
		}

		//数据有效性检查
		if (vsMap.size() == 0 || vsTped.size() == 0) {
			fetalError("Have no data in TPED. May be a incorrect Threshold.", clsParas);
		}

		if (vsMap.size() != vsTped.size()) {
			fetalError("The structure of the tped file is wrong, check please.", clsParas);
		}

		j = vsTped[0].length();
		for (i = 1; i < (int)vsTped.size(); i++) {
			if (vsTped[i].length() != j) {
				char cs[100];
				sprintf(cs, "The rows' length of tped file are different in %d-th line.", i + 1);
				fetalError(cs, clsParas);
			}
		}


		/**************** PLINK tped文本格式（TSNP文件）*************
		每行一个SNP
		如：
		1	15385344	EGAV00000562210	SNP_A-1938722	rs761296
		1	243847383	EGAV00007281350	SNP_A-4217222	rs11582843
		...
		各列含义：
		1、2、3 - 与本程序无关
		4 - SNP LABEL
		5 - RS#
		*************************************************************/
		//输出map文件
		for (i = 0; i< (int)vsMap.size(); i++) {	//整理
			//replaceChar(vsMap[i], DELIMITER2, DELIMITER3);	//把所有TAB用空格替换
			trimRedundance(vsMap[i], true);						//删除多余的TAB或空格（只留一个）,所有TAB用空格替换
		}

		sTmp = getFn(clsParas->sInputFilename, ".tsnp");
		if (access(sTmp.c_str(), 0) != -1) {	//存在tsnp文件
			cout << "Reading " << sTmp << " ..." << endl;

			openStreamFile(fp, sTmp.c_str(), ios::in);
			m = 0;
			while (getline(fp, sLine)) {
				trimRedundance(sLine, true);	//删除多余的TAB或空格（只留一个）,所有TAB用空格替换

				if (sLine.length() == 0) continue;

				vsTfam.push_back(sLine);		// 借用vsTfam
				cout << '\t' << ++m << "...\r";
			}

			sLine = "";
			fp.close();
			fp.clear();
			cout << endl;

			s = " ";
			for (i = 0; i < (int)vsMap.size(); i++) {
				getStringN(vsMap[i], s, 1, sTmp);
				sLine = "";
				for (j = 0; j < (int)vsTfam.size(); j++) {
					if (vsTfam[j].find(sTmp) != string::npos) {
						getStringN(vsTfam[j], s, 3, sLine);
						break;
					}
				}

				if (sLine.length() > 0){
					replace_all_distinct(vsMap[i], sTmp, sLine);
				}
			}
			vsTfam.clear();
		}

		//读取tfam文件（ped文件的前6列）。
		/********* tfam 文件格式 ************
		* 每行一个sample
		* 如：
		FAM_CAD	WTCCC79589	0	0	1	0
		FAM_CAD	WTCCC64372	0	0	2	0
		FAM_CAD	WTCCC79286	0	0	1	0
		...

		*  各列含义：
		*  1 - 家系ID
		*  2 - sample ID
		*  3 - 父亲ID
		*  4 - 母亲ID
		*  5 - 性别（1=男、2=女、0=未知）
		*  6 - 表型（1=对照、2=疾病、0=未知）
		*************************************/

		sLine = getFn(clsParas->sInputFilename, ".tfam");
		openStreamFile(fp, sLine.c_str(), ios::in);
		vsTfam.clear();
		m = 0;
		while (!fp.eof() && fp.good()) {
			sLine = "";
			getline(fp, sLine);							//剩余部分（基因型数据）
			trimString(sLine);							//删除前后空格及TAB
			trimRedundance(sLine, true);				//删除中间多余空格及TAB（只保留一个）,TAB用空格替换
			//replaceChar(sLine, DELIMITER2, DELIMITER3);	//把TAB用空格替换

			//统计列数
			j = 1;
			for (i = 0; i < (int)sLine.length(); i++) {
				if (sLine[i] == DELIMITER3) j++;
			}

			if (j != PLNK_TFAM_COL_CNT) continue;

			if (clsParas->bFixPhenotype){
				sLine[sLine.length() - 1] = clsParas->cPhenotype;	//固定表型
			}

			vsTfam.push_back(sLine);
			cout << '\t' << ++m << "...\r";
		}
		sLine = "";
		fp.close();
		fp.clear();
		cout << endl;

		// 统计表型
		uErr = 0;
		for (i = 0; i < (int)vsTfam.size(); i++) {
			j = 0;
			for (k = 0; k< (int)vsTfam[i].length(); k++) {
				if (vsTfam[i][k] == ' ') {
					j++;
					if (j == PLNK_PED_PHENOTYPE_COL) break;
				}
			}

			if (PLNK_PED_CASE_PHENOTYPE == vsTfam[i][++k]){ uErr++; }		// 只取首字符统计casse
		}

		if (vsTped.empty()) {
			fetalError("Source file " + clsParas->sInputFilename + "has no any valid data.", clsParas);
		}

		clsParas->fpStat << ',' << clsParas->sInputFilename << ',' << uErr << ',' << vsTfam.size() - uErr << ',' << vsTped.size() << endl;

		cout << "Read OK. Includes " << uErr << " cases, " << vsTfam.size() - uErr << " controls and " << vsTped.size() << " SNPs. " << endl;
		clsParas->fpLog << "Read OK." << endl;
	}

	/********************************************
	* 把str中以cDelim为分隔符表示的第iCol列用cRep替换（列号从0开始）
	* 若列号超范围，则不作任何替换
	* 注：只用字符替换，若被替换列有多个字符，只替换首字符
	* 如：
	* str = "A B C wD E", cRep = 'x', cSep = ' ', iCol = 3
	* 结果为："A B C xD E"，即D仍然保留
	*********************************************/
	void replaceAllele(string &str, char cRep, char cDelim, int iCol)
	{
		if (iCol < 0) return;

		int	i;
		int		iCnt;

		iCnt = 0;
		for (i = 0; i < (int)str.length(); i++) {
			if (iCnt == iCol) {
				str[i] = cRep;
				break;
			}

			if (str[i] == cDelim) iCnt++;
		}
	}

	/********************************************
	* 替换矩阵中的missing字符为通用missing字符
	* vvcPed = Ped的基因型字符矩阵
	*********************************************/
	void replMissing4Ped(vvChar &vvcPed)
	{
		int i, j, s;

		s = vvcPed[0].size();
		for (i = 0; i < (int)vvcPed.size(); i++){
			for (j = 0; j < s; j++){
				if (vvcPed[i][j] == PLNK_PED_MISSING_ALLELE1
					|| vvcPed[i][j] == PLNK_PED_MISSING_ALLELE2
					|| vvcPed[i][j] == PLNK_PED_MISSING_ALLELE3
					|| vvcPed[i][j] == PLNK_PED_MISSING_ALLELE4)
				{
					vvcPed[i][j] = MISSING_ALLELE_CHR;
				}
			}
		}
	}

	/********************************************
	* 查找主要等位基因名称
	* vvcPed = Ped的基因型字符矩阵（要求MISSING已用通用MISSING替换）
	* res = 结果向量
	* seekMode = 查找方式（0 - 基于等位基因频率查找，频率高者为主要等位基因；
	*					   1 - 基于等位基因字母序查找，字母序最后者为主要等位基因（不考虑字母大小写，所以小写字母排在后）.
	* 返回值 = 主要等位基因的名称
	*********************************************/
	void seekMajorAlleles(vvChar &vvcPed, vChar &res, int seekMode)
	{
		char cA1, cA2, c;
		int i, j, uSNP, uSampleCnt, uA1, uA2;

		uSNP = vvcPed[0].size();	// SNP 列数
		res.resize(uSNP / 2);
		uSampleCnt = vvcPed.size();	// number of samplses
		if (seekMode == SEEK_MODE_FRQ) {		// 基于等位基因频率查找，频率高者为主要等位基因
			for (i = 0; i < uSNP; i += 2){	// each SNP
				uA1 = uA2 = 0;
				cA1 = cA2 = 0;
				for (j = 0; j < uSampleCnt; j++){	// scan one SNP
					if (vvcPed[j][i] == MISSING_ALLELE_CHR || vvcPed[j][i + 1] == MISSING_ALLELE_CHR) continue;

					if (cA1 == 0){
						uA1++;
						cA1 = vvcPed[j][i];
						if (cA1 == vvcPed[j][i + 1]){
							uA1++;
						}
						else if (cA2 == 0){
							uA2++;
							cA2 = vvcPed[j][i + 1];
						}
						else{
							uA2++;
						}
					}
					else if (cA2 == 0){
						uA2++;
						cA2 = vvcPed[j][i];
						if (cA2 == vvcPed[j][i + 1]){
							uA2++;
						}
						else{
							uA1++;
						}
					}
					else {
						if (cA1 == vvcPed[j][i]){ uA1++; }
						else{ uA2++; }

						if (cA1 == vvcPed[j][i + 1]){ uA1++; }
						else{ uA2++; }
					}
				}
				c = uA1 > uA2 ? cA1 : cA2;
				res[i / 2] = c;
			}
		}
		else if (seekMode == SEEK_MODE_LETTER) {	// 基于等位基因字母序查找，字母序最后者为主要等位基因（不考虑字母大小写，所以小写字母排在后）
			for (i = 0; i < uSNP; i += 2){	// each SNP
				c = 'A';
				for (j = 0; j < uSampleCnt; j++){	// scan one SNP
					if (vvcPed[j][i] == MISSING_ALLELE_CHR || vvcPed[j][i + 1] == MISSING_ALLELE_CHR) continue;

					if (vvcPed[j][i]>c){ c = vvcPed[j][i]; }

					if (vvcPed[j][i + 1]>c){ c = vvcPed[j][i + 1]; }
				}
				res[i / 2] = c;
			}
		}
	}

	/********************************************
	* 交换SNP处于“行”（每行一个SNP，每列一个样本）的基因型字符矩阵中主、次等位基因数相同的SNP
	* vvcData = （输入/输出）文件中的第4列及以后的数据（字符矩阵）
	* lt, rb = 左上角和右下角的位置（原点在左上角）
	* cAA, caa = character of AA and aa
	****************************************************
	如BEAM格式：
	ID	Chr  Pos		1 1 0 1 0 1 0 1 …
	rs0	chr1 738547		2 2 1 2 0 0 0 0 …
	rs1	chr1 5597094	0 1 0 0 2 2 0 0 …
	rs2	chrX 9424115	0 2 2 0 0 0 0 0 …
	rs3	chrY 13879818	0 0 0 0 0 2 2 0 …
	第1行第4列以后：case/control，0-control；1-case
	第2行及以后行的第4列以后：每行一个SNP：0-Aa 1-aa 2-AA <0-missing
	前3列：说明性内容
	其基因型矩阵不包含前3列，设其大小为m*n，则整个矩阵的lt(0,1)、rb(m-1,n-1)
	*****************************************************/
	void swapAllelsInRowSingle(vvChar& vvcData, Point *lt, Point *rb, char cAA, char caa)
	{
		int i, j, iA, ia;

		for (i = lt->y; i < rb->y + 1; i++){		// 按行逐SNP扫描
			iA = ia = 0;

			for (j = lt->x; j < rb->x + 1; j++){	// 按列逐样本扫描以统计SNPi主、次等位基因数（Aa和missing无需统计）
				if (vvcData[i][j] == cAA){ iA += 2; }

				if (vvcData[i][j] == caa){ ia += 2; }
			}

			if (ia > 0 && ia == iA){				// 主、次等位基因数相等，交换
				for (j = lt->x; j < rb->x + 1; j++){
					if (vvcData[i][j] == cAA){ vvcData[i][j] = caa; }
					else if (vvcData[i][j] == caa){ vvcData[i][j] = cAA; }
				}
			}
		}
	}

	/********************************************
	* 交换SNP处于“列”（每列一个SNP，每行一个样本）的基因型字符矩阵中主、次等位基因数相同的SNP
	* vvcData = （输入/输出）文件中的第4列及以后的数据（字符矩阵）
	* lt, rb = 左上角和右下角的位置（原点在左上角）
	* cAA, caa = character of AA and aa
	****************************************************
	如	MDR格式：
	X1	X2 …	X20	Class
	0	1 …	1	1
	0	1 …	0	0
	1	1 …	2	1
	0	1 …	1	0
	所有字符用tab分隔；
	第1到n-1列：每列为一个SNP；
	第n列：Class：0-control, 1-case；
	基因型数据：0-AA, 1-Aa, 2-aa, -1 = missing；
	第1行为表头，其余每行为一个个体。

	其基因型矩阵不包含第1行，设其大小为m*n，则整个矩阵的lt(0,1)、rb(m-1,n-1)
	*****************************************************/
	void swapAllelsInColSingle(vvChar& vvcData, Point *lt, Point *rb, char cAA, char caa)
	{
		int i, j, iA, ia;

		for (i = lt->x; i < rb->x + 1; i++){		// 按列逐SNP扫描
			iA = ia = 0;

			for (j = lt->y; j < rb->y + 1; j++){	// 按行逐样本扫描以统计SNPi主、次等位基因数（Aa和missing无需统计）
				if (vvcData[j][i] == cAA){ iA += 2; }

				if (vvcData[j][i] == caa){ ia += 2; }
			}

			if (ia > 0 && ia == iA){				// 主、次等位基因数相等，交换
				for (j = lt->y; j < rb->y + 1; j++){
					if (vvcData[j][i] == cAA){ vvcData[j][i] = caa; }
					else if (vvcData[j][i] == caa){ vvcData[j][i] = cAA; }
				}
			}
		}
	}

	/********************************************
	* 交换SNP处于“列”（每两列一个SNP，每行一个样本）的基因型字符矩阵中主、次等位基因数相同的SNP
	* vvcData = （输入/输出）字符矩阵
	* lt, rb = 左上角和右下角的位置（原点在左上角）
	* 基因型的列数不为偶数返回false
	****************************************************
	如* PED文件, N-missing（本程序定义）：
	* 1	 1	0	0	1	1	A	A	G	T ...
	* 2	 1	0	0	1	1	A	C	T	G ...
	* 3	 1	0	0	1	1	C	C	G	G ...
	* ...
	*
	* 前6列：Family ID, Individual ID, Paternal ID, Maternal ID, Sex (1=male; 2=female; other=unknown), Phenotype (1=unaffect; 2=affect)
	其基因型矩阵不包含前6列，设其大小为m*n，则整个矩阵的lt(0,1)、rb(m-1,n-1)
	*****************************************************/
	bool swapAllelsInColDouble(vvChar& vvcData, Point *lt, Point *rb)
	{
		int		i, j, ia[2];
		char	ca[2];

		if ((float)(rb->x - lt->x + 1) / 2 != (rb->x - lt->x + 1) / 2) return false;	// not even, return false

		for (i = lt->x; i < rb->x + 1; i += 2){		// 按列逐SNP扫描（每2列一个SNP）
			ia[0] = ia[1] = 0;
			ca[0] = ca[1] = '\0';

			for (j = lt->y; j < rb->y + 1; j++){	// 按行逐样本扫描以统计SNPi主、次等位基因数（Aa和missing无需统计）
				if (vvcData[j][i] == vvcData[j][i + 1]) {
					if (ca[0] == '\0'){
						ca[0] = vvcData[j][i];
						ia[0] += 2;
					}
					else if (ca[0] == vvcData[j][i]){
						ia[0] += 2;
					}
					else if (ca[1] == '\0'){
						ca[1] = vvcData[j][i];
						ia[1] += 2;
					}
					else if (ca[1] == vvcData[j][i]){
						ia[1] += 2;
					}
				}
			}
			if (ia[0] > 0 && ia[0] == ia[1]){		// 主、次等位基因数相等，交换
				for (j = lt->y; j < rb->y + 1; j++){
					if (vvcData[j][i] == ca[0]){ vvcData[j][i] = ca[1]; }
					else if (vvcData[j][i] == ca[1]){ vvcData[j][i] = ca[0]; }

					if (vvcData[j][i + 1] == ca[0]){ vvcData[j][i + 1] = ca[1]; }
					else if (vvcData[j][i + 1] == ca[1]){ vvcData[j][i + 1] = ca[0]; }
				}
			}
		}
		return true;
	}

	/****************************************************
	* 从Plink二进制格式文件数据中提取一个指定样本的基因型
	* sData = SNP数据
	* vcSample = 返回的基因型
	* uSampleNo = 样本在数据集中的列号（必须从0开始编号）
	* 返回值：无
	********************************************************/
	void getSample4Bin(InData *sData, vChar &vcSample, int uSampleNo)
	{
		uint		i, uCol, uNo, uAlleles;
		char		cAllele;

		//输入数据是二进制数据：每行为一个SNP之二进制值。每个uint存放sizeof(uint)个字节。sizeof(uint)个字节在uint中逆序存放
		//每字节存放4个基因型。每个基因型由两位二进制组成（00-AA、01-aA和Aa、11-aa、10-Missing）。4个基因型在字节中逆序存放

		//计算样本在数据中的列号uCol（从0开始编号）及样本在列中的编号uNo（从0开始编号）
		//每列数据是一个uint，每个uint存放sizeof(uint)个字节。每字节存放4个基因型。
		uCol = uSampleNo / (4 * sizeof(uint));			//样本号从0开始编号
		uNo = uSampleNo % (4 * sizeof(uint));
		vcSample.clear();
		vcSample.reserve(sData->vvuSNP.size() * 2);

		for (i = 0; i < sData->vvuSNP.size(); i++) {
			uAlleles = sData->vvuSNP[i][uCol];	//取样本所在列之一个uint基因型数据

			cAllele = uAlleles >> (2 * uNo);	//取出1个基因型样本所在字节（低2位即是）

			switch (cAllele & 0x3){
			case PLNK_BED_AA:
			{
				vcSample.push_back(ME_ALLELE_A);
				vcSample.push_back(ME_ALLELE_A);
				break;
			}
			case PLNK_BED_Aa_aA:
			{
				vcSample.push_back(ME_ALLELE_A);
				vcSample.push_back(ME_ALLELE_a);
				break;
			}
			case PLNK_BED_aa:
			{
				vcSample.push_back(ME_ALLELE_a);
				vcSample.push_back(ME_ALLELE_a);
				break;
			}
			case PLNK_BED_MISSING:
			{
				vcSample.push_back(MISSING_ALLELE_CHR);
				vcSample.push_back(MISSING_ALLELE_CHR);
				break;
			}
			}
		}
	}

	/****************************************************
	* 从Plink二进制格式文件数据中提取一个指定SNP
	* sData = SNP数据
	* vcSNP = 返回的SNP的BEAM格式
	* uRow = SNP在数据集中的行号
	* 返回值：无
	********************************************************/
	void getSNP4Bin(InData *sData, vChar &vcSNP, int uRow)
	{
		//二进制的bed文件格式（Plink v0.99以后，之前版本无前两个字节）：
		/*若ped文件内容是：
		1 1 0 0 1  1  A A  G T
		2 1 0 0 1  1  A C  T G
		3 1 0 0 1  1  C C  G G
		4 1 0 0 1  2  A C  T T
		5 1 0 0 1  2  C C  G T
		6 1 0 0 1  2  C C  T T
		其中前6列：
		Family ID
		Individual ID
		Paternal ID, Maternal ID
		Sex (1=male; 2=female; other=unknown)
		Phenotype (1=unaffect; 2=affect)

		map文件的内容是：
		1 snp1 0 1
		1 snp2 0 2

		则对应的bed文件是（前3个字节是固定的）：
		十六进制：	6C			1B			01			B8			0F			CA			0E
		二进制：	01101100	00011011	00000001	10111000	00001111	11001010	00001110

		从第四个字节开始是基因数据。基因数据编码方式：
		1. 每一个SNP中minor allele用0表示，major allele则用1表示。则有此等价
		表示：
		00 - aa		01 - Aa aA		11 - AA		10 - Missing
		2. 每个SNP用整数个字节不足补0。
		如上例之第二个SNP：G是minor allele、T是major allele，则表示为：01010011 01110000
		注意第二组“TG”也应表示为“01”，第二字节尾部补4个0以形成一个整
		字节
		3. 最后把每个字节逆序存放。
		*/

		//fam文件格式。
		/*
		bed文件仅记录了基因数据（即ped文件的从第7列开始的内容），fam文件则记录的是前6列
		*/

		//bim文件格式。
		/*
		bim文件是ped格式中的map文件的扩展，与上述map文件对应的bim文件：
		1	snp1	0	1	A	C
		1	snp2	0	2	G	T
		各列：
		0 - chromosome (1-22, X, Y or 0 if unplaced)
		1 - rs# or snp identifier
		2 - Genetic distance (morgans)
		3 - Base-pair position (bp units)
		4 - allele 1（minor allele）
		5 - allele 2（major allele）
		注：（1）若两个等位基因个数相同，则按字母序分别是minor allele和major allele
		（2）若只有一种等位基因，则用0标示缺失并作为minor allele
		（3）不判断缺失等位基因符号（如 0、-、N等），所有符号都作为正常符号处理
		*/

		int		i, j, k, uSampleNo;
		uint	uAlleles;
		char	cAllele, c;
		bool	bOK;

		//输入数据是二进制数据：每行为一个SNP之二进制值。每个uint存放sizeof(uint)个字节。sizeof(uint)个字节在uint中逆序存放
		//每字节存放4个基因型。每个基因型由两位二进制组成（00-AA、01-aA和Aa、11-aa、10-Missing）。4个基因型在字节中逆序存放
		uSampleNo = 0;
		bOK = false;
		vcSNP.clear();
		vcSNP.reserve(sData->vcPhenotypes.size());

		for (i = 0; i < (int)sData->vvuSNP[uRow].size(); i++) {
			uAlleles = sData->vvuSNP[uRow][i];	//取一个uint基因型数据

			for (j = 0; j < sizeof(uint); j++) {
				cAllele = uAlleles;					//取出1个基因型字节

				for (k = 0; k < 4; k++) {							//每个基因字节有4个基因型
					switch (cAllele & 0x3){
					case PLNK_BED_AA:
						c = BEAM_ALLELE_AA;
						break;

					case PLNK_BED_Aa_aA:
						c = BEAM_ALLELE_Aa_aA;
						break;

					case PLNK_BED_aa:
						c = BEAM_ALLELE_aa;
						break;

					case PLNK_BED_MISSING:
						c = MISSING_ALLELE_CHR;
						break;
					}
					vcSNP.push_back(c);

					uSampleNo++;
					if (uSampleNo >= (int)sData->vcPhenotypes.size()) {
						bOK = true;
						break;
					}

					cAllele = cAllele >> 2;		//每个基因型占2位（此处丢弃已处理完的2位）
				}
				if (bOK) break;

				uAlleles = uAlleles >> 8;		//丢弃已处理完的一个基因型字节
			}
			if (bOK) break;
		}
	}

	/*****************************************
	* vector<string> tped格式转置为ped格式
	* vsTped = tped文件内容（不含前4列，即纯基因型部分）
	* vsPed = 转置后的tped
	* iSampleCnt = 样本数
	******************************************/
	void vsTped2vsPed(vString &vsTped, vString &vsPed, int iSampleCnt)
	{
		int i, j;
		string	sLine, sTmp;

		//vsTped转置为vsPed

		//生成正好容纳一个SNP的基因型字符串，且预设所有的等位基因为MISSING（可防止MISSING而丢失）
		sLine = "";
		sTmp = PLNK_PED_MISSING_ALLELE2;
		sTmp += DELIMITER3;
		sTmp += PLNK_PED_MISSING_ALLELE2;
		sTmp += DELIMITER3;

		for (i = 0; i < (int)vsTped.size() - 1; i++){ sLine += sTmp; }

		sLine += PLNK_PED_MISSING_ALLELE2;
		sLine += DELIMITER3;
		sLine += PLNK_PED_MISSING_ALLELE2;

		vsPed.reserve(iSampleCnt);
		for (i = 0; i < iSampleCnt; i++) {
			for (j = 0; j < (int)vsTped.size(); j++) {
				sLine[j * 4] = vsTped[j][i * 4];
				sLine[j * 4 + 2] = vsTped[j][i * 4 + 2];
			}

			vsPed.push_back(sLine);
		}
		vsTped.clear();
	}

}
