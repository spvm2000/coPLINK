/****************************************************************
*                                                              *
*           coPLINK (c) 2020-2024 Han-Ming LIU                 *
*                                                              *
* This file is distributed under the GNU General Public        *
* License, Version 3.  Please see the file COPYING for more    *
* details                                                      *
*                                                              *
****************************************************************/


#ifndef _COPLINK_H_
#define _COPLINK_H_
#pragma once

#include <stdio.h>
#include <iostream>
#include <fstream>
#include <string>
#include <math.h>
#include <time.h>
#include <algorithm>
#include <sys/stat.h>
#include "../pubfun/publicFunctions.h"
#include "Args.h"
#include "Options.h"
#include "Formats.h"

//#define	TEST_PERFORMANCE	1							// 性能测试宏，正式发布注释之

#define	VERSION				"coPLINK (V4.1) by H.M. LIU et al. (Dec. 2020). Bug-report: lhmgzjx@163.com\n"	// 修改程序时，请修改此版本号
#define	STAT_FN				"coPLINK-RDstat.csv"						// 记录各种读文件时的操作参数、case数、ctrl数、SNP数
#define	CMP_FN				"coPLINK-cmp.csv"							// 文件比较时的结果文件名
#define	ARGS_FN4OTHER2PED	"coPLINK-2ped.txt"							// 任意格式转ped格式时的参数文件
#define	ARGS_FN4PED2OTHER	"coPLINK-2other.txt"						// ped格式转任意格式时的参数文件
#define	ARGS_FN4INSERT		"coPLINK-insert.txt"						// 为文本文件插入行/列时的参数文件

#define NUM_OF_DIGITS		15		//浮点转字符串时保留的数字位数

#define ADDITIVE			0		//加性模型代码
#define	DOMINANT			1		//显性模型代码
#define RECESSIVE			2		//隐性模型代码

#define HWE_THRESHOLD		0.001	//HWE检验之阈值，高于此则认为HWE检验通过
#define MAF_MISSING_THRESHOLD		0.05	//MAF和SNP等位基因缺失率检验之阈值，高于此则认为检验通过

#define	CMP_BY_TEXT			0		// 文本比较方式（不记录每个非一致的位置）
#define	CMP_BY_BIN			1		// 二进制比较方式（不记录每个非一致的位置）
#define	CMP_BY_TEXT_POS		2		// 文本比较方式（记录每个非一致的位置）
#define	CMP_BY_BIN_POS		3		// 二进制比较方式（记录每个非一致的位置）

/********************* 通用 ***********************/
#define	DELIMITER1			'-'		//字段分隔符1。减号
#define	DELIMITER2			'\t'	//字段分隔符2。TAB
#define	DELIMITER3			' '		//字段分隔符3。空格
#define	DELIMITER4			','		//字段分隔符3。逗号

#define	CHR_X_CODE			24		//X染色体代号
#define	CHR_Y_CODE			25		//Y染色体代号
#define	CHR_NONE_CODE		99		//无效染色体

#define	MISSING_ALLELE_CHR	'#'		//missing基因型（字符，因基因型用char表示，所以需要它）
/**************************************************/

using namespace std;
namespace coPLINK
{
	//程序支持的参数列表（新增的参数须放在INDICATOR之前，且顺序与前述代码定义一致）
	//const string validArgs	=	"-B2P,-P2B,-M2P,-P2M,-S2C,-C2S,-E2P,-P2E,-D2P,-P2D,-P2R,-P2S,-R2P,-I2E,-I2M,-T2P,-L2P,-G2P,-P2P,-SPL,-P2U,-P2I,-TAL,-P2T,-SED,-SEX,-MOD,-CHR,-MDL,-LGT,-PRE,-HWE,-NOR,-PHE,-SFN,-OF";
	//map<string, bool> mapArgs;	// first是参数名，second表示是否操作参数（true-是）全局变量要在cpp或类中声明，否则出错

	// 程序参数
	const string sArgs[] = {
		ARG_OPTIONS,		// 操作参数
		ARG_INDICATORS		//指示参数（必须置于操作参数之后）
	};

	// argument codes of the top 6 col.s in PED and the 4 col.s in MAP
	const string sArgCodes[] = { PED4MAP4 };

	//读取的数据之数据结构（不是所有读取都用此结构）
	struct InData {		// 注：事实上此结构只用在了二进制数据，非二进制数据不建议使用vvuSNP占用内存较多
		vector<vector<uint> >	vvuSNP;			//SNP数据（当输入数据是PLINK二进制数据时：每行为一个SNP之二进制值）。
		vChar					vcPhenotypes;	//顺序记录文件中各样本的表型
		vector<uint>			vuChrNo;		//与vsSNPlabels对应。染色体号
		vector<uint>			vuPos;			//与vsSNPlabels对应。基因对位置
		vString					vsSNPlabels;	//各SNP名称（数量应等于snpData列数）
	};

	struct Point {		// 点结构体。主要用于表示基因型矩阵坐标（坐标原点在左上角）
		int x;
		int y;
		Point(){
			x = 0;
			y = 0;
		}
	};

	class clsLinkage
	{
	public:
		vvChar	codePair;

	public:
		clsLinkage(){};
		~clsLinkage(){};
		bool addPair(char c1, char c2);
		char findCode(char c);
		void correctCodes(void);

	private:
		
	};

	/*************** 任意格式与ped互转结构体 ****************/
	// 更多说明见 Args.h，如有冲突，以 Args.h 为准
	struct sPed6_Map {	// ped 文件的前6列及 map 的4列
		int		type;		// type of the col.
		string	fn;			// filename
		int		no;			// row/col. No.
		int		posBegin;	// begin position
		int		posEnd;		// end position（此变量原设计要用户输入，后来改为自动计算。程序更改时并未更改部分多余程序行，只是保证了结果的正确性）
		char	delim;		// delimiter
		bool	inRow;		// true is row mode, or is col. mode, false is default
	};

	struct sGenotype {		// genotype position
		string	fn;			// filename
		Point	lt;			// left-top point, (0,0) is default
		Point	rb;			// right-bottom point（此变量原设计要用户输入，后来改为自动计算。程序更改时并未更改部分多余程序行，只是保证了结果的正确性）
		char	delim;		// delimiter, space is default
		int		SNPrcCnt;	// number of rows/col.s of each SNP. 0,1,2 and3 represent 2 col.s, one col., 2 rows and one row respectively 
		int		CurPedRow;	// current row No. in alleles of PED to output
		bool	twoAllele;	// true represents a genotype is composed of two alleles. true is default
		char	AA[2];		// chars of genotype AA, the BOOST's code or keeping source code is used if null
		char	Aa[2];		// chars of genotype Aa, the BOOST's code or keeping source code is used if null
		char	aa[2];		// chars of genotype aa, the BOOST's code or keeping source code is used if null
		char	Case;		// char of case, plink ped's is default
		char	Ctrl;		// char of ctrl, plink ped's is default
		char	male;		// char of males, plink ped's is default
		char	female;		// char of females, plink ped's is default
		string	missing;	// string of a missing allele, the ped's missings chars are used if null
	};

	struct sInsert {
		int		no;			// row/col. No.
		string	fn;			// destination filename
		int		posBegin;	// begin position
		char	delim;		// delimiter
		bool	inRow;		// true is row mode, or is col. mode, false is default
		vString vsInserts;	// items being inserted

		bool operator <(const sInsert &other)const   //升序排序（对结构体排序时，linux 不能用排序函数的形式使用sort，编译通不过，所以这里重载小于运算符）
		{
			return no < other.no;
		}
	};
	/******************************************************/

	class parameters
	{
	public:
		int		iOpCode;			// 操作参数在sArgs中下标
		//mString mArgs;
		string	sInputFilename;		//输入文件名
		string	sOutputFilename;	//输出文件名
		string	sFilename2;			//第二文件名（如拼接文件名(Ped文件)）
		string	sChrNo;				//染色体编号（1-22，X,Y）
		string	sMemo;				// 备注
		vector<sPed6_Map> vstPed6map;	// arguments of the 6 col. in PED and the 4 col. in MAP (other and ped converting each other)
		sGenotype struGenotype;		// genotype matrix arguments when other and ped converting each other
		vector<sInsert> vstInserts;	// rows/col.s being inserted into files with "other" format
		int		iModel;				//转LogicReg格式时的模型代码
		int		iMode;				//转SVMSNPs格式时的转换方式代码
		bool	bPreprocess;		//是否对生成结果作删除只有一种基因型及HWE错误的SNP数据的预处理(有此参数则表示是。参数值：0=仅做HWE检验，不保存结果、1=保存结果，默认为0)
		uint	uRndSeed;			//随机数种子（缺省或0为时钟）
		bool	bSex;				//为PLINK ped文本格式文件随机生成个体性别并归一化数据（当前仅用于-p2p。PLINK不会处理“未知性别”的个体）
		bool	bNormalize;			//当涉及到Plink Ped格式文件时（无论输入或输出），是否归一化ped格式(有此参数则表示是)
									//  所谓“归一化”，指把PED格式的基因型数据转换“D”与“d”的组合形式，且用一个空格
									//  分隔（会删除多余的）
		bool	bNorOn;				// 测试用开关（默认true）。部分转换会查找主、次等位基因（如--ped2boost），此时，若数据已归一化，那么当SNP的主、次等位基因个数相等时，
									//   则转换的查找该SNP的主、次等位基因与原主、次等位基因可能不同，从而导致数据的比较不相同。该开关用于关闭此类查找。
									//   当--nor后跟小于0的数则关闭查找（即bNorOn=false）。
		bool	bPed2BedNor;		// 测试用（默认false）。在PED2BED时，是否输出归一化的PED。当--nor后跟大于0的数则为true。
		bool	bFixPhenotype;		//转换时是否将表型固定为指定值（默认否）。
		char	cPhenotype;			//固定的表型值（默认0）
		double	dHweCutoff;			//HWE检验阀值（默认0.001。GWAS等多MARKER一般用0.001或0.0001，而单MARKER一般为0.01）
									//  此参数配合-pre使用。
		double	dMafSnpCutoff;		// MAF和SNP等位基因缺失率检验阈值
		bool	bSwap;				// 当SNP minor和major等位基因数量相同时，此时某些格式（如BOOST）会有两种可能的结果，
									//	此参数用于产生另一种可能的结果（仅支持--ped2boost、--bed2boost）。注：事实上，
									//	两种结果本质上是一样的。本参数的目的主要用以比较转换结果的一致性。
		bool	bHWEexact;			// 是否用精确法作HWE。默认否（即标准法）
		char	cDelimeter;			//  指定每行数据的分隔符（即列分隔符）（默认空格）
		int		iColumn[2];			// 指定列号。只有一个列号，则下标0表示；若是范围，则下标0~下标1之间（含头尾）
		int		iRow[2];			// 指定行号。只有一个行号，则下标0表示；若是范围，则下标0~下标1之间（含头尾）
		fstream	fpLog;				// 日志文件指针
		fstream	fpStat;				// 统计文件指针
#ifdef TEST_PERFORMANCE
		uint	uInSize;			// 输入文件大小（性能测试用）
#endif // TEST_PERFORMANCE


	public:
		parameters(int argc, char **argv);
		~parameters();

	protected:
		void addDefaultParas(string &sOption, mString &mapArgs);
		void displayHelp();										//显示帮助信息
		int findArg(string &arg);
		void checkArgs(int argc, char** argv);
		string findArgValue(mString& mapArgs, string searchedArg);
		void parseArgs(mString& mapArgs);
		void readArgs(string fn, string sType);
		void getMatrixArgs(vString &mat, string sType);
		void getVectorArgs(vvString &vec);
		void getInsertArgs(vvString &ins);
	};

#define HWE_ERR		1
#define MAF_ERR		2
#define	MISSING_ERR	3
#define NULL_ERR	-1
#define	TEST_PASS	0
	struct sHWE_MAF_err {	//错误类型计数器
		int	iHWEerr;
		int	iMAFerr;
		int	iMISSINGerr;
	};
	int testHWE_MAF(string &snp, parameters *clsParas);

	void readPed(vString& vsPed, parameters *clsParas, char cDelimeter = ' ');
	void readPed(vvChar& vvcPed, vString& vsPed6, parameters *clsParas, bool repl = false);
	void readBed(InData *sData, parameters *clsParas);
	void convertPed2BOOST(vChar &vcPhenotype, vvChar &vvcAllele, vvChar &vvcData, bool bSwap, bool bNorOn);
	void getSNP4Bin(InData *sData, vChar &vcSNP, int uRow);
	void getSample4Bin(InData *sData, vChar &vcSample, int uSampleNo);
	void readBOOST(vvChar& vvcData, parameters *clsParas);
	void readWithDelimeter(vvString& vvsData, string fIn, parameters *clsParas, const char* cDelimeter = " ", bool byChar = true, bool verify = true);
	void readTextByRow(vString& vsData, string fIn);
	void saveWithDelimeter(vvString& vvsData, string fOut, const char* cDelimeter = ",");
	void readME(vInt &viNo, vChar &vcPhenotypes, vvChar& vvcData, parameters *clsParas);
	void readBEAM(vvString& vvsBEAM3, vvChar& vvcData, parameters *clsParas);
	void readGeo(vvChar& vvcGEO, parameters *clsParas);
	void swapAllelsInRowSingle(vvChar& vvcData, Point *lt, Point *rb, char cAA, char caa);
	void swapAllelsInColSingle(vvChar& vvcData, Point *lt, Point *rb, char cAA, char caa);
	bool swapAllelsInColDouble(vvChar& vvcData, Point *lt, Point *rb);
	void readMDR(vvString& vvsMap, vvChar& vvcData, parameters *clsParas);
	void readPrettybase(vvString &vvsInfo, vvChar& vvcAlleles, parameters *clsParas);		// 早期版本的pretty格式重载+1
	int readPrettybaseSample(vInt &viPos, vString &vsChr, vString &vsSampleId, vvChar& vvcAlleles, parameters *clsParas);// 早期版本的pretty格式重载+2
	int readPrettybasePosition(vInt &viPos, vString &vsChr, vString &vsSaId, vvChar& vvcAlleles, parameters *clsParas);	// 以POSITION为基准（即认为每个SNP的POSTION不同）读取Prettybase格式的文本文件
	int getPrettyFormat(string fn);		// 判断Pretty文件格式
	string getSnpPos(string sIn);
	void seekMajorAlleles(vvChar &vvcPed, vChar &res, int seekMode);
	bool NormalizePed(vString &vsData, int uStartCol, string &ret);
	bool NormalizeAlleles2Col(vvChar &vvcData, parameters *clsParas, string &ret, bool repl = false, bool bPed = true);
	bool NormalizeAlleles1Col(vvChar &vvcData, parameters *clsParas, string &ret, bool repl = false, bool bPed = true);
	bool NormalizeAlleles2Row(vvChar &vvcData, parameters *clsParas, string &ret, bool repl = false, bool bPed = true);
	bool NormalizeAlleles1Row(vvChar &vvcData, parameters *clsParas, string &ret, bool repl = false, bool bPed = true);
	void sexPed(vString &vsPed, uint uSeed);
	bool preprocessPed(vString &vsPed, vvString &vvsMap, parameters *clsParas, bool bMap, string &ret);
	bool preprocessPed(vvChar &vvcPed, vvString &vvsMap, parameters *clsParas, bool bMap, string &ret);
	bool chkSample4Ped(vString &vsPed, parameters *clsParas);
	bool chkSample4Ped(vvChar &vvcPed, vString& vsPed6, parameters *clsParas, string &ret);
	int AlignPedPos(vString &vsData, int uStartCol);
	string getFn(string &fn, string extFn, bool bRpl = false);
	string addExt(string &fn, string extFn);
	string getCols(vString &vStr, char cSep, int uStart, int uEnd);
	bool deleteCols(vString &vStr, char cDelim, int iStart, int iEnd);
	bool deleteCols(vvChar &vvc, char cDelim, int uStart, int uEnd);
	char getAllele(string &str, char cDelim, int iCol);
	void replaceAllele(string &str, char cRep, char cDelim, int iCol);
	void normalizeRS_ID(vvString &vvsRS);
	void readTped(vString &vsTped, vString &vsMap, vString &vsTfam, parameters *clsParas);
	void vsTped2vsPed(vString &vsTped, vString &vsPed, int iSampleCnt);
	void analyzeSNP(vString &vsSNP, vvChar &vvcSNP, vvChar &vvcAllele, bool bNorOn);
	void readSVMSNPs(vvChar &vvcDAT, vChar &vcLAB, vString &vsSNP, parameters *clsParas);
	void SVMSNPs2PED(parameters *clsParas);
	void replMissing4Ped(vvChar &vvcPed);
	void fetalError(string sErrInfo, parameters *clsParas, bool dispInfo = true);
	void vvcTranspose(vvChar &In, vvChar &Out);
}

#endif
