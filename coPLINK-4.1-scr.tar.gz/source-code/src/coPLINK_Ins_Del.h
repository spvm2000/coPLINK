//////////////////////////////////////////////////////////////////
//                                                              //
//           coPLINK (c) 2020-2024 Han-Ming LIU                 //
//                                                              //
// This file is distributed under the GNU General Public        //
// License, Version 3.  Please see the file COPYING for more    //
// details                                                      //
//                                                              //
//////////////////////////////////////////////////////////////////

#ifndef _H_COPLINK_INS_DEL_H_
#define	_H_COPLINK_INS_DEL_H_

#include "coPLINK.h"

namespace coPLINK
{
	namespace InsDel
	{
		void fileDelete(parameters *clsParas);
		void fileInsert(parameters *clsParas);
		void fileInsert_Old(parameters *clsParas);
		bool sortNo(sInsert &p1, sInsert &p2);
		void coordinateTrans(vString &vsSrc, int *rowCnt, int *colCnt, parameters *clsParas);
		void saveOneRow(fstream &fp, int iRow, int colCnt, vString &vsSrc, int *iOffset, coPLINK::parameters *clsParas);
	}
}

#endif // !_H_COPLINK_INS_DEL_H_
