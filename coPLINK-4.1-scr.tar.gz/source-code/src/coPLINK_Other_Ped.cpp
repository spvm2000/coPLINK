//////////////////////////////////////////////////////////////////
//                                                              //
//           coPLINK (c) 2020-2024 Han-Ming LIU                 //
//                                                              //
// This file is distributed under the GNU General Public        //
// License, Version 3.  Please see the file COPYING for more    //
// details                                                      //
//                                                              //
//////////////////////////////////////////////////////////////////

#include "coPLINK_Other_Ped.h"
#include "../random/randomc.h"

namespace coPLINK
{
	/************************************
	* PLINK ped转任意其它格式
	* clsParas = 类参数指针
	*************************************/
	void Ped2Other(coPLINK::parameters *clsParas)
	{
		string		sLine;
		vString		vsPed6, vs;
		vvString	vvsPed6;
		vvString	vvsMAP;			// Whole col.s of Map
		vvChar		vvcAlleles;		// matrix of genotypes
		int			i, j;
		bool		b;

		// check INSERT section, it does not support inserting rows while inserting columns, and vice versa.后来修改了程序，可以同时了
		/*if ((int)clsParas->vstInserts.size() > 0){
			vs.resize(2);
			for (i = 0; i < (int)clsParas->vstInserts.size(); i++){
				vs[0] = clsParas->vstInserts[i].fn;
				vs[1] = clsParas->vstInserts[i].inRow ? "T" : "F";
				vvsMAP.push_back(vs);	// 借用vvsMAP
			}

			sort(vvsMAP.begin(), vvsMAP.end());

			char	c;

			sLine = vvsMAP[0][0];
			c = vvsMAP[0][1][0];

			for (i = 1; i < (int)vvsMAP.size(); i++){
				//cout << vvsMAP[i][0] << endl;	// in debuging

				if (vvsMAP[i][0] == sLine && vvsMAP[i][1][0] == c) continue;
				else if (vvsMAP[i][0] != sLine){
					sLine = vvsMAP[i][0];
					c = vvsMAP[i][1][0];
				}
				else{
					fetalError("Do not support inserting rows while inserting columns, and vice versa.", clsParas);
				}
			}

			vvsMAP.clear();
			vs.clear();

			/*
			b = clsParas->vstInserts[0].inRow;
			for (i = 1; i < (int)clsParas->vstInserts.size(); i++){
				if (clsParas->vstInserts[i].inRow != b){
					fetalError("Do not support inserting rows while inserting columns, and vice versa.", clsParas);
				}
			}
			*/
		/*}*/

		if (clsParas->iMode == OTHER_MODE_OUT){
			cout << "Your arguments lines:\n\tSection VECTOR (<type>,[row/col. No.],[begin],[delimiter],\n\t\t[direction],[filename]):" << endl;
			clsParas->fpLog << "Your arguments lines:\n\tSection VECTOR (<type>,[row/col. No.],[begin],[delimiter],[direction],[filename]):" << endl;

			for (i = 0; i < (int)clsParas->vstPed6map.size(); i++){
				cout << "\tLine " << i + 1 << ": "
					<< sArgCodes[clsParas->vstPed6map[i].type]
					<< DELIMITER4 << (clsParas->vstPed6map[i].no < 0 ? clsParas->vstPed6map[i].no : clsParas->vstPed6map[i].no + 1)
					<< DELIMITER4 << (clsParas->vstPed6map[i].posBegin < 0 ? clsParas->vstPed6map[i].posBegin : clsParas->vstPed6map[i].posBegin + 1);
					//<< DELIMITER4 << (clsParas->vstPed6map[i].posEnd < 0 ? clsParas->vstPed6map[i].posEnd : clsParas->vstPed6map[i].posEnd + 1);

				if (clsParas->vstPed6map[i].delim == ' '){ sLine = "space"; }
				else if (clsParas->vstPed6map[i].delim == '\t'){ sLine = "tab"; }
				else if (clsParas->vstPed6map[i].delim == ','){ sLine = "comma"; }
				else{ sLine = clsParas->vstPed6map[i].delim; }

				cout << DELIMITER4 << sLine
					<< DELIMITER4 << (clsParas->vstPed6map[i].inRow ? "row" : "column")
					<< DELIMITER4 << clsParas->vstPed6map[i].fn << endl;

				clsParas->fpLog << "\tLine " << i + 1 << ": "
					<< sArgCodes[clsParas->vstPed6map[i].type]
					<< DELIMITER4 << (clsParas->vstPed6map[i].no < 0 ? clsParas->vstPed6map[i].no : clsParas->vstPed6map[i].no + 1)
					<< DELIMITER4 << (clsParas->vstPed6map[i].posBegin < 0 ? clsParas->vstPed6map[i].posBegin : clsParas->vstPed6map[i].posBegin + 1)
					//<< DELIMITER4 << (clsParas->vstPed6map[i].posEnd < 0 ? clsParas->vstPed6map[i].posEnd : clsParas->vstPed6map[i].posEnd + 1)
					<< DELIMITER4 << sLine
					<< DELIMITER4 << (clsParas->vstPed6map[i].inRow ? "row" : "column")
					<< DELIMITER4 << clsParas->vstPed6map[i].fn << endl;
			}

			cout << "\tSection MATRIX (<filename>,[left],[top],[delimiter],[SNP rows/col.s],\n\t\t[character count],[missing],[case],[ctrl],[male],[female],\n\t\t[AA],[Aa],[aa]):" << endl;
			clsParas->fpLog << "\tSection MATRIX (<filename>,[left],[top],[delimiter],[SNP rows/col.s],[character count],[missing],[case],[ctrl],[male],[female],[AA],[Aa],[aa]):" << endl;

			cout << "\t"
				<< clsParas->struGenotype.fn
				<< DELIMITER4 << clsParas->struGenotype.lt.x
				<< DELIMITER4 << clsParas->struGenotype.lt.y;
				/*<< DELIMITER4 << (clsParas->struGenotype.rb.x < 0 ? clsParas->struGenotype.rb.x : clsParas->struGenotype.rb.x + 1)
				<< DELIMITER4 << (clsParas->struGenotype.rb.y < 0 ? clsParas->struGenotype.rb.y : clsParas->struGenotype.rb.y + 1);*/

			if (clsParas->struGenotype.delim == ' '){ sLine = "space"; }
			else if (clsParas->struGenotype.delim == '\t'){ sLine = "tab"; }
			else if (clsParas->struGenotype.delim == ','){ sLine = "comma"; }
			else{ sLine = clsParas->struGenotype.delim; }

			cout << DELIMITER4 << sLine
				<< DELIMITER4 << clsParas->struGenotype.SNPrcCnt
				<< DELIMITER4 << (clsParas->struGenotype.twoAllele ? 2 : 1)
				<< DELIMITER4 << clsParas->struGenotype.missing
				<< DELIMITER4 << clsParas->struGenotype.Case
				<< DELIMITER4 << clsParas->struGenotype.Ctrl
				<< DELIMITER4 << clsParas->struGenotype.male
				<< DELIMITER4 << clsParas->struGenotype.female
				<< DELIMITER4 << clsParas->struGenotype.AA[0]
				<< clsParas->struGenotype.AA[1]
				<< DELIMITER4 << clsParas->struGenotype.Aa[0]
				<< clsParas->struGenotype.Aa[1]
				<< DELIMITER4 << clsParas->struGenotype.aa[0]
				<< clsParas->struGenotype.aa[1]
				<< endl;

			clsParas->fpLog << "\t"
				<< clsParas->struGenotype.fn
				<< DELIMITER4 << clsParas->struGenotype.lt.x
				<< DELIMITER4 << clsParas->struGenotype.lt.y
				/*<< DELIMITER4 << (clsParas->struGenotype.rb.x < 0 ? clsParas->struGenotype.rb.x : clsParas->struGenotype.rb.x + 1)
				<< DELIMITER4 << (clsParas->struGenotype.rb.y < 0 ? clsParas->struGenotype.rb.y : clsParas->struGenotype.rb.y + 1)*/
				<< DELIMITER4 << sLine
				<< DELIMITER4 << clsParas->struGenotype.SNPrcCnt
				<< DELIMITER4 << (clsParas->struGenotype.twoAllele ? 2 : 1)
				<< DELIMITER4 << clsParas->struGenotype.missing
				<< DELIMITER4 << clsParas->struGenotype.Case
				<< DELIMITER4 << clsParas->struGenotype.Ctrl
				<< DELIMITER4 << clsParas->struGenotype.male
				<< DELIMITER4 << clsParas->struGenotype.female
				<< DELIMITER4 << clsParas->struGenotype.AA[0]
				<< clsParas->struGenotype.AA[1]
				<< DELIMITER4 << clsParas->struGenotype.Aa[0]
				<< clsParas->struGenotype.Aa[1]
				<< DELIMITER4 << clsParas->struGenotype.aa[0]
				<< clsParas->struGenotype.aa[1]
				<< endl;

			cout << "\tSection INSERT (<row/col. No.>,[filename],[begin],[delimiter],\n\t\t[direction]):" << endl;
			clsParas->fpLog << "\tSection INSERT (<row/col. No.>,[filename],[begin],[delimiter],[direction]):" << endl;

			for (i = 0; i < (int)clsParas->vstInserts.size(); i++){	// <row/col. No.>,[filename],[begin],[delimiter],[direction],[item1],[item2],...
				// show inserted arguments
				cout << "\tLine " << i + 1 << ": "
					<< (clsParas->vstInserts[i].no < 0 ? clsParas->vstInserts[i].no : clsParas->vstInserts[i].no + 1)
					<< DELIMITER4 << clsParas->vstInserts[i].fn
					<< DELIMITER4 << (clsParas->vstInserts[i].posBegin < 0 ? clsParas->vstInserts[i].posBegin : clsParas->vstInserts[i].posBegin + 1);

				if (clsParas->vstInserts[i].delim == ' '){ sLine = "space"; }
				else if (clsParas->vstInserts[i].delim == '\t'){ sLine = "tab"; }
				else if (clsParas->vstInserts[i].delim == ','){ sLine = "comma"; }
				else{ sLine = clsParas->vstInserts[i].delim; }

				cout << DELIMITER4 << sLine
					<< DELIMITER4 << (clsParas->vstInserts[i].inRow ? "row" : "column") << endl;

				clsParas->fpLog << "\tLine " << i + 1 << ": "
					<< (clsParas->vstInserts[i].no < 0 ? clsParas->vstInserts[i].no : clsParas->vstInserts[i].no + 1)
					<< DELIMITER4 << clsParas->vstInserts[0].fn
					<< DELIMITER4 << (clsParas->vstInserts[i].posBegin < 0 ? clsParas->vstInserts[i].posBegin : clsParas->vstInserts[i].posBegin + 1)
					<< DELIMITER4 << sLine
					<< DELIMITER4 << (clsParas->vstInserts[i].inRow ? "row" : "column") << endl;
			}
		}

		cout << "\nReading and verifying source file(s). Please wait ..." << endl;
		// swap 2 input files
		sLine = clsParas->sInputFilename;
		clsParas->sInputFilename = clsParas->sFilename2;
		clsParas->sFilename2 = sLine;

		if (!clsParas->struGenotype.twoAllele || clsParas->struGenotype.Aa[0] != '\0') {
			b = clsParas->bNormalize;
			clsParas->bNormalize = true;
		}

		if (clsParas->struGenotype.twoAllele){ readPed(vvcAlleles, vsPed6, clsParas, true); }	// normalize if need
		else{ readPed(vvcAlleles, vsPed6, clsParas, false); }									// normalize if need

		if (!clsParas->struGenotype.twoAllele || clsParas->struGenotype.Aa[0] != '\0'){ clsParas->bNormalize = b; }

		readWithDelimeter(vvsMAP, getFn(clsParas->sInputFilename, ".map", true), clsParas);

		//检查PED文件内容与MAP内容是否匹配
		i = vvcAlleles[0].size() / 2;	//PED文件中的SNP个数（2个等位基因构成SNP中的一个基因型）
		j = vvsMAP.size();				//MAP文件中的SNP个数

		if (i != j) {
			char cs[100];
			sprintf(cs, "The number of SNPs are not equivalent between PED and MAP file.\nTheir numbers are as follows:\n\tPED: %d \tMAP: %d.", i, j);
			fetalError(cs, clsParas);
		}

		if (clsParas->iMode == OTHER_MODE_LST){	// list SNP and sample sizes of PED
			cout << "\nPlease remember the Information about the source PED file to help you designing the arguments for \"other\" file(s)." << endl;
			cout << "Note: Each SNP contains two columns, and each sample occupies one row." << endl;
			cout << "Press any key to continue ..." << endl;
			i = system("stty raw");
			char c = getchar();
			i = system("stty -raw");
			clsParas->fpLog.close();
			clsParas->fpStat.close();
			exit(0);
		}

		cout << "Saving ..." << endl;
		// split Ped6
		for (i = 0; i < (int)vsPed6.size(); i++){
			stringSplit(vsPed6[i].c_str(), vs, ' ');
			vvsPed6.push_back(vs);
		}
		vString().swap(vsPed6);
		vString().swap(vs);

		saveOthers(vvcAlleles, vvsPed6, vvsMAP, clsParas);
	}

	/************************************
	* 把PLINK ped内容保存为指定的任意其它格式
	* vvcAlleles = 基因型矩阵（样本数行*2倍的SNP数列）
	* vsPed6 = PED文件的前6列（字串向量）
	* vvsMAP = MAP文件的所有内容（字串矩阵）
	* clsParas = 类参数指针
	*************************************/
	void saveOthers(vvChar &vvcAlleles, vvString &vvsPed6, vvString &vvsMAP, parameters *clsParas)
	{
		string		sLine;
		int			i, j, rowCnt, colCnt;
		fstream		fp;

		// get unique out-filenames
		map<string, int>	fns;
		j = 0;
		for (i = 0; i < (int)clsParas->vstPed6map.size(); i++){
			sLine = clsParas->vstPed6map[i].fn;				// can not be inserted if did not do like this
			fns.insert(pair<string, int>(sLine, j++));
		}

		for (i = 0; i < (int)clsParas->vstInserts.size(); i++){
			sLine = clsParas->vstInserts[i].fn;
			fns.insert(pair<string, int>(sLine, j++));
		}

		fns.insert(pair<string, int>(clsParas->struGenotype.fn, i++));	// but, done here ?

		cout << "Total " << fns.size() << " file(s) will be saved:" << endl;
		clsParas->fpLog << "Total " << fns.size() << " file(s) will be saved:" << endl;
		int	iRow = 0;
		
		map<string, int>::iterator it;	// Linux 不支持auto
		for (/*auto*/ it = fns.begin(); it != fns.end(); it++){
			sLine = it->first;
			//cout << '\t' << sLine << endl;
			clsParas->fpLog << '\t' << sLine;

			cout << "\tSaving " << sLine << " ..." << endl;

			coordinateTrans(sLine, vvcAlleles, vvsPed6, vvsMAP, &rowCnt, &colCnt, clsParas);
			cout << "\tTotal " << rowCnt << " rows and " << colCnt << " columns" << endl;
			clsParas->fpLog << " with " << rowCnt << " rows and " << colCnt << " columns" << endl;

			openStreamFile(fp, sLine.c_str(), ios::out);
			clsParas->struGenotype.CurPedRow = -1;	// row No. in alleles of PED to output

			for (iRow = 0; iRow < rowCnt; iRow++){
				saveOneRow(fp, iRow, colCnt, sLine, vvcAlleles, vvsPed6, vvsMAP, clsParas);
				cout << '\t' << ceil((float)iRow / rowCnt * 100) << "% completed." << '\r';
			}
			fp.close();
			fp.clear();

			cout << "\t100% completed.\n" << endl;
		}

		cout << "The file(s) saved OK." << endl;
		clsParas->fpLog << "The file(s) saved OK." << endl;

#ifdef _DEBUG
		system("pause");
#endif // DEBUG

	}

	/************************************
	* PLINK ped转任意其它格式 - 输出一行
	* fp = out-file pointer
	* iRow = will be outted row No.
	* colCnt = number of col.s of the out-file
	* fn = out-file's filename
	* vvcAlleles = data of alleles
	* vvsPed6 = the first 6 col.s in PED
	* vvsMAP = data of MAP
	* clsParas = 类参数指针
	*************************************/
	void saveOneRow(fstream &fp, int iRow, int colCnt, string &fn, vvChar &vvcAlleles, vvString &vvsPed6, vvString &vvsMAP, coPLINK::parameters *clsParas)
	{
		int		i, j, m,/* n,*/ iCurCol, iLoop;
		char	c;

		iCurCol = 0;	// col. No. will be outed
		while (true)
		{
			iLoop = iCurCol;	// avoid endless loop
			/////// find row beginning at 0 with row No. of iRow to out //////////
			for (i = 0; i < (int)clsParas->vstPed6map.size(); i++){		// scan line beginning at iCurCol in iRow on [VECTOR]
				if (clsParas->vstPed6map[i].fn != fn) continue;

				if (clsParas->vstPed6map[i].inRow){
					if (clsParas->vstPed6map[i].no == iRow){
						if (clsParas->vstPed6map[i].posBegin == iCurCol){
							if (clsParas->vstPed6map[i].type < SEX_ID) {	// 无法用宏来表示case中的范围，此处不能用switch
								for (j = 0; j < (int)vvsPed6.size(); j++){
									if (iCurCol == 0){ fp << vvsPed6[j][clsParas->vstPed6map[i].type]; }
									else{ fp << clsParas->vstPed6map[i].delim << vvsPed6[j][clsParas->vstPed6map[i].type]; }

									iCurCol++;
								}
								//fp << vvsPed6[j][clsParas->vstPed6map[i].type];	// no delimeter at last
							}
							else if (clsParas->vstPed6map[i].type == SEX_ID){
								for (j = 0; j < (int)vvsPed6.size(); j++){
									c = vvsPed6[j][clsParas->vstPed6map[i].type][0] == PLNK_PED_MALE ?
										clsParas->struGenotype.male : clsParas->struGenotype.female;

									if (iCurCol == 0){ fp << c; }
									else{ fp << clsParas->vstPed6map[i].delim << c; }

									iCurCol++;
								}
								//fp << c;
							}
							else if (clsParas->vstPed6map[i].type == PHENOTYPE_ID){
								for (j = 0; j < (int)vvsPed6.size(); j++){
									c = vvsPed6[j][clsParas->vstPed6map[i].type][0] == PLNK_PED_CASE_PHENOTYPE ?
										clsParas->struGenotype.Case : clsParas->struGenotype.Ctrl;

									if (iCurCol == 0){ fp << c; }
									else{ fp << clsParas->vstPed6map[i].delim << c; }

									iCurCol++;
								}
								//fp << c;
							}
							else{
								for (j = 0; j < (int)vvsMAP.size(); j++){
									if (iCurCol == 0){ fp << vvsMAP[j][clsParas->vstPed6map[i].type - CHROMOSOME_ID]; }
									else{ fp << clsParas->vstPed6map[i].delim << vvsMAP[j][clsParas->vstPed6map[i].type - CHROMOSOME_ID]; }

									iCurCol++;
								}
								//fp << vvsMAP[j][clsParas->vstPed6map[i].type - CHROMOSOME_ID];	// no delimeter at last
							}
							/*iCurCol++;
							if (iCurCol >= colCnt){
							fp << endl;
							return;
							}
							else fp << clsParas->vstPed6map[i].delim;*/
						}
					}
				}
				else{
					m = iRow - clsParas->vstPed6map[i].posBegin;
					if (clsParas->vstPed6map[i].no == iCurCol && m >= 0){
						if ((int)vvsPed6.size() > m){
							if (clsParas->vstPed6map[i].type < SEX_ID) {	// 无法用宏来表示case中的范围，此处不能用switch
								if (iCurCol == 0){ fp << vvsPed6[m][clsParas->vstPed6map[i].type]; }
								else{ fp << clsParas->vstPed6map[i].delim << vvsPed6[m][clsParas->vstPed6map[i].type]; }

								iCurCol++;
							}
							else if (clsParas->vstPed6map[i].type == SEX_ID){
								c = vvsPed6[m][clsParas->vstPed6map[i].type][0] == PLNK_PED_MALE ?
									clsParas->struGenotype.male : clsParas->struGenotype.female;

								if (iCurCol == 0){ fp << c; }
								else{ fp << clsParas->vstPed6map[i].delim << c; }

								iCurCol++;
							}
							else if (clsParas->vstPed6map[i].type == PHENOTYPE_ID){
								c = vvsPed6[m][clsParas->vstPed6map[i].type][0] == PLNK_PED_CASE_PHENOTYPE ?
									clsParas->struGenotype.Case : clsParas->struGenotype.Ctrl;

								if (iCurCol == 0){ fp << c; }
								else{ fp << clsParas->vstPed6map[i].delim << c; }

								iCurCol++;
							}
						}

						if (clsParas->vstPed6map[i].no == iCurCol && (int)vvsMAP.size() > m){	// 上一步可能修改iCurCol，此处需要判断
							if (iCurCol == 0){ fp << vvsMAP[m][clsParas->vstPed6map[i].type - CHROMOSOME_ID]; }
							else{ fp << clsParas->vstPed6map[i].delim << vvsMAP[m][clsParas->vstPed6map[i].type - CHROMOSOME_ID]; }

							iCurCol++;
						}
					}
				}
			}

			for (i = 0; i < (int)clsParas->vstInserts.size(); i++){		// scan line beginning at iCurCol in iRow on [INSERT]
				if (clsParas->vstInserts[i].fn != fn) continue;

				if (clsParas->vstInserts[i].inRow){
					if (clsParas->vstInserts[i].no == iRow){
						if (clsParas->vstInserts[i].posBegin == iCurCol){
							for (j = 0; j < (int)clsParas->vstInserts[i].vsInserts.size(); j++){
								if (iCurCol == 0){ fp << clsParas->vstInserts[i].vsInserts[j]; }
								else{ fp << clsParas->vstInserts[i].delim << clsParas->vstInserts[i].vsInserts[j]; }

								iCurCol++;
							}
							//fp << clsParas->vstInserts[i].vsInserts[j];	// no delimeter at last
							//iCurCol++;
							//if (iCurCol >= colCnt){
							//	fp << endl;
							//	return;
							//}
							//else fp << clsParas->vstInserts[i].delim;
						}
					}
				}
				else{
					m = iRow - clsParas->vstInserts[i].posBegin;
					if (((int)clsParas->vstInserts[i].vsInserts.size() > m) && (m >= 0) && (clsParas->vstInserts[i].no == iCurCol)){
						if (iCurCol == 0){ fp << clsParas->vstInserts[i].vsInserts[m]; }
						else{ fp << clsParas->vstInserts[i].delim << clsParas->vstInserts[i].vsInserts[m]; }

						iCurCol++;
					}
				}
			}

			if (clsParas->struGenotype.fn == fn && clsParas->struGenotype.lt.x == iCurCol){	// scan line beginning at iCurCol in iRow on [MATRIX]
				if (clsParas->struGenotype.lt.y <= iRow && iRow <= clsParas->struGenotype.rb.y){
					m = iRow - clsParas->struGenotype.lt.y;

					if (m < 0){
						cout << "The expected row No. is " << iRow + 1 << ", but the max row No. of the alleles is only "
							<< clsParas->struGenotype.lt.y << endl;
						fp.close();
						fetalError("Output one row Error 1: The outputing row No. is out of the max row No. of the alleles.", clsParas, false);
					}

					if (clsParas->struGenotype.twoAllele){
						switch (clsParas->struGenotype.SNPrcCnt)
						{
						case SNP_2_COL:
						{
							if (m >= (int)vvcAlleles.size()){
								cout << "The expected row No. in area of alleles is " << m + 1 << ", but the number of rows of the alleles is only "
									<< vvcAlleles.size() << endl;
								fp.close();
								fetalError("Output one row Error 2: The outputing row No. in area of alleles is out of the number of rows of the alleles.", clsParas, false);
							}

							for (i = 0; i < (int)vvcAlleles[0].size(); i++){
								if (iCurCol == 0){
									if (vvcAlleles[m][i] == MISSING_ALLELE_CHR){ fp << clsParas->struGenotype.missing; }
									else{ fp << vvcAlleles[m][i]; }
								}
								else {
									if (vvcAlleles[m][i] == MISSING_ALLELE_CHR){ fp << clsParas->struGenotype.delim << clsParas->struGenotype.missing; }
									else{ fp << clsParas->struGenotype.delim << vvcAlleles[m][i]; }
								}
								iCurCol++;
							}
							break;
						}
						case SNP_2_ROW:
						{
							if (m >= (int)vvcAlleles[0].size()){
								cout << "The expected row No. in area of alleles is " << m + 1
									<< " while outputing transposed alleles, but the number of columns of the alleles is only "
									<< vvcAlleles[0].size() << endl;
								fp.close();
								fetalError("Output one row Error 3: The outputing row No. in area of alleles is out of the number of columns of the alleles while outputing transposed alleles.", clsParas, false);
							}

							for (i = 0; i < (int)vvcAlleles.size(); i++){
								if (iCurCol == 0){
									if (vvcAlleles[i][m] == MISSING_ALLELE_CHR){ fp << clsParas->struGenotype.missing; }
									else fp << vvcAlleles[i][m];
								}
								else {
									if (vvcAlleles[i][m] == MISSING_ALLELE_CHR){ fp << clsParas->struGenotype.delim << clsParas->struGenotype.missing; }
									else{ fp << clsParas->struGenotype.delim << vvcAlleles[i][m]; }
								}

								iCurCol++;
							}
							break;
						}
						case SNP_1_COL:
						{
							if ((float)m / 2 == m / 2) {
								clsParas->struGenotype.CurPedRow++;
								if ((float)clsParas->struGenotype.CurPedRow / 2 == clsParas->struGenotype.CurPedRow / 2){ j = 0; }
								else{ j = 1; }
							}

							for (i = j; i < (int)vvcAlleles[0].size(); i += 2){
								if (iCurCol == 0){
									if (vvcAlleles[clsParas->struGenotype.CurPedRow][i] == MISSING_ALLELE_CHR){ fp << clsParas->struGenotype.missing; }
									else{ fp << vvcAlleles[clsParas->struGenotype.CurPedRow][i]; }
								}
								else {
									if (vvcAlleles[clsParas->struGenotype.CurPedRow][i] == MISSING_ALLELE_CHR){
										fp << clsParas->struGenotype.delim << clsParas->struGenotype.missing;
									}
									else{
										fp << clsParas->struGenotype.delim << vvcAlleles[clsParas->struGenotype.CurPedRow][i];
									}
								}

								iCurCol++;
							}
							break;
						}
						case SNP_1_ROW:
						{
							if (2 * m >= (int)vvcAlleles[0].size()){
								cout << "The expected row No. in area of alleles is " << m + 1 << " while outputing two rows of transposed alleles as one row, but the number of rows of the alleles is only "
									<< vvcAlleles[0].size() << endl;
								fp.close();
								fetalError("Output one row Error 4: The outputing row No. in area of alleles is out of the number of rows of the alleles while outputing two rows of transposed alleles as one row.", clsParas, false);
							}

							for (i = 0; i < (int)vvcAlleles.size(); i++){
								if (iCurCol == 0) {
									if (vvcAlleles[i][2 * m] == MISSING_ALLELE_CHR){
										fp << clsParas->struGenotype.missing << clsParas->struGenotype.delim;
									}
									else{
										fp << vvcAlleles[i][2 * m] << clsParas->struGenotype.delim;
									}

									if (vvcAlleles[i][2 * m + 1] == MISSING_ALLELE_CHR){ fp << clsParas->struGenotype.missing; }
									else{ fp << vvcAlleles[i][2 * m + 1]; }
								}
								else {
									fp << clsParas->struGenotype.delim;

									if (vvcAlleles[i][2 * m] == MISSING_ALLELE_CHR){ fp << clsParas->struGenotype.missing << clsParas->struGenotype.delim; }
									else{ fp << vvcAlleles[i][2 * m] << clsParas->struGenotype.delim; }

									if (vvcAlleles[i][2 * m + 1] == MISSING_ALLELE_CHR){ fp << clsParas->struGenotype.missing; }
									else{ fp << vvcAlleles[i][2 * m + 1]; }
								}

								iCurCol += 2;
							}
							break;
						}
						default:
							break;
						}
					}
					else{
						if (clsParas->struGenotype.SNPrcCnt == SNP_1_COL){
							if (m >= (int)vvcAlleles.size()){
								cout << "The expected row No. is in area of alleles " << m + 1 << ", but the number of rows of the alleles is only "
									<< vvcAlleles.size() << endl;
								fp.close();
								fetalError("Output one row Error 5: The outputing row No. in area of alleles is out of the number of rows of the alleles.", clsParas, false);
							}

							for (i = 0; i < (int)vvcAlleles[0].size(); i += 2){
								if (vvcAlleles[m][i] == PLNK_PED_A && vvcAlleles[m][i + 1] == PLNK_PED_A){
									c = clsParas->struGenotype.AA[0];
								}
								else if ((vvcAlleles[m][i] == PLNK_PED_A && vvcAlleles[m][i + 1] == PLNK_PED_a)
									|| (vvcAlleles[m][i] == PLNK_PED_a && vvcAlleles[m][i + 1] == PLNK_PED_A))
								{
									c = clsParas->struGenotype.Aa[0];
								}
								else if (vvcAlleles[m][i] == PLNK_PED_a && vvcAlleles[m][i + 1] == PLNK_PED_a){
									c = clsParas->struGenotype.aa[0];
								}
								else{
									c = MISSING_ALLELE_CHR;
								}

								if (iCurCol == 0) {
									if (c == MISSING_ALLELE_CHR){ fp << clsParas->struGenotype.missing; }
									else{ fp << c; }
								}
								else {
									if (c == MISSING_ALLELE_CHR){ fp << clsParas->struGenotype.delim << clsParas->struGenotype.missing; }
									else{ fp << clsParas->struGenotype.delim << c; }
								}

								iCurCol++;
							}
						}
						else{
							for (i = 0; i < (int)vvcAlleles.size(); i++){
								if (2 * m >= (int)vvcAlleles[0].size()){
									cout << "The expected row No. is in area of alleles " << m + 1 << " while outputing two rows of transposed alleles as one row, but the number of rows of the alleles is only "
										<< vvcAlleles[0].size() << endl;
									fp.close();
									fetalError("Output one row Error 6: The outputing row No. in area of alleles is out of the number of rows of the alleles while outputing two rows of transposed alleles as one row.", clsParas, false);
								}

								if (vvcAlleles[i][2 * m] == PLNK_PED_A && vvcAlleles[i][2 * m + 1] == PLNK_PED_A)
								{
									c = clsParas->struGenotype.AA[0];
								}
								else if ((vvcAlleles[i][2 * m] == PLNK_PED_A && vvcAlleles[i][2 * m + 1] == PLNK_PED_a)
									|| (vvcAlleles[i][2 * m] == PLNK_PED_a && vvcAlleles[i][2 * m + 1] == PLNK_PED_A))
								{
									c = clsParas->struGenotype.Aa[0];
								}
								else if (vvcAlleles[i][2 * m] == PLNK_PED_a && vvcAlleles[i][2 * m + 1] == PLNK_PED_a){
									c = clsParas->struGenotype.aa[0];
								}
								else{
									c = MISSING_ALLELE_CHR;
								}

								if (iCurCol == 0) {
									if (c == MISSING_ALLELE_CHR){ fp << clsParas->struGenotype.missing; }
									else{ fp << c; }
								}
								else {
									if (c == MISSING_ALLELE_CHR){ fp << clsParas->struGenotype.delim << clsParas->struGenotype.missing; }
									else{ fp << clsParas->struGenotype.delim << c; }
								}

								iCurCol++;
							}
						}
					}
					/*if (iCurCol >= colCnt){
					fp << endl;
					return;
					}
					else fp << clsParas->struGenotype.delim;*/
				}
			}

			/*
			/////// find col. laying in iCurCol with item locating at iRow to out //////////
			for (i = 0; i < (int)clsParas->vstPed6map.size(); i++){		// scan in [VECTOR]
				if (clsParas->vstPed6map[i].fn != fn) continue;

				if (clsParas->vstPed6map[i].no == iCurCol && !clsParas->vstPed6map[i].inRow){
					if (clsParas->vstPed6map[i].posBegin <= iRow){
						m = iRow - clsParas->vstPed6map[i].posBegin;	// real loc. in vector

						if (clsParas->vstPed6map[i].type < CHROMOSOME_ID){
							if (m >= (int)vvsPed6.size()){
								cout << "The expected row No. subtracts [begin] is greater than sample count while outputing "
									<< iRow + 1 << "th, " << iCurCol + 1 << "th." << endl;
								fp.close();
								fetalError("Output one row Error 7: The expected row No. subtracts [begin] is greater than sample count.", clsParas, false);
							}
						}
						else if (m >= (int)vvsMAP.size()){
							cout << "The expected row No. subtracts [begin] is greater than SNP count while outputing "
								<< iRow + 1 << "th, " << iCurCol + 1 << "th." << endl;
							fp.close();
							fetalError("Output one row Error 8: The expected row No. subtracts [begin] is greater than SNP count.", clsParas, false);
						}

						n = clsParas->vstPed6map[i].posBegin + (clsParas->vstPed6map[i].type < CHROMOSOME_ID ? vvsPed6.size() : vvsMAP.size());	// end row No.

						if (iCurCol > 0) fp << clsParas->vstPed6map[i].delim;

						if (m < n) {
							if (clsParas->vstPed6map[i].type < SEX_ID) fp << vvsPed6[m][clsParas->vstPed6map[i].type];	// no delimeter at last
							else if (clsParas->vstPed6map[i].type == SEX_ID){
								c = vvsPed6[m][clsParas->vstPed6map[i].type][0] == PLNK_PED_MALE ? clsParas->struGenotype.male : clsParas->struGenotype.female;
								fp << c;
							}
							else if (clsParas->vstPed6map[i].type == PHENOTYPE_ID){
								c = vvsPed6[m][clsParas->vstPed6map[i].type][0] == PLNK_PED_CASE_PHENOTYPE ? clsParas->struGenotype.Case : clsParas->struGenotype.Ctrl;
								fp << c;
							}
							else fp << vvsMAP[m][clsParas->vstPed6map[i].type - CHROMOSOME_ID];	// no delimeter at last
						}
						else fp << clsParas->vstPed6map[i].delim;

						iCurCol++;
						/*if (iCurCol >= colCnt){
						fp << endl;
						return;
						}
						else fp << clsParas->vstPed6map[i].delim;
					}
				}
			}

			for (i = 0; i < (int)clsParas->vstInserts.size(); i++){		// scan in [INSERT]
				if (clsParas->vstInserts[i].fn != fn) continue;

				if (clsParas->vstInserts[i].no == iCurCol && !clsParas->vstInserts[i].inRow){
					if (clsParas->vstInserts[i].posBegin <= iRow){
						m = iRow - clsParas->vstInserts[i].posBegin;	// real loc. in insert

						if (m >= (int)clsParas->vstInserts[i].vsInserts.size()){
							cout << "The expected row No. subtracts [begin] is greater than item count while outputing inserted items at "
								<< iRow + 1 << "th, " << iCurCol + 1 << "th." << endl;
							fp.close();
							fetalError("Output one row Error 9: The expected row No. subtracts [begin] is greater than item count.", clsParas, false);
						}

						n = clsParas->vstInserts[i].posBegin + clsParas->vstInserts[i].vsInserts.size();	// end row No.

						if (iCurCol > 0) fp << clsParas->vstInserts[i].delim;
						if (m < n) fp << clsParas->vstInserts[i].vsInserts[m];
						else fp << clsParas->vstInserts[i].delim;

						iCurCol++;
						if (iCurCol >= colCnt){
						fp << endl;
						return;
						}
						else fp << clsParas->vstInserts[i].delim;
					}
				}
			}*/
			if (iCurCol == iLoop){
				fp << endl;

				if (iLoop < colCnt){
					cout << "The row " << iRow + 1 << " of file " << fn << " has " << iCurCol << " column(s) (< " << colCnt << "), please confirm." << endl;
					clsParas->fpLog << "The row " << iRow + 1 << " of file " << fn << " has " << iCurCol << " column(s) (< " << colCnt << "), please confirm." << endl;
				}

				return;
			}
		}
	}


	/************************************
	* 读取Ped前6列和Map全部4列，为任意其它格式转PLINK ped准备
	* vvsPed4 = Ped前4列. Family ID, Individual ID, Paternal ID and Maternal ID respectively
	* vvsMAP = Whole col.s of Map
	* vvcPed2 = 5 and 6 col. of Ped
	* clsParas = 类参数指针
	*************************************/
	void readPed6Map4Cols(vvString &vvsPed4, vvString &vvsMAP, vvChar &vvcPed2, coPLINK::parameters *clsParas)
	{
		fstream		fp;
		string		sLine, sOldFn;
		vString		vsText, vs;
		char		cs[10];
		vInt		viNull;			// save line No.s of null lines
		int			uv, ud, i, n;
		int			ii;
		char		c;

		// read the top 6 col.s of Ped and 4 col.s of Map
		sOldFn = "";
		for (uv = 0; uv < (int)clsParas->vstPed6map.size(); uv++){
			if (sOldFn != clsParas->vstPed6map[uv].fn){
				viNull.clear();
				sOldFn = clsParas->vstPed6map[uv].fn;
				cout << "Reading source file " << sOldFn << " to get the top 6 columns for PED and all 4 columns for MAP ..." << endl;
				openStreamFile(fp, sOldFn.c_str(), ios::in);
				// reading whole file
				vsText.clear();
				n = 0;
				ii = 0;
				while (getline(fp, sLine))
				{
					n++;
					trimString(sLine);							//删除前后空格及TAB
					trimRedundance(sLine, true);				//删除中间多余空格及TAB（只保留一个）, and replace tab with space

					if (sLine.length() == 0) {
						viNull.push_back(n);					// save No. of the null line
						continue;
					}

					vsText.push_back(sLine);
					cout << '\t' << ++ii << " ...\r";
				}
				fp.close();
				fp.clear();
				cout << endl << "\tAnalyzing ..." << endl;

				if (vsText.empty()){
					fetalError("The source file " + sOldFn + " includes nothing.", clsParas);
				}
			}
			if (clsParas->vstPed6map[uv].inRow&&clsParas->vstPed6map[uv].no < 0) clsParas->vstPed6map[uv].no += (viNull.size() + vsText.size());	// get real row No.
			// resize 3 arguments relating to "row"
			if (!viNull.empty()){
				if (clsParas->vstPed6map[uv].inRow){
					n = clsParas->vstPed6map[uv].no;
				}
				else{
					n = clsParas->vstPed6map[uv].posEnd;
					ii = clsParas->vstPed6map[uv].posBegin;
				}

				for (i = 0; i < (int)viNull.size(); i++){
					if (clsParas->vstPed6map[uv].inRow){
						if (viNull[i] > n){ break; }
						else{ clsParas->vstPed6map[uv].no--; }
					}
					else{
						if (viNull[i] > n && viNull[i] >= ii){ break; }
						else {
							if (viNull[i] <= n){ clsParas->vstPed6map[uv].posEnd--; }

							if (viNull[i] < ii){ clsParas->vstPed6map[uv].posBegin--; }
						}
					}
				}
			}

			for (ud = 0; ud < 10; ud++){		// the top 6 col.s in Ped and whole col.s in Map
				if (clsParas->vstPed6map[uv].type == ud){
					if (clsParas->vstPed6map[uv].inRow){	// each row is a datum
						//stringSplit(vs, vsText[clsParas->vstPed6map[uv].no], clsParas->vstPed6map[uv].delim);	// it removes null
						if (clsParas->vstPed6map[uv].delim == '\t'){ c = ' '; }				// tab was replaced with space at prev. steps
						else{ c = clsParas->vstPed6map[uv].delim; }

						stringSplit(vsText[clsParas->vstPed6map[uv].no].c_str(), vs, c);	// need keep null string
						// get real End
						if (clsParas->vstPed6map[uv].posEnd < 0){ ii = vs.size() + clsParas->vstPed6map[uv].posEnd + 1; }
						else if (clsParas->vstPed6map[uv].posEnd == 0){ ii = vs.size(); }
						else{ ii = clsParas->vstPed6map[uv].posEnd; }

						if (ii <= clsParas->vstPed6map[uv].posBegin){
							fetalError("The real [end] is less than the [begin] while setting a negative <end> in coding \""
								+ sArgCodes[ud] + "\". Check the settings in argument file and file " + sOldFn + ", please.", clsParas);
						}

						for (i = clsParas->vstPed6map[uv].posBegin; i < ii; i++){
							if (ud < 4){
								vvsPed4[ud].push_back(vs[i]);
							}
							else if (ud < 6) {
								trimString(vs[i]);	// trim to remove the spaces at the both ends of the string
								if (ud == 4){		// sex
									//c = vs[i][0] == clsParas->struGenotype.male ? PLNK_PED_MALE : PLNK_PED_FEMALE;	// moved to at last
									vvcPed2[0].push_back(vs[i][0]);
								}
								else{
									//c = vs[i][0] == clsParas->struGenotype.Case ? PLNK_PED_CASE_PHENOTYPE : PLNK_PED_CTRL_PHENOTYPE; // moved to at last
									vvcPed2[1].push_back(vs[i][0]);
								}
							}
							else{
								vvsMAP[ud - 6].push_back(vs[i]);
							}
						}
					}
					else{
						// get real End
						if (clsParas->vstPed6map[uv].posEnd < 0){ ii = vsText.size() + clsParas->vstPed6map[uv].posEnd + 1; }
						else if (clsParas->vstPed6map[uv].posEnd == 0){ ii = vsText.size(); }
						else{ ii = clsParas->vstPed6map[uv].posEnd; }

						if (ii <= clsParas->vstPed6map[uv].posBegin){
							fetalError("The real [end] is less than the [begin] while setting a negative <end> in coding \""
								+ sArgCodes[ud] + "\". Check the settings in argument file and file " + sOldFn + ", please.", clsParas);
						}

						n = vsText.size();
						for (i = clsParas->vstPed6map[uv].posBegin; i < ii; i++){
							//stringSplit(vs, vsText[i], clsParas->vstPed6map[uv].delim);	// it removes null
							if (clsParas->vstPed6map[uv].delim == '\t'){ c = ' '; }		// tab was replaced with space at prev. steps
							else{ c = clsParas->vstPed6map[uv].delim; }

							stringSplit(vsText[i].c_str(), vs, c);						// need keep null string
							if (clsParas->vstPed6map[uv].no < 0){ clsParas->vstPed6map[uv].no += vs.size(); }	// get real col. No.

							if (clsParas->vstPed6map[uv].no >((int)vs.size() - 1)){
								if (clsParas->vstPed6map[uv].posEnd == 0) break;

								sprintf(cs, "%d", i);
								sLine = cs;
								fetalError("The [row/col. No.] is greater than the number of column of row "
									+ sLine + " while coding \"" + sArgCodes[ud] + "\". Check the settings in argument file and file "
									+ sOldFn + ", please.", clsParas);
							}

							if (ud < 4){
								vvsPed4[ud].push_back(vs[clsParas->vstPed6map[uv].no]);
							}
							else if (ud < 6) {
								trimString(vs[clsParas->vstPed6map[uv].no]);
								vvcPed2[ud - 4].push_back(vs[clsParas->vstPed6map[uv].no][0]);
							}
							else{
								vvsMAP[ud - 6].push_back(vs[clsParas->vstPed6map[uv].no]);
							}
						}
					}
				}
			}
		}
		vString().swap(vsText);
		vInt().swap(viNull);
		vString().swap(vs);

		// transform sexes and phenotypes to PED format
		for (i = 0; i < (int)vvcPed2[0].size(); i++){	// sex
			if (vvcPed2[0][i] == clsParas->struGenotype.female){ vvcPed2[0][i] = PLNK_PED_FEMALE; }
			else if (vvcPed2[0][i] == clsParas->struGenotype.male){ vvcPed2[0][i] = PLNK_PED_MALE; }
			else{ vvcPed2[0][i] = PLNK_PED_UNKNOWN_SEX; }
		}

		for (i = 0; i < (int)vvcPed2[1].size(); i++){	// sex
			if (vvcPed2[1][i] == clsParas->struGenotype.Case){ vvcPed2[1][i] = PLNK_PED_CASE_PHENOTYPE; }
			else if (vvcPed2[1][i] == clsParas->struGenotype.Ctrl){ vvcPed2[1][i] = PLNK_PED_CTRL_PHENOTYPE; }
			else{ vvcPed2[1][i] = PLNK_PED_UNKNOWN_PHENOTYPE; }
		}
	}

	/************************************
	* 校验读取Ped前6列和Map全部4列，并补齐空列
	* vvsPed4 = Ped前4列. Family ID, Individual ID, Paternal ID and Maternal ID respectively
	* vvsMAP = Whole col.s of Map
	* vvcPed2 = 5 and 6 col. of Ped
	* clsParas = 类参数指针
	* return: 0 - OK; 1 - lengths of all of top 6 col.s in PED are 0;
	*		  2 - lengths of all of 4 col.s in MAP are 0.
	*		  3 - lengths of all 10 col.s are 0.
	*************************************/
	int verifyPed6Map4Cols(vvString &vvsPed4, vvString &vvsMAP, vvChar &vvcPed2, coPLINK::parameters *clsParas)
	{
		int		i, n, ret = 0;
		char	cs[20];

		cout << "Verifying the read top 6 columns for PED and all 4 columns for MAP ..." << endl;

		///////////// verify the data of Ped //////////////////
		// search non-empty entries
		n = 0;
		for (i = 0; i<4; i++){
			if (vvsPed4[i].size()>0){
				n = vvsPed4[i].size();
				break;
			}
		}

		if (n == 0){
			for (i = 0; i < 2; i++){
				if (vvcPed2[i].size() > 0){
					n = vvcPed2[i].size();
					break;
				}
			}
		}

		// checking missing entries and imputing
		if (vvsPed4[0].size() == 0 && n > 0){	// imputing "family"
			for (i = 0; i < n; i++){ vvsPed4[0].push_back("1"); } // fixed in 1
		}

		if (vvsPed4[1].size() == 0 && n > 0){	// imputing "individual"
			for (i = 0; i < n; i++) {
				sprintf(cs, "%d", i + 1);
				vvsPed4[1].push_back(cs);		// serial No.
			}
		}

		if (vvsPed4[2].size() == 0 && n > 0){	// imputing "paternal"
			for (i = 0; i < n; i++){ vvsPed4[2].push_back("0"); }	// fixed in 0
		}

		if (vvsPed4[3].size() == 0 && n > 0){	// imputing "maternal"
			for (i = 0; i < n; i++){ vvsPed4[3].push_back("0"); }	// fixed in 0
		}

		if (vvcPed2[0].size() == 0 && n > 0){	// imputing "sex"
			CRandomMersenne crnd(clsParas->uRndSeed);

			for (i = 0; i < n; i++){ vvcPed2[0].push_back(I2C(crnd.IRandom(1, 2))); }	// generating randomly (PLINK does not care the data with unkonwn sex)
		}

		if (vvcPed2[1].size() == 0 && n > 0){	// imputing "phenotye"
			for (i = 0; i < n; i++){ vvcPed2[1].push_back('0'); }	// fixed in PLINK's "unknown" of 0
		}

		if (n > 0){	// check length
			for (i = 1; i < 4; i++){
				if (n != vvsPed4[i].size() && vvsPed4[i].size() != 0){
					fetalError("The length of \"" + sArgCodes[i] + "\" does not match that of \"" + sArgCodes[0]
						+ "\". Check the settings in argument file and file " + clsParas->vstPed6map[i].fn + ", please.", clsParas);
				}
			}

			for (i = 0; i < 2; i++){
				if (n != vvcPed2[i].size() && vvcPed2.size() != 0){
					fetalError("The length of \"" + sArgCodes[i + 4] + "\" does not match that of \"" + sArgCodes[0]
						+ "\". Check the settings in argument file and file " + clsParas->vstPed6map[i + 4].fn + ", please.", clsParas);
				}
			}
		}
		else ret += 1;	// all of the top 6 in PED are missing, and need impute next step

		//////////// verify the data of Map //////////////
		// search non-empty entries
		n = 0;
		for (i = 0; i<4; i++){
			if (vvsMAP[i].size()>0){
				n = vvsMAP[i].size();
				break;
			}
		}

		// checking missing entries and imputing
		if (vvsMAP[0].size() == 0 && n > 0){	// imputing "chr"
			for (i = 0; i < n; i++){ vvsMAP[0].push_back(clsParas->sChrNo); }	// 0 if unplaced
		}

		if (vvsMAP[1].size() == 0 && n > 0){	// imputing "SNP id"
			for (i = 0; i < n; i++) {
				sprintf(cs, "SNP%d", i + 1);
				vvsMAP[1].push_back(cs);		// serial No.
			}
		}

		if (vvsMAP[2].size() == 0 && n > 0){	// imputing "genetic distance"
			for (i = 0; i < n; i++){ vvsMAP[2].push_back("0"); }	// fixed in 0
		}

		if (vvsMAP[3].size() == 0 && n > 0){	// imputing "position"
			for (i = 0; i < n; i++){ vvsMAP[3].push_back("0"); }	// fixed in 0
		}

		if (n > 0){	// has non-empty entry
			for (i = 1; i < 4; i++){
				if (n != vvsMAP[i].size()){
					fetalError("The length of \"" + sArgCodes[i + 6] + "\" does not match that of \"" + sArgCodes[6]
						+ "\". Check the settings in argument file and file " + clsParas->vstPed6map[i + 6].fn + ", please.", clsParas);
				}
			}
		}
		else ret += 2;	// all of the 4 col.s in MAP are empty

		return ret;
	}

	/************************************
	* 读取基因型数据，并补齐PED和MAP的全空列
	* vvsPed4 = Ped前4列. Family ID, Individual ID, Paternal ID and Maternal ID respectively
	* vvsMAP = Whole col.s of Map
	* vvcPed2 = 5 and 6 col. of Ped
	* vvcAlleles = matrix of sGenotypes
	* clsParas = 类参数指针
	*************************************/
	void readGenotypes(vvString &vvsPed4, vvString &vvsMAP, vvChar &vvcPed2, vvChar &vvcAlleles, coPLINK::parameters *clsParas)
	{
		fstream		fp;
		string		sLine, sOldFn;
		vString		vsText, vs;
		vInt		viNull;			// save line No.s of null lines
		int			uv, ud, i, ii, n, iSNP;
		char		cs[50], c;

		cout << "Reading source file " << clsParas->struGenotype.fn << " to get genotypes for PED ..." << endl;
		cout << "\tCAUTION: If the source file cannot be found, a path may be added in the arguments file." << endl;

		// read genotypes
		openStreamFile(fp, clsParas->struGenotype.fn.c_str(), ios::in);
		n = 0;
		i = 0;
		while (getline(fp, sLine))
		{
			n++;
			trimString(sLine);					//删除前后空格及TAB
			trimRedundance(sLine, true);		//删除中间多余空格及TAB（只保留一个）, and replace tab with space

			if (sLine.length() == 0) {
				viNull.push_back(n);
				continue;
			}

			vsText.push_back(sLine);
			cout << '\t' << ++i << " ...\r";
		}
		fp.close();
		fp.clear();
		cout << endl << "\tAnalyzing ..." << endl;

		if (((int)vsText.size() - 1) < clsParas->struGenotype.lt.y){
			fetalError("The specified area in source file "
				+ clsParas->struGenotype.fn + " includes nothing. Chech the settings in argument file and the source file, please.", clsParas);
		}

		// resize 2 arguments relating to "row"
		if (!viNull.empty()){
			n = clsParas->struGenotype.lt.y;
			ii = clsParas->struGenotype.rb.y;

			for (i = 0; i < (int)viNull.size(); i++){
				if (viNull[i] >= n && viNull[i] > ii){
					break;
				}
				else {
					if (viNull[i] < n){ clsParas->struGenotype.lt.y--; }

					if (viNull[i] <= ii){ clsParas->struGenotype.rb.y--; }
				}
			}
		}

		Point r;
		c = clsParas->struGenotype.delim == '\t' ? ' ' : clsParas->struGenotype.delim;				// tab was repaced with space at prev. steps
		stringSplit(vsText[clsParas->struGenotype.lt.y].c_str(), vs, c);	// need keep null string

		// get real right-bottom corner //
		// right
		if (clsParas->struGenotype.rb.x < 0){ r.x = clsParas->struGenotype.rb.x + vs.size() + 1; }
		else if (clsParas->struGenotype.rb.x == 0){ r.x = vs.size(); }
		else{ r.x = clsParas->struGenotype.rb.x; }

		//bottom
		if (clsParas->struGenotype.rb.y < 0){ r.y = clsParas->struGenotype.rb.y + vsText.size() + 1; }
		else if (clsParas->struGenotype.rb.y == 0){ r.y = vsText.size(); }
		else{ r.y = clsParas->struGenotype.rb.y; }

		if (r.x <= clsParas->struGenotype.lt.x){
			fetalError("The real <right> is less than the <left> while setting a negative <right> in coding [MATRIX]. Check the settings in argument file and file"
				+ clsParas->struGenotype.fn + ", please.", clsParas);
		}

		if (r.y <= clsParas->struGenotype.lt.y){
			fetalError("The real <bottom> is less than the <top> while setting a negative <bottom> in coding [MATRIX]. Check the settings in argument file and file"
				+ clsParas->struGenotype.fn + ", please.", clsParas);
		}

		vChar	vc;
		c = clsParas->struGenotype.delim == '\t' ? ' ' : clsParas->struGenotype.delim;				// tab was repaced with space at prev. steps
		for (uv = clsParas->struGenotype.lt.y; uv < r.y; uv++){
			stringSplit(vsText[uv].c_str(), vs, c);	// need keep null string
			n = vs.size();
			for (i = clsParas->struGenotype.lt.x; i < r.x; i++){	// scan each allele
				if (i == n){
					sprintf(cs, "%d", n);
					sLine = cs;
					sprintf(cs, "%d", uv);
					fetalError("The row " + (string)cs + " does not include all alleles. The number of its columns is " + sLine, clsParas);
				}

				trimString(vs[i]);
				if (clsParas->struGenotype.missing[0] == MISSING_ALLELE_CHR && clsParas->struGenotype.missing[1] == '\0'){
					if ((vs[i][0] == PLNK_PED_MISSING_ALLELE1)
						|| (vs[i][0] == PLNK_PED_MISSING_ALLELE2)
						|| (vs[i][0] == PLNK_PED_MISSING_ALLELE3)
						|| (vs[i][0] == PLNK_PED_MISSING_ALLELE4))
					{
						vc.push_back(MISSING_ALLELE_CHR);
					}
					else{
						vc.push_back(vs[i][0]);
					}
				}
				else if (clsParas->struGenotype.missing == vs[i]){
					vc.push_back(MISSING_ALLELE_CHR);
				}
				else {
					vc.push_back(vs[i][0]);
				}
			}
			vvcAlleles.push_back(vc);
			vc.clear();
		}
		vString().swap(vsText);
		vString().swap(vs);
		vChar().swap(vc);

		// verify matrix (unnecessary, it is done in reading)

		// check even number if need
		if (clsParas->struGenotype.twoAllele){
			// number of rows/col.s of SNPs
			if (clsParas->struGenotype.SNPrcCnt == SNP_2_COL || clsParas->struGenotype.SNPrcCnt == SNP_1_ROW){ i = vvcAlleles[0].size(); }
			else{ i = vvcAlleles.size(); }

			if (i / 2 != (float)i / 2){
				sprintf(cs, "%d", i);
				fetalError("The number of allele rows is " + (string)cs + " but not even.", clsParas);
			}
		}

		cout << "Imputing the read top 6 columns for PED and all 4 columns for MAP ..." << endl;
		/////////// imputing if need ////////////////
		if (vvsPed4[0].size() == 0){	// all of top 6 col.s in PED are empty
			CRandomMersenne crnd(clsParas->uRndSeed);
			// sample size
			if (clsParas->struGenotype.twoAllele){
				switch (clsParas->struGenotype.SNPrcCnt)
				{
				case SNP_2_COL:{ n = vvcAlleles.size(); break; }
				case SNP_2_ROW:{ n = vvcAlleles[0].size(); break; }
				case SNP_1_COL:{ n = vvcAlleles.size() / 2; break; }
				case SNP_1_ROW:{ n = vvcAlleles[0].size() / 2; break; }
				default: break;
				}
			}
			else{
				n = clsParas->struGenotype.SNPrcCnt == SNP_1_COL ? vvcAlleles.size() : vvcAlleles[0].size();
			}

			for (i = 0; i < n; i++){ vvsPed4[0].push_back("1"); }	// imputing "family", fixed in 1

			for (i = 0; i < n; i++) {
				sprintf(cs, "%d", i + 1);
				vvsPed4[1].push_back(cs);						// imputing "individual", serial No.
			}

			for (i = 0; i < n; i++){ vvsPed4[2].push_back("0"); }	// imputing "paternal", fixed in 0
			for (i = 0; i < n; i++){ vvsPed4[3].push_back("0"); }	// imputing "maternal", fixed in 0
			for (i = 0; i < n; i++){ vvcPed2[0].push_back(I2C(crnd.IRandom(1, 2))); }	// imputing "sex", generating randomly (PLINK does not care the data with unkonwn sex)
			for (i = 0; i < n; i++){ vvcPed2[1].push_back('0'); }	// imputing "phenotye", fixed in PLINK's "unknown" of 0
		}
		if (vvsMAP[0].size() == 0){		// all 4 col.s of MAP are empty
			// get SNP size
			if (clsParas->struGenotype.twoAllele){
				switch (clsParas->struGenotype.SNPrcCnt)
				{
				case SNP_2_COL:{ n = vvcAlleles[0].size() / 2; break; }
				case SNP_2_ROW:{ n = vvcAlleles.size() / 2; break; }
				case SNP_1_COL:{ n = vvcAlleles[0].size(); break; }
				case SNP_1_ROW:{ n = vvcAlleles.size(); break; }
				default: break;
				}
			}
			else{
				n = clsParas->struGenotype.SNPrcCnt == SNP_1_COL ? vvcAlleles[0].size() : vvcAlleles.size();
			}

			for (i = 0; i < n; i++){ vvsMAP[0].push_back("0"); }	// imputing "chr", fixed in 0 (unplaced)

			for (i = 0; i < n; i++) {
				sprintf(cs, "SNP%d", i + 1);
				vvsMAP[1].push_back(cs);						// imputing "SNP id", serial No.
			}

			for (i = 0; i < n; i++){ vvsMAP[2].push_back("0"); }	// imputing "genetic distance", fixed in 0
			for (i = 0; i < n; i++){ vvsMAP[3].push_back("0"); }	// imputing "position", fixed in 0
		}

		//////////// verifying matches among all data ////////////////
		i = vvsMAP[0].size();	// SNP size
		// get SNP size in matrix
		if (clsParas->struGenotype.twoAllele){
			switch (clsParas->struGenotype.SNPrcCnt)
			{
			case SNP_2_COL:{ n = vvcAlleles[0].size() / 2; break; }
			case SNP_2_ROW:{ n = vvcAlleles.size() / 2; break; }
			case SNP_1_COL:{ n = vvcAlleles[0].size(); break; }
			case SNP_1_ROW:{ n = vvcAlleles.size(); break; }
			default: break;
			}
		}
		else{
			n = clsParas->struGenotype.SNPrcCnt == SNP_1_COL ? vvcAlleles[0].size() : vvcAlleles.size();
		}

		if (!clsParas->struGenotype.twoAllele && n != i){
			sprintf(cs, "(%d vs. %d).", i, n);
			fetalError("The number of SNPs in MAP does not match to that of in alleles " + (string)cs, clsParas);
		}
		iSNP = n;

		i = vvsPed4[0].size();	// sample size
		// sample size in genotype
		if (clsParas->struGenotype.twoAllele){
			switch (clsParas->struGenotype.SNPrcCnt)
			{
			case SNP_2_COL:{ n = vvcAlleles.size(); break; }
			case SNP_2_ROW:{ n = vvcAlleles[0].size(); break; }
			case SNP_1_COL:{ n = vvcAlleles.size() / 2; break; }
			case SNP_1_ROW:{ n = vvcAlleles[0].size() / 2; break; }
			default: break;
			}
		}
		else{
			n = clsParas->struGenotype.SNPrcCnt == SNP_1_COL ? vvcAlleles.size() : vvcAlleles[0].size();
		}

		if (n != i){
			sprintf(cs, "(%d vs. %d).", i, n);
			fetalError("\nThe sample size in PED does not match to that of in alleles " + (string)cs, clsParas);
		}

		// normalizing
		if (clsParas->struGenotype.twoAllele && clsParas->struGenotype.Aa[0] != '\0'){
			switch (clsParas->struGenotype.SNPrcCnt)
			{
			case SNP_2_COL:
			{
				if (!NormalizeAlleles2Col(vvcAlleles, clsParas, sLine, true, false)){ fetalError(sLine, clsParas); }
				break;
			}
			case SNP_2_ROW:
			{
				if (!NormalizeAlleles2Row(vvcAlleles, clsParas, sLine, true, false)){ fetalError(sLine, clsParas); }
				break;
			}
			case SNP_1_COL:
			{
				if (!NormalizeAlleles1Col(vvcAlleles, clsParas, sLine, true, false)){ fetalError(sLine, clsParas); }
				break;
			}
			case SNP_1_ROW:
			{
				if (!NormalizeAlleles1Row(vvcAlleles, clsParas, sLine, true, false)){ fetalError(sLine, clsParas); }
				break;
			}
			default:
				break;
			}
		}

		// counting cases
		uv = ud = 0;
		for (i = 0; i < (int)vvcPed2[0].size(); i++){
			if (vvcPed2[0][i] == PLNK_PED_MALE){ uv++; }

			if (vvcPed2[1][i] == PLNK_PED_CASE_PHENOTYPE){ ud++; }
		}

		cout << "Total " << iSNP << "(s) and " << n << " samples which of " << uv << " males and " << n - uv << " females, including "
			<< ud << " cases and " << n - ud << " controls." << endl;

		clsParas->fpStat << ",-," << ud << ',' << n - ud << ',' << iSNP << endl;	// file	case	control	SNP

	}

	/************************************
	* 任意其它格式转PLINK ped
	* clsParas = 类参数指针
	*************************************/
	void Other2Ped(coPLINK::parameters *clsParas)
	{
		fstream		fp;
		string		sLine, sOldFn;
		vString		vsText, vs;
		vvString	vvsPed4(4);		// Ped前4列. Family ID, Individual ID, Paternal ID and Maternal ID respectively
		vvString	vvsMAP(4);		// Whole col.s of Map
		vvChar		vvcPed2(2);		// 5 and 6 col. of Ped
		vvChar		vvcAlleles;		// matrix of genotypes
		vInt		viNull;			// save line No.s of null lines
		int			uv, i, n;
		char		c;

		cout << "Your arguments lines:\n\tSection VECTOR (<type>,[row/col. No.],[begin],[delimiter],\n\t\t[direction],[filename]):" << endl;
		clsParas->fpLog << "Your arguments lines:\n\tSection VECTOR (<type>,[row/col. No.],[begin],[delimiter],[direction],[filename]):" << endl;

		for (i = 0; i < (int)clsParas->vstPed6map.size(); i++){
			cout << "\tLine " << i + 1 << ": "
				<< sArgCodes[clsParas->vstPed6map[i].type]
				<< DELIMITER4 << (clsParas->vstPed6map[i].no < 0 ? clsParas->vstPed6map[i].no : clsParas->vstPed6map[i].no + 1)
				<< DELIMITER4 << (clsParas->vstPed6map[i].posBegin < 0 ? clsParas->vstPed6map[i].posBegin : clsParas->vstPed6map[i].posBegin + 1);
				//<< DELIMITER4 << (clsParas->vstPed6map[i].posEnd < 0 ? clsParas->vstPed6map[i].posEnd : clsParas->vstPed6map[i].posEnd + 1);

			if (clsParas->vstPed6map[i].delim == ' '){ sLine = "space"; }
			else if (clsParas->vstPed6map[i].delim == '\t'){ sLine = "tab"; }
			else if (clsParas->vstPed6map[i].delim == ','){ sLine = "comma"; }
			else{ sLine = clsParas->vstPed6map[i].delim; }

			cout << DELIMITER4 << sLine
				<< DELIMITER4 << (clsParas->vstPed6map[i].inRow ? "row" : "column")
				<< DELIMITER4 << clsParas->vstPed6map[i].fn << endl;

			clsParas->fpLog << "\tLine " << i + 1 << ": "
				<< sArgCodes[clsParas->vstPed6map[i].type]
				<< DELIMITER4 << (clsParas->vstPed6map[i].no < 0 ? clsParas->vstPed6map[i].no : clsParas->vstPed6map[i].no + 1)
				<< DELIMITER4 << (clsParas->vstPed6map[i].posBegin < 0 ? clsParas->vstPed6map[i].posBegin : clsParas->vstPed6map[i].posBegin + 1)
				//<< DELIMITER4 << (clsParas->vstPed6map[i].posEnd < 0 ? clsParas->vstPed6map[i].posEnd : clsParas->vstPed6map[i].posEnd + 1)
				<< DELIMITER4 << sLine
				<< DELIMITER4 << (clsParas->vstPed6map[i].inRow ? "row" : "column")
				<< DELIMITER4 << clsParas->vstPed6map[i].fn << endl;
		}

		cout << "\tSection MATRIX (<filename>,[left],[top],[delimiter],[SNP rows/col.s],\n\t\t[character count],[missing],[case],[ctrl],[male],[female],\n\t\t[AA],[Aa],[aa]):" << endl;
		clsParas->fpLog << "\tSection MATRIX (<filename>,[left],[top],[delimiter],[SNP rows/col.s],[character count],[missing],[case],[ctrl],[male],[female],[AA],[Aa],[aa]):" << endl;

		cout << "\t"
			<< clsParas->struGenotype.fn
			<< DELIMITER4 << clsParas->struGenotype.lt.x
			<< DELIMITER4 << clsParas->struGenotype.lt.y;
			/*<< DELIMITER4 << (clsParas->struGenotype.rb.x < 0 ? clsParas->struGenotype.rb.x : clsParas->struGenotype.rb.x + 1)
			<< DELIMITER4 << (clsParas->struGenotype.rb.y < 0 ? clsParas->struGenotype.rb.y : clsParas->struGenotype.rb.y + 1);*/

		if (clsParas->struGenotype.delim == ' '){ sLine = "space"; }
		else if (clsParas->struGenotype.delim == '\t'){ sLine = "tab"; }
		else if (clsParas->struGenotype.delim == ','){ sLine = "comma"; }
		else{ sLine = clsParas->struGenotype.delim; }

		cout << DELIMITER4 << sLine
			<< DELIMITER4 << clsParas->struGenotype.SNPrcCnt
			<< DELIMITER4 << (clsParas->struGenotype.twoAllele ? 2 : 1)
			<< DELIMITER4 << clsParas->struGenotype.missing
			<< DELIMITER4 << clsParas->struGenotype.Case
			<< DELIMITER4 << clsParas->struGenotype.Ctrl
			<< DELIMITER4 << clsParas->struGenotype.male
			<< DELIMITER4 << clsParas->struGenotype.female
			<< DELIMITER4 << clsParas->struGenotype.AA[0]
			<< clsParas->struGenotype.AA[1]
			<< DELIMITER4 << clsParas->struGenotype.Aa[0]
			<< clsParas->struGenotype.Aa[1]
			<< DELIMITER4 << clsParas->struGenotype.aa[0]
			<< clsParas->struGenotype.aa[1]
			<< endl;

		clsParas->fpLog << "\t"
			<< clsParas->struGenotype.fn
			<< DELIMITER4 << clsParas->struGenotype.lt.x
			<< DELIMITER4 << clsParas->struGenotype.lt.y
			/*<< DELIMITER4 << (clsParas->struGenotype.rb.x < 0 ? clsParas->struGenotype.rb.x : clsParas->struGenotype.rb.x + 1)
			<< DELIMITER4 << (clsParas->struGenotype.rb.y < 0 ? clsParas->struGenotype.rb.y : clsParas->struGenotype.rb.y + 1)*/
			<< DELIMITER4 << sLine
			<< DELIMITER4 << clsParas->struGenotype.SNPrcCnt
			<< DELIMITER4 << (clsParas->struGenotype.twoAllele ? 2 : 1)
			<< DELIMITER4 << clsParas->struGenotype.missing
			<< DELIMITER4 << clsParas->struGenotype.Case
			<< DELIMITER4 << clsParas->struGenotype.Ctrl
			<< DELIMITER4 << clsParas->struGenotype.male
			<< DELIMITER4 << clsParas->struGenotype.female
			<< DELIMITER4 << clsParas->struGenotype.AA[0]
			<< clsParas->struGenotype.AA[1]
			<< DELIMITER4 << clsParas->struGenotype.Aa[0]
			<< clsParas->struGenotype.Aa[1]
			<< DELIMITER4 << clsParas->struGenotype.aa[0]
			<< clsParas->struGenotype.aa[1]
			<< endl;

		cout << "\nReading and verifying source file(s). Please wait ..." << endl;

		readPed6Map4Cols(vvsPed4, vvsMAP, vvcPed2, clsParas);			// reading
		verifyPed6Map4Cols(vvsPed4, vvsMAP, vvcPed2, clsParas);			// verifying and imputing
		readGenotypes(vvsPed4, vvsMAP, vvcPed2, vvcAlleles, clsParas);	// reading and verifying genotypes, and normalizing genotypes if need

		// save Ped
		sLine = getFn(clsParas->sOutputFilename, ".ped", true);
		cout << "Saving PED as " << sLine << " ..." << endl;
		openStreamFile(fp, sLine.c_str(), ios::out);

		n = vvsPed4[0].size();	// sample size
		for (i = 0; i < n; i++){ // each sample
			cout << '\t' << ceil((float)i / n * 100) << "% completed ...\r";

			// top 6 col.
			for (uv = 0; uv < 4; uv++){
				fp << vvsPed4[uv][i] << DELIMITER3;
			}
			fp << vvcPed2[0][i] << DELIMITER3 << vvcPed2[1][i];

			// alleles
			if (clsParas->struGenotype.twoAllele){
				switch (clsParas->struGenotype.SNPrcCnt)
				{
				case SNP_2_COL:
				{
					for (uv = 0; uv < (int)vvcAlleles[0].size(); uv++){
						fp << DELIMITER3;
						c = vvcAlleles[i][uv] == MISSING_ALLELE_CHR ? PLNK_PED_MISSING_ALLELE2 : vvcAlleles[i][uv];
						fp << c;
					}
					break;
				}
				case SNP_2_ROW:
				{
					for (uv = 0; uv < (int)vvcAlleles.size(); uv++){
						fp << DELIMITER3;
						c = vvcAlleles[uv][i] == MISSING_ALLELE_CHR ? PLNK_PED_MISSING_ALLELE2 : vvcAlleles[uv][i];
						fp << c;
					}
					break;
				}
				case SNP_1_COL:
				{
					for (uv = 0; uv < (int)vvcAlleles[0].size(); uv++){
						fp << DELIMITER3;
						c = vvcAlleles[2 * i][uv] == MISSING_ALLELE_CHR ? PLNK_PED_MISSING_ALLELE2 : vvcAlleles[2 * i][uv];
						fp << c;
						fp << DELIMITER3;
						c = vvcAlleles[2 * i + 1][uv] == MISSING_ALLELE_CHR ? PLNK_PED_MISSING_ALLELE2 : vvcAlleles[2 * i + 1][uv];
						fp << c;
					}
					break;
				}
				case SNP_1_ROW:
				{
					for (uv = 0; uv < (int)vvcAlleles.size(); uv++){
						fp << DELIMITER3;
						c = vvcAlleles[uv][2 * i] == MISSING_ALLELE_CHR ? PLNK_PED_MISSING_ALLELE2 : vvcAlleles[uv][2 * i];
						fp << c;
						fp << DELIMITER3;
						c = vvcAlleles[uv][2 * i + 1] == MISSING_ALLELE_CHR ? PLNK_PED_MISSING_ALLELE2 : vvcAlleles[uv][2 * i + 1];
						fp << c;
					}
					break;
				}
				default:
					break;
				}
			}
			else{
				if (clsParas->struGenotype.SNPrcCnt == SNP_1_COL){
					for (uv = 0; uv < (int)vvcAlleles[0].size(); uv++){
						if (vvcAlleles[i][uv] == clsParas->struGenotype.AA[0]){ fp << " D D"; }
						else if (vvcAlleles[i][uv] == clsParas->struGenotype.Aa[0]){ fp << " d D"; }
						else if (vvcAlleles[i][uv] == clsParas->struGenotype.aa[0]){ fp << " d d"; }
						else{ fp << " N N"; }
					}
				}
				else{
					for (uv = 0; uv < (int)vvcAlleles.size(); uv++){
						if (vvcAlleles[uv][i] == clsParas->struGenotype.AA[0]){ fp << " D D"; }
						else if (vvcAlleles[uv][i] == clsParas->struGenotype.Aa[0]){ fp << " d D"; }
						else if (vvcAlleles[uv][i] == clsParas->struGenotype.aa[0]){ fp << " d d"; }
						else{ fp << " N N"; }
					}
				}
			}

			fp << endl;
		}
		fp.close();
		fp.clear();
		vvChar().swap(vvcAlleles);
		vvString().swap(vvsPed4);
		vvChar().swap(vvcPed2);

		cout << "\t100% completed ..." << endl << "\tOK." << endl;
		clsParas->fpLog << "The PED file saved as " << sLine << endl;

		// save Map
		sLine = getFn(clsParas->sOutputFilename, ".map", true);
		cout << "Saving MAP as " << sLine << " ..." << endl;
		openStreamFile(fp, sLine.c_str(), ios::out);

		n = vvsMAP[0].size();
		for (i = 0; i < n; i++){
			cout << '\t' << ceil((float)i / n * 100) << "% completed ...\r";
			fp << vvsMAP[0][i] << DELIMITER3;
			fp << vvsMAP[1][i] << DELIMITER3;
			fp << vvsMAP[2][i] << DELIMITER3;
			fp << vvsMAP[3][i] << endl;
		}
		fp.close();
		cout << "\t100% completed ..." << endl << "\tOK." << endl;

		clsParas->fpLog << "The MAP file saved as " << sLine << endl;
	}

	/************************************
	* PLINK ped转任意其它格式 - 坐标变换（把小于0的坐标变换成大于或等于0）
	* clsParas = 类参数指针
	* 注：1. 变换结果是真实的行、列，没有加1。如共5行，那么-2变换为3而不是4。
	*     2. PED中的基因型矩阵在“other”中必须作为一个整体存放，即它的中间不能有其它行或列，但可以转置。
	*     3. MAP中的列在“other”中必须作为一个整行或整列存放，即它的中间不能有其它行或列，但可以变为行，各列也无需连续存放。
	*************************************/
	void coordinateTrans(string &fn, vvChar &vvcAlleles, vvString &vvsPed6, vvString &vvsMAP, int *rowCnt, int *colCnt, coPLINK::parameters *clsParas)
	{
		int		i, j, k, m, n, p;
		bool	b, bAlt, bInd2 = false;	// bInd2表示样本数是否加倍(V4.1增加)
		char	cs[10];
		string	s, s1, s2;

		//// transform wildcards ///////////////
		for (i = 0; i < (int)clsParas->vstInserts.size(); i++){
			if (clsParas->vstInserts[i].fn != fn) continue;

			// replace wildcards with serial No. of alleles, SNPs or samples or two alternated chars for alleles
			m = clsParas->vstInserts[i].vsInserts.size();
			for (j = 0; j < m; j++){
				b = false;
				bInd2 = false;
				if (clsParas->vstInserts[i].vsInserts[j][0] == WILDCARD_ALLELE_NO
					|| clsParas->vstInserts[i].vsInserts[j][0] == WILDCARD_SNP_NO
					|| clsParas->vstInserts[i].vsInserts[j][0] == WILDCARD_SAMPLE_NO
					|| clsParas->vstInserts[i].vsInserts[j][0] == WILDCARD_ALTER_AB)
				{	// the first is wildcard
					b = true;	// if a string include several wildcards, the first meeted wildcard will be used and the others will be ignored.
					bAlt = clsParas->vstInserts[i].vsInserts[j][0] == WILDCARD_ALTER_AB ? true : false;
					n = 0;	// 0th char is wildcard
				}

				if (!b){ // continue to find wildcard while the first is non-wildcard
					for (n = 1; n < (int)clsParas->vstInserts[i].vsInserts[j].size(); n++){
						if (clsParas->vstInserts[i].vsInserts[j][n] == WILDCARD_ALLELE_NO
							|| clsParas->vstInserts[i].vsInserts[j][n] == WILDCARD_SNP_NO
							|| clsParas->vstInserts[i].vsInserts[j][n] == WILDCARD_SAMPLE_NO
							|| clsParas->vstInserts[i].vsInserts[j][n] == WILDCARD_ALTER_AB)
						{
							if (clsParas->vstInserts[i].vsInserts[j][n - 1] == '\\') continue;

							b = true;
							bAlt = clsParas->vstInserts[i].vsInserts[j][n] == WILDCARD_ALTER_AB ? true : false;
							break;	// if a string include several wildcards, the first meeted wildcard will be used and the others will be ignored.
						}
					}
				}

				if (b){
					if (clsParas->vstInserts[i].vsInserts[j][n] == WILDCARD_ALLELE_NO
						|| clsParas->vstInserts[i].vsInserts[j][n] == WILDCARD_ALTER_AB){
						p = clsParas->struGenotype.twoAllele ? vvcAlleles[0].size() : vvcAlleles[0].size() / 2;	// allele cnt（V.1前：p = vvcAlleles[0].size()）
					}
					else if (clsParas->vstInserts[i].vsInserts[j][n] == WILDCARD_SAMPLE_NO){
						p = vvsPed6.size();	// sample cnt

						//V4.1 增加///////
						bInd2 = false;
						if ((clsParas->struGenotype.SNPrcCnt == 1 || clsParas->struGenotype.SNPrcCnt == 3) && clsParas->struGenotype.twoAllele) {
							p *= 2;	
							bInd2 = true;
						}
						////////////////
					}
					else{
						p = vvsMAP.size();	// SNP cnt
					}

					p++;
					s1 = n == 0 ? "" : clsParas->vstInserts[i].vsInserts[j].substr(0, n);

					//sprintf(cs, "afaf%d", n);	//test
					if (clsParas->vstInserts[i].vsInserts[j][n] == WILDCARD_ALTER_AB){
						// two chars used to alternating
						if ((int)clsParas->vstInserts[i].vsInserts[j].length() > n + 2){
							s2 = clsParas->vstInserts[i].vsInserts[j].substr(n + 3);
							cs[0] = clsParas->vstInserts[i].vsInserts[j][n + 1];
							cs[1] = clsParas->vstInserts[i].vsInserts[j][n + 2];
						}
						else{
							s2 = "";
							// two default chars
							cs[0] = '0';
							cs[1] = '1';
						}
					}
					else{
						s2 = clsParas->vstInserts[i].vsInserts[j].substr(n + 1);
					}

					b = true;


					for (k = 1; k < p; k++){
						if (bAlt){ // is WILDCARD_ALTER_AB
							s = s1 + (b ? cs[0] : cs[1]) + s2;
							b = !b;
						}
						else {
							if (bInd2){
								if (EVEN_NUMBER(k)) sprintf(cs, "%dB", k / 2);
								else sprintf(cs, "%dA", (k + 1) / 2);
							}
							else sprintf(cs, "%d", k);

							s = s1 + (string)cs + s2;
						}

						j++;
						clsParas->vstInserts[i].vsInserts.insert(clsParas->vstInserts[i].vsInserts.begin() + j, s);
					}

					p = j - (--p);
					clsParas->vstInserts[i].vsInserts.erase(clsParas->vstInserts[i].vsInserts.begin() + p);
					j--;
					m = clsParas->vstInserts[i].vsInserts.size();
				}
			}
			// scan again to replace "\#", "\$" and "\@" with "#", "$" and "@"
			for (j = 0; j < m; j++){
				s = WILDCARD_ALLELE_NO;
				clsParas->vstInserts[i].vsInserts[j] = replace_all_distinct(clsParas->vstInserts[i].vsInserts[j], ESC_ALLELE_STR, s);
				s = WILDCARD_SNP_NO;
				clsParas->vstInserts[i].vsInserts[j] = replace_all_distinct(clsParas->vstInserts[i].vsInserts[j], ESC_SNP_STR, s);
				s = WILDCARD_SAMPLE_NO;
				clsParas->vstInserts[i].vsInserts[j] = replace_all_distinct(clsParas->vstInserts[i].vsInserts[j], ESC_SAMPLE_STR, s);
				s = WILDCARD_ALTER_AB;
				clsParas->vstInserts[i].vsInserts[j] = replace_all_distinct(clsParas->vstInserts[i].vsInserts[j], ESC_ALTER_STR, s);
			}
		}

		////// transform negative row No. into positive or 0 ////////
		// transform rb.y firstly because lt.y >= 0 (cannot be set negative)
		if (clsParas->struGenotype.rb.y <= clsParas->struGenotype.lt.y && clsParas->struGenotype.fn == fn) {
			m = clsParas->struGenotype.lt.y;

			if (clsParas->struGenotype.twoAllele){
				switch (clsParas->struGenotype.SNPrcCnt)
				{
				case SNP_2_COL:{ m += vvcAlleles.size(); break; }
				case SNP_2_ROW:{ m += vvcAlleles[0].size(); break; }
				case SNP_1_COL:{ m += vvcAlleles.size() * 2; break; }
				case SNP_1_ROW:{ m += vvcAlleles[0].size() / 2; break; }
				default: break;
				}
			}
			else{
				if (clsParas->struGenotype.SNPrcCnt == SNP_1_COL){ m += vvcAlleles.size(); }
				else{ m += vvcAlleles[0].size() / 2; }
			}
			clsParas->struGenotype.rb.y = --m;	// the real rb.y (not plus 1)
		}
		else if (clsParas->struGenotype.fn == fn){
			m = clsParas->struGenotype.rb.y;
		}
		else{
			m = 0;
		}

		// find the maximum positive row No.
		for (i = 0; i < (int)clsParas->vstPed6map.size(); i++){
			if (clsParas->vstPed6map[i].fn != fn) continue;

			if (clsParas->vstPed6map[i].inRow) {
				if (clsParas->vstPed6map[i].no > m){ m = clsParas->vstPed6map[i].no; }
			}
			else if (clsParas->vstPed6map[i].posBegin >= 0){
				k = clsParas->vstPed6map[i].posBegin;
				k += clsParas->vstPed6map[i].type < CHROMOSOME_ID ? vvsPed6.size() : vvsMAP.size();
				k--;	// purpose is row No. not count, so --
				if (k > m){ m = k; }
			}
		}
		for (i = 0; i < (int)clsParas->vstInserts.size(); i++){
			if (clsParas->vstInserts[i].fn != fn) continue;

			if (clsParas->vstInserts[i].inRow) {
				if (clsParas->vstInserts[i].no > m) m = clsParas->vstInserts[i].no;
			}
			else if (clsParas->vstInserts[i].posBegin >= 0){
				k = clsParas->vstInserts[i].posBegin;
				k += clsParas->vstInserts[i].vsInserts.size();
				k--;
				if (k > m){ m = k; }
			}
		}
		// find the minimum negative row No. next the matrix
		k = 0;
		if (clsParas->struGenotype.fn == fn) {	// matrix is included the file
			if (clsParas->struGenotype.rb.y >= m) {	// height of matrix has not been included in m
				for (i = 0; i < (int)clsParas->vstPed6map.size(); i++){
					if (clsParas->vstPed6map[i].fn != fn || !clsParas->vstPed6map[i].inRow) continue;

					if (clsParas->vstPed6map[i].no < 0) {
						j = clsParas->vstPed6map[i].no + m;
						if (j >= clsParas->struGenotype.lt.y && j <= m && clsParas->vstPed6map[i].no < k){
							k = clsParas->vstPed6map[i].no;
						}
					}
				}
			}
			for (i = 0; i < (int)clsParas->vstInserts.size(); i++){
				if (clsParas->vstInserts[i].fn != fn || !clsParas->vstInserts[i].inRow) continue;

				if (clsParas->vstInserts[i].no < 0){
					j = clsParas->vstInserts[i].no + m;
					if (j >= clsParas->struGenotype.lt.y && j <= m && clsParas->vstInserts[i].no < k){
						k = clsParas->vstInserts[i].no;
					}
				}
			}
		}
		// get total number of rows of the file
		m -= k;
		m++;
		*rowCnt = m;

		// transform the negative row No. into not less than 0
		for (i = 0; i < (int)clsParas->vstPed6map.size(); i++){
			if (clsParas->vstPed6map[i].fn != fn || !clsParas->vstPed6map[i].inRow) continue;

			if (clsParas->vstPed6map[i].no < 0){ clsParas->vstPed6map[i].no += m; }
		}

		for (i = 0; i < (int)clsParas->vstInserts.size(); i++){
			if (clsParas->vstInserts[i].fn != fn || !clsParas->vstInserts[i].inRow) continue;

			if (clsParas->vstInserts[i].no < 0){ clsParas->vstInserts[i].no += m; }
		}

		////// transform negative col. No. into positive or 0 ////////
		// transform rb.x firstly because lt.x >= 0 (cannot be set negative)
		if (clsParas->struGenotype.rb.x <= clsParas->struGenotype.lt.x && clsParas->struGenotype.fn == fn) {
			m = clsParas->struGenotype.lt.x;

			if (clsParas->struGenotype.twoAllele){
				switch (clsParas->struGenotype.SNPrcCnt)
				{
				case SNP_2_COL:{ m += vvcAlleles[0].size(); break; }
				case SNP_2_ROW:{ m += vvcAlleles.size(); break; }
				case SNP_1_COL:{ m += vvcAlleles[0].size() / 2; break; }
				case SNP_1_ROW:{ m += vvcAlleles.size() * 2; break; }
				default: break;
				}
			}
			else{
				if (clsParas->struGenotype.SNPrcCnt == SNP_1_COL){ m += vvcAlleles[0].size() / 2; }
				else{ m += vvcAlleles.size(); }
			}
			clsParas->struGenotype.rb.x = --m;	// the real rb.x (not plus 1)
		}
		else if (clsParas->struGenotype.fn == fn){
			m = clsParas->struGenotype.rb.x;
		}
		else{
			m = 0;
		}

		// find the maximum positive row No.
		for (i = 0; i < (int)clsParas->vstPed6map.size(); i++){
			if (clsParas->vstPed6map[i].fn != fn) continue;

			if (!clsParas->vstPed6map[i].inRow) {
				if (clsParas->vstPed6map[i].no > m){ m = clsParas->vstPed6map[i].no; }
			}
			else if (clsParas->vstPed6map[i].posBegin >= 0){
				k = clsParas->vstPed6map[i].posBegin;
				k += clsParas->vstPed6map[i].type < CHROMOSOME_ID ? vvsPed6.size() : vvsMAP.size();
				k--;
				if (k > m){ m = k; }
			}
		}

		for (i = 0; i < (int)clsParas->vstInserts.size(); i++){
			if (clsParas->vstInserts[i].fn != fn) continue;

			if (!clsParas->vstInserts[i].inRow) {
				if (clsParas->vstInserts[i].no > m){ m = clsParas->vstInserts[i].no; }
			}
			else if (clsParas->vstInserts[i].posBegin >= 0){
				k = clsParas->vstInserts[i].posBegin;
				k += clsParas->vstInserts[i].vsInserts.size();
				k--;
				if (k > m){ m = k; }
			}
		}
		// find the minimum negative col. No. next matrix
		k = 0;
		if (clsParas->struGenotype.fn == fn) {	// matrix is included the file
			if (clsParas->struGenotype.rb.y >= m) {	// height of matrix has not been included in m
				for (i = 0; i < (int)clsParas->vstPed6map.size(); i++){
					if (clsParas->vstPed6map[i].fn != fn || clsParas->vstPed6map[i].inRow) continue;

					if (clsParas->vstPed6map[i].no < 0) {
						j = clsParas->vstPed6map[i].no + m;

						if (j >= clsParas->struGenotype.lt.x && j <= m && clsParas->vstPed6map[i].no < k){
							k = clsParas->vstPed6map[i].no;
						}
					}
				}
			}
			for (i = 0; i < (int)clsParas->vstInserts.size(); i++){
				if (clsParas->vstInserts[i].fn != fn || clsParas->vstInserts[i].inRow) continue;

				if (clsParas->vstInserts[i].no < 0){
					j = clsParas->vstInserts[i].no + m;

					if (j >= clsParas->struGenotype.lt.x && j <= m && clsParas->vstInserts[i].no < k){
						k = clsParas->vstInserts[i].no;
					}
				}
			}
		}
		// get total number of col.s of the file
		m -= k;
		m++;
		*colCnt = m;

		// transform the negative col. No. into not less than 0
		for (i = 0; i < (int)clsParas->vstPed6map.size(); i++){
			if (clsParas->vstPed6map[i].fn != fn || clsParas->vstPed6map[i].inRow) continue;

			if (clsParas->vstPed6map[i].no < 0){ clsParas->vstPed6map[i].no += m; }
		}

		for (i = 0; i < (int)clsParas->vstInserts.size(); i++){
			if (clsParas->vstInserts[i].fn != fn || clsParas->vstInserts[i].inRow) continue;

			if (clsParas->vstInserts[i].no < 0){ clsParas->vstInserts[i].no += m; }
		}

		// transform the coordinate of right-bottom when it locates at the top-left corner of the coordinate of left-top
		if (clsParas->struGenotype.fn == fn) {
			if (clsParas->struGenotype.rb.x < clsParas->struGenotype.lt.x){ clsParas->struGenotype.rb.x = *colCnt - 1; }

			if (clsParas->struGenotype.rb.y < clsParas->struGenotype.lt.y){ clsParas->struGenotype.rb.y = *rowCnt - 1; }
		}
	}

}
