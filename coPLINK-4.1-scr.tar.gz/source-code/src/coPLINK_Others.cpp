//////////////////////////////////////////////////////////////////
//                                                              //
//           coPLINK (c) 2020-2024 Han-Ming LIU                 //
//                                                              //
// This file is distributed under the GNU General Public        //
// License, Version 3.  Please see the file COPYING for more    //
// details                                                      //
//                                                              //
//////////////////////////////////////////////////////////////////

#include "coPLINK_Others.h"
#include "../pubfun/hash.h"
#include "../random/randomc.h"
#include "../pubfun/specifyFunctions.h"

namespace coPLINK
{
	/****************************************************
	* PLINK ped 格式转 BOOST 格式（重载+2）
	* 用字符矩阵实现（不支持多字符组成基因型，多字符基因型只保留首字符）
	* vsMap = MAP文件内容（已删除多余分隔符）
	* vvcPed = 基因型矩阵（样本数行*2SNP列）
	* vsPed6 = PED文件的前6列
	* fOut = 输出文件名
	* bSwap = 当SNP的minor和major alleles数量相同时，是否交换两种等位基因
	* cDelimeter = 分隔符
	***************************************************
	PLINK ped文本格式（PED文件, N-missing）(每行一个个体)：
	1	1	0	0	1	1	A	A	G	T
	2	1	0	0	1	1	A	C	T	G
	3	1	0	0	1	1	C	C	G	G
	4	1	0	0	1	2	A	C	T	T
	5	1	0	0	1	2	C	C	G	T
	6	1	0	0	1	2	C	C	T	T
	前6列(前4列可多个字符组成)：
	Family ID
	Individual ID
	Paternal ID
	Maternal ID
	Sex (1=male; 2=female; other=unknown)
	Phenotype (1=unaffect; 2=affect)

	BOOST格式(每行一个个体)：
	1 2 2 0 0 0 0 2 2 1 2 0 2 2 0 1 …
	0 1 2 0 1 0 0 2 2 0 2 0 1 2 2 1 …
	0 2 1 0 0 0 1 0 2 0 2 1 1 2 0 2 …
	1 2 1 1 1 0 1 0 2 1 2 0 2 2 0 1 …
	第1列：0=control、1=case
	第2列以后（次等位基因个数）：0 = AA, 1 = Aa/aA, 2 = aa, -9 = missing
	*****************************************************/
	void Ped2BOOST(vString& vsPed6, vvChar vvcPed, parameters *clsParas)
	{
		int	uSampleCnt = vsPed6.size();
		if (uSampleCnt == 0) return;

		int	i, j, k;
		vvChar	vvcData;
		vChar	vcPhenotype(uSampleCnt);
		string	strBOOST;
		fstream	fp;

		// 取表型
		for (i = 0; i < uSampleCnt; i++) {
			j = 0;
			for (k = 0; k < (int)vsPed6[i].length(); k++) {
				if (vsPed6[i][k] == clsParas->cDelimeter) {
					j++;
					if (j == PLNK_PED_PHENOTYPE_COL) break;
				}
			}
			vcPhenotype[i] = vsPed6[i][++k];	// 只取首字符
		}
		vString().swap(vsPed6);

		convertPed2BOOST(vcPhenotype, vvcPed, vvcData, clsParas->bSwap, clsParas->bNorOn);	// retruned result using MISSING_ALLELE_CHR as missing
		vChar().swap(vcPhenotype);
		vvChar().swap(vvcPed);

		//生成BOOST文件名
		strBOOST = getFn(clsParas->sOutputFilename, ".txt");

		//生成BOOST文件
		openStreamFile(fp, strBOOST.c_str(), ios::out);

		for (i = 0; i < (int)vvcData.size(); i++) {
			fp << vvcData[i][0];
			for (j = 1; j < (int)vvcData[i].size(); j++) {
				if (vvcData[i][j] == MISSING_ALLELE_CHR){ fp << clsParas->cDelimeter << BOOST_MISSING_ALLELE_STR; }
				else{ fp << clsParas->cDelimeter << vvcData[i][j]; }
			}
			fp << endl;

			cout << '\t' << i << " ...\r";
		}
		fp.close();
		fp.clear();

		vvcData.clear();

		cout << "\n\tSave " << strBOOST << " OK." << endl;
	}

	/********************************************
	* 把ped格式转换成BOOST格式（程序对数据的处理均使用BOOST格式）
	* vcPhenotype = 表型字符向量（样本行）
	* vvcAllele = 基因型字符矩阵（样本行*2SNP列）
	* vvcData = 输出字符矩阵
	* bSwap = 当SNP的minor和major alleles数量相同时，是否交换两种等位基因
	* bNorOn = 测试用开关（默认true）部分转换会查找主、次等位基因（如--ped2boost），此时，若数据已归一化，那么当SNP的主、次等位基因个数相等时，
	*			则转换的查找该SNP的主、次等位基因与原主、次等位基因可能不同，从而导致数据的比较不相同。该开关用于关闭此类查找。
	*			当--nor后跟小于0的数则关闭查找（即bNorOn=false）。
	*
	* 说明：函数只枚举各种可能的MISSING符号来进行转换，
	*       这样枚举不全的几率过要小于函数convertPed2BOOST
	*********************************************/
	void convertPed2BOOST(vChar &vcPhenotype, vvChar &vvcAllele, vvChar &vvcData, bool bSwap, bool bNorOn)
	{
		char			c, cA1, cA2;
		int				i, j, j1, uA1, uA2, uSampleCnt;
		int				k;
		vector<char>	vctmp;

		//转换等位基因符号为显、隐性形式（次等位基因为隐性）
		uSampleCnt = vvcAllele.size();	//行数（样本数）

		if (bNorOn){	// 已归一化的数据，无需重新查找
			for (j = 0; j < (int)vvcAllele[0].size(); j += 2) {		//逐列（SNP）扫描
				uA1 = uA2 = 0;
				j1 = j + 1;
				for (i = 0; i < uSampleCnt; i++) {	//扫描一个SNP，查找两个等基因均非MISSING的首位置
					if ((vvcAllele[i][j] == PLNK_PED_MISSING_ALLELE1)
						|| (vvcAllele[i][j] == PLNK_PED_MISSING_ALLELE2)
						|| (vvcAllele[i][j] == PLNK_PED_MISSING_ALLELE3)
						|| (vvcAllele[i][j] == PLNK_PED_MISSING_ALLELE4)
						|| (vvcAllele[i][j] == MISSING_ALLELE_CHR)
						|| (vvcAllele[i][j1] == PLNK_PED_MISSING_ALLELE1)
						|| (vvcAllele[i][j1] == PLNK_PED_MISSING_ALLELE2)
						|| (vvcAllele[i][j1] == PLNK_PED_MISSING_ALLELE3)
						|| (vvcAllele[i][j1] == PLNK_PED_MISSING_ALLELE4)
						|| (vvcAllele[i][j1] == MISSING_ALLELE_CHR))
					{
						vvcAllele[i][j] = vvcAllele[i][j1] = MISSING_ALLELE_CHR;	//两个等位基因，只要有一个MISSING，则两个一起设为MISSING
						continue;
					}
					break;
				}
				if (i == uSampleCnt) continue;

				uA1++;
				c = vvcAllele[i][j];
				if (vvcAllele[i][j1] == c) uA1++;
				else uA2++;
				i++;
				for (; i < uSampleCnt; i++) {		//继续扫描（逐样本）
					if ((vvcAllele[i][j] == PLNK_PED_MISSING_ALLELE1)
						|| (vvcAllele[i][j] == PLNK_PED_MISSING_ALLELE2)
						|| (vvcAllele[i][j] == PLNK_PED_MISSING_ALLELE3)
						|| (vvcAllele[i][j] == PLNK_PED_MISSING_ALLELE4)
						|| (vvcAllele[i][j] == MISSING_ALLELE_CHR)
						|| (vvcAllele[i][j1] == PLNK_PED_MISSING_ALLELE1)
						|| (vvcAllele[i][j1] == PLNK_PED_MISSING_ALLELE2)
						|| (vvcAllele[i][j1] == PLNK_PED_MISSING_ALLELE3)
						|| (vvcAllele[i][j1] == PLNK_PED_MISSING_ALLELE4)
						|| (vvcAllele[i][j1] == MISSING_ALLELE_CHR))
					{
						vvcAllele[i][j] = vvcAllele[i][j1] = MISSING_ALLELE_CHR;	//两个等位基因，只要有一个MISSING，则两个一起设为MISSING
						continue;
					}

					if (vvcAllele[i][j] == c){ uA1++; }
					else{ uA2++; }
					if (vvcAllele[i][j1] == c){ uA1++; }
					else{ uA2++; }
				}

				if (uA1 < uA2) {
					cA1 = PLNK_PED_a;
					cA2 = PLNK_PED_A;
				}
				else {
					cA1 = PLNK_PED_A;
					cA2 = PLNK_PED_a;
				}
				for (i = 0; i < uSampleCnt; i++) {	//重新扫描该列（SNP），把等位基因替换成显、隐性形式
					if (vvcAllele[i][j] == MISSING_ALLELE_CHR) continue;

					if (bSwap && uA1 == uA2){		// 交换
						vvcAllele[i][j] = vvcAllele[i][j] == c ? cA2 : cA1;
						vvcAllele[i][j1] = vvcAllele[i][j1] == c ? cA2 : cA1;
					}
					else{
						vvcAllele[i][j] = vvcAllele[i][j] == c ? cA1 : cA2;
						vvcAllele[i][j1] = vvcAllele[i][j1] == c ? cA1 : cA2;
					}
				}
			}
		}

		//转BOOST格式（是一种通用格式：用次等位基因个数表示基因型，-9/小于0 表示MISSING）
		vvcData.reserve(uSampleCnt);
		vctmp.reserve(vvcAllele[0].size());
		for (i = 0; i < uSampleCnt; i++) {
			//转换成BOOST格式之表型
			c = vcPhenotype[i] == PLNK_PED_CASE_PHENOTYPE ? BOOST_CASE_PHENOTYPE : BOOST_CTRL_PHENOTYPE;
			vctmp.push_back(c);	

			//转换基因型
			for (j = 0; j < (int)vvcAllele[i].size(); j += 2) {
				if (vvcAllele[i][j] == MISSING_ALLELE_CHR){
					vctmp.push_back(MISSING_ALLELE_CHR);
					continue;
				}

				k = 0;
				if(vvcAllele[i][j] == PLNK_PED_a) k++;

				if(vvcAllele[i][j + 1] == PLNK_PED_a) k++;
				vctmp.push_back(I2C(k));
			}
			vvcData.push_back(vctmp);
			vctmp.clear();
		}
		vvChar().swap(vvcAllele);
	}

	/************************************
	* 把由cDelimeter1分隔的文本文件转为由cDelimeter2分隔
	*************************************/
	void Delimeter12Delimeter2(string fIn, string fOut, const char cDelimeter1, const char cDelimeter2, fstream &fpStat)
	{
		vString vsTmp;
		fstream	fpIn, fpOut;
		string	sLine;
		int		in, out;

		openStreamFile(fpIn, fIn.c_str(), ios::in);
		openStreamFile(fpOut, fOut.c_str(), ios::out);

		cout << "Reading file " << fIn << " and converting to " << fOut << "..." << endl;
		in = out = 0;
		//while (!fpIn.eof() && fpIn.good()) {	// 这种写法会把最后一个空行读入
		//	getline(fpIn, sLine);
		while (getline(fpIn, sLine)) {	// 这样不会读入最后一个空行
			in++;
			trimString(sLine);							//删除前后空格及TAB
			trimRedundance(sLine, true);				//删除中间多余空格及TAB（只保留一个）,所有TAB用空格替换掉（为分拆作准备）
			if (sLine.length() == 0) {
				fpOut << sLine << endl;
				out++;
				continue;
			}
			sLine = replaceChar(sLine, cDelimeter1, cDelimeter2);		//把所有TAB用空格替换掉（为分拆作准备）
			fpOut << sLine << endl;
			out++;
		}
		fpIn.close();
		fpOut.close();

		fpStat << ',' << fIn << ',' << in << "(in)," << out << "(out)," << fOut << "(outFn)" << endl;

		cout << "Read " << in << " lines and wrote " << out << " lines successfully." << endl;
	}

	/********************************************
	* Linkage格式转PLINK ped格式
	* clsParas = 参数类指针
	*
	* Linkage格式包含两个文件：数据文件（默认扩展名.ped）和位点信息文件（默认扩展名.info）
	* 数据文件格式：
	* 每行一个样本个体
	* 如：(N-missing)
	IBD054 430 0   0   1 0 1  3 3  1 4  1
	IBD054 412 430 431 2 2 1  3 1  3 4  1
	IBD055 431 0   0   2 0 3  3 3  3 1  1
	...

	* 前6列是表头，从第7列开始每2列代表一个SNP位点
	*  前6列：
	*  1 - 家系的ID
	*  2 - 个体的ID
	*  3 - 父亲的ID
	*  4 - 母亲的ID
	*  5 - 性别信息。1代表男性，2代表女性
	*  6 - 患病状态。0表示疾病状态未知；1表示个体未患病，2代表个体患病
	* 从第7列起每2列代表一个SNP位点：1代表碱基A；2代表碱基C；3代表碱基G；4代表碱基T。 缺失数据用0表示
	*
	* 位点信息文件格式：
	* 包含两列，第一列为SNP的名字，第二列为SNP的物理位置（bp）
	* 如：
	IGR1118a_1 274044
	IGR1119a_1 274541
	IGR1143a_1 286593
	...
	*************************************/
	void Lingkage2Ped(coPLINK::parameters *clsParas)
	{
		string		sLine;
		char		cS[127];
		int			i, j, k, m, uSNP;
		fstream		fp;
		vString		vsPed, vs;
		vvString	vvsMap;
		char		code[] = {PLNK_PED_MISSING_ALLELE2, 'A', 'C', 'G', 'T'};

		//读取 Linkage 数据文件（默认扩展名.ped）

		/************ Plink Ped格式文件 *****
		1	1	0	0	1	1	A	A	G	T
		2	1	0	0	1	1	A	C	T	G
		3	1	0	0	1	1	C	C	G	G
		4	1	0	0	1	2	A	C	T	T
		5	1	0	0	1	2	C	C	G	T
		6	1	0	0	1	2	C	C	T	T
		.......

		N-missing。每行一个个体
		前6列(前4列可多个字符组成)：
		Family ID
		Individual ID
		Paternal ID
		Maternal ID
		Sex (1=male; 2=female; other=unknown)
		Phenotype (1=unaffect; 2=affect)
		*************************************/

		cout << "Loading data file " << clsParas->sInputFilename << " ..." << endl;

		sLine = getFn(clsParas->sInputFilename, ".ped", true);	//未指定扩展名，则使用默认.ped
		openStreamFile(fp, sLine.c_str(), ios::in);

		m = 0;
		while (getline(fp, sLine)) {
			trimString(sLine);							//删除前后空格及TAB
			trimRedundance(sLine, true);				//删除中间多余空格及TAB（只保留一个）,所有TAB用空格替换
			if (sLine.length() == 0) continue;

			k = 0;
			for (i = 0; i < 6; i++) {
				k = sLine.find(DELIMITER3, k);
				if (k == string::npos) break;

				k++;
			}
			if (k == string::npos) continue;				//少于6列

			i = sLine.length();
			for (; k < i; k++) {
				if (sLine[k] == DELIMITER3) continue;

				j = C2I(sLine[k]);
				if (j > 0 && j < 5){ sLine[k] = code[j]; }
				else{ sLine[k] = PLNK_PED_MISSING_ALLELE2; }

				while (k < i) {		//查找下一个分隔符“ ”
					if (sLine[k + 1] == DELIMITER3) break;

					k++;
				}
			}

			vsPed.push_back(sLine);
			cout << '\t' << ++m << " ...\r";
		}
		sLine = "";
		fp.close();
		fp.clear();
		cout << endl;

		//数据有效性检查
		sLine = DELIMITER3;
		j = stringCount(vsPed[0], sLine);		//vsPed[0]中空格的个数
		uSNP = ((j - 6) + 1) / 2;				// SNP个数

		for (i = 1; i < (int)vsPed.size(); i++) {
			if (stringCount(vsPed[i], sLine) != j) {
				char cs[100];
				sprintf(cs, "The column number of in file does not match to the first at row %d.", i + 1);
				fetalError(cs, clsParas);
			}
		}

		if (clsParas->bNormalize){
			if (!NormalizePed(vsPed, 6, sLine)) {	// 归一化
				fetalError(sLine, clsParas);
			}
		}

		coPLINK::readWithDelimeter(vvsMap, coPLINK::getFn(clsParas->sInputFilename, ".info", true), clsParas);

		if (vvsMap.size() == 0) {		//对应的info文件不存在
			vvsMap.reserve(uSNP);
			for (i = 0; i < uSNP; i++) {
				sprintf(cS, "SNP%d", i + 1);
				sLine = cS;
				vs.push_back(sLine);
				vs.push_back("0");
				vvsMap.push_back(vs);
			}
		}

		//HWE和MAF检验
		if (clsParas->bPreprocess) {
			if (!chkSample4Ped(vsPed, clsParas)){	//样本检查（在预处理之前，其可能删除样本）
				fetalError("An error is encountered while alleles missing rates of samples checking.", clsParas);
			}

			if (!preprocessPed(vsPed, vvsMap, clsParas, true, sLine)) {	//HWE和MAF检验
				fetalError("An error is encountered while preprocessing: " + sLine, clsParas);
			}
			// 重新计算SNP数
			sLine = DELIMITER3;
			j = stringCount(vsPed[0], sLine);		//vsPed[0]中空格的个数
			uSNP = ((j - 6) + 1) / 2;				//SNP个数
		}

		//数据有效性检查
		if (!clsParas->bPreprocess && vvsMap.size() != uSNP) {	// 预处理会做此工作
			fetalError("The SNP number of INFO file does not match to PED, check please.", clsParas);
		}

		cout << "Converting to ped ..." << endl;

		//输出ped文件
		sLine = getFn(clsParas->sOutputFilename, ".ped");
		openStreamFile(fp, sLine.c_str(), ios::out);

		for (i = 0; i < (int)vsPed.size(); i++) {
			fp << vsPed[i];
			fp << endl;

			cout << '\t' << i << " ...\r";
		}
		fp.close();
		fp.clear();
		cout << "\n\tSave " << sLine << " OK." << endl;

		cout << "Converting to map ..." << endl;

		//输出map文件
		sLine = getFn(clsParas->sOutputFilename, ".map");
		openStreamFile(fp, sLine.c_str(), ios::out);
		uSNP = vvsMap.size();

		for (i = 0; i < uSNP; i++) {
			fp << clsParas->sChrNo << DELIMITER3;	// chr. no.
			fp << vvsMap[i][0];					// SNP label
			fp << " 0 ";							// genetic distance
			fp << vvsMap[i][1] << endl;			// base-pair pos.
			cout << '\t' << i << " ...\r";
		}
		fp.close();
		fp.clear();
		cout << "\n\tSave " << sLine << ".fam OK." << endl;

		// 统计表型
		m = 0;
		for (i = 0; i < (int)vsPed.size(); i++) {
			j = 0;
			for (k = 0; k < (int)vsPed[i].length(); k++) {
				if (vsPed[i][k] == DELIMITER3) {
					j++;
					if (j == PLNK_PED_PHENOTYPE_COL) break;
				}
			}
			if (PLNK_PED_CASE_PHENOTYPE == vsPed[i][++k]) m++;		// 只取首字符统计casse
		}

		clsParas->fpStat << ',' << clsParas->sInputFilename << ',' << m << ',' << vsPed.size() - m << ',' << uSNP << endl;

		cout << "Converted OK. Includes " << m << " cases, " << (vsPed.size() - m)
			<< " controls and " << uSNP << " SNPs" << endl;

		clsParas->fpLog << "Converted OK." << endl;
	}

	/********************************************
	* PLINK ped格式转 Linkage格式或 GS-Linkage 格式
	* clsParas = 参数类指针
	* bLinkage = 是否是 Linkage 格式
	***************************************************
	* Linkage格式包含两个文件：数据文件（默认扩展名.ped）和位点信息文件（默认扩展名.info）
	* 数据文件格式：
	* 每行一个样本个体
	* 如：(N-missing)
	IBD054 430 0   0   1 0 1  3 3  1 4  1
	IBD054 412 430 431 2 2 1  3 1  3 4  1
	IBD055 431 0   0   2 0 3  3 3  3 1  1
	...

	* 前6列是表头，从第7列开始每2列代表一个SNP位点
	*  前6列：
	*  1 - 家系的ID
	*  2 - 个体的ID
	*  3 - 父亲的ID
	*  4 - 母亲的ID
	*  5 - 性别信息。1代表男性，2代表女性
	*  6 - 患病状态。0表示疾病状态未知；1表示个体未患病，2代表个体患病
	* 从第7列起每2列代表一个SNP位点：1代表碱基A；2代表碱基C；3代表碱基G；4代表碱基T。 缺失数据用0表示
	*				GS-Linkage 格式：0 - missing allele, 1 - allele 0, 2 - allele 1
	*
	* 位点信息文件格式（GS-Linkage 格式无此文件）：
	* 包含两列，第一列为SNP的名字，第二列为SNP的物理位置（bp）
	* 如：
	IGR1118a_1 274044
	IGR1119a_1 274541
	IGR1143a_1 286593
	...
	*************************************/
	void Ped2Lingkage(coPLINK::parameters *clsParas, bool bLinkage)
	{
		string		sLine;
		char		cs[100], c1,c2;
		int			i, j, k, m, uSNP;
		fstream		fp;
		vvChar		vvcPed;
		vString		vsPed6;
		vvString	vvsMap;
		clsLinkage	clsA;
		bool		b, bOk;
		Point		lt, rb;

		cout << "Loading data file " << clsParas->sInputFilename << " ..." << endl;

		sLine = getFn(clsParas->sInputFilename, ".ped", true);	//未指定扩展名，则使用默认.ped

		// 改在 parameters.cpp 的 adddefaultparas中完成
		//if (!bLinkage && clsParas->bNorOn) clsParas->bNormalize = true;	// GS Linkage 只支持两种等位基因字符，所以，强制归一化
		//if (!clsParas->bNorOn) clsParas->bNormalize = false;	// 测试模式，输入的PED已归一化
		readPed(vvcPed, vsPed6, clsParas);

		if (clsParas->bSwap) {		// 交换矩形（lt, rb)间的等位基因数相同的major和minor alleles
			lt.x = 0; lt.y = 0;
			rb.x = vvcPed[0].size() - 1; rb.y = vvcPed.size() - 1;
			if (!swapAllelsInColDouble(vvcPed, &lt, &rb)){
				fetalError("The number of columns of SNPs is not even.", clsParas);
			}
		}

		if (bLinkage) readWithDelimeter(vvsMap, getFn(clsParas->sInputFilename, ".map", true), clsParas);

		//HWE和MAF检验
		if (clsParas->bPreprocess) {
			if (!chkSample4Ped(vvcPed, vsPed6, clsParas, sLine)) {	//样本检查（在预处理之前，其可能删除样本）
				fetalError("An error is encountered while alleles missing rates of samples checking: " + sLine, clsParas);
			}

			if (!preprocessPed(vvcPed, vvsMap, clsParas, bLinkage, sLine)) {	//HWE和MAF检验
				fetalError("An error is encountered while preprocessing:" + sLine, clsParas);
			}
		}

		cout << "Checking ..." << endl;

		//数据有效性检查
		uSNP = vvcPed[0].size() / 2;
		if (vvsMap.size() != uSNP && bLinkage) {
			fetalError("The SNP number of MAP file does not match to PED, check please.", clsParas);
		}

		if (!clsParas->bNormalize){
			// 检查等位基因符号数（不能超过4种）
			cs[0] = cs[1] = cs[2] = cs[3] = MISSING_ALLELE_CHR;
			for (i = 0; i < (int)vvcPed.size(); i++){
				for (j = 0; j < (int)vvcPed[i].size(); j++){
					if (vvcPed[i][j] == MISSING_ALLELE_CHR) continue;

					b = true;
					for (k = 0; k < 4; k++){
						if (vvcPed[i][j] == cs[k]){
							b = false;
							break;
						}
					}

					if (b){		// find an un-recorded char
						for (k = 0; k < 4; k++){
							if (MISSING_ALLELE_CHR == cs[k]){
								b = false;
								cs[k] = vvcPed[i][j];
								break;
							}
						}

						if (b) fetalError("The number of allele charachers in source exceeds 4.", clsParas);
					}
				}
				cout << '\t' << i << " ...\r";
			}
			cout << endl;
		}

		cout << (bLinkage ? "Converting to ped ..." : "Converting to dat ...") << endl;

		///////// ped 格式转换 ////////
		if (bLinkage){
			// 查找碱基组成并为其编码
			for (i = 0; i < (int)vvcPed[0].size(); i += 2){	// 逐SNP
				c1 = c2 = MISSING_ALLELE_CHR;
				b = false;
				for (j = 0; j < (int)vvcPed.size(); j++){	// 逐样本
					if (vvcPed[j][i] != MISSING_ALLELE_CHR){
						if (c1 == MISSING_ALLELE_CHR && vvcPed[j][i] != c2){
							c1 = vvcPed[j][i];
						}
						else if (c2 == MISSING_ALLELE_CHR && vvcPed[j][i] != c1){
							c2 = vvcPed[j][i];
						}
					}

					if (c1 != MISSING_ALLELE_CHR && c2 != MISSING_ALLELE_CHR) {
						bOk = clsA.addPair(c1, c2);
						b = true;
						break;
					}

					if (vvcPed[j][i + 1] != MISSING_ALLELE_CHR){
						if (c2 == MISSING_ALLELE_CHR && vvcPed[j][i + 1] != c1){
							c2 = vvcPed[j][i + 1];
						}
						else if (c1 == MISSING_ALLELE_CHR && vvcPed[j][i + 1] != c2){
							c1 = vvcPed[j][i + 1];
						}
					}

					if (c1 != MISSING_ALLELE_CHR && c2 != MISSING_ALLELE_CHR) {
						bOk = clsA.addPair(c1, c2);
						b = true;
						break;
					}

					if (b) break;
				}

				if (!bOk) break;	// 4个碱基已查找完成
			}
		}
		else{	// GS-Linkage的PED已归一化，无需查找
			// 一个等位基因符号占一行（两个字符），第一个字符是等位基因符号，第二个字符是对应的linkage编码
			clsA.codePair.resize(2);
			clsA.codePair[0].resize(2);
			clsA.codePair[1].resize(2);
			clsA.codePair[0][0] = PLNK_PED_a;	// minor 为 allele0（建议与gs-linkage2ped一致）
			clsA.codePair[0][1] = '1';
			clsA.codePair[1][0] = PLNK_PED_A;
			clsA.codePair[1][1] = '2';
		}

		if (clsA.codePair.empty()) fetalError("The source has not any valide genotype.", clsParas);

		if (bLinkage) clsA.correctCodes();

		//if (!bLinkage){	// 一个等位基因符号占一行（两个字符），第一个字符是等位基因符号，第二个字符是对应的linkage编码
		//	if (clsA.codePair[0][1] == '3'){ clsA.codePair[0][1] = '2'; }		// GS-Linkage 格式只有两种等位基因
		//	else if (clsA.codePair[1][1] == '3'){ clsA.codePair[1][1] = '2'; }	// GS-Linkage 格式只有两种等位基因
		//}

		// 基因型编码
		for (i = 0; i < (int)vvcPed.size(); i++){	// 逐样本
			for (j = 0; j < (int)vvcPed[0].size(); j++){	// 逐碱基
				c1 = clsA.findCode(vvcPed[i][j]);
				if (c1 == MISSING_ALLELE_CHR){ c1 = '0'; }
				vvcPed[i][j] = c1;
			}
		}

		if (0){
			//数据碱基配对检查（防止出现1,2和3,4配对情况，实际数据会出现此类情况）
			b = false;
			for (i = 0; i < (int)vvcPed[0].size(); i += 2){	// 逐SNP
				for (j = 0; j < (int)vvcPed.size(); j++){	// 逐样本
					if ((vvcPed[j][i] == '1' && vvcPed[j][i + 1] == '2')
						|| (vvcPed[j][i] == '3' && vvcPed[j][i + 1] == '4'))
					{
						b = true;
						break;
					}
				}

				if (b) break;
			}

			if (b){
				cout << "Codes: " << clsA.codePair[0][0] << '/' << clsA.codePair[0][1] << '\t' << clsA.codePair[1][0] << '/' << clsA.codePair[1][1];

				if (clsA.codePair.size() > 2){ cout << '\t' << clsA.codePair[2][0] << '/' << clsA.codePair[2][1]; }

				if (clsA.codePair.size() > 3){ cout << '\t' << clsA.codePair[3][0] << '/' << clsA.codePair[3][1]; }

				cout << "\nError in file: " << vvcPed[j][i] << '/' << vvcPed[j][i + 1] << endl;

				sprintf(cs, "The base-pair of SNP %d is error at sample %d.", i / 2 + 1, j + 1);
				fetalError((string)cs, clsParas);
			}
		}

		

		//输出ped文件
		sLine = getFn(clsParas->sOutputFilename, (bLinkage ? ".ped" : ".dat"));
		openStreamFile(fp, sLine.c_str(), ios::out);

		for (i = 0; i < (int)vvcPed.size(); i++) {
			fp << vsPed6[i];
			
			for (j = 0; j < (int)vvcPed[i].size(); j++){
				fp << DELIMITER3 << vvcPed[i][j];
			}
			fp << endl;

			cout << '\t' << i << " ...\r";
		}
		uSNP = vvcPed[0].size() / 2;

		vvChar().swap(vvcPed);
		fp.close();
		fp.clear();
		cout << "\n\tSave " << sLine << " OK." << endl;

		if (bLinkage) {	// GS-Linkage 格式无此文件
			cout << "Converting to .info ..." << endl;

			//输出info文件
			sLine = getFn(clsParas->sOutputFilename, ".info");
			openStreamFile(fp, sLine.c_str(), ios::out);


			for (i = 0; i < uSNP; i++) {
				fp << vvsMap[i][1] << DELIMITER3	// SNP ID
					<< vvsMap[i][3] << endl;		// base-pair pos.					

				cout << '\t' << i << " ...\r";
			}
			fp.close();
			fp.clear();
			cout << "\n\tSave " << sLine << " OK." << endl;
		}

		// 统计表型
		m = 0;
		for (i = 0; i < (int)vsPed6.size(); i++) {
			j = 0;
			for (k = 0; k < (int)vsPed6[i].length(); k++) {
				if (vsPed6[i][k] == DELIMITER3) {
					j++;
					if (j == PLNK_PED_PHENOTYPE_COL) break;
				}
			}

			if (PLNK_PED_CASE_PHENOTYPE == vsPed6[i][++k]) m++;		// 只取首字符统计casse
		}

		clsParas->fpStat << ',' << clsParas->sInputFilename << ',' << m << ',' << vsPed6.size() - m << ',' << uSNP << endl;

		cout << "Converted OK. Includes " << m << " cases, " << (vsPed6.size() - m)
			<< " controls and " << uSNP << " SNPs" << endl;

		clsParas->fpLog << "Converted OK." << endl;
	}

	/********************************************
	* GWASimulator GWAS数据模拟器之Lingkage格式转PLINK ped格式
	* sIn = 输入文件名
	* sOut = 输出文件名
	* sChrNo = 染色体号（Linkage文件中没有包含染色体号，需另行指定）
	* bPreprocess = 是否做预处理（去除SNP中等位基因缺失率高于0.05；
	*	去除HWE检验失败（P <= hwe阀值)；去除MAF<0.05）
	* dHweCutoff = HWE检验阀值
	*
	* 数据文件格式（默认扩展名.dat）：
	* 每行一个样本个体
	* 前6列是表头，从第7列开始每2列代表一个SNP位点
	*  前6列：
	*  1 - 家系的ID
	*  2 - 个体的ID
	*  3 - 父亲的ID
	*  4 - 母亲的ID
	*  5 - 性别信息。1代表男性，2代表女性
	*  6 - 患病状态。0表示疾病状态未知；1表示个体未患病，2代表个体患病
	* 从第7列起每2列代表一个SNP位点：0 - missing allele, 1 - allele 0, 2 - allele 1
	*************************************/
	void GsLingkage2Ped(coPLINK::parameters *clsParas)
	{
		string		sLine, sTmp;
		int			i, j, m, uSNP;
		int			k;
		fstream		fp;
		vString		vsPed;
		vvString	vvs;
		char		code[] = { PLNK_PED_MISSING_ALLELE2, PLNK_PED_a, PLNK_PED_A};

		//读取GWASimulator GWAS数据文件（默认扩展名.dat）

		/************ Plink Ped格式文件 *****
		1	1	0	0	1	1	A	A	G	T
		2	1	0	0	1	1	A	C	T	G
		3	1	0	0	1	1	C	C	G	G
		4	1	0	0	1	2	A	C	T	T
		5	1	0	0	1	2	C	C	G	T
		6	1	0	0	1	2	C	C	T	T
		.......

		N-missing。每行一个个体
		前6列(前4列可多个字符组成)：
		Family ID
		Individual ID
		Paternal ID
		Maternal ID
		Sex (1=male; 2=female; other=unknown)
		Phenotype (1=unaffect; 2=affect)
		*************************************/

		cout << "Loading data file " << clsParas->sInputFilename << " ..." << endl;

		//sLine = getFn(clsParas->sInputFilename, ".dat", true);	//未指定扩展名，则使用默认.dat
		sLine = clsParas->sInputFilename;
		openStreamFile(fp, sLine.c_str(), ios::in);

		m = 0;
		while (getline(fp, sLine)) {
			trimString(sLine);							//删除前后空格及TAB
			trimRedundance(sLine, true);				//删除中间多余空格及TAB（只保留一个）,所有TAB用空格替换
			if(sLine.length() == 0) continue;

			//replaceChar(sLine, DELIMITER2, DELIMITER3);	//把所有TAB用空格替换
			k = 0;
			for(i = 0; i < 6; i++) {
				k = sLine.find(DELIMITER3, k);
				if(k == string::npos) break;	

				k++;
			}
			if(k == string::npos) continue;				//少于6列

			i = sLine.length();
			for(; k < i; k++) {
				if(sLine[k] == DELIMITER3) continue;
				/*switch(sLine[k]) {
					case '0':
						sLine[k] = PLNK_PED_MISSING_ALLELE2;
						break;
					case '1': case '3':
						sLine[k] = PLNK_PED_A;
						break;
					case '2': case '4':
						sLine[k] = PLNK_PED_a;
						break;
				}*/
				j = C2I(sLine[k]);
				if (j > 0 && j < 3){ sLine[k] = code[j]; }
				else{ sLine[k] = PLNK_PED_MISSING_ALLELE2; }

				/*if (sLine[k] == '0') sLine[k] = PLNK_PED_MISSING_ALLELE2;
				else if (sLine[k] == '1' || sLine[k] == '3') sLine[k] = PLNK_PED_A;
				else if (sLine[k] == '2' || sLine[k] == '4') sLine[k] = PLNK_PED_a;*/

				while(k < i) {		//查找下一个分隔符“ ”
					if(sLine[k+1] == DELIMITER3) break;

					k++;
				}
			}

			vsPed.push_back(sLine);
			cout << '\t' << ++m << " ...\r";
		}
		sLine = "";
		fp.close();
		fp.clear();
		cout << endl;

		//数据有效性检查
		sTmp = DELIMITER3;
		j = stringCount(vsPed[0], sTmp);		//vsPed[0]中空格的个数
		for (i = 1; i < (int)vsPed.size(); i++) {
			if(stringCount(vsPed[i], sTmp) != j) {
				char cs[100];
				sprintf(cs, "The column number of in file does not match to the first at row %d.", i + 1);
				fetalError(cs, clsParas);
			}
		}

		if (clsParas->bNormalize){
			if (!NormalizePed(vsPed, 6, sLine)) {	// 归一化
				fetalError(sLine, clsParas);
			}
		}

		uSNP = ((j - 6) + 1) / 2;					// SNP个数
		//HWE和MAF检验
		if(clsParas->bPreprocess) {
			if (!chkSample4Ped(vsPed, clsParas)){	//样本检查（要比处理先，其可能删除样本）
				fetalError("An error is encountered while alleles missing rates of samples checking.", clsParas);
			}

			if(!preprocessPed(vsPed, vvs, clsParas, false, sLine)) {	//HWE和MAF检验
				fetalError("An error is encountered while preprocessing: " + sLine, clsParas);
			}
			// 重新计算SNP数
			sTmp = DELIMITER3;
			j = stringCount(vsPed[0], sTmp);		//vsPed[0]中空格的个数
			uSNP = ((j - 6) + 1) / 2;				//SNP个数
			
		}

		// 统计表型
		m = 0;
		for (i = 0; i < (int)vsPed.size(); i++) {
			j = 0;
			for (k = 0; k < (int)vsPed[i].length(); k++) {
				if (vsPed[i][k] == ' ') {
					j++;
					if (j == PLNK_PED_PHENOTYPE_COL) break;
				}
			}
			if (PLNK_PED_CASE_PHENOTYPE == vsPed[i][++k]){ m++; }		// 只取首字符统计casse
		}

		clsParas->fpStat << ',' << clsParas->sInputFilename << ',' << m << ',' << vsPed.size() - m << ',' << uSNP << endl;
		cout << "GWASimulator file read OK. Includes " << m << "cases, " << (vsPed.size() - m)
			<< " controls and " << uSNP << " SNPs" << endl;
		clsParas->fpLog << "GWASimulator file read OK." << endl;

		cout << "Converting to .ped ..." << endl;

		//输出ped文件
		sTmp = getFn(clsParas->sOutputFilename, ".ped");
		openStreamFile(fp, sTmp.c_str(), ios::out);

		for (i = 0; i < (int)vsPed.size(); i++) {
			fp << vsPed[i];
			fp << endl;

			cout << '\t' << i << " ...\r";
		}
		vsPed.clear();
		fp.close();
		fp.clear();
		cout << "\n\tSave " << sTmp << " OK." << endl;

		//生成PLINK MAP文件（默认扩展名.map）
		/******** PLINK MAP文件格式 **********
		* 包含4列，如：
		1 snp1 0 1
		1 snp2 0 2
		各列含义：
		chromosome (1-22, X, Y or 0 if unplaced)
		rs# or snp identifier
		Genetic distance (morgans)
		Base-pair position (bp units)
		*************************************/

		cout << "Converting to .map ..." << endl;
		//输出map文件
		sTmp = getFn(clsParas->sOutputFilename, ".map");
		openStreamFile(fp, sTmp.c_str(), ios::out);

		for(i = 0; i < uSNP; i++) {
			fp << clsParas->sChrNo << " SNP" << (i + 1) << " 0 0" << endl;
			cout << '\t' << i << " ...\r";
		}
		fp.close();
		fp.clear();

		cout << "\n\tSave " << sTmp << " OK." << endl;
	}


	/********************************************
	* Lingkage格式转PLINK ped格式
	* clsParas = 参数类指针
	************************ LogicReg格式 ******************
	* 每行一个个体，第1列为case/control（或logit值），其余每列（对于加性模型则是每两列）表示一个SNP。（本程序使用1、0表示case和ctrl）
	* 加性模型SNP：AA = 0 0, Aa = aA = 0 1, aa = 1 1（本程序使用“- -”表示missing）
	* 显性模型SNP：AA = Aa = aA = 0, aa = 1（本程序使用“-”表示missing）
	* 隐性模型SNP：AA = 0, Aa = aA = aa = 1（本程序使用“-”表示missing）
	*************************************/
	void LogicReg2Ped(coPLINK::parameters *clsParas)
	{
		CRandomMersenne crnd(clsParas->uRndSeed);
		string			sLine;
		int				i, j, m, uSNP;
		fstream			fp;
		vString			vs;
		vChar			vc;
		vvChar			vvc;

		//读取数据文件
		cout << "Loading and converting data file " << clsParas->sInputFilename << " ..." << endl;

		openStreamFile(fp, clsParas->sInputFilename.c_str(), ios::in);
		m = 0;
		while (getline(fp, sLine)) {
			trimString(sLine);							//删除前后空格及TAB
			trimRedundance(sLine, true);				//删除中间多余空格及TAB（只保留一个）,所有TAB用空格替换
			if (sLine.length() == 0) continue;

			stringSplit(sLine.c_str(), vs, clsParas->cDelimeter);

			j = vs.size();
			// 不少于1个SNP
			if (clsParas->iModel == ADDITIVE) {
				if (j < 3) continue;

				if (!EVEN_NUMBER(j - 1)) {
					cout << "The number of alleles at row " << m + 1 << "(excluding null row) is not an even number." << endl;
					continue;
				}
			}
			else if (j < 2) continue;

			if (clsParas->iModel == ADDITIVE){ vc.resize(j); }
			else{ vc.resize(2 * (j - 1) + 1); }
			// phenotype
			if (clsParas->iMode == LOGREG_LOGIT) {	// logit transformed
				vc[0] = atoi(vs[0].c_str())>0 ? PLNK_PED_CASE_PHENOTYPE : PLNK_PED_CTRL_PHENOTYPE;
			}
			else vc[0] = vs[0][0] == LOGREG_CASE_PHENOTYPE ? PLNK_PED_CASE_PHENOTYPE : PLNK_PED_CTRL_PHENOTYPE;	// first char only

			if (clsParas->iModel == ADDITIVE) {
				for (i = 1; i < j; i++) {
					if (vs[i][0] == '0'){ vc[i] = PLNK_PED_A; }
					else if (vs[i][0] == '1'){ vc[i] = PLNK_PED_a; }
					else{ vc[i] = PLNK_PED_MISSING_ALLELE2; }
				}
			}
			else {
				/*显性模型SNP：AA = Aa = aA = 0, aa = 1（本程序使用“ - ”表示missing）
				隐性模型SNP：AA = 0, Aa = aA = aa = 1（本程序使用“ - ”表示missing）*/
				for (i = 1; i < j; i++) {
					if (vs[i][0] == '0'){ vc[2 * i - 1] = vc[2 * i] = PLNK_PED_A; }
					else if (vs[i][0] == '1'){ vc[2 * i - 1] = vc[2 * i] = PLNK_PED_a; }
					else{ vc[2 * i - 1] = vc[2 * i] = PLNK_PED_MISSING_ALLELE2; }
				}
			}

			vvc.push_back(vc);

			cout << '\t' << ++m << " ...\r";
		}
		sLine = "";
		fp.close();
		fp.clear();
		vString().swap(vs);
		vChar().swap(vc);

		cout << endl;

		//数据有效性检查
		j = vvc[0].size();	
		for (i = 1; i < (int)vvc.size(); i++) {
			if ((int)vvc[i].size() != j) {
				char cs[100];
				sprintf(cs, "The column number of in-file does not match to the first at row %d.", i + 1);
				fetalError(cs, clsParas);
			}
		}

		// cal. SNP cnt
		uSNP = (j - 1) / 2;

		// 统计表型
		m = 0;
		for (i = 0; i < (int)vvc.size(); i++) {
			if (PLNK_PED_CASE_PHENOTYPE == vvc[i][0]) m++;
		}

		clsParas->fpStat << ',' << clsParas->sInputFilename << ',' << m << ',' << vvc.size() - m << ',' << uSNP << endl;
		cout << "LogicReg file read OK. Includes " << m << "cases, " << (vvc.size() - m)
			<< " controls and " << uSNP << " SNPs" << endl;
		clsParas->fpLog << "LogicReg file read OK." << endl;

		cout << "Converting to .ped ..." << endl;

		//输出ped文件
		/************ Plink Ped格式文件 *****
		1	1	0	0	1	1	A	A	G	T
		2	1	0	0	1	1	A	C	T	G
		3	1	0	0	1	1	C	C	G	G
		4	1	0	0	1	2	A	C	T	T
		5	1	0	0	1	2	C	C	G	T
		6	1	0	0	1	2	C	C	T	T
		.......

		N-missing。每行一个个体
		前6列(前4列可多个字符组成)：
		Family ID
		Individual ID
		Paternal ID
		Maternal ID
		Sex (1=male; 2=female; other=unknown)
		Phenotype (1=unaffect; 2=affect)
		*************************************/

		sLine = getFn(clsParas->sOutputFilename, ".ped");
		openStreamFile(fp, sLine.c_str(), ios::out);

		for (i = 0; i < (int)vvc.size(); i++) {
			fp << "1 "						//family ID
				<< i + 1					//individual ID
				<< " 0 0 "					//paternal ID, maternal ID
				<< (int)crnd.IRandom(1, 2);	//sex。随机生成

			for (j = 0; j < (int)vvc[i].size(); j++){
				fp << DELIMITER3 << vvc[i][j];
			}
			fp << endl;

			cout << '\t' << i << " ...\r";
		}
		vvChar().swap(vvc);
		fp.close();
		fp.clear();
		cout << "\n\tSave " << sLine << " OK." << endl;

		//生成PLINK MAP文件（默认扩展名.map）
		/******** PLINK MAP文件格式 **********
		* 包含4列，如：
		1 snp1 0 1
		1 snp2 0 2
		各列含义：
		chromosome (1-22, X, Y or 0 if unplaced)
		rs# or snp identifier
		Genetic distance (morgans)
		Base-pair position (bp units)
		*************************************/

		cout << "Converting to .map ..." << endl;
		//输出map文件
		sLine = getFn(clsParas->sOutputFilename, ".map");
		openStreamFile(fp, sLine.c_str(), ios::out);

		for (i = 0; i < uSNP; i++) {
			fp << clsParas->sChrNo << " SNP" << (i + 1) << " 0 0";
			fp << endl;

			cout << '\t' << i << " ...\r";
		}
		fp.close();
		fp.clear();

		cout << "\n\tSave " << sLine << " OK." << endl;
	}

	/*******************************************
	* Ped 转 tped 函数（直接字串操作实现，速度太慢（540M的文件耗时44分，i3, 4G, win7 x86），但对内存要求低）
	* vsMap = Map 文件内容（已删除多余空格）
	* vsPed = Ped 文件内容（已删除多余空格）
	* clsParas = 类参数指针
	*******************************************
	PLINK ped文本格式（PED文件, N-missing）(每行一个个体)：
	1 1 0 0 1 1 A A G T
	2 1 0 0 1 1 A C T G
	3 1 0 0 1 1 C C G G
	4 1 0 0 1 2 A C T T
	5 1 0 0 1 2 C C G T
	6 1 0 0 1 2 C C T T
	前6列(前4列可多个字符组成)：
	Family ID
	Individual ID
	Paternal ID
	Maternal ID
	Sex (1=male; 2=female; other=unknown)
	Phenotype (1=unaffect; 2=affect；0=unknow)

	PLINK ped文本格式（MAP文件）：
	1 snp1 0 5000650
	1 snp2 0 5000830
	各列含义：
	chromosome (1-22, X, Y or 0 if unplaced)
	rs# or snp identifier
	Genetic distance (morgans)
	Base-pair position (bp units)

	PLINK tped文本格式（TPED文件）：
	 每行一个SNP
	 如：(N-missing)
		1 snp1 0 5000650 A A A C C C A C C C C C
		1 snp2 0 5000830 G T G T G G T T G T T T
		...
	 前4列即是ped格式中的map文件所包含的4列:
	  map文件各列含义：
	  1 - chromosome (1-22, X, Y or 0 if unplaced)
	  2 - rs# or snp identifier
	  3 - Genetic distance (morgans)
	  4 - Base-pair position (bp units)
	 从第5列起为samples的基因型（samples的信息由tfam文件说明）

	PLINK tped文本格式（TFAM文件）：
	 每行一个sample
	 如：
		1 1 0 0 1 1
		2 1 0 0 1 1
		3 1 0 0 1 1
		4 1 0 0 1 2
		5 1 0 0 1 2
		6 1 0 0 1 2
		...
	  各列含义（即ped文件的前6列）：
	  1 - 家系ID
	  2 - sample ID
	  3 - 父亲ID
	  4 - 母亲ID
	  5 - 性别（1=男、2=女、0=未知）
	  6 - 表型（1=对照、2=疾病、0=未知）
	*****************************************************/
	void Ped2Tped(vString& vsMap, vString &vsPed, coPLINK::parameters *clsParas)
	{
		string	sFnTPED, sFnTFAM, sTmp;
		int	i, j, k, m, n, p;
		fstream	fp;

		//检查PED文件内容与MAP内容是否匹配
		j = 0;
		for (i = 0; i < (int)vsPed[0].size(); i++){
			if (vsPed[0][i] == DELIMITER3) j++;
		}
		j -= PLNK_PED_PHENOTYPE_COL;
		j /= 2;	//PED文件中的SNP个数（每个SNP占2个空格位置）

		i = vsMap.size();										//MAP文件中的SNP个数
		if (i != j) {
			char cs[50];
			sprintf(cs, "%d(PED) vs. %d(MAP).", j, i);
			fetalError("The number of SNPs are not equivalent between PED and MAP file. The numbers: " + (string)cs, clsParas);
		}

		//生成文件名
		sFnTPED = getFn(clsParas->sOutputFilename, ".tped");
		sFnTFAM = getFn(clsParas->sOutputFilename, ".tfam");

		// 生成TFAM
		openStreamFile(fp, sFnTFAM.c_str(), ios::out);
		for (i = 0; i < (int)vsPed.size(); i++){
			// 取出前PLNK_PED_GENOTYPE_COL列，并写tfam
			j = 0;
			n = vsPed[i].size();
			for (k = 0; k < n; k++){
				if (vsPed[i][k] == DELIMITER3){
					j++;
					if (j == PLNK_PED_GENOTYPE_COL) break;
				}
			}
			sTmp = vsPed[i].substr(0, k);
			fp << sTmp << endl;

			// 去掉前PLNK_PED_GENOTYPE_COL列
			k++;
			vsPed[i] = vsPed[i].substr(k, n - k + 1);

			cout << '\t' << i << " ...\r";
		}
		fp.close();
		fp.clear();
		cout << endl << sFnTFAM << " is OK (" << getDT() << ").\n\nConverting to TBED ..." << endl;
		clsParas->fpLog << sFnTFAM << " is OK." << endl;

		// 生成TPED
		openStreamFile(fp, sFnTPED.c_str(), ios::out);
		n = vsPed.size();
		for (i = 0; i < (int)vsMap.size(); i++) {	//逐行扫描
			sTmp = vsMap[i] + DELIMITER3;
			for (j = 0; j < n; j++){
				m = 0;
				p = vsPed[j].size();
				for (k = 0; k < p; k++){
					if (vsPed[j][k] == DELIMITER3){
						m++;
						if (m == 2) break;
					}
				}
				sTmp += vsPed[j].substr(0, k);
				sTmp += DELIMITER3;
				k++;
				if (k < p){ vsPed[j] = vsPed[j].substr(k, p - k + 1); }
			}
			m = sTmp.size() - 1;
			sTmp[m] = '\n';		// 去掉最后个空格
			fp << sTmp;

			cout << '\t' << i << " ...\r";
		}
		fp.close();
		fp.clear();
		
		cout << "\nThe TPED file has been saved as " << sFnTPED << " and " << sFnTFAM << endl;
		clsParas->fpLog << "The TPED file has been saved as " << sFnTPED << " and " << sFnTFAM << endl;
	}

	/*************重载***************
	* 用字符矩阵实现（不支持多字符组成基因型，多字符基因型只保留首字符）
	* vvsMap = MAP文件内容（字串矩阵）
	* vvcPed = 基因型矩阵（样本数行*2SNP列），当bNor=false时，要求已归一化
	* vsPed6 = PED文件的前6列
	* clsParas = 参数类指针
	* bStandard = 是否按标准格式转换.tped
	*	true - 是
	*	false - 否，即自定义格式，tped中的基因型用0、1、2分别表示AA、Aa/aA、aa（同BOOST），其余同标准tped
	**********************************/
	void Ped2Tped(vvString& vvsMap, vString& vsPed6, vvChar &vvcPed, coPLINK::parameters *clsParas, bool bStandard)
	{
		string	sFnTPED, sFnTFAM, sTmp;
		int		i, j, k, uSNPcnt, uSampleCnt;
		fstream	fp;
		Point	lt, rb;

		//检查PED文件内容与MAP内容是否匹配
		uSNPcnt = vvcPed[0].size();
		j = uSNPcnt / 2;	//PED文件中的SNP个数（每个SNP占2个空格位置）

		i = vvsMap.size();							//MAP文件中的SNP个数
		if (i != j) {
			char cs[50];
			sprintf(cs, "%d(PED) vs. %d(MAP).", j, i);
			fetalError("The number of SNPs are not equivalent between PED and MAP file. The numbers: " + (string)cs, clsParas);
		}

		if (clsParas->bPreprocess){
			if (!chkSample4Ped(vvcPed, vsPed6, clsParas, sTmp)){	// 需在预处理之前，其可能删除样本
				fetalError("An error is encountered while alleles missing rates of samples checking: " + sTmp, clsParas);
			}

			if (!preprocessPed(vvcPed, vvsMap, clsParas, true, sTmp)){
				fetalError("An error is encountered while preprocessing: " + sTmp, clsParas);
			}
			uSNPcnt = vvcPed[0].size();	// reset, since the preprocessing may remove individuals
		}

		uSampleCnt = vsPed6.size();

		if (clsParas->bSwap) {		// 交换矩形（lt, rb)间的等位基因数相同的major和minor alleles
			lt.x = 0; lt.y = 0;
			rb.x = vvcPed[0].size() - 1; rb.y = vvcPed.size() - 1;
			if (!swapAllelsInColDouble(vvcPed, &lt, &rb)){
				fetalError("The number of columns of SNPs is not even.", clsParas);
			}
		}


		//生成文件名
		sFnTPED = getFn(clsParas->sOutputFilename, ".tped");
		sFnTFAM = getFn(clsParas->sOutputFilename, ".tfam");

		// 生成TFAM
		openStreamFile(fp, sFnTFAM.c_str(), ios::out);
		for (i = 0; i < uSampleCnt; i++){
			fp << vsPed6[i] << endl;
			cout << '\t' << i << " ...\r";
		}
		fp.close();
		fp.clear();
		cout << endl << sFnTFAM << " is OK (" << getDT() << ").\n\nConverting to TPED ..." << endl;
		clsParas->fpLog << sFnTFAM << " is OK." << endl;
		vString().swap(vsPed6);

		// 生成TPED
		openStreamFile(fp, sFnTPED.c_str(), ios::out);
		k = 0;
		for (i = 0; i < uSNPcnt; i += 2) {	//逐SNP扫描
			sTmp = vvsMap[k][0];
			sTmp += DELIMITER3;
			sTmp += vvsMap[k][1];
			sTmp += DELIMITER3;
			sTmp += vvsMap[k][2];
			sTmp += DELIMITER3;
			sTmp += vvsMap[k++][3];

			for (j = 0; j < uSampleCnt; j++){
				sTmp += DELIMITER3;

				if (bStandard) {
					sTmp += (vvcPed[j][i] == MISSING_ALLELE_CHR ? PLNK_PED_MISSING_ALLELE2 : vvcPed[j][i]);
					sTmp += DELIMITER3;
					sTmp += (vvcPed[j][i + 1] == MISSING_ALLELE_CHR ? PLNK_PED_MISSING_ALLELE2 : vvcPed[j][i + 1]);
				}
				else{
					if ((vvcPed[j][i] == PLNK_PED_A && vvcPed[j][i + 1] == PLNK_PED_a)
						|| (vvcPed[j][i] == PLNK_PED_a && vvcPed[j][i + 1] == PLNK_PED_A))
					{
						sTmp += BOOST_Aa_aA;
					}
					else if (vvcPed[j][i] == PLNK_PED_a && vvcPed[j][i + 1] == PLNK_PED_a){ sTmp += BOOST_aa; }
					else if (vvcPed[j][i] == PLNK_PED_A && vvcPed[j][i + 1] == PLNK_PED_A){ sTmp += BOOST_AA; }
					else{ sTmp += BOOST_MISSING_ALLELE_STR; }
				}
			}

			fp << sTmp << endl;

			cout << '\t' << i << " ...\r";
		}
		fp.close();
		fp.clear();

		cout << "\nThe TPED files saved as " << sFnTPED << " and " << sFnTFAM << endl;
		clsParas->fpLog << "The TPED files saved as " << sFnTPED << " and " << sFnTFAM << endl;
	}

	/*******************************************
	* Ped 转 tped 函数2（拆分字串实现，大文件时内存容易不足）
	* vsMap = Map 文件内容（已删除多余空格）
	* vsPed = Ped 文件内容（已删除多余空格）
	* clsParas = 参数类指针
	*******************************************/
	void Ped2Tped2(vString& vsMap, vString &vsPed, coPLINK::parameters *clsParas)
	{
		string		sFnTPED, sFnTFAM, sTmp;
		int			i, j, k, n, uSNPcnt, uSampleCnt;
		fstream		fp;
		vvString	vvsPed;
		vString		vs;

		//检查PED文件内容与MAP内容是否匹配
		j = 0;
		for (i = 0; i < (int)vsPed[0].size(); i++){
			if (vsPed[0][i] == DELIMITER3) j++;
		}
		j -= PLNK_PED_PHENOTYPE_COL;
		j /= 2;	//PED文件中的SNP个数（每个SNP占2个空格位置）

		uSNPcnt = vsMap.size();										//MAP文件中的SNP个数
		if (uSNPcnt != j) {
			char cs[50];
			sprintf(cs, "%d(PED) vs. %d(MAP).", j, uSNPcnt);
			fetalError("The number of SNPs are not equivalent between PED and MAP file. The numbers: " + (string)cs, clsParas);
		}

		//生成文件名
		sFnTPED = getFn(clsParas->sOutputFilename, ".tped");
		sFnTFAM = getFn(clsParas->sOutputFilename, ".tfam");
		uSampleCnt = vsPed.size();
		vvsPed.reserve(uSampleCnt);
		vs.reserve(uSNPcnt * 2);
		// 生成TFAM
		openStreamFile(fp, sFnTFAM.c_str(), ios::out);
		for (i = 0; i < uSampleCnt; i++){
			// 取出前PLNK_PED_GENOTYPE_COL列，并写tfam
			j = 0;
			n = vsPed[i].size();
			for (k = 0; k < n; k++){
				if (vsPed[i][k] == DELIMITER3){
					j++;
					if (j == PLNK_PED_GENOTYPE_COL) break;
				}
			}
			sTmp = vsPed[i].substr(0, k);
			fp << sTmp << endl;

			// 去掉前PLNK_PED_GENOTYPE_COL列
			k++;
			vsPed[i] = vsPed[i].substr(k, n - k + 1);
		}
		fp.close();
		fp.clear();
		
		cout << sFnTFAM << " is OK (" << getDT() << ").\n\nConverting to TBED ..." << endl;
		clsParas->fpLog << sFnTFAM << " is OK." << endl;

		// 拆分PED（拆结果逆序排列）
		i = uSampleCnt - 1;
		while (true)
		{
			stringSplit(vsPed[i], vs);
			vsPed.resize(i--);			// 减小一个size（实删除最后一个）
			vString(vsPed).swap(vsPed);	// 减小capacity，以释放内存
			vvsPed.push_back(vs);
			if (i < 0) break;
		}
		vsPed.clear();
		vString().swap(vsPed);			// 完全清空

		// 生成TPED
		openStreamFile(fp, sFnTPED.c_str(), ios::out);

		for (i = 0; i < uSNPcnt; i++) {		//逐行(SNP)扫描
			sTmp = vsMap[i] + DELIMITER3;
			for (j = uSampleCnt - 1; j > 0; j--){	// vvsPed逆序
				sTmp += vvsPed[j][i * 2];
				sTmp += DELIMITER3;
				sTmp += vvsPed[j][i * 2 + 1];
				sTmp += DELIMITER3;
			}
			// 最后一个不要空格
			sTmp += vvsPed[j][i * 2];
			sTmp += DELIMITER3;
			sTmp += vvsPed[j][i * 2 + 1];
			
			fp << sTmp << endl;
		}
		fp.close();
		fp.clear();

		cout << "The TPED files saved as " << sFnTPED << " and " << sFnTFAM << endl;
		clsParas->fpLog << "The TPED files saved as " << sFnTPED << " and " << sFnTFAM << endl;
	}

	/*******************************************
	* Ped 转 tped 函数3（拆分字串并用动态数据实现，比直接字串实现内存上升更快）
	* vsMap = Map 文件内容（已删除多余空格）
	* vsPed = Ped 文件内容（已删除多余空格）
	* clsParas = 参数类指针
	*******************************************/
	void Ped2Tped3(vString& vsMap, vString &vsPed, coPLINK::parameters *clsParas)
	{
		string		sFnTPED, sFnTFAM, sTmp;
		int			i, j, k, n, uSNPcnt, uSampleCnt;
		fstream		fp;
		string**	vvsPed;
		vString		vs;

		//检查PED文件内容与MAP内容是否匹配
		j = 0;
		for (i = 0; i < (int)vsPed[0].size(); i++){
			if (vsPed[0][i] == DELIMITER3) j++;
		}
		j -= PLNK_PED_PHENOTYPE_COL;
		j /= 2;	//PED文件中的SNP个数（每个SNP占2个空格位置）

		uSNPcnt = vsMap.size();										//MAP文件中的SNP个数
		if (uSNPcnt != j) {
			char cs[50];
			sprintf(cs, "%d(PED) vs. %d(MAP).", j, uSNPcnt);
			fetalError("The number of SNPs are not equivalent between PED and MAP file. The numbers: " + (string)cs, clsParas);
		}

		//生成文件名
		sFnTPED = getFn(clsParas->sOutputFilename, ".tped");
		sFnTFAM = getFn(clsParas->sOutputFilename, ".tfam");
		uSampleCnt = vsPed.size();

		vs.reserve(uSNPcnt * 2);
		// 生成TFAM
		openStreamFile(fp, sFnTFAM.c_str(), ios::out);
		for (i = 0; i < uSampleCnt; i++){
			// 取出前PLNK_PED_GENOTYPE_COL列，并写tfam
			j = 0;
			n = vsPed[i].size();
			for (k = 0; k < n; k++){
				if (vsPed[i][k] == DELIMITER3){
					j++;
					if (j == PLNK_PED_GENOTYPE_COL) break;
				}
			}
			sTmp = vsPed[i].substr(0, k);
			fp << sTmp << endl;

			// 去掉前PLNK_PED_GENOTYPE_COL列
			k++;
			vsPed[i] = vsPed[i].substr(k, n - k + 1);
		}
		fp.close();
		fp.clear();

		cout << sFnTFAM << " is OK (" << getDT() << ").\n\nConverting to TBED ..." << endl;
		clsParas->fpLog << sFnTFAM << " is OK." << endl;

		// 拆分PED
		//
		vvsPed = new string*[uSampleCnt];
		for (i = 0; i < uSampleCnt; i++){ vvsPed[i] = new string[uSNPcnt * 2]; }

		i = uSampleCnt - 1;
		while (true)
		{
			stringSplit(vsPed[i], vs);
			vsPed.resize(i);			// 减小一个size（实删除最后一个）
			vString(vsPed).swap(vsPed);	// 减小capacity，以释放内存
			for (j = 0; j < uSNPcnt * 2; j++){ vvsPed[i][j] = vs[j]; }

			i--;
			if (i < 0) break;
		}
		vsPed.clear();
		vString().swap(vsPed);			// 完全清空

		// 生成TPED
		openStreamFile(fp, sFnTPED.c_str(), ios::out);

		for (i = 0; i < uSNPcnt; i++) {		//逐行(SNP)扫描
			sTmp = vsMap[i] + DELIMITER3;
			for (j = 0; j < uSampleCnt - 1; j++){	
				sTmp += vvsPed[j][i * 2];
				sTmp += DELIMITER3;
				sTmp += vvsPed[j][i * 2 + 1];
				sTmp += DELIMITER3;
			}
			// 最后一个不要空格
			sTmp += vvsPed[j][i * 2];
			sTmp += DELIMITER3;
			sTmp += vvsPed[j][i * 2 + 1];

			fp << sTmp << endl;
		}
		fp.close();
		fp.clear();

		for (i = 0; i < uSampleCnt; i++){ delete[] vvsPed[i]; }

		delete[] vvsPed;

		cout << "The TPED files saved as " << sFnTPED << " and " << sFnTFAM << endl;
		clsParas->fpLog << "The TPED files saved as " << sFnTPED << " and " << sFnTFAM << endl;
	}

	/*****************************************
	* Plink tped格式转为ped格式（所有输入内容均已删除多余空格）
	* vsTped = tped文件内容（不含前4列）
	* vsMap = map文件内容（tped文件的前4列）
	* vsTfam = tfam文件内容
	* clsParas = 程序输入参数类指针
	******************************************/
	void Tped2Ped(vString &vsTped, vString &vsMap, vString &vsTfam, parameters *clsParas)
	{
		string			sLine, sTmp, fn, s;
		int				i;
		fstream			fp;
		vString			vsPed;

		cout << "Converting to ped ..." << endl;

		//输出map文件
		sTmp = getFn(clsParas->sOutputFilename, ".map");
		openStreamFile(fp, sTmp.c_str(), ios::out);

		for (i = 0; i < (int)vsMap.size(); i++) {
			fp << vsMap[i];
			fp << endl;
			cout << '\t' << i << " ...\r";
		}
		fp.close();
		fp.clear();
		vsMap.clear();

		cout << "\n\tSave " << sTmp << " OK." << endl;

		//vsTped转置为vsPed
		vsTped2vsPed(vsTped, vsPed, vsTfam.size());

		//数据有效性检查
		if (vsTfam.size() != vsPed.size()) {
			fetalError("The structures between tped and tfam are not consensus, check please.", clsParas);
		}
		else{
			clsParas->fpLog << "There are " << vsPed.size() << " individuals in total." << endl;
		}

		for (i = 0; i < (int)vsTfam.size(); i++){ vsPed[i] = vsTfam[i] + DELIMITER3 + vsPed[i]; }
		vsTfam.clear();

		if (clsParas->bNormalize) {
			if(!NormalizePed(vsPed, PLNK_PED_GENOTYPE_COL, sLine)) {	//归一化
				fetalError(sLine, clsParas);
			}
		}

		if (clsParas->bPreprocess) {
			if (!chkSample4Ped(vsPed, clsParas)){						//样本有效性检查
				fetalError("An error is encountered while alleles missing rates of samples checking.", clsParas);
			}
		}

		if (clsParas->bSex) sexPed(vsPed, clsParas->uRndSeed);									//随机生成性别

		//输出ped文件
		sTmp = getFn(clsParas->sOutputFilename, ".ped");
		openStreamFile(fp, sTmp.c_str(), ios::out);

		for (i = 0; i < (int)vsPed.size(); i++) {
			fp << vsPed[i];
			fp << endl;

			cout << '\t' << i << " ...\r";
		}
		fp.close();
		fp.clear();

		cout << "\n\tSave " << sTmp << " OK." << endl;
	}

	/*****************************************
	* Plink tped格式转为自定义tped格式（所有输入内容均已删除多余空格）
	* 自定义tped格式：tped中的基因型用0、1、2分别表示AA、Aa/aA、aa，其余同标准tped
	* vsTped = tped文件内容（不含前4列）
	* vsMap = map文件内容（tped文件的前4列）
	* vsTfam = tfam文件内容
	* clsParas = 程序输入参数类指针
	******************************************/
	void Tped2UsrTped(vString &vsTped, vString &vsMap, vString &vsTfam, parameters *clsParas)
	{
		string		sTmp, s;
		int			i, j;
		fstream		fp, fpIn;
		vvChar		vvcAllele;
		vvChar		vvcTped;

		cout << "Converting .tfam ..." << endl;

		// 仅tped文件与标准不同，其余两个文件直接复制即可（不能复制，因可能更改表型和预处理）
		//生成文件名
		sTmp = getFn(clsParas->sOutputFilename, ".tfam", true);

		openStreamFile(fp, sTmp.c_str(), ios::out);

		for (i = 0; i < (int)vsTfam.size(); i++){
			fp << vsTfam[i] << endl;
			cout << '\t' << i + 1 << " ...\r";
		}
		fp.close();
		fp.clear();

		cout << "\n\tSave " << sTmp << " OK." << endl;

		// 自定义TPED，无tsnp文件
		//cout << "Converting .tsnp ..." << endl;

		//sTmp = getFn(clsParas->sInputFilename, ".tsnp");
		//if (access(sTmp.c_str(), 0) != -1) {	//存在tsnp文件
		//	if (!clsParas->bPreprocess){		// 没有预处理，直接复制
		//		fpIn.open(sTmp.c_str(), ios_base::in);
		//		if (!fpIn.good()) {
		//			fpIn.close();
		//			fetalError("Source file " + sTmp + " opend error.", clsParas);
		//		}

		//		s = getFn(clsParas->sOutputFilename, ".tsnp", true);

		//		fp.open(s.c_str(), ios_base::out);
		//		if (!fp.good()) {
		//			fp.close();

		//			fetalError("Write file " + s + " failed.", clsParas);
		//		}

		//		fp << fpIn.rdbuf();		//复制生成tsnp文件

		//		fp.close();
		//		fpIn.close();
		//		fp.clear();
		//		fpIn.clear();
		//	}

		//	cout << "\tSave " << s << " OK." << endl;
		//}

		cout << "Converting .tped ..." << endl;

		// 拆分vsTped为vvcTped，并得到主、次等位基因组成：vvcAllele = 输出各SNP主、次等基因字符矩阵（每行对应一个SNP的主、次等基因，次等位基因在前，MISSING为N）
		analyzeSNP(vsTped, vvcTped, vvcAllele, clsParas->bNorOn);	

		// 输出tped文件
		s = getFn(clsParas->sOutputFilename, ".tped");
		openStreamFile(fp, s.c_str(), ios::out);

		for (i = 0; i < (int)vvcTped.size(); i++) {
			sTmp = vsMap[i];
			for (j = 0; j < (int)vvcTped[0].size(); j += 2){
				sTmp += DELIMITER3;
				
				if (vvcTped[i][j] == PLNK_PED_MISSING_ALLELE2 || vvcTped[i][j + 1] == PLNK_PED_MISSING_ALLELE2){	// vvcAllele 使用同符号的MISSING，这块置前
					sTmp += BOOST_MISSING_ALLELE_STR;
					continue;
				}

				if ((vvcTped[i][j] == vvcAllele[i][1] && vvcTped[i][j + 1] == vvcAllele[i][0])
					|| (vvcTped[i][j] == vvcAllele[i][0] && vvcTped[i][j + 1] == vvcAllele[i][1]))
				{
					sTmp += BOOST_Aa_aA;
				}
				else if (vvcTped[i][j] == vvcAllele[i][0] && vvcTped[i][j + 1] == vvcAllele[i][0]){ sTmp += BOOST_aa; }
				else if (vvcTped[i][j] == vvcAllele[i][1] && vvcTped[i][j + 1] == vvcAllele[i][1] || vvcAllele[i][0] == '0'){ sTmp += BOOST_AA; }
			}
			fp << sTmp << endl;

			cout << '\t' << i << " ...\r";
		}
		fp.close();
		fp.clear();

		cout << "\n\tSave " << s << " OK." << endl;

		clsParas->fpLog << "The user defined tpeds saved as " << clsParas->sOutputFilename << endl;
	}

	/*****************************************
	* Plink tped格式转为ped格式
	* vsTped = tped文件内容（不含前4列）
	* vsMap = map文件内容（tped文件的前4列）
	* vsTfam = tfam文件内容
	* clsParas = pointer of class
	******************************************/
	void Tped2Bed(vString &vsTped, vString &vsMap, vString &vsTfam, parameters *clsParas)
	{
		string		sTmp;
		int		i, k, n, uSampleCnt, uSNPcnt;
		vvChar		vvcAllele;
		vvChar		vvcTped;		// 用vvString 可以处理等位基因多个字符（当作缺失）的问题，但在大文件时占用内存太大（300M左右的文件，内存超过2G从而退出）
		char		c, cs[4];
		ofstream	fp;			// fstream 创建二进制文件会失败

		cout << "Saving fam ..." << endl;

		sTmp = getFn(clsParas->sOutputFilename, ".fam");
		fp.open(sTmp.c_str(), ios::out);
		if (!fp.is_open()){
			fp.close();
			fetalError("Create file " + sTmp + " failed.", clsParas);
		}

		for (i = 0; i < (int)vsTfam.size(); i++) {
			fp << vsTfam[i] << endl;

			cout << '\t' << i << " ...\r";
		}
		fp.close();
		fp.clear();
		cout << "\n\tSave " << sTmp << " OK." << endl;

		uSampleCnt = vsTfam.size();
		vsTfam.clear();
		uSNPcnt = vsTped.size();	// 此行必须置于vsTped2vsPed之前，vsTped2vsPed会清空vsTped

		// 拆分vsTped为vvcTped，并得到主、次等位基因组成：vvcAllele = 输出各SNP主、次等基因字符矩阵（每行对应一个SNP的主、次等基因，次等位基因在前，MISSING为N）
		analyzeSNP(vsTped, vvcTped, vvcAllele, clsParas->bNorOn);
		

		cout << "Converting to bim ..." << endl;
		//生成bim文件名
		sTmp = getFn(clsParas->sOutputFilename, ".bim");

		//生成bim文件
		fp.open(sTmp.c_str(), ios::out);
		if (!fp.is_open()){
			fp.close();
			fetalError("Create file " + sTmp + " failed.", clsParas);
		}

		cs[3] = '\0';
		for (i = 0; i < uSNPcnt; i++){
			cs[0] = vvcAllele[i][0]; cs[1] = DELIMITER3; cs[2] = vvcAllele[i][1];
			fp << vsMap[i] << DELIMITER3 << cs << endl;

			cout << '\t' << i << " ...\r";
		}
		fp.close();
		fp.clear();
		vsMap.clear();
		cout << "\n\tSave " << sTmp << " OK." << endl;

		cout << "Converting to bed ..." << endl;
		//生成bed文件名
		sTmp = getFn(clsParas->sOutputFilename, ".bed");

		//生成bed文件
		fp.open(sTmp.c_str(), ios::binary);
		if (!fp.is_open()){
			fp.close();
			fetalError("Create file " + sTmp + " failed.", clsParas);
		}

		// bed文件前两个字节固定，第3字节01表示只支持SNP-majar格式
		c = 0x6C;
		fp.write((char *)&c, 1);	//读写都要做这样的转换(char *)&c，另外，不能用“<<”操作符输出（结果不正确）
		c = 0x1B;
		fp.write((char *)&c, 1);
		c = 0x01;
		fp.write((char *)&c, 1);
		k = 0;
		c = 0;
		for (i = 0; i < uSNPcnt; i++) {	// 逐SNP
			for (n = 0; n < uSampleCnt * 2; n += 2){	// 逐样本
				if (vvcTped[i][n] == PLNK_PED_MISSING_ALLELE2 || vvcTped[i][n + 1] == PLNK_PED_MISSING_ALLELE2){ // 缺失
					c |= PLNK_BED_MISSING << k;
				}
				else if (vvcTped[i][n] != vvcTped[i][n + 1]){	// 杂合子
					c |= PLNK_BED_Aa_aA << k;
				}
				else if (vvcTped[i][n] == vvcAllele[i][0]){	// minor allele 纯合子
					c |= PLNK_BED_aa << k;
				}
				else{
					c |= PLNK_BED_AA << k;
				}

				k += 2;
				if (k >= 8) {
					fp.write((char *)&c, 1);
					k = c = 0;
				}
			}
			if (k){
				fp.write((char *)&c, 1);
				k = c = 0;
			}
			cout << '\t' << i << " ...\r";
		}
		fp.close();
		fp.clear();

		vvcAllele.clear();
		vvcTped.clear();
		vvChar().swap(vvcAllele);
		vvChar().swap(vvcTped);

		cout << "\n\tSave " << sTmp << " OK." << endl;

		clsParas->fpLog << "The Binary file saved as " << clsParas->sOutputFilename << endl;
#ifdef _DEBUG
		system("pause");
#endif // DEBUG
	}


	/********************************************
	* 拼接PLINK ped格式文件
	* clsParas = 程序输入参数类指针
	*
	* PED文件, N-missing（本程序定义）：
	* 1	 1	0	0	1	1	A	A	G	T ...
	* 2	 1	0	0	1	1	A	C	T	G ...
	* 3	 1	0	0	1	1	C	C	G	G ...
	* ...
	*
	* 前6列：Family ID, Individual ID, Paternal ID, Maternal ID, Sex (1=male; 2=female; other=unknown), Phenotype (1=unaffect; 2=affect)
	*
	* map包含4列:
	*  map文件各列含义：
	*  1 - chromosome (1-22, X, Y or 0 if unplaced)
	*  2 - rs# or snp identifier
	*  3 - Genetic distance (morgans)
	*  4 - Base-pair position (bp units)
	*************************************/
	void SplicingPeds(coPLINK::parameters *clsParas)
	{
		fstream			fp;
		string			sLine, s, sSplicedMapFn;
		vString			vsPedSpliced, vsPedSplicing, vsSplit, vsPed6;
		vvString		vvsMapSpliced, vvsMapSplicing;
		vInt			viSNPinSplicing;	//被拼接文件中的SNP在拼接MAP文件中的下标+PLNK_PED_GENOTYPE_COL（小于0表示不存在）
		int				i, j, k, uSize, uSNPs;
		//char			cS[STR_LENGTH];
		bool			b;

		cout << "Loading ped files ..." << endl;

		//读取被拼接ped文件（由参数 OP_SPLPED 指定）。
		sLine = getFn(clsParas->sInputFilename, ".ped", false);
		sLine = sLine.substr(0, sLine.length() - 4);					//提取主文件名。主文件名中可能包含“.”，不能由带TRUE的GETFN产生
		clsParas->fpStat << "Spliced: " << sLine;
		clsParas->sInputFilename = sLine;

		sSplicedMapFn = sLine + ".map";		// store the map filename to be used after

		readPed(vsPedSpliced, clsParas);

		//写输出文件（由于输出文件太大，只能一边处理一边写输出，否则极易内存溢出）
		s = getFn(clsParas->sOutputFilename, ".ped");
		openStreamFile(fp, s.c_str(), ios::out);

		for (i = 0; i < (int)vsPedSpliced.size(); i++){ 
			////////2020.7.6 取出前6列
			trimString(vsPedSpliced[i]);						//删除前后空格及TAB
			trimRedundance(vsPedSpliced[i], true);				//删除中间多余空格及TAB（只保留一个），并把TAB用空格替换

			if (vsPedSpliced[i].length() == 0) continue;

			k = 0;

			for (j = 0; j < (int)vsPedSpliced[i].size(); j++){
				if (vsPedSpliced[i][j] == DELIMITER3) k++;

				if (k == PLNK_PED_GENOTYPE_COL) break;

			}

			if (k < PLNK_PED_GENOTYPE_COL) continue;	// 丢弃不足6列的数据

			s = vsPedSpliced[i].substr(0, j);

			vsPed6.push_back(s);
			//////////2020.7.6
			fp << vsPedSpliced[i] << endl; 
		}

		uSize = vsPedSpliced.size();
		vsPedSpliced.clear();
		vString().swap(vsPedSpliced);

		readWithDelimeter(vvsMapSpliced, sSplicedMapFn, clsParas);

		//读取拼接ped文件（由参数--file2指定）。
		sLine = getFn(clsParas->sFilename2, ".map", false);
		sLine = sLine.substr(0, sLine.length() - 4);					//提取主文件名。主文件名中可能包含“.”，不能由带TRUE的GETFN产生
		clsParas->fpStat << "Splicing: " << sLine;
		clsParas->sInputFilename = sLine;

		readPed(vsPedSplicing, clsParas);
		readWithDelimeter(vvsMapSplicing, sLine + ".map", clsParas);

		/**********此段程序用于临时处理MAP文件（详见normalizeRS_ID函数说明）***********
		normalizeRS_ID(vvsMapSplicing);

		openStreamFile(fp, sLine.c_str(), ios::out);
		for(i = 0; i < vvsMapSplicing.size(); i++) {
			for(j = 0; j < 3; j++) fp << vvsMapSplicing[i][j] << '\t';
			fp << vvsMapSplicing[i][j] << endl;
		}
		fp.close();
		fp.clear();
		return;
		*******************************************************************************/

		i = vsPedSplicing.size();
		clsParas->fpLog << "The numbers of individuals in splicd (after " OP_SPLPED << ") and splicing (after " << ID_FILE2 
			<< ") files are " << uSize << " and " << i << "." << endl;

		cout << "The numbers of individuals in splicd (after " OP_SPLPED << ") and splicing (after " << ID_FILE2
			<< ") files are " << uSize << " and " << i << "." << endl;

		cout << "Parsing SNPs ..." << endl;

		//在拼接文件中查找被拼接文件SNP的下标
		uSize = vvsMapSpliced.size();
		uSNPs = vvsMapSplicing.size();
		viSNPinSplicing.resize(uSize);

		for (i = 0; i < uSize; i++){ viSNPinSplicing[i] = -1; }		//小于0表示拼接文件中无此SNP

		clsParas->fpLog << "Before splicing, the numbers of SNPs in spliced and splicing files are " << uSize << " and " << uSNPs << ", respectively." << endl;
		cout << "Before splicing, the numbers of SNPs in spliced and splicing files are " << uSize << " and " << uSNPs << ", respectively." << endl;
		clsParas->fpLog << "The chr-No./Pos. in spliced file differs from that in splicing(in spliced vs. in splicing):" << endl;
		
		k = 0;
		for(i = 0; i < uSize; i++) {
			for(j = 0; j < uSNPs; j++) {
				if(vvsMapSpliced[i][PLNK_MAP_SNP_ID_COL] == vvsMapSplicing[j][PLNK_MAP_SNP_ID_COL]) {
					k++;
					viSNPinSplicing[i] = 2 * j + PLNK_PED_GENOTYPE_COL;		//*2和+PLNK_PED_GENOTYPE_COL是为了在PED文件中寻址方便（PED前PLNK_PED_GENOTYPE_COL列是行头）
					if ((vvsMapSpliced[i][PLNK_MAP_CHR_COL] != vvsMapSplicing[j][PLNK_MAP_CHR_COL])
						|| (vvsMapSpliced[i][PLNK_MAP_POS_COL] != vvsMapSplicing[j][PLNK_MAP_POS_COL])){
						clsParas->fpLog << "No. in spliced: " << i << '\t' << vvsMapSpliced[i][PLNK_MAP_CHR_COL]
							<< "<-->" << vvsMapSplicing[j][PLNK_MAP_CHR_COL] << endl;
					}
					break;
				}
			}
		}

		vvsMapSpliced.clear();
		vvsMapSplicing.clear();
		uSNPs = uSize;

		//统计拼接文件中没有的SNP数
		j = 0;
		for (i = 0; i < uSize; i++){
			if (viSNPinSplicing[i] < 0) j++;
		}

		clsParas->fpLog << "Total " << k << " SNPs are the same in the two files. In additional, " << j 
			<< " SNPs in splicing file can't be found in spliced file." << endl;
		cout << "Total " << k << " SNPs are the same in the two files. In additional, " << j
			<< " SNPs in splicing file can't be found in spliced file." << endl;

		//拼接文件
		clsParas->fpLog << "The individuals of splicing file that can not be spliced (No.):" << endl;
		cout << "Splicing ..." << endl;

		for (i = 0; i < (int)vsPedSplicing.size(); i++) {
			//replace_all_distinct(vsPedSplicing[i], "\t", " ");	//把所有TAB用空格替换。此函数速度超慢，用以下函数代替
			//replaceChar(vsPedSplicing[i], DELIMITER2, DELIMITER3);	2020.7.6前

	/************************此段程序采用直接对字串操作的方式消耗的时间过多********************************
			cout << "\rstep 1      ";		//调试用

			//取前5列（含最后一个分隔符）
			sLine = "";
			j = 0;
			for(k = 0; k < vsPedSplicing[i].size(); k++) {
				if(j == PLNK_PED_PHENOTYPE_COL) break;
				cS[k] = vsPedSplicing[i][k];
				if(cS[k] == DELIMITER3) j++;
			}
			if(j != PLNK_PED_PHENOTYPE_COL) continue;		//列数不足
			if(clsParas->bFixPhenotype) cS[k] = clsParas->cPhenotype;
			else cS[k] = vsPedSplicing[i][k];
			cS[++k] = DELIMITER3;
			cS[++k] = '\0';
			sLine = cS;

			//统计sLine列数
			uSize = 0;
			for(j = 0; j < vsPedSplicing[i].length(); j++) if(vsPedSplicing[i][j] == DELIMITER3) uSize++;
			uSize--;
			
			cout << "\rstep 2      ";		//调试用

			cS[1] = DELIMITER3;
			cS[3] = DELIMITER3;
			cS[4] = '\0';
			for(j = 0; j < viSNPinSplicing.size() - 1; j ++) {	//加入基因型列
				if(viSNPinSplicing[j] < 0 || viSNPinSplicing[j] > (int)uSize) {	//拼接入的个体之SNP个数可能小于其MAP，所以viSNPinSplicing[j] > uSize
					cS[0] = PLNK_PED_MISSING_ALLELE2;
					cS[2] = PLNK_PED_MISSING_ALLELE2;
				} else {
					cS[0] = getAllele(vsPedSplicing[i], DELIMITER3, viSNPinSplicing[j]);
					cS[2] = getAllele(vsPedSplicing[i], DELIMITER3, viSNPinSplicing[j] + 1);
				}
				sLine += cS;
			}
			//加入最后一列
			if(viSNPinSplicing[j] < 0 || viSNPinSplicing[j] > (int)uSize) {	//拼接入的个体之SNP个数可能小于其MAP，所以viSNPinSplicing[j] > uSize
				cS[0] = PLNK_PED_MISSING_ALLELE2;
				cS[2] = PLNK_PED_MISSING_ALLELE2;
			} else {
				cS[0] = getAllele(vsPedSplicing[i], DELIMITER3, viSNPinSplicing[j]);
				cS[2] = getAllele(vsPedSplicing[i], DELIMITER3, viSNPinSplicing[j] + 1);
			}
			sLine += cS;

	*******************************************************************************************************/

			////////2020.7.6 取出前6列
			trimString(vsPedSplicing[i]);						//删除前后空格及TAB
			trimRedundance(vsPedSplicing[i], true);				//删除中间多余空格及TAB（只保留一个），并把TAB用空格替换

			// 以下6行是2020.7.6前	
			stringSplit(vsPedSplicing[i], vsSplit, " ");			//以空格为分隔符拆分字符串
			uSize = vsSplit.size();
			if(uSize < PLNK_PED_GENOTYPE_COL) {						//没有足够的列数
				clsParas->fpLog << '\t' << i << endl;
				continue;
			}

			//cout << "\rstep 1      ";		//调试用
			//调试用
			/*clsParas->fpLog << i << ": " << uSize << endl;
			if(i > 3) {
				clsParas->fpLog.close(); exit(1);
			}*/

			// 以下5行是2020.7.6前
			sLine = "";
			for (j = 0; j < PLNK_PED_PHENOTYPE_COL; j++){ sLine += vsSplit[j] + DELIMITER3; }	//加入前5列

			//加入第6列
			if (clsParas->bFixPhenotype){ sLine += clsParas->cPhenotype; }
			else{ sLine += vsSplit[j]; }

			// 检查样本是否重复，前6列相同即认为重复
			b = false;
			for (j = 0; j < (int)vsPed6.size(); j++){
				if (sLine == vsPed6[j]){
					b = true;
					break;
				}
			}

			if (b){
				clsParas->fpLog << '\t' << i << endl;
				continue;
			}
			/////////2020.7.6

			sLine += DELIMITER3;

			//cout << "\rstep 2       ";		//调试用

			uSize -= 2;
			for(j = 0; j < uSNPs - 1; j ++) {	//加入基因型列（前N-1列）
				if(viSNPinSplicing[j] < 0 || viSNPinSplicing[j] > (int)uSize) {	//拼接入的个体之SNP个数可能小于其MAP，所以viSNPinSplicing[j] > uSize
					//与常量运算，以下几行不能写作一行
					sLine += PLNK_PED_MISSING_ALLELE2;
					sLine += DELIMITER3;
					sLine += PLNK_PED_MISSING_ALLELE2;
				}
				else{
					sLine += vsSplit[viSNPinSplicing[j]] + DELIMITER3 + vsSplit[viSNPinSplicing[j] + 1];
				}

				sLine += DELIMITER3;
			}
			//加入最后一列
			if(viSNPinSplicing[j] < 0) {
				//与常量运算，以下几行不能写作一行
				sLine += PLNK_PED_MISSING_ALLELE2;
				sLine += DELIMITER3;
				sLine += PLNK_PED_MISSING_ALLELE2;
			}
			else{
				sLine += vsSplit[viSNPinSplicing[j]] + DELIMITER3 + vsSplit[viSNPinSplicing[j] + 1];
			}
	
			//vsPedSpliced.push_back(sLine);
			fp << sLine << endl;		//由于输出文件太大，只能一边处理一边写输出，否则极易内存溢出

			
			//cout << '\r' << i << "/" << vsPedSplicing.size() << "         "; //调试用
		}

		fp.close();
		fp.clear();

		//清空缓存（.NET的内存回收机制似乎存在问题，所以此处人为地清空缓存）
		vString().swap(vsPedSpliced);
		vString().swap(vsPedSplicing);
		vString().swap(vsSplit);
		vInt().swap(viSNPinSplicing);
		
		cout << "The ped file was spliced as " << clsParas->sOutputFilename << "(.ped)." << endl;
		clsParas->fpLog << "The ped file was spliced as " << clsParas->sOutputFilename << "(.ped)." << endl;


		// 因是以被拼接文件的MAP为基准拼接的，所以MAP文件直接复制即可
		//生成文件名
		s = getFn(clsParas->sOutputFilename, ".map", true);

		fp.open(s.c_str(), ios_base::out);
		if (!fp.good()) {
			fp.close();
			fetalError("Write file " + s + " failed.", clsParas);
		}

		fstream	fpIn;

		fpIn.open(sSplicedMapFn.c_str(), ios_base::in);
		if (!fpIn.good()) {
			fpIn.close();
			fetalError("MAP file " + sSplicedMapFn + " opened error.", clsParas);
		}

		fp << fpIn.rdbuf();		//复制生成map文件

		fp.close();
		fpIn.close();
		fp.clear();
		fpIn.clear();

		cout << "The map file was saved as " << sSplicedMapFn << "." << endl;
		clsParas->fpLog << "The map file was saved as " << sSplicedMapFn << "." << endl;
	}

	/********************************************
	* 比较两个文件
	*********************************************/
	void fileCompare(coPLINK::parameters *clsParas)
	{
		bool	b;

		if (clsParas->sInputFilename == "") {
			fetalError("Please specify the first file.", clsParas);
		}
		if (clsParas->sFilename2 == "") {
			fetalError("Please specify the second file.", clsParas);
		}

		if (clsParas->cDelimeter == '\t') clsParas->cDelimeter = ' ';	// 后续操作统一把TAB用空格替换

		clsParas->iColumn[0]--;	// 因为列号从1开始计数，这里-1以便程序编写

		b = (clsParas->iColumn[0] < 0 || clsParas->iMode == CMP_BY_BIN || clsParas->iMode == CMP_BY_BIN_POS) ? true : false;			// 列号小于0或二进制比较,则顺序比较

		if (b) {// 顺序比较
			cout << "Comparing file " << clsParas->sInputFilename << " with " << clsParas->sFilename2 << " by order ..." << endl;
			cmpFileInOrder(clsParas);
		}
		else {	// 按基准列比较
			cout << "Comparing file " << clsParas->sInputFilename << " with " << clsParas->sFilename2 << " by reference column "
				<< clsParas->iColumn[0] + 1 << " ..." << endl;
			cmpFileInRef(clsParas);		
		}
			
	}

	/***********************************************
	* 逐行或逐字节顺序比较两个文件
	************************************************/
	void cmpFileInOrder(parameters *clsParas)
	{
		fstream			fp1, fp2, fpOut;
		string			sLine1, sLine2;
		int				iCnt, iDiffCnt, i;
		uint			iSize1, iSize2;
		bool			b = false;
		char			c1, c2;

		iSize1 = getFileSize(clsParas->sInputFilename, &b);
		iSize2 = getFileSize(clsParas->sFilename2, &b);
#ifdef TEST_PERFORMANCE
		clsParas->uInSize = (iSize1 + iSize2) / 2;
#endif
		cout << "The sizes of file1 " << clsParas->sInputFilename << " and file2 " << clsParas->sFilename2
			<< " are " << iSize1 << " and " << iSize2 << " bytes, respectively.\n" << endl;

		sLine1 = getFn(clsParas->sOutputFilename, ".csv");
		b = access(sLine1.c_str(), 0) == -1;

		fpOut.open(sLine1.c_str(), ios::out | ios::app);
		if (!fpOut.good()){
			fetalError("The out file " + clsParas->sOutputFilename + " open/create is failed.", clsParas);
		}
		if (b){	// 文件不存在
			fpOut << "Created at " << getDT() << " via " << VERSION << endl << endl;
			fpOut << "Mode,File1,File2,Compared,Diff Cnt,Size1/*row1,Size2/*row2,column,Memo" << endl;
		}
		else fpOut << "\n******************************" << endl;

		iCnt = iDiffCnt = 0;
		if (clsParas->iMode == CMP_BY_TEXT || clsParas->iMode == CMP_BY_TEXT_POS) {
			openStreamFile(fp1, clsParas->sInputFilename.c_str(), ios::in/* | ios::_Nocreate*/);
			openStreamFile(fp2, clsParas->sFilename2.c_str(), ios::in /*| ios::_Nocreate*/);

			while (getline(fp1, sLine1) && getline(fp2, sLine2)) {
				iCnt++;

				if (clsParas->cDelimeter == ' '){	// 如果分隔符是空格或TAB，则把前导和尾部空格去掉。前面已把TAB分隔符替换为空格
					trimString(sLine1);				//删除前后空格及TAB
					trimRedundance(sLine1, true);	//删除中间多余空格及TAB（只保留一个）,所有TAB用空格替换掉
					trimString(sLine2);				//删除前后空格及TAB
					trimRedundance(sLine2, true);	//删除中间多余空格及TAB（只保留一个）,所有TAB用空格替换掉
				}

				if (sLine1 != sLine2) {
					iDiffCnt++;
					if (clsParas->iMode == CMP_BY_TEXT_POS) {
						i = stringCmp(sLine1, sLine2, clsParas->cDelimeter);
						if (i == string::npos){	// 无差异
							iDiffCnt--;
							continue;
						}

						// "Mode,File1,File2,Compared,Diff Cnt,Size1/*row1,Size2/*row2,column,Memo"
						fpOut << "Text," << clsParas->sInputFilename << ',' << clsParas->sFilename2 << ',' 
							<< iCnt << ',' << iDiffCnt << ",*"
							<< iCnt << ",*" << iCnt << ',' << i + 1 << ',' << clsParas->sMemo << endl;
					}
				}

				cout << '\t' << iCnt << " ...\r";
			}

			fpOut << "Text," << clsParas->sInputFilename << ',' << clsParas->sFilename2 << ',' 
				<< iCnt << ',' << iDiffCnt << ',' << iSize1 << ',' << iSize2 << ",-,Summary of "
				<< clsParas->sMemo << endl;
		}
		else{	// 二进制比较
			openStreamFile(fp1, clsParas->sInputFilename.c_str(), ios::in | ios::binary);
			openStreamFile(fp2, clsParas->sFilename2.c_str(), ios::in | ios::binary);

			while (fp1.read(&c1, sizeof(char)) && fp2.read(&c2, sizeof(char))) {	// 这样不会读入最后一个结束符
				iCnt++;
				if (c1 != c2) {
					iDiffCnt++;
					if (clsParas->iMode == CMP_BY_BIN_POS){
						// "Mode,File1,File2,Compared,Diff Cnt,Size1/*row1,Size2/*row2,column,Memo"
						fpOut << "Binary," << clsParas->sInputFilename << ',' << clsParas->sFilename2 << ',' 
							<< iCnt << ',' << iDiffCnt << ",*"
							<< iCnt << ",*" << iCnt << ",-," << clsParas->sMemo << endl;
					}
				}

				cout << '\t' << iCnt << " ...\r";
			}
			fpOut << "Binary," << clsParas->sInputFilename << ',' << clsParas->sFilename2 << ',' 
				<< iCnt << ',' << iDiffCnt << ',' << iSize1 << ',' << iSize2 << ",-,Summary of "
				<< clsParas->sMemo << endl;
		}

		fp1.close();
		fp2.close();
		//fpOut.flush();	//强制写硬盘（流式文件可能不需要）
		fpOut.close();

		cout << "\nCompared rows/bytes are " << iCnt << " which of " << iDiffCnt << " rows/bytes are different.\n" << endl;
		clsParas->fpLog << "Compared rows/bytes are " << iCnt << " which of " << iDiffCnt << " rows/bytes are different." << endl;
	}

	/***********************************************
	* 以指定的列号（用户给定从1开始）所在列为基准进行比较
	* 用户给定的列号大于0且是文本比较方式，进入本比较模式
	* ***********************************************
		如，两个文件：
		f.csv:
			0,SNP4,0,0
			0,SNP3,0,0
			0,SNP2,0,1
			0,SNP1,0,0
		g.csv:
			0,SNP1,0,0
			0,SNP2,0,0
			0,SNP3,0,0
			0,SNP4,0,0
		则 coPLINK --compare f.csv --file2 g.csv --out e --col 2 --delim , --mode 2 的结果：
			Mode	Compared	Difference	Size1/*row1	Size2/*row2	Memo
			Text	2			1			*3			*2			f.csv-g.csv
			Text	4			1			48			48			f.csv-g.csv
	************************************************/
	void cmpFileInRef(parameters *clsParas){
		fstream					fp, fpOut;
		string					sLine1, sLine2;
		int						i, j, k, iCnt, iDiffCnt, iComparedCnt;
		uint					iSize1, iSize2;
		bool					b = false;
		vString					vsf1;
		vector<bool>			vb1;
		multimap<string, int>	mk;

		iSize1 = getFileSize(clsParas->sInputFilename, &b);
		iSize2 = getFileSize(clsParas->sFilename2, &b);
#ifdef TEST_PERFORMANCE
		clsParas->uInSize = (iSize1 + iSize2) / 2;
#endif
		cout << "The sizes of file1 " << clsParas->sInputFilename << " and file2 " << clsParas->sFilename2
			<< " are " << iSize1 << " and " << iSize2 << " bytes, respectively.\n" << endl;

		sLine1 = getFn(clsParas->sOutputFilename, ".csv");
		b = access(sLine1.c_str(), 0) == -1;

		fpOut.open(sLine1.c_str(), ios::out | ios::app);
		if (!fpOut.good()){
			fetalError("The out file " + clsParas->sOutputFilename + " open/create is failed.", clsParas);
		}

		if (b){	// 文件不存在
			fpOut << "Created at " << getDT() << " via " << VERSION << endl << endl;
			fpOut << "Mode,File1,File2,Compared,Diff Cnt,Size1/*row1,Size2/*row2,column,Memo" << endl;
		}
		else{
			fpOut << "\n******************************" << endl;
		}

		openStreamFile(fp, clsParas->sInputFilename.c_str(), ios::in);
		iCnt = -1;
		while (getline(fp, sLine1)) {	// 这样不会读入最后一个空行
			iCnt++;

			if (clsParas->cDelimeter == ' '){	// 如果分隔符是空格或TAB，则把前导和尾部空格去掉。前面已把TAB分隔符替换为空格
				trimString(sLine1);							//删除前后空格及TAB
				trimRedundance(sLine1, true);				//删除中间多余空格及TAB（只保留一个）,所有TAB用空格替换掉（为分拆作准备）
			}

			vsf1.push_back(sLine1);
			j = sLine1.length();
			if (j == 0) continue;						// 空行不参与比较，但保存在vsf1

			// find col. cnt.
			k = 0;
			for (i = 0; i < j; i++){
				if (sLine1[i] == clsParas->cDelimeter) k++;

				if (k == clsParas->iColumn[0]) break;
			}

			if (i == j){	// out of the length
				cout << "Skip row " << iCnt + 1 << " with fewer columns than specified col. No. in file " << clsParas->sInputFilename << endl;
				clsParas->fpLog << "Skip row " << iCnt + 1 << " with fewer columns than specified col. No. in file " << clsParas->sInputFilename << endl;
				continue;
			}

			// get the field used to compare
			sLine2 = sLine1[++i];
			i++;
			for (; i < j; i++){
				if (sLine1[i] == clsParas->cDelimeter) break;

				sLine2 += sLine1[i];
			}

			mk.insert(pair<string, int>(sLine2, iCnt));	// store the field and row No.
			
		}
		fp.close();
		fp.clear();

		if (vsf1.empty()){
			char cs[10];
			sprintf(cs, "%d", clsParas->iColumn[0]);
			fetalError("File " + clsParas->sInputFilename + " has not any rows with " + (string)cs + " column(s) or more.", clsParas);
		}

		vb1.resize(vsf1.size(), true);	// true表示在file2未找到的行
		multimap<string, int>::size_type entries, cnt;
		multimap<string, int>::iterator iter;

		openStreamFile(fp, clsParas->sFilename2.c_str(), ios::in);

		iCnt = iDiffCnt = iComparedCnt = 0;
		while (getline(fp, sLine1)) {	// 这样不会读入最后一个空行
			iCnt++;

			if (clsParas->cDelimeter == ' '){	// 如果分隔符是空格或TAB，则把前导和尾部空格去掉。前面已把TAB分隔符替换为空格
				trimString(sLine1);							//删除前后空格及TAB
				trimRedundance(sLine1, true);				//删除中间多余空格及TAB（只保留一个）,所有TAB用空格替换掉（为分拆作准备）
			}

			j = sLine1.length();
			if (j == 0) continue;						// 空行不参与比较

			iComparedCnt++;

			// find col.
			k = 0;
			for (i = 0; i < j; i++){
				if (sLine1[i] == clsParas->cDelimeter) k++;

				if (k == clsParas->iColumn[0]) break;
			}

			if (i == j){	// out of the length
				cout << "\nSkip row " << iCnt << " with fewer columns than specified col. No. in file " << clsParas->sFilename2 << endl;
				clsParas->fpLog << "Skip row " << iCnt << " with fewer columns than specified col. No. in file " << clsParas->sFilename2 << endl;
				continue;
			}

			// get the field used to be compared
			sLine2 = sLine1[++i];
			i++;
			for (; i < j; i++){
				if (sLine1[i] == clsParas->cDelimeter) break;

				sLine2 += sLine1[i];
			}

			// 查找比较
			entries = mk.count(sLine2);	//找到元素的个数
			iter = mk.find(sLine2);

			i = -1;						// -1表示file1中没有
			if (iter != mk.end()) {
				i = iter->second;
				vb1[i] = false;			// file1中有，就是一次比较
			}

			b = true;
			for (cnt = 0; cnt != entries; ++cnt, ++iter)
			{
				if (vsf1[i] == sLine1){
					b = false;
					break;
				}
			}

			if (b) {	// not found
				iDiffCnt++;
				if (clsParas->iMode == CMP_BY_TEXT_POS) {	// size1保存文件1的行号（从1开始），size2保存文件2的行号（包括空行）
					if (i < 0) {	// file1中没有
						// "Mode,File1,File2,Compared,Diff Cnt,Size1/*row1,Size2/*row2,column,Memo"
						fpOut << "Text," << clsParas->sInputFilename << ',' << clsParas->sFilename2 << ','
							<< iComparedCnt << ',' << iDiffCnt << ",Not found,*" << iCnt << ",-,"
							<< clsParas->sMemo << endl;
					}
					else {
						k = stringCmp(vsf1[i], sLine1, clsParas->cDelimeter);
						if (k == string::npos){	// 无差异
							iDiffCnt--;
							continue;
						}

						fpOut << "Text," << clsParas->sInputFilename << ',' << clsParas->sFilename2 << ',' 
							<< iComparedCnt << ',' << iDiffCnt << ",*" << i + 1 << ",*" << iCnt << ','
							<< k + 1 << ',' << clsParas->sMemo << endl;
					}
				}
			}

			cout << '\t' << iCnt << " ...\r";
		}
		fp.close();
		fp.clear();

		// 统计file1中未到的行
		for (i = 0; i < (int)vb1.size(); i++){
			if (vb1[i] && vsf1[i].length() > 0){	// not found
				iDiffCnt++;

				if (clsParas->iMode == CMP_BY_TEXT_POS) {	// size1保存文件1的行号（从1开始），size2保存文件2的行号（包括空行）
					///// 从vsf1提取关键字段以获得file1中的行号
					//// find col.
					//k = 0;
					//for (j = 0; j < (int)vsf1[i].length(); i++){
					//	if (vsf1[i][j] == clsParas->cDelimeter) k++;
					//	if (k == clsParas->iColumn[0]) break;
					//}

					//// get the field used to compare
					//sLine2 = vsf1[i][++j];
					//j++;
					//for (; k < j; k++){
					//	if (vsf1[i][k] == clsParas->cDelimeter) break;
					//	sLine2 += vsf1[i][k];
					//}

					//iter = mk.find(sLine2);
					//k = iter == mk.end() ? i + 1 : iter->second;

					// "Mode,File1,File2,Compared,Diff Cnt,Size1/*row1,Size2/*row2,column,Memo"
					fpOut << "Text," << clsParas->sInputFilename << ',' << clsParas->sFilename2 << ',' 
						<< iComparedCnt << ',' << iDiffCnt << ",*" << i + 1 << ",Not found,-," << clsParas->sMemo << endl;;
				}
			}
		}

		fpOut << "Text," << clsParas->sInputFilename << ',' << clsParas->sFilename2 << ',' 
			<< iComparedCnt << ',' << iDiffCnt << ',' << iSize1 << ',' << iSize2 << ",-,Summary of "
			<< clsParas->sMemo << endl;

		fpOut.close();

		cout << "\nCompared rows are " << iComparedCnt << " which of " << iDiffCnt << " rows are different.\n" << endl;
		clsParas->fpLog << "Compared rows are " << iComparedCnt << " which of " << iDiffCnt << " rows are different." << endl;
	}

	/********************************************
	* BOOST格式转PLINK ped文本格式
	* vvcData = BOOST格式的数据（字符矩阵）
	* fOut = 输出文件名
	* strNo = 染色体编号
	* uSeed = 随机数种子
	*********************************************
	BOOST格式(每行一个个体)：
	1 2 2 0 0 0 0 2 2 1 2 0 2 2 0 1 …
	0 1 2 0 1 0 0 2 2 0 2 0 1 2 2 1 …
	0 2 1 0 0 0 1 0 2 0 2 1 1 2 0 2 …
	1 2 1 1 1 0 1 0 2 1 2 0 2 2 0 1 …
	第1列：0=control、1=case
	第2列以后：0 = AA, 1 = Aa/aA, 2 = aa, -9 = missing

	PLINK ped文本格式（PED文件, N-missing）(每行一个个体)：
	1	1	0	0	1	1	A	A	G	T
	2	1	0	0	1	1	A	C	T	G
	3	1	0	0	1	1	C	C	G	G
	4	1	0	0	1	2	A	C	T	T
	5	1	0	0	1	2	C	C	G	T
	6	1	0	0	1	2	C	C	T	T
	前6列(前4列可多个字符组成)：
	Family ID
	Individual ID
	Paternal ID
	Maternal ID
	Sex (1=male; 2=female; other=unknown)
	Phenotype (1=unaffect; 2=affect)

	PLINK ped文本格式（MAP文件）：
	1 snp1 0 1
	1 snp2 0 2
	各列含义：
	chromosome (1-22, X, Y or 0 if unplaced)
	rs# or snp identifier
	Genetic distance (morgans)
	Base-pair position (bp units)
	*************************************************/
	void BOOST2Ped(vvChar& vvcData, string fOut, string strNo, uint uSeed)
	{
		CRandomMersenne crnd(uSeed);

		string	strPed, strMap, sTmp;
		int	i, j;
		fstream	fp;

		//生成Plink文件名
		strPed = getFn(fOut, ".ped");
		strMap = getFn(fOut, ".map");

		//生成ped文件
		openStreamFile(fp, strPed.c_str(), ios::out);


		for (i = 0; i < (int)vvcData.size(); i++) {
			fp << "1 "							//family ID
				<< i + 1						//individual ID
				<< " 0 0 "						//paternal ID, maternal ID
				<< (int)crnd.IRandom(1, 2)		//sex。随机生成
				<< DELIMITER3
				<< (vvcData[i][0] == BOOST_CTRL_PHENOTYPE ? PLNK_PED_CTRL_PHENOTYPE : PLNK_PED_CASE_PHENOTYPE);

			sTmp = "";
			for (j = 1; j < (int)vvcData[0].size(); j++) {
				if (vvcData[i][j] == BOOST_AA){
					sTmp += " D D";
				}
				else if (vvcData[i][j] == BOOST_Aa_aA){
					sTmp += DELIMITER3;
					sTmp += PLNK_PED_Aa_aA;
				}
				else if (vvcData[i][j] == BOOST_aa){
					sTmp += " d d";
				}
				else{
					sTmp += " N N";
				}
			}

			fp << sTmp << endl;
			cout << '\t' << i << " ...\r";
		}
		fp.close();
		fp.clear();

		cout << "\nThe PED file saved as " << strPed << endl;

		//生成map文件
		openStreamFile(fp, strMap.c_str(), ios::out);

		for (i = 0; i < (int)vvcData[0].size() - 1; i++) {
			fp << strNo				//染色体号
				<< " SNP" << i + 1	//SNP ID
				<< " 0 0"<< endl;			//Genetic distance, Base-pair position

			cout << '\t' << i << " ...\r";
		}
		fp.close();
		fp.clear();

		cout << "\nThe MAP file saved as " << strMap << endl;
	}

	/********************************************
	* BOOST格式转PLINK bed文本格式
	* vvcData = BOOST格式的数据（字符矩阵）
	* clsParas = pointer of class
	*********************************************
	BOOST格式(每行一个个体)：
	1 2 2 0 0 0 0 2 2 1 2 0 2 2 0 1 …
	0 1 2 0 1 0 0 2 2 0 2 0 1 2 2 1 …
	0 2 1 0 0 0 1 0 2 0 2 1 1 2 0 2 …
	1 2 1 1 1 0 1 0 2 1 2 0 2 2 0 1 …
	第1列：0=control、1=case
	第2列以后：0 = AA, 1 = Aa/aA, 2 = aa, -9 = missing

	PLINK二进制的bed文件格式（Plink v0.99以后，之前版本无前两个字节）：
 	若ped文件内容是：
	1 1 0 0 1  1  A A  G T
	2 1 0 0 1  1  A C  T G
	3 1 0 0 1  1  C C  G G
	4 1 0 0 1  2  A C  T T
	5 1 0 0 1  2  C C  G T
	6 1 0 0 1  2  C C  T T
	其中前6列：
	Family ID
	Individual ID
	Paternal ID, Maternal ID
	Sex (1=male; 2=female; other=unknown)
	Phenotype (1=unaffect; 2=affect)

	map文件的内容是：
	1 snp1 0 1
	1 snp2 0 2
		
	则对应的bed文件是（前3个字节是固定的）：
	十六进制：	6C		1B		01		B8		0F		CA		0E
	二进制：	01101100	00011011	00000001	10111000	00001111	11001010	00001110
		
	从第四个字节开始是基因数据。基因数据编码方式：
	1. 每一个SNP中minor allele用0表示，major allele则用1表示。则有此等价
	   表示：
		00 - aa		01 - Aa aA		11 - AA		10 - Missing
	2. 每个SNP用整数个字节不足补0。
	如上例之第二个SNP：G是minor allele、T是major allele，则表示为：01010011 01110000
	注意第二组“TG”也应表示为“01”，第二字节尾部补4个0以形成一个整
	字节
	3. 最后把每个字节逆序存放。
	
	PLINK fam文件格式。
		bed文件仅记录了基因数据（即ped文件的从第7列开始的内容），fam文件
		则记录的是ped的前6列

	PLINK bim文件格式。
		bim文件是ped格式中的map文件的扩展，与上述map文件对应的bim文件：
		1	snp1	0	1	A	C
		1	snp2	0	2	G	T
		各列： 
		0 - chromosome (1-22, X, Y or 0 if unplaced)
		1 - rs# or snp identifier
		2 - Genetic distance (morgans)
		3 - Base-pair position (bp units)
		4 - allele 1（minor allele）
		5 - allele 2（major allele）
		注：（1）若两个等位基因个数相同，则Plink 1.9 Beta6按字母序分别是
			minor allele和major allele,Plink 1.07把先遇到的作为minor
			 allele（这里按Plink 1.9 Beta6规则编程）
		    （2）若只有一种等位基因，则用0标示缺失一种并作为minor allele
		    （3）不判断缺失等位基因符号（如 0、-、N等），所有符号都作为正常符号处理
	*************************************************/
	void BOOST2Bed(vvChar& vvcData, parameters *clsParas)
	{
		CRandomMersenne crnd(clsParas->uRndSeed);

		string		sFam, sBim, sBed;
		int		i, k, n, uSampleCnt;
		char		ctmp[20], c;
		ofstream	fpFam, fpBim, fpBed;			// fstream 创建二进制文件会失败
		bool		bAa, baa, bAA, bMissing;

		//生成fam文件
		cout << "Converting to fam ..." << endl;

		sFam = getFn(clsParas->sOutputFilename, ".fam");
		fpFam.open(sFam.c_str(), ios::out);
		if (!fpFam.is_open()){
			fpFam.close();
			fetalError("Create file " + sFam + " failed.", clsParas);
		}

		ctmp[11] = '\0';
		uSampleCnt = vvcData.size();
		for (i = 0; i < uSampleCnt; i++) {
			sprintf(ctmp, "1 %d 0 0 %d %c", i + 1, (int)crnd.IRandom(1, 2), //family ID, individual ID, paternal ID, maternal ID, sex。随机生成
				(vvcData[i][0] == BOOST_CASE_PHENOTYPE ? PLNK_PED_CASE_PHENOTYPE : PLNK_PED_CTRL_PHENOTYPE)); // Phenotype
			//ctmp[0] = '0';								//family ID
			//ctmp[1] = DELIMITER3;
			//ctmp[2] = '1';								//individual ID
			//ctmp[3] = DELIMITER3;
			//ctmp[4] = '0';								//paternal ID
			//ctmp[5] = DELIMITER3;
			//ctmp[6] = '0';								//maternal ID
			//ctmp[7] = DELIMITER3;
			//ctmp[8] = I2C((int)crnd.IRandom(1, 2));		//sex。随机生成
			//ctmp[9] = DELIMITER3;
			//ctmp[10] = vvcData[i][0] == BOOST_CASE_PHENOTYPE ? PLNK_PED_CASE_PHENOTYPE : PLNK_PED_CTRL_PHENOTYPE;
			
			fpFam << ctmp << endl;
			cout << '\t' << i << " ...\r";
		}
		fpFam.close();
		fpFam.clear();
		cout << endl;
		cout << "\tSave " << sFam << " OK." << endl;

		cout << "Converting to .bim and .bed ..." << endl;

		sBim = getFn(clsParas->sOutputFilename, ".bim");
		fpBim.open(sBim.c_str(), ios::out);
		if (!fpBim.is_open()){
			fpBim.close();
			fetalError("Create file " + sBim + " failed.", clsParas);
		}

		//生成bed文件名
		sBed = getFn(clsParas->sOutputFilename, ".bed");

		//生成bed文件
		fpBed.open(sBed.c_str(), ios::binary);
		if (!fpBed.is_open()){
			fpBed.close();
			fetalError("Create file " + sBed + " failed.", clsParas);
		}

		// bed文件前两个字节固定，第3字节01表示只支持SNP-majar格式
		c = 0x6C;
		fpBed.write((char *)&c, 1);	//读写都要做这样的转换(char *)&c，另外，不能用“<<”操作符输出（结果不正确）
		c = 0x1B;
		fpBed.write((char *)&c, 1);
		c = 0x01;
		fpBed.write((char *)&c, 1);
		k = 0;
		c = 0;
		
		for (i = 1; i < (int)vvcData[0].size(); i++) {	// 逐SNP
			fpBim << clsParas->sChrNo << DELIMITER2 << "snp" << i;	// chr no. (0 is unplaced), SNP label
			fpBim << "\t0\t";						// Genetic distance (morgans)
			fpBim << i << DELIMITER2;				// Base - pair position(bp units)
			bAA = bAa = baa = bMissing = false;
			ctmp[0] = '0';
			ctmp[1] = DELIMITER2;
			ctmp[2] = '0';
			ctmp[3] = '\0';
			for (n = 0; n < uSampleCnt; n++){				// 逐样本
				if (vvcData[n][i] == BOOST_AA){				// major allele 纯合子
					c |= PLNK_BED_AA << k;
					bAA = true;
				}
				else if (vvcData[n][i] == BOOST_Aa_aA) {	// 杂合子
					c |= PLNK_BED_Aa_aA << k;
					bAa = true;
				}
				else if (vvcData[n][i] == BOOST_aa){		// minor allele 纯合子
					c |= PLNK_BED_aa << k;
					baa = true;
				}
				else {										// 缺失
					c |= PLNK_BED_MISSING << k;
					bMissing = true;
				}

				k += 2;
				if (k >= 8) {
					fpBed.write((char *)&c, 1);
					k = c = 0;
				}
			}
			if (k){
				fpBed.write((char *)&c, 1);
				k = c = 0;
			}

			if (bAa || (bAA && baa)){		// 存在杂合子或两种纯合子
				ctmp[0] = 'd';
				ctmp[2] = 'D';
			}
			else{
				if (bMissing){
					if (bAA){
						ctmp[0] = PLNK_PED_MISSING_ALLELE2;
						ctmp[2] = 'D';
					}
					else{
						ctmp[0] = PLNK_PED_MISSING_ALLELE2;
						ctmp[2] = 'd';
					}
				}
				else {
					if (bAA){
						ctmp[0] = '0';
						ctmp[2] = 'D';
					}
					else{
						ctmp[0] = '0';
						ctmp[2] = 'd';
					}
				}
			}
			fpBim << ctmp << endl;
			cout << '\t' << i << " ...\r";
		}
		fpBed.close();
		fpBim.close();

		cout << "\n\tSave " << sBed << " OK." << endl;
		cout << "\tSave " << sBim << " OK." << endl;
	}

	/********************************************
	* 转换ME格式文本文件为PLINK ped文本格式
	* viNo = No. 列向量
	* vcPhenotypes = 表型列向量
	* vvcData = 除一、二列外的文件内容（基因型矩阵，字符矩阵）
	* clsParas = 参数类
	*********************************************
	ME格式(每行一个个体)：
	No.	Case/Control	Allele0	Allele1	Allele0 …
	1		1 				1 		1 		1 	...
	2    	2 				1 		1 		2 	...
	第1列：样本序号
	第2列：1=control 2=case
	第3列以后每两列组成一个SNP：0/0和1/1=AA、1/2和2/1=Aa、2/2=aa（本程序定义missing = -1）
	************************************************
	PLINK ped文本格式（PED文件, N-missing）(每行一个个体)：
	1	1	0	0	1	1	A	A	G	T
	2	1	0	0	1	1	A	C	T	G
	3	1	0	0	1	1	C	C	G	G
	4	1	0	0	1	2	A	C	T	T
	5	1	0	0	1	2	C	C	G	T
	6	1	0	0	1	2	C	C	T	T
	前6列(前4列可多个字符组成)：
	Family ID
	Individual ID
	Paternal ID
	Maternal ID
	Sex (1=male; 2=female; other=unknown)
	Phenotype (1=unaffect; 2=affect)

	PLINK ped文本格式（MAP文件）：
	1 snp1 0 1
	1 snp2 0 2
	各列含义：
	chromosome (1-22, X, Y or 0 if unplaced)
	rs# or snp identifier
	Genetic distance (morgans)
	Base-pair position (bp units)

	vviData = ME文件内容
	***********************************************/
	void ME2Ped(vInt &viNo, vChar &vcPhenotypes, vvChar& vvcData, coPLINK::parameters *clsParas)
	{
		if (vvcData.size() == 0){
			fetalError("Not any data to convert!", clsParas);
		}

		CRandomMersenne crnd(clsParas->uRndSeed);

		string	strPed, strMap;
		int		i, j;
		fstream	fp;

		//生成Plink文件名
		strPed = getFn(clsParas->sOutputFilename, ".ped");
		strMap = getFn(clsParas->sOutputFilename, ".map");

		//生成ped文件
		openStreamFile(fp, strPed.c_str(), ios::out);

		for (i = 0; i < (int)vvcData.size(); i++) {
			fp << "1 "						//family ID
				<< viNo[i]					//individual ID
				<< " 0 0 "					//paternal ID, maternal ID
				<< (int)crnd.IRandom(1, 2)	//sex。随机生成
				<< DELIMITER3
				<< (vcPhenotypes[i] == ME_CTRL_PHENOTYPE ? PLNK_PED_CTRL_PHENOTYPE : PLNK_PED_CASE_PHENOTYPE);

			for (j = 0; j < (int)vvcData[0].size(); j++) {
				fp << DELIMITER3;
				if (vvcData[i][j] == ME_ALLELE_A1 || vvcData[i][j] == ME_ALLELE_A)
				{
					fp << PLNK_PED_A;
				}
				else if (vvcData[i][j] == ME_ALLELE_a)
				{
					fp << PLNK_PED_a;
				}
				else{
					fp << PLNK_PED_MISSING_ALLELE2;	//missing
				}			
			}
			fp << endl;

			cout << '\t' << i << " ...\r";
		}
		fp.close();
		fp.clear();

		cout << "\nThe PED file saved as " << strPed << endl;
		clsParas->fpLog << "The PED file saved as " << strPed << endl;

		//生成map文件
		openStreamFile(fp, strMap.c_str(), ios::out);
		
		for (i = 0; i < (int)vvcData[0].size() / 2; i++) {
			fp << clsParas->sChrNo	//染色体号
				<< " SNP" << i + 1	//SNP ID
				<< " 0 0" << endl;	//Genetic distance, Base-pair position

			cout << '\t' << i << " ...\r";
		}
		fp.close();
		fp.clear();

		cout << "\nThe MAP file saved as " << strMap << endl;
		clsParas->fpLog << "The MAP file saved as " << strMap << endl;

	}

	/********************************************
	* PLINK二进制格式转ME格式
	* sData = Plink二进制格式文件内容
	* fn = 输出文件名
	*********************************************
	ME格式(每行一个个体)：
	No.	Case/Control	Allele0	Allele1	Allele0 …
	1		1 			1 		1 		1 	...
	2    	2 			1 		1 		2 	...
	第1列：样本序号
	第2列：1=control 2=case
	第3列以后每两列组成一个SNP：0/0和1/1=AA、1/2和2/1=Aa、2/2=aa（本程序定义missing = -1）
	*********************************************/
	void Bed2ME(InData *sData, string fn)
	{
		int		i, j;
		vChar	vc;
		fstream	fp;

		/**************test*******************
		vvChar vvcsamp, vvcsnp;
		char	c;

		for (j = 0; j < (int)sData->vcPhenotypes.size(); j++) {
			vc.clear();
			getSample4Bin(sData, vc, j);	//读取的vc已是ME格式
			vvcsamp.push_back(vc);
		}
		
		for (j = 0; j < (int)sData->vvuSNP.size(); j++) {
			vc.clear();
			getSNP4Bin(sData, vc, j);	//读取的vc已是BEAM格式
			vvcsnp.push_back(vc);
		}

		for (i = 0; i < (int)vvcsamp.size(); i++){
			for (j = 0; j < (int)vvcsnp.size(); j++){
				if (vvcsamp[i][2 * j] == ME_ALLELE_A && vvcsamp[i][2 * j + 1] == ME_ALLELE_A) c = BEAM_ALLELE_AA;
				else if(vvcsamp[i][2 * j] == ME_ALLELE_A && vvcsamp[i][2 * j + 1] == ME_ALLELE_a) c = BEAM_ALLELE_Aa_aA;
				else if (vvcsamp[i][2 * j] == ME_ALLELE_a && vvcsamp[i][2 * j + 1] == ME_ALLELE_a) c = BEAM_ALLELE_aa;
				else c = MISSING_ALLELE_CHR;

				if (c != vvcsnp[j][i]){
					cout << ",sample " << i << ",snp " << j;
				}
			}
		}

		return;
		/*************************************/

		openStreamFile(fp, fn.c_str(), ios::out);

		for (j = 0; j < (int)sData->vcPhenotypes.size(); j++) {
			getSample4Bin(sData, vc, j);	//读取的vc已是ME格式

			if(vc.empty()) continue;

			fp << j + 1 << DELIMITER3		// No.
				<< (sData->vcPhenotypes[j] == PLNK_PED_CTRL_PHENOTYPE ? ME_CTRL_PHENOTYPE : ME_CASE_PHENOTYPE);

			for (i = 0; i < (int)vc.size(); i++) {
				fp << DELIMITER3;
				if (vc[i] == MISSING_ALLELE_CHR){
					fp << ME_ALLELE_MISSING_NUM;
				}
				else{
					fp << vc[i];
				}
			}
			fp << endl;

			cout << '\t' << j << " ...\r";
		}
		fp.close();
		fp.clear();

		cout << "\nThe ME file saved as " << fn << endl;
	}

	/********************************************
	* PLINK ped文本格式转ME格式
	* vvcPed = 基因型矩阵（样本数行 * 2SNP列），要求已归一化
	* vsPed6 = PED文件的前6列（空格分隔各列）
	* clsParas = 参数类指针
	
	PLINK ped文本格式（PED文件, N-missing）(每行一个个体)：
	1	1	0	0	1	1	A	A	G	T
	2	1	0	0	1	1	A	C	T	G
	3	1	0	0	1	1	C	C	G	G
	4	1	0	0	1	2	A	C	T	T
	5	1	0	0	1	2	C	C	G	T
	6	1	0	0	1	2	C	C	T	T
	前6列(前4列可多个字符组成)：
	Family ID
	Individual ID
	Paternal ID
	Maternal ID
	Sex (1=male; 2=female; other=unknown)
	Phenotype (1=unaffect; 2=affect)

	ME格式(每行一个个体)：
	No.	Case/Control	Allele0	Allele1	Allele0 …
	1		1 			1 		1 		1 	...
	2    	2 			1 		1 		2 	...
	第1列：样本序号
	第2列：1=control 2=case
	第3列以后每两列组成一个SNP：0/0和1/1=AA、1/2和2/1=Aa、2/2=aa（本程序定义missing = -1）
	******************************************************/
	void Ped2ME(vvChar& vvcPed, vString& vsPed6, parameters *clsParas)
	{
		string	strME;
		int	i, j, k;
		fstream	fp;
		Point	lt, rb;

		if (clsParas->bSwap) {		// 交换矩形（lt, rb)间的等位基因数相同的major和minor alleles
			lt.x = 0; lt.y = 0;
			rb.x = vvcPed[0].size() - 1; rb.y = vvcPed.size() - 1;
			if (!swapAllelsInColDouble(vvcPed, &lt, &rb)){
				fetalError("The number of columns of SNPs is not even.", clsParas);
			}
		}

		//生成ME文件名
		strME = addExt(clsParas->sOutputFilename, ".me");

		//生成ME文件
		openStreamFile(fp, strME.c_str(), ios::out);
		// 输入数据已归一化
		for (i = 0; i < (int)vsPed6.size(); i++) {
			k = 0;
			for (j = 1; j < (int)vsPed6[i].size(); j++){	// find phenotype posi.
				if (vsPed6[i][j] == DELIMITER3) k++;

				if (k == PLNK_PED_PHENOTYPE_COL) break;
			}

			fp << i + 1 << DELIMITER3	// No.
				<< (vsPed6[i][++j] == PLNK_PED_CTRL_PHENOTYPE ? ME_CTRL_PHENOTYPE : ME_CASE_PHENOTYPE);	// Phenotype

			for (j = 0; j < (int)vvcPed[0].size(); j++) {
				fp << DELIMITER3;
				if (vvcPed[i][j] == PLNK_PED_A) {
					fp << ME_ALLELE_A;
				}
				else if (vvcPed[i][j] == PLNK_PED_a) {
					fp << ME_ALLELE_a;
				}
				else{
					fp << ME_ALLELE_MISSING_NUM;						//missing
				}
			}
			fp << endl;

			cout << '\t' << i << " ...\r";
		}
		fp.close();
		fp.clear();

		cout << "\nThe ME file saved as " << strME << endl;
	}


	/********************************************
	* 转换BEAM格式文本文件为PLINK ped文本格式
	* vvsBEAM3 = （输出）文件中的前3列内容（字串矩阵）
	* vvcData = （输出）文件中的第4列及以后的数据（字符矩阵）
	* clsParas = 参数类指针
	*********************************************
	BEAM格式：
	ID	Chr  Pos		1 1 0 1 0 1 0 1 …
	rs0	chr1 738547		2 2 1 2 0 0 0 0 …
	rs1	chr1 5597094	0 1 0 0 2 2 0 0 …
	rs2	chrX 9424115	0 2 2 0 0 0 0 0 …
	rs3	chrY 13879818	0 0 0 0 0 2 2 0 …
	第1行第4列以后：case/control，0-control；1-case
	第2行及以后行的第4列以后：每行一个SNP：0-Aa 1-aa 2-AA <0-missing
	前3列：Posi
	前4列用TAB分隔，以后的列用空格分隔
	******************************************************
	PLINK ped文本格式（PED文件, N-missing）(每行一个个体)：
	1	1	0	0	1	1	A	A	G	T
	2	1	0	0	1	1	A	C	T	G
	3	1	0	0	1	1	C	C	G	G
	4	1	0	0	1	2	A	C	T	T
	5	1	0	0	1	2	C	C	G	T
	6	1	0	0	1	2	C	C	T	T
	前6列(前4列可多个字符组成)：
	Family ID
	Individual ID
	Paternal ID
	Maternal ID
	Sex (1=male; 2=female; other=unknown)
	Phenotype (1=unaffect; 2=affect)

	PLINK ped文本格式（MAP文件）：
	1 snp1 0 1
	1 snp2 0 2
	各列含义：
	chromosome (1-22, X, Y or 0 if unplaced)
	rs# or snp identifier
	Genetic distance (morgans)
	Base-pair position (bp units)
	*******************************************************/
	void BEAM2Ped(vvString& vvsBEAM3, vvChar& vvcData, coPLINK::parameters *clsParas)
	{
		CRandomMersenne crnd(clsParas->uRndSeed);

		string	strPed, strMap, sTmp;
		int	i, j;
		fstream	fp;
		char	cs[127];
		Point	lt, rb;

		/***************************debug **************
		fstream	ff;
		openStreamFile(ff, "rew.txt", ios::out);
		
		for (i = 0; i < vvsS3.size(); i++){
			for (j = 0; j < 3; j++)	ff << vvsS3[i][j] << DELIMITER2;
			for (j = 0; j < vviData[i].size() - 1; j++) ff << vviData[i][j] << DELIMITER3;
			ff << vviData[i][j] << endl;
		}
		ff.close();
		ff.clear();
		/****************************************************/

		//生成Plink文件名
		strPed = getFn(clsParas->sOutputFilename, ".ped");
		strMap = getFn(clsParas->sOutputFilename, ".map");

		//生成ped文件
		openStreamFile(fp, strPed.c_str(), ios::out);
		lt.x = 0; lt.y = 1;
		rb.x = vvcData[0].size() - 1; rb.y = vvcData.size() - 1;
		if (clsParas->bSwap) swapAllelsInRowSingle(vvcData, &lt, &rb, BEAM_ALLELE_AA, BEAM_ALLELE_aa);
		/*
		for(i = 0; i < vviData[0].size(); i++) {	//vviData[0].size() = 个体数
			fp << "1 "						//family ID
				<< i + 1					//individual ID
				<< " 0 0 "					//paternal ID, maternal ID
				<< (int)crnd.IRandom(1, 2)	//sex。随机生成
				<< ' '
				<< (vviData[0][i] == C2I(BEAM_CTRL_PHENOTYPE) ? PLNK_PED_CTRL_PHENOTYPE : PLNK_PED_CASE_PHENOTYPE)//phenotype 
				<< DELIMITER3;
			for(j = 1; j < vviData.size() - 1; j++) {		//vviData.size() - 1 = SNP个数(第1行是case/control)
				switch (vviData[j][i]) {
				case BEAM_ALLELE_Aa_aA:
					fp << "D d ";
					break;
				case BEAM_ALLELE_aa:
					fp << "d d ";
					break;
				case BEAM_ALLELE_AA:
					fp << "D D ";
					break;
				default:
					fp << "N N ";	
					break;
				}
			}
			switch (vviData[j][i]) {
			case BEAM_ALLELE_Aa_aA:
				fp << "D d" << endl;
				break;
			case BEAM_ALLELE_aa:
				fp << "d d" << endl;
				break;
			case BEAM_ALLELE_AA:
				fp << "D D" << endl;
				break;
			default:
				fp << "N N" << endl;
				break;
			}
		}
		*/
		// 以上写法，在大文件时会出错（奇怪？？？）。按以下注释部分写，曾经正常过，但修正了部分其它函数（与本函数无关）后又不行了
		// 最终按以下修改后可行，估计是switch(char)的问题
		for (i = 0; i < (int)vvcData[0].size(); i++) {	//vviData[0].size() = 个体数
			//fp << "1 "						//family ID
			//	<< i + 1					//individual ID
			//	<< " 0 0 "					//paternal ID, maternal ID
			//	<< (int)crnd.IRandom(1, 2)	//sex。随机生成
			//	<< ' '
			//	<< (vvcData[0][i] == BEAM_CTRL_PHENOTYPE ? PLNK_PED_CTRL_PHENOTYPE : PLNK_PED_CASE_PHENOTYPE)//phenotype 
			//	<< DELIMITER3;
			sprintf(cs, "1 %d 0 0 %d %c", i + 1, (int)crnd.IRandom(1, 2), (vvcData[0][i] == BEAM_CTRL_PHENOTYPE ? PLNK_PED_CTRL_PHENOTYPE : PLNK_PED_CASE_PHENOTYPE));
			sTmp = cs;
			for (j = 1; j < (int)vvcData.size(); j++) {		//vviData.size() - 1 = SNP个数(第1行是case/control)
				/*switch (vvcData[j][i]) {
				case BEAM_ALLELE_Aa_aA:
					sTmp += "D d ";
					break;
				case BEAM_ALLELE_aa:
					sTmp += "d d ";
					break;
				case BEAM_ALLELE_AA:
					sTmp += "D D ";
					break;
				default:
					sTmp += "N N ";
					break;
				}*/
				if (vvcData[j][i] == BEAM_ALLELE_Aa_aA){ 
					sTmp += DELIMITER3;
					sTmp += PLNK_PED_Aa_aA;
				}
				else if (vvcData[j][i] == BEAM_ALLELE_aa){ sTmp += " d d"; }
				else if (vvcData[j][i] == BEAM_ALLELE_AA){ sTmp += " D D"; }
				else{ sTmp += " N N"; }
			}
			fp << sTmp << endl;
			cout << '\t' << i << " ...\r";
		}
		fp.close();
		fp.clear();

		cout << "\nThe PED file saved as " << strPed << endl;
		clsParas->fpLog << "The PED file saved as " << strPed << endl;

		//生成map文件
		openStreamFile(fp, strMap.c_str(), ios::out);

		for (i = 1; i < (int)vvcData.size(); i++) {	//第0行是表头
			fp << vvsBEAM3[i][1] << DELIMITER3 << vvsBEAM3[i][0] << " 0 " << vvsBEAM3[i][2] << endl;	//染色体号, SNP ID, 遗传距离, SNP position
			cout << '\t' << i << " ...\r";
		}
		fp.close();
		fp.clear();

		cout << "\nThe MAP file saved as " << strMap << endl;
		clsParas->fpLog << "The MAP file saved as " << strMap << endl;
	}

	/********************************************
	* 转换GEO格式文本文件为PLINK ped文本格式
	* vvcGeo = （输入）GEO文件字符矩阵
	* vvsMAP = （输入）MAP文件字串矩阵
	* clsParas = 参数类指针
	*************** geo格式：**********************************
	geo文件：
	1,1,0,1,0,1,0,1,…
	2,2,1,2,0,0,0,0,…
	0,1,0,0,2,2,0,0,…
	0,2,2,0,0,0,0,0,…
	0,0,0,0,0,2,2,0,…
	第1行：case/control，0-control；1-case
	第2行及以后行：每行一个SNP：0-Aa 1-aa 2-AA <0-missing
	本质上是BEAM格式去除前三列并用逗号分隔。
	map文件：
	与geo文件对应的SNP信息：
	第一行为标题行：Affymetrix ID,Target Description,Gene Title,Gene Symbol
	第一列：base-pair Pos.；第二列：genetic distance；第三列：rs#或chr No.；第四列：SNP ID
	其余行是内容
	******************************************************
	PLINK ped文本格式（PED文件, N-missing）(每行一个个体)：
	1	1	0	0	1	1	A	A	G	T
	2	1	0	0	1	1	A	C	T	G
	3	1	0	0	1	1	C	C	G	G
	4	1	0	0	1	2	A	C	T	T
	5	1	0	0	1	2	C	C	G	T
	6	1	0	0	1	2	C	C	T	T
	前6列(前4列可多个字符组成)：
	Family ID
	Individual ID
	Paternal ID
	Maternal ID
	Sex (1=male; 2=female; other=unknown)
	Phenotype (1=unaffect; 2=affect)

	PLINK ped文本格式（MAP文件）：
	1 snp1 0 1
	1 snp2 0 2
	各列含义：
	chromosome (1-22, X, Y or 0 if unplaced)
	rs# or snp identifier
	Genetic distance (morgans)
	Base-pair position (bp units)
	*******************************************************/
	void Geo2Ped(vvChar &vvcGeo, vvString &vvsMAP, coPLINK::parameters *clsParas)
	{
		CRandomMersenne crnd(clsParas->uRndSeed);

		string	strPed, strMap;
		int		i, j;
		fstream	fp;
		Point	lt, rb;

		//生成Plink文件名
		strPed = getFn(clsParas->sOutputFilename, ".ped", true);
		strMap = getFn(clsParas->sOutputFilename, ".map", true);

		//生成ped文件
		openStreamFile(fp, strPed.c_str(), ios::out);
		lt.x = 0; lt.y = 1;
		rb.x = vvcGeo[0].size() - 1; rb.y = vvcGeo.size() - 1;
		if (clsParas->bSwap) swapAllelsInRowSingle(vvcGeo, &lt, &rb, BEAM_ALLELE_AA, BEAM_ALLELE_aa);
		
		for (i = 0; i < (int)vvcGeo[0].size(); i++) {	//vviData[0].size() = 个体数
			fp << "1 "		// family ID
				<< i + 1	// individual ID
				<< " 0 0 "	// paternal and maternal ID
				<< (int)crnd.IRandom(1, 2) << DELIMITER3	// sex
				<< (vvcGeo[0][i] == BEAM_CTRL_PHENOTYPE ? PLNK_PED_CTRL_PHENOTYPE : PLNK_PED_CASE_PHENOTYPE);	// phenotype

			for (j = 1; j < (int)vvcGeo.size(); j++) {		//vviData.size() - 1 = SNP个数(第1行是case/control)
				fp << DELIMITER3;

				if (vvcGeo[j][i] == BEAM_ALLELE_Aa_aA){ fp << PLNK_PED_Aa_aA; }
				else if (vvcGeo[j][i] == BEAM_ALLELE_aa){ fp << PLNK_PED_a << DELIMITER3 << PLNK_PED_a; }
				else if (vvcGeo[j][i] == BEAM_ALLELE_AA){ fp << PLNK_PED_A << DELIMITER3 << PLNK_PED_A; }
				else{ fp << PLNK_PED_MISSING_ALLELE2 << DELIMITER3 << PLNK_PED_MISSING_ALLELE2; }
			}
			fp << endl;

			cout << '\t' << i << " ...\r";
		}
		fp.close();
		fp.clear();

		cout << "\nThe PED file saved as " << strPed << endl;
		clsParas->fpLog << "The PED file saved as " << strPed << endl;

		//生成map文件
		openStreamFile(fp, strMap.c_str(), ios::out);

		for (i = 1; i < (int)vvsMAP.size(); i++) {	// first row is tittle
			fp << vvsMAP[i][2] << DELIMITER3 << vvsMAP[i][3] << DELIMITER3 << vvsMAP[i][1] << DELIMITER3 << vvsMAP[i][0] << endl;	//染色体号, SNP ID, 遗传距离, SNP position
			cout << '\t' << i << " ...\r";
		}
		fp.close();
		fp.clear();

		cout << "\nThe MAP file saved as " << strMap << endl;
		clsParas->fpLog << "The MAP file saved as " << strMap << endl;
	}

	/********************************************
	* 转换BEAM格式文本文件为BOOST文本格式
	* vvsBEAM3 = （输出）文件中的前3列内容（字串矩阵）
	* vvcData = （输出）文件中的第4列及以后的数据（字符矩阵）
	* clsParas = 参数类指针
	*********************************************
	BEAM格式（除第一行外，每行一个SNP）：
	ID	Chr  Pos		1 1 0 1 0 1 0 1 …
	rs0	chr1 738547		2 2 1 2 0 0 0 0 …
	rs1	chr1 5597094	0 1 0 0 2 2 0 0 …
	rs2	chrX 9424115	0 2 2 0 0 0 0 0 …
	rs3	chrY 13879818	0 0 0 0 0 2 2 0 …
	第1行第4列以后：case/control，0-control；1-case
	第2行及以后行的第4列开始：每行一个SNP：0-Aa 1-aa 2-AA <0-missing
	前3列：SNP Posi.
	*********************************************
	BOOST格式(每行一个个体)：
	1 2 2 0 0 0 0 2 2 1 2 0 2 2 0 1 …
	0 1 2 0 1 0 0 2 2 0 2 0 1 2 2 1 …
	0 2 1 0 0 0 1 0 2 0 2 1 1 2 0 2 …
	1 2 1 1 1 0 1 0 2 1 2 0 2 2 0 1 …
	第1列：0=control、1=case
	第2列以后（次等位基因个数）：0 = AA, 1 = Aa/aA, 2 = aa, -1 = missing
	*******************************************************/
	void BEAM2BOOST(vvString& vvsBEAM3, vvChar& vvcData, coPLINK::parameters *clsParas)
	{
		string	strBOOST, sTmp;
		int	i, j, uSampleCnt;
		fstream	fp;
		Point	lt, rb;

		//生成文件名
		strBOOST = getFn(clsParas->sOutputFilename, ".txt");
		openStreamFile(fp, strBOOST.c_str(), ios::out);
		lt.x = 0; rb.x = vvcData[0].size();
		lt.y = 1; rb.y = vvcData.size() - 1;
		if (clsParas->bSwap) swapAllelsInRowSingle(vvcData, &lt, &rb, BEAM_ALLELE_AA, BEAM_ALLELE_aa);
		uSampleCnt = vvcData[0].size();	//vviData[0].size() = 个体数
		for (i = 0; i < uSampleCnt; i++) {
			sTmp = "";
			sTmp += vvcData[0][i] == BEAM_CTRL_PHENOTYPE ? BOOST_CTRL_PHENOTYPE : BOOST_CASE_PHENOTYPE;	// 表型
			
			for (j = 1; j < (int)vvcData.size(); j++) {		//vviData.size() - 1 = SNP个数(第1行是case/control)
				sTmp += DELIMITER3;
				if (vvcData[j][i] == BEAM_ALLELE_Aa_aA) {
					sTmp += BOOST_Aa_aA;
				}
				else if (vvcData[j][i] == BEAM_ALLELE_aa) {
					sTmp += BOOST_aa;
				}
				else if (vvcData[j][i] == BEAM_ALLELE_AA) {
					sTmp += BOOST_AA;
				}
				else{
					sTmp += BOOST_MISSING_ALLELE_STR;
				}
			}
			fp << sTmp << endl;
			cout << '\t' << i << " ...\r";
		}
		fp.close();
		fp.clear();

		cout << "\nThe BOOST file saved as " << strBOOST << ".txt" << endl;
		clsParas->fpLog << "The BOOST file saved as " << strBOOST << endl;
	}

	/********************************************
	* 转换MDR格式文本文件为BOOST文本格式
	* vvcData = dat文件内容（字符矩阵，第一列为表型）
	* clsParas = 参数类
	*********************************************
	MDR格式：
	X1	X2 …	X20	Class
	0	1 …	1	1
	0	1 …	0	0
	1	1 …	2	1
	0	1 …	1	0
	所有字符用tab分隔；
	第1到n-1列：每列为一个SNP；
	第n列：Class：0-control, 1-case；
	基因型数据：0-AA, 1-Aa, 2-aa, -1 = missing；
	第1行为表头，其余每行为一个个体。
	******* 以上是早期自定义这样的格式（也许当时的资料这样描述），以下是2020.3.8查找到的格式 ************
	The data file is a required document with a default of .dat as its extension, which looks like this:
	0	1 	…	1	1
	0	1 	…	0	0
	1	1 	…	2	1
	0	1 	…	1	0
		* The delimiter in a MDR file is a TAB.
		* The first column: Phenotypes. Here we use 0 - control, 1 - case.
		* The additional columns: Genotypes. Each column is a SNP.
	These values range from 0 to the MAXLOCIVALUE defined by MDR confiures.
	Here we use 0 - AA, 1 - Aa or aA, 2 - aa, -1 - missing.
		* Each row is a separate individual.
	Except for the .dat file, a .map file may be included as an optional.
	It allows names to be specified for the variables in the data file.
	Usually, the first column is the chromosome number, second column the name and
	third column the base-pair position of the SNP.
	程序按新格式作了修改
	*********************************************
	BOOST格式(每行一个个体)：
	1 2 2 0 0 0 0 2 2 1 2 0 2 2 0 1 …
	0 1 2 0 1 0 0 2 2 0 2 0 1 2 2 1 …
	0 2 1 0 0 0 1 0 2 0 2 1 1 2 0 2 …
	1 2 1 1 1 0 1 0 2 1 2 0 2 2 0 1 …
	第1列：0=control、1=case
	第2列以后（次等位基因个数）每列一个SNP：0 = AA, 1 = Aa/aA, 2 = aa, -1 = missing
	*******************************************************/
	void MDR2BOOST(vvChar& vvcData, coPLINK::parameters *clsParas)
	{
		string	strBOOST, sTmp;
		int		i, j, uSNPcnt;
		fstream	fp;
		Point	lt, rb;

		//生成文件名
		strBOOST = getFn(clsParas->sOutputFilename, ".txt");
		openStreamFile(fp, strBOOST.c_str(), ios::out);

		if (clsParas->bSwap) {				// 交换矩形（lt, rb)间的等位基因数相同的major和minor alleles
			lt.x = 1; lt.y = 0;
			rb.x = vvcData[0].size() - 1; rb.y = vvcData.size() - 1;
			swapAllelsInColSingle(vvcData, &lt, &rb, MDR_AA, MDR_aa);
		}

		uSNPcnt = vvcData[0].size();	// SNP数+1（第一列是表型）
		for (i = 0; i < (int)vvcData.size(); i++) {	// each row
			sTmp = "";
			sTmp += vvcData[i][0] == MDR_CASE_PHENOTYPE ? BOOST_CASE_PHENOTYPE : BOOST_CTRL_PHENOTYPE;	// 表型
			
			for (j = 1; j < uSNPcnt; j++) {		// each col.
				sTmp += DELIMITER3;
				if (vvcData[i][j] == MDR_Aa_aA){ sTmp += BOOST_Aa_aA; }
				else if (vvcData[i][j] == MDR_aa){ sTmp += BOOST_aa; }
				else if (vvcData[i][j] == MDR_AA){ sTmp += BOOST_AA; }
				else{ sTmp += BOOST_MISSING_ALLELE_STR; }
			}
			fp << sTmp << endl;

			cout << '\t' << i << " ...\r";
		}
		fp.close();
		fp.clear();

		cout << "\nThe BOOST file saved as " << strBOOST << endl;
		clsParas->fpLog << "The BOOST file saved as " << strBOOST << endl;
	}

	/********************************************
	* 转换MDR格式文本文件为BOOST文本格式
	* vcPhenotypes = 表型列向量
	* vvcData = 除一、二列外的文件内容（基因型矩阵，字符矩阵）
	* clsParas = 参数类
	*********************************************
	ME格式(每行一个个体)：
	No.	Case/Control	Allele0	Allele1	Allele0 …
	1		1 				1 		1 		1 	...
	2    	2 				1 		1 		2 	...
	第1列：样本序号
	第2列：1=control 2=case
	第3列以后每两列组成一个SNP：0/0和1/1=AA、1/2和2/1=Aa、2/2=aa（本程序定义missing = -1）
	*********************************************
	BOOST格式(每行一个个体)：
	1 2 2 0 0 0 0 2 2 1 2 0 2 2 0 1 …
	0 1 2 0 1 0 0 2 2 0 2 0 1 2 2 1 …
	0 2 1 0 0 0 1 0 2 0 2 1 1 2 0 2 …
	1 2 1 1 1 0 1 0 2 1 2 0 2 2 0 1 …
	第1列：0=control、1=case
	第2列以后（次等位基因个数）每列一个SNP：0 = AA, 1 = Aa/aA, 2 = aa, -1 = missing
	*******************************************************/
	void ME2BOOST(vChar &vcPhenotypes, vvChar& vvcData, coPLINK::parameters *clsParas)
	{
		string	strBOOST;
		int		i, j;
		fstream	fp;

		//生成文件名
		strBOOST = getFn(clsParas->sOutputFilename, ".txt");
		openStreamFile(fp, strBOOST.c_str(), ios::out);

		for (i = 0; i < (int)vvcData.size(); i++) {			// each row
			fp << (vcPhenotypes[i] == ME_CASE_PHENOTYPE ? BOOST_CASE_PHENOTYPE : BOOST_CTRL_PHENOTYPE);	// 表型
			
			for (j = 0; j < (int)vvcData[0].size(); j += 2) {	// each col.
				fp << DELIMITER3;
				if (((vvcData[i][j] == ME_ALLELE_A || vvcData[i][j] == ME_ALLELE_A1) && vvcData[i][j + 1] == ME_ALLELE_a)
					|| (vvcData[i][j] == ME_ALLELE_a && (vvcData[i][j + 1] == ME_ALLELE_A || vvcData[i][j + 1] == ME_ALLELE_A1)))
				{
					fp << BOOST_Aa_aA;
				}
				else if (vvcData[i][j] == ME_ALLELE_a && vvcData[i][j + 1] == ME_ALLELE_a){
					fp << BOOST_aa;
				}
				else if ((vvcData[i][j] == ME_ALLELE_A && vvcData[i][j + 1] == ME_ALLELE_A) ||
					(vvcData[i][j] == ME_ALLELE_A1 && vvcData[i][j + 1] == ME_ALLELE_A1))
				{
					fp << BOOST_AA;
				}
				else{
					fp << BOOST_MISSING_ALLELE_STR;
				}
			}
			fp << endl;

			cout << '\t' << i << " ...\r";
		}
		fp.close();
		fp.clear();

		cout << "\nThe BOOST file saved as " << strBOOST << endl;
		clsParas->fpLog << "The BOOST file saved as " << strBOOST << endl;
	}

	/********************************************
	* PLINK二进制格式转BEAM格式
	* sData = Plink二进制格式文件内容
	* clsParas = pointer of class
	* BEAM前4列用TAB分隔，以后的列用空格分隔
	*********************************************/
	void Bed2BEAM(InData *sData, parameters *clsParas)
	{
		int		i, j, uLen;
		vChar		vc;
		fstream		fp;
		string		strBEAM;

		//生成BEAM文件名
		strBEAM = getFn(clsParas->sOutputFilename, ".txt");

		fp.open(strBEAM.c_str(), ios_base::out);
		if(!fp.good()) {
			fetalError("Write file " + strBEAM + " failed.", clsParas);
		}
		//输出第一行
		fp << "ID\tChr\tPos\t";

		uLen = sData->vcPhenotypes.size();
		for(i = 0; i < uLen; i++) {
			j = sData->vcPhenotypes[i] == PLNK_PED_CTRL_PHENOTYPE ? C2I(BEAM_CTRL_PHENOTYPE) : C2I(BEAM_CASE_PHENOTYPE);
			if(i < uLen - 1) fp << j << DELIMITER3;
			else fp << j << endl;
		}

		for (j = 0; j < (int)sData->vvuSNP.size(); j++) {
			getSNP4Bin(sData, vc, j);	//读取的vc已是BEAM格式

			if(vc.empty()) continue;

			if (sData->vuChrNo[j] == CHR_X_CODE) {
				fp << sData->vsSNPlabels[j] << "\tChrX\t" << sData->vuPos[j] << DELIMITER2;
			}
			else if (sData->vuChrNo[j] == CHR_Y_CODE){
				fp << sData->vsSNPlabels[j] << "\tChrY\t" << sData->vuPos[j] << DELIMITER2;
			}
			else if (sData->vuChrNo[j] == CHR_NONE_CODE){
				fp << sData->vsSNPlabels[j] << "\tChr0\t" << sData->vuPos[j] << DELIMITER2;
			}
			else{
				fp << sData->vsSNPlabels[j] << "\tChr" << sData->vuChrNo[j] << DELIMITER2 << sData->vuPos[j] << DELIMITER2;
			}

			uLen = vc.size();
			for(i = 0; i < uLen - 1; i++) {
				if (vc[i] == MISSING_ALLELE_CHR){
					fp << BEAM_MISSING_ALLELE_STR << DELIMITER3;
				}
				else{
					fp << vc[i] << DELIMITER3;
				}
			}

			if (vc[i] == MISSING_ALLELE_CHR){
				fp << BEAM_MISSING_ALLELE_STR << endl;
			}
			else{
				fp << vc[i] << endl;
			}

			cout << '\t' << j << " ...\r";
		}
		fp.close();
		fp.clear();

		cout << "\nThe BEAM file saved as " << strBEAM << endl;
		clsParas->fpLog << "The BEAM file saved as " << strBEAM << endl;
	}

	/********************************************
	* PLINK二进制Bed格式转Tped格式
	* sData = Plink二进制格式文件内容
	* clsParas  = 参数类
	*********************************************
	PLINK TPED文件：
	每行一个SNP
	如：(N-missing)
	1 snp1 0 5000650 A A A C C C A C C C C C
	1 snp2 0 5000830 G T G T G G T T G T T T
	...
	前4列即是ped格式中的map文件所包含的4列(也是bim文件的前4列）:
	map文件各列含义：
	1 - chromosome (1-22, X, Y or 0 if unplaced)
	2 - rs# or snp identifier
	3 - Genetic distance (morgans)
	4 - Base-pair position (bp units)
	从第5列起为samples的基因型（samples的信息由tfam文件说明）

	PLINK TFAM文件：
	每行一个sample
	如：
	1 1 0 0 1 1
	2 1 0 0 1 1
	3 1 0 0 1 1
	4 1 0 0 1 2
	5 1 0 0 1 2
	6 1 0 0 1 2
	...
	各列含义（即ped文件的前6列）：
	1 - 家系ID
	2 - sample ID
	3 - 父亲ID
	4 - 母亲ID
	5 - 性别（1=男、2=女、0=未知）
	6 - 表型（1=对照、2=疾病、0=未知）
	*********************************************/
	void Bed2Tped(InData *sData, coPLINK::parameters *clsParas)
	{
		int		i, j, k;
		vChar		vc;
		fstream		fp, fpIn;
		string		strTmp;
		char		c, c1, *cs;

		//生成文件名
		strTmp = getFn(clsParas->sOutputFilename, ".tfam", true);

		fp.open(strTmp.c_str(), ios_base::out);
		if (!fp.good()) {
			fetalError("Write file " + strTmp + " failed.", clsParas);
		}

		strTmp = getFn(clsParas->sInputFilename, ".fam", true);

		fpIn.open(strTmp.c_str(), ios_base::in);
		if (!fpIn.good()) {
			fetalError("Source file " + strTmp + " open failed.", clsParas);
		}

		fp << fpIn.rdbuf();		//复制生成tfam文件
		
		fp.close();
		fpIn.close();
		fp.clear();
		fpIn.clear();

		cout << "\tSave " << getFn(clsParas->sOutputFilename, ".tfam", true) << " OK." << endl;

		//生成文件名
		strTmp = getFn(clsParas->sOutputFilename, ".tped", true);

		fp.open(strTmp.c_str(), ios_base::out);
		if (!fp.good()) {
			fetalError("Write file " + strTmp + " failed.", clsParas);
		}

		/**************************************
		PLINK bim文件格式。
		bim文件是ped格式中的map文件的扩展，与上述map文件对应的bim文件：
		1	snp1	0	1	A	C
		1	snp2	0	2	G	T
		各列：
		0 - chromosome (1-22, X, Y or 0 if unplaced)
		1 - rs# or snp identifier
		2 - Genetic distance (morgans)
		3 - Base-pair position (bp units)
		4 - allele 1（minor allele）
		5 - allele 2（major allele）
		注：（1）若两个等位基因个数相同，则Plink 1.9 Beta6按字母序分别是
		minor allele和major allele,Plink 1.07把先遇到的作为minor
		allele（这里按Plink 1.9 Beta6规则编程）
		（2）若只有一种等位基因，则用0标示缺失一种并作为minor allele
		（3）不判断缺失等位基因符号（如 0、-、N等），所有符号都作为正常符号处理
		**************************************/
		strTmp = getFn(clsParas->sInputFilename, ".bim", true);

		fpIn.open(strTmp.c_str(), ios_base::in);
		if (!fpIn.good()) {
			fetalError("Source file " + strTmp + " open failed.", clsParas);
		}

		cs = new char[512];
		for (j = 0; j < (int)sData->vvuSNP.size(); j++) {
			fpIn.getline(cs, 512);
			trimRedundance(cs, true);			// 删除多余的空格及TAB（只保留一个），且TAB替换为空格
			k = charNfind(cs, DELIMITER3, 4);
			if (k == string::npos) continue;	// 不足4列

			c = cs[k + 1];						// minor allele
			c1 = cs[k + 3];						// major allele
			cs[k] = '\0';
			fp << cs;

			if (c == '0') c = c1;

			getSNP4Bin(sData, vc, j);			//读取的vc是BEAM格式
			if (vc.empty()) continue;

			for (i = 0; i < (int)vc.size(); i++) {
				fp << DELIMITER3;

				if (vc[i] == BEAM_ALLELE_Aa_aA){
					fp << c << DELIMITER3 << c1 << DELIMITER3;
				}
				else if (vc[i] == BEAM_ALLELE_aa){
					fp << c << DELIMITER3 << c << DELIMITER3;
				}
				else if (vc[i] == BEAM_ALLELE_AA){
					fp << c1 << DELIMITER3 << c1 << DELIMITER3;
				}
				else{
					fp << " N N";
				}
			}
			fp << endl;

			cout << '\t' << j << " ...\r";
		}
		fp.close();
		fp.clear();
		delete[]	cs;

		cout << "\nThe Tped files saved as " << getFn(clsParas->sOutputFilename, ".tped", true) << endl;
		clsParas->fpLog << "The Tped files saved as " << clsParas->sOutputFilename << endl;
	}

	/********************************************
	* PLINK二进制Bed格式转BOOST格式
	* sData = Plink二进制格式文件内容
	* fnOut = 输出文件名
	* bSwap = 当SNP的minor和major alleles数量相同时，是否交换两种等位基因
	*********************************************/
	void Bed2BOOST(InData *sData, string fnOut, bool bSwap)
	{
		int		i, j, m, n, uSNPcnt, uSampleCnt;
		vChar		vc;
		vvChar		vvcSNP;
		fstream		fp;
		string		strBOOST;

		// 读取SNP数据
		/**************************************
		BEAM格式：
			ID	Chr  Pos		1 1 0 1 0 1 0 1 …
			rs0	chr1 738547		2 2 1 2 0 0 0 0 …
			rs1	chr1 5597094	0 1 0 0 2 2 0 0 …
			rs2	chrX 9424115	0 2 2 0 0 0 0 0 …
			rs3	chrY 13879818	0 0 0 0 0 2 2 0 …
			第1行的第4列以后：case / control，0 - control；1 - case
			第2行及以后行的第4列以后：每行一个SNP：0 - Aa 1 - aa 2 - AA <0 - missing
			前3列：Base - pair position
		*******************************************/
		uSNPcnt = sData->vvuSNP.size();
		uSampleCnt = sData->vcPhenotypes.size();
		for (i = 0; i < uSNPcnt; i++) {
			getSNP4Bin(sData, vc, i);			//读取的vc是BEAM格式

			if (vc.empty()) continue;

			vc.resize(uSampleCnt + 1, '0');		// 增加一列用于指示对应的SNP的minor和major alleles数量是否相同
			vvcSNP.push_back(vc);
		}
		vc.clear();
		
		if (bSwap){
			// 查找各SNP两种等位基因数是否相同
			for (i = 0; i < uSNPcnt; i++) {
				m = n = 0;
				for (j = 0; j < uSampleCnt; j++){
					if (vvcSNP[i][j] == BEAM_ALLELE_aa) {
						m++;
					}

					if (vvcSNP[i][j] == BEAM_ALLELE_AA) {
						n++;
					}
				}

				if (m == n && m > 0) {
					vvcSNP[i][uSampleCnt] = '1';	// 相同
				}
			}

		}
		
		//生成文件名
		strBOOST = getFn(fnOut, ".txt", true);
		openStreamFile(fp, strBOOST.c_str(), ios::out);

		for (i = 0; i < uSampleCnt; i++){		// 逐样本
			fp << (C2I(sData->vcPhenotypes[i]) - 1) << DELIMITER3;
			for (j = 0; j < uSNPcnt; j++){
				/*switch (vvcSNP[j][i]){
				case BEAM_ALLELE_aa:
					fp << (vvcSNP[j][uSampleCnt] == '1' && bSwap ? BOOST_AA : BOOST_aa);
					break;
				case BEAM_ALLELE_AA:
					fp << (vvcSNP[j][uSampleCnt] == '1' && bSwap ? BOOST_aa : BOOST_AA);
					break;
				case BEAM_ALLELE_Aa_aA:
					fp << 1;
					break;
				default:
					fp << BOOST_MISSING_ALLELE_NUM;
				}*/
				if (vvcSNP[j][i] == BEAM_ALLELE_aa){
					fp << (vvcSNP[j][uSampleCnt] == '1' && bSwap ? BOOST_AA : BOOST_aa);
				}
				else if (vvcSNP[j][i] == BEAM_ALLELE_AA){
					fp << (vvcSNP[j][uSampleCnt] == '1' && bSwap ? BOOST_aa : BOOST_AA);
				}
				else if (vvcSNP[j][i] == BEAM_ALLELE_Aa_aA){
					fp << 1;
				}
				else{
					fp << BOOST_MISSING_ALLELE_NUM;
				}

				if (j < uSNPcnt - 1) {
					fp << DELIMITER3;
				}
			}
			fp << endl;
			cout << '\t' << i << " ...\r";
		}
		fp.close();

		cout << "\nThe BOOST file saved as " << strBOOST << endl;
	}

	/********************************************
	* PLINK ped文本格式转BEAM格式
	* vvcPed = 基因型矩阵（样本数行*2SNP列）
	* vsPed6 = PED文件的前6列
	* vvsMap = Plink的map文件内容
	* clsParas = 参数类指针
	*********************************************/
	void Ped2BEAM(vvChar& vvcPed, vString& vsPed6, vvString& vvsMap, coPLINK::parameters *clsParas)
	{
		int	uSampleCnt = vsPed6.size();
		if (uSampleCnt == 0) return;

		int		i, j, k;
		vvChar	vvcData;
		vChar	vcPhenotype(uSampleCnt);
		string	strBEAM;
		fstream	fp;

		if (clsParas->bPreprocess) {
			cout << "Preprocessing .." << endl;

			if (!chkSample4Ped(vvcPed, vsPed6, clsParas, strBEAM)){	// 需在预处理之前，其可能删除样本
				fetalError("An error is encountered while alleles missing rates of samples checking: " + strBEAM, clsParas);
			}

			if (!preprocessPed(vvcPed, vvsMap, clsParas, true, strBEAM)) {	// error
				fetalError("An error is encountered while preprocessing: " + strBEAM, clsParas);
			}

			uSampleCnt = vsPed6.size();	// 预处理后样本和SNP都可能变化
		}

		// 取表型
		for (i = 0; i < uSampleCnt; i++) {
			j = 0;
			for (k = 0; k < (int)vsPed6[i].length(); k++) {
				if (vsPed6[i][k] == clsParas->cDelimeter) {
					j++;
					if (j == PLNK_PED_PHENOTYPE_COL) break;
				}
			}
			vcPhenotype[i] = vsPed6[i][++k];	// 只取首字符
		}
		vString().swap(vsPed6);

		cout << "Saving ..." << endl;

		convertPed2BOOST(vcPhenotype, vvcPed, vvcData, clsParas->bSwap, clsParas->bNorOn);	// retruned result using MISSING_ALLELE_CHR as missing
		vChar().swap(vcPhenotype);
		vvChar().swap(vvcPed);

		//生成BEAM文件名
		strBEAM = getFn(clsParas->sOutputFilename, ".txt");

		//生成BEAM文件
		openStreamFile(fp, strBEAM.c_str(), ios::out);

		//生成第1行
		fp << "ID\tChr\tPos\t";
		uSampleCnt--;
		for (i = 0; i < uSampleCnt; i++) {
			fp << (vvcData[i][0] == BOOST_CTRL_PHENOTYPE ? BEAM_CTRL_PHENOTYPE : BEAM_CASE_PHENOTYPE) << DELIMITER3;
		}
		fp << (vvcData[i][0] == BOOST_CTRL_PHENOTYPE ? BEAM_CTRL_PHENOTYPE : BEAM_CASE_PHENOTYPE) << endl;//行末无空格

		for (i = 1; i < (int)vvcData[0].size(); i++) {	//逐列扫描
			j = i - 1;
			fp << vvsMap[j][1] << DELIMITER2		//SNP ID + tab
				<< "Chr" << vvsMap[j][0] << DELIMITER2	//chromsome ID + tab
				<< vvsMap[j][3] << DELIMITER2;		//base-pair position + tab

			for (j = 0; j < uSampleCnt; j++) {	//逐行扫描
				if (vvcData[j][i] == BOOST_AA){ fp << BEAM_ALLELE_AA; }
				else if (vvcData[j][i] == BOOST_aa){ fp << BEAM_ALLELE_aa; }
				else if (vvcData[j][i] == BOOST_Aa_aA){ fp << BEAM_ALLELE_Aa_aA; }
				else{ fp << BEAM_MISSING_ALLELE_STR; }
				
				fp << DELIMITER3;
			}
			// 最后个不要space
			if (vvcData[j][i] == BOOST_AA){ fp << BEAM_ALLELE_AA; }
			else if (vvcData[j][i] == BOOST_aa){ fp << BEAM_ALLELE_aa; }
			else if (vvcData[j][i] == BOOST_Aa_aA){ fp << BEAM_ALLELE_Aa_aA; }
			else{ fp << BEAM_MISSING_ALLELE_STR; }

			fp << endl;

			cout << '\t' << i << " ...\r";
		}
		fp.close();
		fp.clear();

		cout << "\nThe BEAM file saved as " << strBEAM << endl;
		clsParas->fpLog << "The BEAM file saved as " << strBEAM << endl;
	}

	/********************************************
	* PLINK ped文本格式转geo格式
	* vvcPed = 基因型矩阵（样本数行*2倍的SNP数列），要求已归一化
	* vsPed6 = PED文件的前6列
	* vvsMAP = map文件内容（字串矩阵）
	* clsParas = 类参数指针
	*************** geo格式：**********************************
	geo文件：
	1,1,0,1,0,1,0,1,…
	2,2,1,2,0,0,0,0,…
	0,1,0,0,2,2,0,0,…
	0,2,2,0,0,0,0,0,…
	0,0,0,0,0,2,2,0,…
	第1行：case/control，0-control；1-case
	第2行及以后行：每行一个SNP：0-Aa 1-aa 2-AA <0-missing
	本质上是BEAM格式去除前三列并用逗号分隔。
	map文件：
	与geo文件对应的SNP信息：
	第一行为标题行：Affymetrix ID,Target Description,Gene Title,Gene Symbol
	第一列：base-pair Pos.；第二列：genetic distance；第三列：rs#或chr No.；第四列：SNP ID
	其余行是内容
	***************************************************************/
	void Ped2Geo(vvChar& vvcPed, vString& vsPed6, vvString &vvsMAP, coPLINK::parameters *clsParas)
	{
		string		strGeo, strMap;
		int			i, j, k, uSampleCnt, uSNP;
		fstream		fp;
		Point		lt, rb;

		if (clsParas->bPreprocess) {
			if (!chkSample4Ped(vvcPed, vsPed6, clsParas, strMap)){	// 需在预处理之前，其可能删除样本
				fetalError("An error is encountered while alleles missing rates of samples checking: " + strMap, clsParas);
			}

			if (!preprocessPed(vvcPed, vvsMAP, clsParas, true, strMap)) {	// error
				fetalError("An error is encountered while preprocessing: " + strMap, clsParas);
			}
		}

		//检查PED文件内容与MAP内容是否匹配
		uSNP = vvcPed[0].size();
		i = uSNP / 2;				//PED文件中的SNP个数（每个SNP占2个字符位置）
		j = vvsMAP.size();			//MAP文件中的SNP个数
		if(i != j) {
			char cs[100];
			sprintf(cs, "The number of SNPs in PED file does not match to that in MAP.\nNumbers: PED = %d\tMAP = %d.", i, j);
			fetalError(cs, clsParas);
		}

		if (clsParas->bSwap) {		// 交换矩形（lt, rb)间的等位基因数相同的major和minor alleles
			lt.x = 0; lt.y = 0;
			rb.x = vvcPed[0].size() - 1; rb.y = vvcPed.size() - 1;
			if (!swapAllelsInColDouble(vvcPed, &lt, &rb)){
				fetalError("The number of columns of SNPs is not even.", clsParas);
			}
		}

		//生成geo文件名
		strGeo = getFn(clsParas->sOutputFilename, ".geo");
		//生成map文件名
		strMap = getFn(clsParas->sOutputFilename, ".map");

		//生成输出geo文件
		openStreamFile(fp, strGeo.c_str(), ios::out);

		//生成第1行 (phenotypes)
		uSampleCnt = vsPed6.size();
		for (i = 0; i < uSampleCnt; i++) {
			k = 0;
			for (j = 1; j < (int)vsPed6[i].length(); j++){
				if (vsPed6[i][j] == DELIMITER3){ k++; }

				if (k == PLNK_PED_PHENOTYPE_COL){ break; }
			}

			fp << (vsPed6[i][++j] ==  PLNK_PED_CTRL_PHENOTYPE ? BEAM_CTRL_PHENOTYPE : BEAM_CASE_PHENOTYPE);

			if (i < uSampleCnt - 1) fp << DELIMITER4;
		}
		fp << endl;
		vString().swap(vsPed6);

		for (i = 0; i < uSNP; i += 2) {	//逐SNP扫描
			// out the firs one
			if (vvcPed[0][i] == PLNK_PED_A && vvcPed[0][i + 1] == PLNK_PED_A){ fp << BEAM_ALLELE_AA; }
			else if ((vvcPed[0][i] == PLNK_PED_A && vvcPed[0][i + 1] == PLNK_PED_a)
				|| (vvcPed[0][i] == PLNK_PED_a && vvcPed[0][i + 1] == PLNK_PED_A)){
				fp << BEAM_ALLELE_Aa_aA;
			}
			else if (vvcPed[0][i] == PLNK_PED_a && vvcPed[0][i + 1] == PLNK_PED_a){ fp << BEAM_ALLELE_aa; }
			else{ fp << -1; }

			for (j = 1; j < uSampleCnt; j++) {	//逐行扫描
				fp << DELIMITER4;

				if (vvcPed[j][i] == PLNK_PED_A && vvcPed[j][i + 1] == PLNK_PED_A){ fp << BEAM_ALLELE_AA; }
				else if ((vvcPed[j][i] == PLNK_PED_A && vvcPed[j][i + 1] == PLNK_PED_a)
					|| (vvcPed[j][i] == PLNK_PED_a && vvcPed[j][i + 1] == PLNK_PED_A)){
					fp << BEAM_ALLELE_Aa_aA;
				}
				else if (vvcPed[j][i] == PLNK_PED_a && vvcPed[j][i + 1] == PLNK_PED_a){ fp << BEAM_ALLELE_aa; }
				else{ fp << -1; }
			}
			fp << endl;

			cout << '\t' << i << " ...\r";
		}
		fp.close();
		fp.clear();
		vvChar().swap(vvcPed);

		cout << "\nThe GEO file saved as " << strGeo << endl;
		clsParas->fpLog << "The GEO file saved as " << strGeo << endl;

		//生成输出Map文件
		openStreamFile(fp, strMap.c_str(), ios::out);

		//生成第1行
		fp << "Affymetrix ID,Target Description,Gene Title,Gene Symbol" << endl;
		uSNP /= 2;	// number of SNPs
		for (i = 0; i < uSNP; i++) {	//逐SNP扫描
			fp << vvsMAP[i][3] << DELIMITER4		//base-pair position
				<< vvsMAP[i][2] << DELIMITER4		// genetic distance
				<< vvsMAP[i][0] << DELIMITER4		//chromsome ID
				<< vvsMAP[i][1] << endl;					//SNP ID

			cout << '\t' << i << " ...\r";
		}
		fp.close();
		fp.clear();

		cout << "\nThe MAP file saved as " << strMap << endl;
		clsParas->fpLog << "The MAP file saved as " << strMap << endl;
	}

	/********************************************
	* PLINK ped文本格式转MDR格式
	* 用字符矩阵实现（不支持多字符组成基因型，多字符基因型只保留首字符）
	* vsMap = MAP文件内容（已删除多余分隔符）
	* vvcPed = 基因型矩阵（样本数行*2SNP列）
	* vsPed6 = PED文件的前6列
	* clsPara = 参数类
	*************************************************
	PLINK ped文本格式（PED文件, N-missing）(每行一个个体)：
	1	1	0	0	1	1	A	A	G	T
	2	1	0	0	1	1	A	C	T	G
	3	1	0	0	1	1	C	C	G	G
	4	1	0	0	1	2	A	C	T	T
	5	1	0	0	1	2	C	C	G	T
	6	1	0	0	1	2	C	C	T	T
	前6列(前4列可多个字符组成)：
	Family ID
	Individual ID
	Paternal ID
	Maternal ID
	Sex (1=male; 2=female; other=unknown)
	Phenotype (1=unaffect; 2=affect)

	PLINK ped文本格式（MAP文件）：
	1 snp1 0 1
	1 snp2 0 2
	各列含义：
	chromosome (1-22, X, Y or 0 if unplaced)
	rs# or snp identifier
	Genetic distance (morgans)
	Base-pair position (bp units)

	MDR格式：
	X1	X2 …	X20	Class
	0	1 …	1	1
	0	1 …	0	0
	1	1 …	2	1
	0	1 …	1	0
	所有字符用tab分隔；
	第1到n-1列：每列为一个SNP；
	第n列：Class：0-control, 1-case；
	基因型数据：0-AA, 1-Aa, 2-aa, -1 = missing；
	第1行为表头，其余每行为一个个体。
	******* 以上是早期自定义这样的格式（也许当时的资料这样描述），以下是2020.3.8查找到的格式 ************
	The data file is a required document with a default of .dat as its extension, which looks like this:
	0	1 	…	1	1
	0	1 	…	0	0
	1	1 	…	2	1
	0	1 	…	1	0
		* The delimiter in a MDR file is a TAB.
		* The first column: Phenotypes. Here we use 0 - control, 1 - case.
		* The additional columns: Genotypes. Each column is a SNP.
	These values range from 0 to the MAXLOCIVALUE defined by MDR confiures.
	Here we use 0 - AA, 1 - Aa or aA, 2 - aa, -1 - missing.
		* Each row is a separate individual.
	Except for the .dat file, a .map file may be included as an optional.
	It allows names to be specified for the variables in the data file.
	Usually, the first column is the chromosome number, second column the name and
	third column the base-pair position of the SNP.
	程序按新格式作了修改
	***************************************************************/
	void Ped2MDR(vvString& vvsMap, vString &vsPed6, vvChar &vvcPed, coPLINK::parameters *clsParas)
	{
		int	uSampleCnt = vsPed6.size();
		if (uSampleCnt == 0) return;

		int		i, j, k;
		vvChar	vvcData;
		vChar	vcPhenotype(uSampleCnt);
		string	strMDR;
		fstream	fp;

		if (clsParas->bPreprocess){
			if (!chkSample4Ped(vvcPed, vsPed6, clsParas, strMDR)){	// 需在预处理之前，其可能删除样本
				fetalError("An error is encountered while alleles missing rates of samples checking: " + strMDR, clsParas);
			}

			if (!preprocessPed(vvcPed, vvsMap, clsParas, true, strMDR)){
				fetalError("An error is encountered while preprocessing: " + strMDR, clsParas);
			}

			uSampleCnt = vsPed6.size();	// 预处理后样本和SNP都可能变化
		}

		// 取表型
		for (i = 0; i < uSampleCnt; i++) {
			j = 0;
			for (k = 0; k < (int)vsPed6[i].length(); k++) {
				if (vsPed6[i][k] == clsParas->cDelimeter) {
					j++;
					if (j == PLNK_PED_PHENOTYPE_COL) break;
				}
			}
			vcPhenotype[i] = vsPed6[i][++k];	// 只取首字符
		}
		vString().swap(vsPed6);

		convertPed2BOOST(vcPhenotype, vvcPed, vvcData, clsParas->bSwap, clsParas->bNorOn);	// retruned result using MISSING_ALLELE_CHR as missing
		vChar().swap(vcPhenotype);
		vvChar().swap(vvcPed);

		//生成MDR MAP文件名
		strMDR = getFn(clsParas->sOutputFilename, ".map");

		//生成MDR文件
		openStreamFile(fp, strMDR.c_str(), ios::out);

		for (i = 0; i < (int)vvsMap.size(); i++) {	
			fp << vvsMap[i][0]	<< DELIMITER2
				<< vvsMap[i][1]
				<< "\t0\t"
				<< vvsMap[i][2] << endl;

			cout << '\t' << i << " ...\r";
		}
		
		fp.close();
		fp.clear();
		vvString().swap(vvsMap);
		cout << "\n\tSave " << strMDR << " OK." << endl;

		//生成MDR DAT文件名
		strMDR = getFn(clsParas->sOutputFilename, ".dat");

		//生成MDR文件
		openStreamFile(fp, strMDR.c_str(), ios::out);
		k = 0;
		for (i = 0; i < (int)vvcData.size(); i++) {
			fp << (vvcData[i][0] == BOOST_CASE_PHENOTYPE ? MDR_CASE_PHENOTYPE : MDR_CTRL_PHENOTYPE);

			for (j = 1; j < (int)vvcData[i].size(); j++) {
				if (vvcData[i][j] == MISSING_ALLELE_CHR){ fp << DELIMITER2 << MDR_MISSING_STR; }
				else{ fp << DELIMITER2 << vvcData[i][j]; }
			}
			fp << endl;

			if (vvcData[i][0] == BOOST_CASE_PHENOTYPE) k++;	// had beed converted to BOOST

			cout << '\t' << i << " ...\r";
		}
		fp.close();
		fp.clear();
		cout << "\n\tSave " << strMDR << " OK." << endl;

		cout << "\nCase, control and SNP: " << k << ", " << vvcData.size() - k << ", " << vvcData[1].size() - 1 << endl;

		clsParas->fpLog << "The MDR file saved as " << strMDR << endl;
	}

	/********************************************
	* PLINK ped文本格式转Prettybase格式
	* 用字符矩阵实现（不支持多字符组成基因型，多字符基因型只保留首字符）
	* vsMap = MAP文件内容（已删除多余分隔符）
	* vvcPed = 基因型矩阵（样本数行*2SNP列）
	* vsPed6 = PED文件的前6列
	* clsPara = 参数类
	*************************************************
	PLINK ped文本格式（PED文件, N-missing）(每行一个个体)：
	1	1	0	0	1	1	A	A	G	T
	2	1	0	0	1	1	A	C	T	G
	3	1	0	0	1	1	C	C	G	G
	4	1	0	0	1	2	A	C	T	T
	5	1	0	0	1	2	C	C	G	T
	6	1	0	0	1	2	C	C	T	T
	前6列(前4列可多个字符组成)：
	Family ID
	Individual ID
	Paternal ID
	Maternal ID
	Sex (1=male; 2=female; other=unknown)
	Phenotype (1=unaffect; 2=affect)

	PLINK ped文本格式（MAP文件）：
	1 snp1 0 1
	1 snp2 0 2
	各列含义：
	chromosome (1-22, X, Y or 0 if unplaced)
	rs# or snp identifier
	Genetic distance (morgans)
	Base-pair position (bp units)

	Prettybase格式：
	1. 用TAB分隔
	2. 每行组成：<position> <PGA Sample ID> <Allele1> <Allele2>
	3. 一个“position”代表一个SNP
	4. 缺失用“-”或“N”表示（早期的），新的从其sample可以发现用?或N表示MISSING（这里支持三种）
	***********************************************************/
	void Ped2Pretty(vvString& vvsMap, vString &vsPed6, vvChar &vvcPed, coPLINK::parameters *clsParas)
	{
		int	uSampleCnt = vsPed6.size();
		if (uSampleCnt == 0) return;

		int		i, j, k, m;
		vvChar	vvcData;
		vString	vsSampleID(uSampleCnt);
		string	strPretty, sTmp;
		fstream	fp;
		Point	lt, rb;

		if (clsParas->bSwap) {		// 交换矩形（lt, rb)间的等位基因数相同的major和minor alleles
			lt.x = 0; lt.y = 0;
			rb.x = vvcPed[0].size() - 1; rb.y = vvcPed.size() - 1;
			if (!swapAllelsInColDouble(vvcPed, &lt, &rb)){
				fetalError("The number of columns of SNPs is not even.", clsParas);
			}
		}

		if (clsParas->bPreprocess){
			if (!chkSample4Ped(vvcPed, vsPed6, clsParas, sTmp)){	// 需在预处理之前，其可能删除样本
				fetalError("An error is encountered while alleles missing rates of samples checking: " + sTmp, clsParas);
			}

			if (!preprocessPed(vvcPed, vvsMap, clsParas, true, sTmp)){
				fetalError("An error is encountered while preprocessing: " + sTmp, clsParas);
			}

			uSampleCnt = vsPed6.size();	// 预处理后样本和SNP都可能变化
		}

		// 取individual id
		for (i = 0; i < uSampleCnt; i++) {
			j = 0;
			for (k = 0; k < (int)vsPed6[i].length(); k++) {
				if (vsPed6[i][k] == DELIMITER3) {
					j++;
					if (j == PLNK_PED_INDIVIDUAL_COL) break;
				}
			}
			for (m = ++k; m < (int)vsPed6[i].length(); m++){
				if (vsPed6[i][m] == DELIMITER3) break;
			}
			sTmp = vsPed6[i].substr(k, m - k + 1);
			vsSampleID[i] = sTmp;	
		}
		vString().swap(vsPed6);

		//生成文件名
		strPretty = getFn(clsParas->sOutputFilename, ".pretty");

		//生成Prettybase文件
		openStreamFile(fp, strPretty.c_str(), ios::out);

		for (i = 0; i < (int)vvcPed[0].size(); i += 2) {	//逐行扫描以取出SNP pos.
			for (j = 0; j < uSampleCnt; j++){
				fp << vvsMap[i / 2][3];// pos.

				if (clsParas->iMode == PRET_SeattleSNPs){
					fp << '-' << clsParas->sMemo << '-' << vvsMap[i / 2][0];
				}

				fp << DELIMITER2 << vsSampleID[j];	// sample ID

				
				if (vvcPed[j][i] == MISSING_ALLELE_CHR){ fp << DELIMITER2 << PRET_MISSING_A2; }
				else{ fp << DELIMITER2 << vvcPed[j][i]; }

				if (vvcPed[j][i + 1] == MISSING_ALLELE_CHR){ fp << DELIMITER2 << PRET_MISSING_A2 << endl; }
				else{ fp << DELIMITER2 << vvcPed[j][i + 1] << endl; }
			}

			cout << '\t' << i << " ...\r";
		}
		fp.close();
		fp.clear();

		cout << "\nThe Prettybase file saved as " << strPretty << endl;
		clsParas->fpLog << "The Prettybase file saved as " << strPretty << endl;
	}

	/********************************************
	* PLINK ped文本格式的文本文件转PLINK bed二进制格式
	* vvsMap = Plink的map文件内容
	* vvcPed = 基因型字符矩阵（样本数行*2SNP列）
	* vsPed6 = PED文件的前6列
	* clsParas = 类参数指针
	*********************************************
	PLINK ped文本格式（PED文件, N-missing）(每行一个个体)：
	1	1	0	0	1	1	A	A	G	T
	2	1	0	0	1	1	A	C	T	G
	3	1	0	0	1	1	C	C	G	G
	4	1	0	0	1	2	A	C	T	T
	5	1	0	0	1	2	C	C	G	T
	6	1	0	0	1	2	C	C	T	T
	前6列(前4列可多个字符组成)：
	Family ID
	Individual ID
	Paternal ID
	Maternal ID
	Sex (1=male; 2=female; other=unknown)
	Phenotype (1=unaffect; 2=affect)

	PLINK ped文本格式（MAP文件）：
	1 snp1 0 1
	1 snp2 0 2
	各列含义：
	chromosome (1-22, X, Y or 0 if unplaced)
	rs# or snp identifier
	Genetic distance (morgans)
	Base-pair position (bp units)

	//二进制的bed文件格式（Plink v0.99以后，之前版本无前两个字节）：
		/*若ped文件内容是：
		1 1 0 0 1  1  A A  G T
		2 1 0 0 1  1  A C  T G
		3 1 0 0 1  1  C C  G G
		4 1 0 0 1  2  A C  T T
		5 1 0 0 1  2  C C  G T
		6 1 0 0 1  2  C C  T T
		其中前6列：
		Family ID
		Individual ID
		Paternal ID, Maternal ID
		Sex (1=male; 2=female; other=unknown)
		Phenotype (1=unaffect; 2=affect)

		map文件的内容是：
		1 snp1 0 1
		1 snp2 0 2

		则对应的bed文件是（前3个字节是固定的）：
		十六进制：	6C			1B			01			B8			0F			CA			0E
		二进制：	01101100	00011011	00000001	10111000	00001111	11001010	00001110

		从第四个字节开始是基因数据。基因数据编码方式：
		1. 每一个SNP中minor allele用0表示，major allele则用1表示。则有此等价
		   表示：
			00 - aa		01 - Aa aA		11 - AA		10 - Missing
		2. 每个SNP用整数个字节不足补0。
		如上例之第二个SNP：G是minor allele、T是major allele，则表示为：01010011 01110000
		注意第二组“TG”也应表示为“01”，第二字节尾部补4个0以形成一个整
		字节
		3. 最后把每个字节逆序存放。
		*/

	//fam文件格式。
	/*
	bed文件仅记录了基因数据（即ped文件的从第7列开始的内容），fam文件则记录的是前6列
	*/

	//bim文件格式。
	/*
	bim文件是ped格式中的map文件的扩展，与上述map文件对应的bim文件：
	1	snp1	0	1	A	C
	1	snp2	0	2	G	T
	各列：
	0 - chromosome (1-22, X, Y or 0 if unplaced)
	1 - rs# or snp identifier
	2 - Genetic distance (morgans)
	3 - Base-pair position (bp units)
	4 - allele 1（minor allele）
	5 - allele 2（major allele）
	注：（1）若两个等位基因个数相同，则Plink 1.9 Beta6按字母序分别是
			minor allele和major allele,Plink 1.07把先遇到的作为minor
			 allele（这里按Plink 1.9 Beta6规则编程）
		（2）若只有一种等位基因，则用0标示缺失并作为minor allele
		（3）不判断缺失等位基因符号（如 0、-、N等），所有符号都作为正常符号处理（这里 0、-、N三种缺失基因符号不参与计数统计）
	***************************************************************/
	void Ped2Bed(vvString& vvsMap, vvChar& vvcPed, vString& vsPed6, coPLINK::parameters *clsParas)
	{
		string		strBin, sTmp;
		int			i, j, k, n, uSampleCnt, uSNPcnt, uA[2];
		ofstream	fp;		// fstream 创建二进制文件会失败
		vString		vsTmp;
		vChar		vcAllele(2);
		vvChar		vvcAllele;
		vChar		vcTmp;
		char		c, cs[4], cMissing;
		bool		bMissing;

		if (clsParas->bPreprocess){
			if (!chkSample4Ped(vvcPed, vsPed6, clsParas, sTmp)){	// 需在预处理之前，其可能删除样本
				fetalError("An error is encountered while alleles missing rates of samples checking: " + sTmp, clsParas);
			}

			if (!preprocessPed(vvcPed, vvsMap, clsParas, true, sTmp)){
				fetalError("An error is encountered while preprocessing: " + sTmp, clsParas);
			}
		}

		//检查PED文件内容与MAP内容是否匹配
		i = vvcPed[0].size() / 2;	//PED文件中的SNP个数（2个等位基因构成SNP中的一个基因型）
		uSNPcnt = vvsMap.size();	//MAP文件中的SNP个数
		if (i != uSNPcnt) {
			char cs[100];
			sprintf(cs, "The number of SNPs are not equivalent between PED and MAP file.\nTheir numbers are as follows:\n\tPED: %d \tMAP: %d.", i, uSNPcnt);
			fetalError(cs, clsParas);
		}

		if (clsParas->bPed2BedNor){ //仅用于PED2BED时同时输出归一化了的PED（ID_FILE2指定文件名）
			//生成ped文件名
			strBin = getFn(clsParas->sFilename2, ".ped");

			cout << "Saveing file " << strBin << ". Please wait ..." << endl;
			
			fp.open(strBin.c_str(), ios::out);
			if (!fp.is_open()){
				fetalError("Create file " + strBin + " failed.", clsParas);
			}

			n = vvcPed[0].size();
			for (i = 0; i < (int)vsPed6.size(); i++) {
				fp << vsPed6[i];

				for (j = 0; j < n; j++){
					fp << DELIMITER3 << vvcPed[i][j];
				}
				fp << endl;

				cout << '\t' << i << " ...\r";
			}

			fp.close();
			fp.clear();
			cout << endl;

			cout << strBin << " saved OK." << endl;
			clsParas->fpLog << strBin << " saved OK." << endl;

			//生成map文件名
			strBin = getFn(clsParas->sFilename2, ".map");

			cout << "Saveing file " << strBin << ". Please wait ..." << endl;

			fp.open(strBin.c_str(), ios::out);
			if (!fp.is_open()){
				fetalError("Create file " + strBin + " failed.", clsParas);
			}

			n = vvsMap[0].size();
			for (i = 0; i < uSNPcnt; i++) {
				fp << vvsMap[i][0];

				for (j = 1; j < n; j++){
					fp << DELIMITER3 << vvsMap[i][j];
				}
				fp << endl;

				cout << '\t' << i << " ...\r";
			}

			fp.close();
			fp.clear();
			cout << endl;

			cout << strBin << " saved OK." << endl;
			clsParas->fpLog << strBin << " saved OK." << endl;
		}

		cout << "Converting to fam ..." << endl;
		//生成fam文件名
		strBin = getFn(clsParas->sOutputFilename, ".fam");

		//生成fam文件
		fp.open(strBin.c_str(), ios::out);
		if (!fp.is_open()){
			fetalError("Create file " + strBin + " failed.", clsParas);
		}

		uSampleCnt = vsPed6.size();
		for (i = 0; i < uSampleCnt; i++){
			fp << vsPed6[i] << endl;

			cout << '\t' << i << " ...\r";
		}

		fp.close();
		fp.clear();
		vsPed6.clear();
		vString().swap(vsPed6);

		cout << "\tSave " << strBin << " OK." << endl;

		/********** test ***********
		bool bb;
		for (i = 0; i < uSNPcnt * 2; i += 2){
			bb = false;
			k = 0;
			for (j = 0; j < uSampleCnt; j++){
				if (vvcPed[j][i] != vvcPed[j][i + 1]) {
					if (!bb) {
						vcAllele[0] = vvcPed[j][i];
						vcAllele[1] = vvcPed[j][i + 1];
						bb = true;
					}
					else if (vcAllele[0] != vvcPed[j][i]) k++;
				}
			}
			if (k > 0) {
				cout << "Differs heterozygote count in SNP " << i << " is " << k << endl;
				system("pause");
			}
		}
		/****************/

		if (clsParas->bNorOn){
			// 获得各SNP等位基因组成（次等位基因在前）
			for (i = 0; i < uSNPcnt * 2; i += 2){	// 每两列一个SNP
				vcAllele[0] = vcAllele[1] = '0';	// 若只有一种等位基因，那么另一个标示为‘0’或missing
				uA[0] = uA[1] = 0;
				bMissing = false;

				for (j = 0; j < uSampleCnt; j++){
					if (vvcPed[j][i] != PLNK_PED_MISSING_ALLELE1
						&& vvcPed[j][i] != PLNK_PED_MISSING_ALLELE2
						&& vvcPed[j][i] != PLNK_PED_MISSING_ALLELE3
						&& vvcPed[j][i] != PLNK_PED_MISSING_ALLELE4
						&& vvcPed[j][i] != MISSING_ALLELE_CHR){
						if (vcAllele[0] == '0') {
							vcAllele[0] = vvcPed[j][i];
							uA[0]++;
						}
						else if (vcAllele[0] == vvcPed[j][i]){
							uA[0]++;
						}
						else if (vcAllele[1] == '0') {
							vcAllele[1] = vvcPed[j][i];
							uA[1]++;
						}
						else uA[1]++;
					}
					else {
						cMissing = vvcPed[j][i] == MISSING_ALLELE_CHR ? PLNK_PED_MISSING_ALLELE2 : vvcPed[j][i];
						vvcPed[j][i] = MISSING_ALLELE_CHR;	// 统一修改缺失值
						bMissing = true;
					}


					if (vvcPed[j][i + 1] != PLNK_PED_MISSING_ALLELE1
						&& vvcPed[j][i + 1] != PLNK_PED_MISSING_ALLELE2
						&& vvcPed[j][i + 1] != PLNK_PED_MISSING_ALLELE3
						&& vvcPed[j][i + 1] != PLNK_PED_MISSING_ALLELE4
						&& vvcPed[j][i + 1] != MISSING_ALLELE_CHR){
						if (vcAllele[0] == '0') {
							vcAllele[0] = vvcPed[j][i + 1];
							uA[0]++;
						}
						else if (vcAllele[0] == vvcPed[j][i + 1]){
							uA[0]++;
						}
						else if (vcAllele[1] == '0') {
							vcAllele[1] = vvcPed[j][i + 1];
							uA[1]++;
						}
						else uA[1]++;
					}
					else {
						cMissing = vvcPed[j][i + 1] == MISSING_ALLELE_CHR ? PLNK_PED_MISSING_ALLELE2 : vvcPed[j][i + 1];
						vvcPed[j][i + 1] = MISSING_ALLELE_CHR;	// 统一修改缺失值
						bMissing = true;
					}
				}

				if ((uA[0] > uA[1]) || ((uA[0] == uA[1]) && (vcAllele[0] > vcAllele[1]))) {
					c = vcAllele[0];
					vcAllele[0] = vcAllele[1];
					vcAllele[1] = c;
				}

				if (bMissing && vcAllele[0] == '0') vcAllele[0] = cMissing;

				vvcAllele.push_back(vcAllele);
			}
		}
		else{	// 测试模式，输入的数据已归一化
			// 获得各SNP等位基因组成（次等位基因在前）
			for (i = 0; i < uSNPcnt * 2; i += 2){	// 每两列一个SNP
				vcAllele[0] = vcAllele[1] = '0';	// 若只有一种等位基因，那么另一个标示为‘0’或missing
				uA[0] = uA[1] = 0;
				bMissing = false;

				for (j = 0; j < uSampleCnt; j++){
					if (vvcPed[j][i] != PLNK_PED_MISSING_ALLELE1
						&& vvcPed[j][i] != PLNK_PED_MISSING_ALLELE2
						&& vvcPed[j][i] != PLNK_PED_MISSING_ALLELE3
						&& vvcPed[j][i] != PLNK_PED_MISSING_ALLELE4
						&& vvcPed[j][i] != MISSING_ALLELE_CHR){
						if (vcAllele[0] == '0' && vvcPed[j][i] == PLNK_PED_a) {
							vcAllele[0] = vvcPed[j][i];
						}
						else if (vcAllele[1] == '0' && vvcPed[j][i] == PLNK_PED_A) {
							vcAllele[1] = vvcPed[j][i];
						}
					}
					else {
						vvcPed[j][i] = MISSING_ALLELE_CHR;	// 统一修改缺失值
						bMissing = true;
					}


					if (vvcPed[j][i + 1] != PLNK_PED_MISSING_ALLELE1
						&& vvcPed[j][i + 1] != PLNK_PED_MISSING_ALLELE2
						&& vvcPed[j][i + 1] != PLNK_PED_MISSING_ALLELE3
						&& vvcPed[j][i + 1] != PLNK_PED_MISSING_ALLELE4
						&& vvcPed[j][i + 1] != MISSING_ALLELE_CHR){
						if (vcAllele[0] == '0' && vvcPed[j][i + 1] == PLNK_PED_a) {
							vcAllele[0] = vvcPed[j][i + 1];
						}
						else if (vcAllele[1] == '0' && vvcPed[j][i + 1] == PLNK_PED_A) {
							vcAllele[1] = vvcPed[j][i + 1];
						}
					}
					else {
						vvcPed[j][i + 1] = MISSING_ALLELE_CHR;	// 统一修改缺失值
						bMissing = true;
					}
				}

				if (bMissing){
					if (vcAllele[0] == '0') vcAllele[0] = PLNK_PED_MISSING_ALLELE2;
					else if (vcAllele[1] == '0') {
						vcAllele[1] = vcAllele[0];
						vcAllele[0] = PLNK_PED_MISSING_ALLELE2;
					}
				}
				else if (vcAllele[1] == '0') {
					vcAllele[1] = vcAllele[0];
					vcAllele[0] = '0';
				}

				vvcAllele.push_back(vcAllele);
			}
		}

		cout << "\nConverting to bim ..." << endl;
		//生成bim文件名
		strBin = getFn(clsParas->sOutputFilename, ".bim");

		//生成bim文件
		fp.open(strBin.c_str(), ios::out);
		if (!fp.is_open()){
			fetalError("Create file " + strBin + " failed.", clsParas);
		}

		cs[3] = '\0';
		for (i = 0; i < uSNPcnt; i++){
			sTmp = "";
			for (j = 0; j < 4; j++){
				sTmp += vvsMap[i][j] + "\t";	// tab分割
			}

			cs[0] = vvcAllele[i][0]; cs[1] = '\t'; cs[2] = vvcAllele[i][1]; 
			sTmp += cs;
			fp << sTmp << endl;

			cout << '\t' << i << " ...\r";
		}
		fp.close();
		fp.clear();
		cout << "\n\tSave " << strBin << " OK." << endl;

		cout << "Converting to bed ..." << endl;
		//生成bed文件名
		strBin = getFn(clsParas->sOutputFilename, ".bed");

		//生成bed文件
		fp.open(strBin.c_str(), ios::binary);
		if (!fp.is_open()){
			fetalError("Create file " + strBin + " failed.", clsParas);
		}
		
		// bed文件前两个字节固定，第3字节01表示只支持SNP-majar格式
		c = 0x6C;
		fp.write((char *)&c, 1);	//读写都要做这样的转换(char *)&c，另外，不能用“<<”操作符输出（结果不正确）
		c = 0x1B;
		fp.write((char *)&c, 1);
		c = 0x01;
		fp.write((char *)&c, 1);
		k = 0;
		c = 0;
		for (i = 0; i < uSNPcnt * 2; i += 2) {	// 逐SNP
			for (n = 0; n < uSampleCnt; n++){	// 逐样本
				if (vvcPed[n][i] == MISSING_ALLELE_CHR || vvcPed[n][i + 1] == MISSING_ALLELE_CHR){ // 缺失
					c |= PLNK_BED_MISSING << k;
				}
				else if (vvcPed[n][i] != vvcPed[n][i + 1]){	// 杂合子
					c |= PLNK_BED_Aa_aA << k;
				}
				else if (vvcPed[n][i] == vvcAllele[i / 2][0]){	// minor allele 纯合子
					c |= PLNK_BED_aa << k;
				}
				else{
					c |= PLNK_BED_AA << k;
				}

				k += 2;
				if (k >= 8) {
					fp.write((char *)&c, 1);
					k = c = 0;
				}
			}
			if (k){
				fp.write((char *)&c, 1);
				k = c = 0;
			}

			cout << '\t' << i << " ...\r";
		}
		fp.close();
		fp.clear();

		vvcAllele.clear();
		vvcPed.clear();

		cout << "\n\tSave " << strBin << " OK." << endl;
		clsParas->fpLog << "The Binary file saved as " << strBin << endl;
#ifdef _DEBUG
		system("pause");
#endif // DEBUG
	}

	/********************************************
	* 检查PLINK ped文本格式数据中杂合子等位基因的组成
	* vvsMap = Plink的map文件内容
	* vsPed = Plink ped格式的数据(ped文件内容)
	* sPedFn = 被测试文件名
	* clsParas = pointer of class
	*********************************************/
	void TestPedAlleles(vvString& vvsMap, vString &vsPed, const char* sPedFn, parameters *clsParas)
	{
		string				s, sbak;
		int					i, j, k, n, uSampleCnt, uSNPcnt;
		fstream				fp;		// fstream 创建二进制文件会失败
		vString				vsTmp;
		//vChar				vcAllele(2);
		vChar				vcTmp;
		//vvChar				vvcAllele;
		vvChar				vvcPed;		// 用vvString 可以处理等位基因多个字符（当作缺失）的问题，但在大文件时占用内存太大（300M左右的文件，内存超过2G从而退出）
		map<string, char>	mp;
		map<string, char>::iterator it;
		static bool			bFisrt = true;

		

		// 拆分vsPed
		cout << "Spliting ..." << endl;

		uSampleCnt = vsPed.size();
		for (i = 0; i < uSampleCnt; i++){
			stringSplit(vsPed[i], vsTmp, " ");				//以空格为分隔符分拆vsPed
			j = vsTmp.size();
			if (j < PLNK_PED_GENOTYPE_COL) continue;		//最少PLNK_PED_GENOTYPE_COL列

			vcTmp.resize(j - PLNK_PED_GENOTYPE_COL);

			for (k = PLNK_PED_GENOTYPE_COL; k < j; k++){ vcTmp[k - PLNK_PED_GENOTYPE_COL] = vsTmp[k][0]; }	//只取首字符

			vvcPed.push_back(vcTmp);
		}

		vString().swap(vsPed);	// 释放vsPed

		s = getFn(clsParas->sOutputFilename, ".csv", true);

		if (bFisrt) {
			sbak = getFn(clsParas->sOutputFilename, ".bak", true);
			if (access(s.c_str(), 0) != -1) {			//文件存在
				if (access(sbak.c_str(), 0) != -1) {	// bak文件存在
					if (remove(sbak.c_str()) == 0){
						if (rename(s.c_str(), sbak.c_str()) == -1){ cout << "Rename file " << s << " failed." << endl; }
						else{ cout << "The old " << s << " was renamed as " << sbak << endl; }
					}
					else{
						cout << "Delete file " << sbak << " failed." << endl;
					}
				}
				else {
					if (rename(s.c_str(), sbak.c_str()) == -1){ cout << "Rename file " << s << " failed." << endl; }
					else{ cout << "The old " << s << " was renamed as " << sbak << endl; }
				}

				openStreamFile(fp, s.c_str(), ios::out);

				fp << "File Name,SNP,Genotype,Test mode" << endl;	// 文件首次创建，则写表头
				bFisrt = false;
			}
			else{
				openStreamFile(fp, s.c_str(), ios::out);

				fp << "File Name,SNP,Genotype,Test mode" << endl;	// 文件首次创建，则写表头
				bFisrt = false;
			}
		}
		else{
			openStreamFile(fp, s.c_str(), ios::app | ios::out);
		}

		if (!fp.is_open()){
			fetalError("Open file " + s + " failed.", clsParas);
		}

		uSNPcnt = vvsMap.size();
		std::cout << "SNP size: " << uSNPcnt << endl;
		for (i = 0; i < uSNPcnt * 2; i += 2){
			mp.clear();
			for (j = 0; j < uSampleCnt; j++){
				if (clsParas->iMode == 0){
					if (vvcPed[j][i] != vvcPed[j][i + 1]) {
						/*b = false;
						n = vvcAllele.size();
						if (n > 0){
						for (k = 0; k < n; k++){
						if ((vvcAllele[k][0] != vvcPed[j][i]) || (vvcAllele[k][1] != vvcPed[j][i + 1])){
						b = true;
						break;
						}
						}
						}
						else b = true;

						if (b) {
						vcAllele[0] = vvcPed[j][i];
						vcAllele[1] = vvcPed[j][i + 1];
						vvcAllele.push_back(vcAllele);
						}*/
						// 以上写法容易引起重复
						s = vvcPed[j][i];
						s += vvcPed[j][i + 1];
						mp.insert(make_pair(s, vvcPed[j][i + 1]));	//  利用map不重复的特性
					}
				}
				else{
					s = vvcPed[j][i];
					s += vvcPed[j][i + 1];
					mp.insert(make_pair(s, vvcPed[j][i + 1]));
				}
			}

			k = mp.size();
			if (k > 0){
				k--;
				n = 0;
				s = "";

				for (it = mp.begin(); n < k; it++, n++){
					s += it->first;
					s += '|';
				}
				// 最后个不要“｜”
				s += it->first;

				fp << sPedFn << ',' << vvsMap[i / 2][1] << ',' << s << ',' << (clsParas->iMode == 0 ? "Heterozygote Only" : "All genotypes") << endl;
			}
		}
	
		fp.close();
		vvString().swap(vvsMap);
		vvChar().swap(vvcPed);
	}

	
	/********************************************
	* 转换MDR格式文本文件为PLINK ped文本格式
	* vvsMap = MAP文件内容，字串矩阵
	* vvcData = dat文件内容（字符矩阵，第一列是表型）
	* clsParas = 参数类
	***********************************************************
	PLINK ped文本格式（PED文件, N-missing）(每行一个个体)：
	1	1	0	0	1	1	A	A	G	T
	2	1	0	0	1	1	A	C	T	G
	3	1	0	0	1	1	C	C	G	G
	4	1	0	0	1	2	A	C	T	T
	5	1	0	0	1	2	C	C	G	T
	6	1	0	0	1	2	C	C	T	T
	前6列(前4列可多个字符组成)：
	Family ID
	Individual ID
	Paternal ID
	Maternal ID
	Sex (1=male; 2=female; other=unknown)
	Phenotype (1=unaffect; 2=affect)

	PLINK ped文本格式（MAP文件）：
	1 snp1 0 1
	1 snp2 0 2
	各列含义：
	chromosome (1-22, X, Y or 0 if unplaced)
	rs# or snp identifier
	Genetic distance (morgans)
	Base-pair position (bp units)

	MDR格式：
	X1	X2 …	X20	Class
	0	1 …	1	1
	0	1 …	0	0
	1	1 …	2	1
	0	1 …	1	0
	所有字符用tab分隔；
	第1到n-1列：每列为一个SNP；
	第n列：Class：0-control, 1-case；
	基因型数据：0-AA, 1-Aa, 2-aa, -1 = missing；
	第1行为表头，其余每行为一个个体。
	******* 以上是早期自定义这样的格式（也许当时的资料这样描述），以下是2020.3.8查找到的格式 ************
	The data file is a required document with a default of .dat as its extension, which looks like this:
	0	1 	…	1	1
	0	1 	…	0	0
	1	1 	…	2	1
	0	1 	…	1	0
		* The delimiter in a MDR file is a TAB.
		* The first column: Phenotypes. Here we use 0 - control, 1 - case.
		* The additional columns: Genotypes. Each column is a SNP.
	These values range from 0 to the MAXLOCIVALUE defined by MDR confiures.
	Here we use 0 - AA, 1 - Aa or aA, 2 - aa, -1 - missing.
		* Each row is a separate individual.
	Except for the .dat file, a .map file may be included as an optional.
	It allows names to be specified for the variables in the data file.
	Usually, the first column is the chromosome number, second column the name and
	third column the base-pair position of the SNP.
	程序按新格式作了修改
	************************************************************/
	void MDR2Ped(vvString& vvsMap, vvChar& vvcData, coPLINK::parameters *clsParas)
	{
		CRandomMersenne crnd(clsParas->uRndSeed);

		string	strPed, strMap, sTmp;
		int	i, j, uSNPCnt;
		fstream	fp;
		Point	lt, rb;

		if (clsParas->bSwap) {				// 交换矩形（lt, rb)间的等位基因数相同的major和minor alleles
			lt.x = 1; lt.y = 0;
			rb.x = vvcData[0].size() - 1; rb.y = vvcData.size() - 1;
			swapAllelsInColSingle(vvcData, &lt, &rb, MDR_AA, MDR_aa);
		}

		//生成Plink文件名
		strPed = addExt(clsParas->sOutputFilename, ".ped");
		strMap = addExt(clsParas->sOutputFilename, ".map");

		//生成ped文件
		openStreamFile(fp, strPed.c_str(), ios::out);

		uSNPCnt = vvcData[0].size();			//SNP个数+1（第一列是case/control）

		for (i = 0; i < (int)vvcData.size(); i++) {
			//_itoa_s(i + 1, ctmp, sizeof(ctmp) / sizeof(ctmp[0]), 10);		//family ID
			//sTmp = ctmp;
			//sTmp += " 1 0 0 ";		//individual ID, paternal ID, maternal ID 
			//sTmp += I2C((int)crnd.IRandom(1,2));		//sex。随机生成
			//sTmp += DELIMITER3;
			//sTmp += vviData[i][uSNPCnt] == C2I(MDR_CTRL_PHENOTYPE) ? PLNK_PED_CTRL_PHENOTYPE : PLNK_PED_CASE_PHENOTYPE;	//
			//sTmp += DELIMITER3;
			// 代替以上行（代替前，大文件时，总是不能正确生成ctrl表型，怪？？？）
			fp << "1 "								//family ID
				<< i + 1							//individual ID
				<< " 0 0 "							//paternal ID, maternal ID
				<< (int)crnd.IRandom(1, 2) << ' '	//sex。随机生成
				<< (vvcData[i][0] == MDR_CTRL_PHENOTYPE ? PLNK_PED_CTRL_PHENOTYPE : PLNK_PED_CASE_PHENOTYPE);

			sTmp = "";
			for (j = 1; j < uSNPCnt; j++) {
				/*switch (vvcData[i][j]) {
				case MDR_AA:
					sTmp += "D D ";
					break;
				case MDR_Aa_aA:
					sTmp += "D d ";
					break;
				case MDR_aa:
					sTmp += "d d ";
					break;
				default:
					sTmp += "N N ";
					break;
				}*/
				if (vvcData[i][j] == MDR_AA){ sTmp += " D D"; }
				else if (vvcData[i][j] == MDR_Aa_aA){
					sTmp += DELIMITER3;
					sTmp += PLNK_PED_Aa_aA;
				}
				else if (vvcData[i][j] == MDR_aa){ sTmp += " d d"; }
				else{ sTmp += " N N"; }
			}
			fp << sTmp << endl;

			cout << '\t' << i << " ...\r";
		}
		fp.close();
		fp.clear();

		cout << "\nThe PED file saved as " << strPed << endl;
		clsParas->fpLog << "The PED file saved as " << strPed << endl;

		//生成map文件
		openStreamFile(fp, strMap.c_str(), ios::out);
		uSNPCnt--;

		if (vvsMap.empty()){
			for (i = 0; i < uSNPCnt; i++) {
				fp << clsParas->sChrNo << DELIMITER3 << "SNP" << i + 1 << " 0 0" << endl;//染色体号, SNP ID, Genetic distance, Base-pair position

				cout << '\t' << i << " ...\r";
			}
		}
		else {
			for (i = 0; i < uSNPCnt; i++) {
				fp << vvsMap[i][0] << DELIMITER3 << vvsMap[i][1] << " 0 " << vvsMap[i][2] << endl;//染色体号, SNP ID, Genetic distance, Base-pair position

				cout << '\t' << i << " ...\r";
			}
		}
		fp.close();
		fp.clear();

		cout << "\nThe MAP file saved as " << strMap << endl;

		clsParas->fpLog << "The MAP file saved as " << strMap << endl;
	}

	/********************************************
	* PLINK ped文本格式转LogicReg格式
	* vvcPed = 基因型字符矩阵（样本数行*2SNP列），已归一化
	* vsPed6 = PED文件的前6列字串向量
	* clsParas = 参数类
	**********************************************
	PLINK ped文本格式（PED文件, N-missing）(每行一个个体)：
	1	1	0	0	1	1	A	A	G	T
	2	1	0	0	1	1	A	C	T	G
	3	1	0	0	1	1	C	C	G	G
	4	1	0	0	1	2	A	C	T	T
	5	1	0	0	1	2	C	C	G	T
	6	1	0	0	1	2	C	C	T	T
	前6列(前4列可多个字符组成)：
	Family ID
	Individual ID
	Paternal ID
	Maternal ID
	Sex (1=male; 2=female; other=unknown)
	Phenotype (1=unaffect; 2=affect)

	* LogicReg格式：每行一个个体，第1列为case/control，其余每列（对于加性模型则是每两列）表示一个SNP。
	* 对因变量Y（即case/control）做logit变换方法：log(P/(1-P)), P = Y == 0 ? EPSILON : 1 - EPSILON
	* 基因型模型代码：
	*	0 - 加性模型。每个基因型由两位二进制组成：AA = 00, Aa = aA = 01, aa = 11
	*	1 - 显性模型。AA = 0, Aa = aA = aa = 1
	*	2 - 隐性模型。AA = Aa = aA = 0, aa = 1
	*********************************************/
	void Ped2LogicReg(vvChar vvcPed, vString& vsPed6, coPLINK::parameters *clsParas)
	{
		int		i, j, k;
		string	sTmp;
		char	cStr[STR_LENGTH];
		double	p;
		fstream	fp;
		Point	lt, rb;

		if (clsParas->bSwap) {		// 交换矩形（lt, rb)间的等位基因数相同的major和minor alleles
			lt.x = 0; lt.y = 0;
			rb.x = vvcPed[0].size() - 1; rb.y = vvcPed.size() - 1;
			if (!swapAllelsInColDouble(vvcPed, &lt, &rb)){
				fetalError("The number of columns of SNPs is not even.", clsParas);
			}
		}

		//生成LogicReg文件
		openStreamFile(fp, clsParas->sOutputFilename.c_str(), ios::out);

		for (i = 0; i < (int)vsPed6.size(); i++) {
			// find phenotype pos.
			k = 0;
			for (j = 1; j < (int)vsPed6[i].size(); j++){
				if (vsPed6[i][j] == DELIMITER3) k++;

				if (k == PLNK_PED_PHENOTYPE_COL) break;
			}
			k = ++j;

			if (clsParas->iMode == LOGREG_LOGIT) {	// logit transformation
				j = vsPed6[i][k] == PLNK_PED_CTRL_PHENOTYPE ? 0 : 1;		//case or control
				p = j == 0 ? EPSILON : 1 - EPSILON;
				p = log(p / (1 - p));
				double2string(cStr, p, NUM_OF_DIGITS, true);
				sTmp = cStr;
			}else {
				sTmp = vsPed6[i][k] ==  PLNK_PED_CTRL_PHENOTYPE ? LOGREG_CTRL_PHENOTYPE : LOGREG_CASE_PHENOTYPE;	//case/control
			}

			for (j = 0; j < (int)vvcPed[i].size(); j += 2) {
				if (vvcPed[i][j] == 'D' && vvcPed[i][j + 1] == 'D') {
					switch (clsParas->iModel) {
					case ADDITIVE:
						sTmp += " 0 0";
						break;
					case DOMINANT:
						sTmp += " 0";
						break;
					case RECESSIVE:
						sTmp += " 0";
						break;
					}
				}
				else if ((vvcPed[i][j] == 'D' && vvcPed[i][j + 1] == 'd')
					|| (vvcPed[i][j] == 'd' && vvcPed[i][j + 1] == 'D')) {
					switch (clsParas->iModel) {
					case ADDITIVE:
						sTmp += " 0 1";
						break;
					case DOMINANT:
						sTmp += " 1";
						break;
					case RECESSIVE:
						sTmp += " 0";
						break;
					}
				}
				else if (vvcPed[i][j] == 'd' && vvcPed[i][j + 1] == 'd') {
					switch (clsParas->iModel) {
					case ADDITIVE:
						sTmp += " 1 1";
						break;
					case DOMINANT:
						sTmp += " 1";
						break;
					case RECESSIVE:
						sTmp += " 1";
						break;
					}
				}
				else {
					switch (clsParas->iModel) {
					case ADDITIVE:
					{
						if (vvcPed[i][j] == 'D' && vvcPed[i][j + 1] == MISSING_ALLELE_CHR){ sTmp += " 0 -"; }
						else if (vvcPed[i][j] == MISSING_ALLELE_CHR && vvcPed[i][j + 1] == 'D'){ sTmp += " - 0"; }
						else if (vvcPed[i][j] == MISSING_ALLELE_CHR && vvcPed[i][j + 1] == 'd'){ sTmp += " - 1"; }
						else if (vvcPed[i][j] == 'd' && vvcPed[i][j + 1] == MISSING_ALLELE_CHR){ sTmp += " 1 -"; }
						else{ sTmp += " - -"; }

						break;
					}
					case DOMINANT:
						sTmp += " -";
						break;
					case RECESSIVE:
						sTmp += " -";
						break;
					}
				}	//missing

			}
			fp << sTmp << endl;

			cout << '\t' << i << " ...\r";
		}
		fp.close();
		fp.clear();

		cout << "\nThe LogicReg file saved as " << clsParas->sOutputFilename << endl;
		cout << "Note: The Plink data include " << vsPed6.size() <<" samples and "
			<< vvcPed[0].size() / 2 << " SNPs." << endl;
		clsParas->fpLog << "The LogicReg file saved as " << clsParas->sOutputFilename << ". The Plink data include " << vsPed6.size() <<" samples and "
			<< vvcPed[0].size() / 2 << " SNPs." << endl;
	}

	/********************************************
	* SVMSNPs格式转PLINK ped文本格式(文献作者在网站与README中说明的SVMSNPs格式不同!!!!!）
	* vvcDAT = DAT文件基因型字符矩阵（样本数行*SNP数列）
	* vcLAB = LAB文件表型字符向量（虽然文件有两列，但第2列只是序号，无需保存）
	* vsNAME = NAME文件字符串向量（SNP label）
	* clsParas = 类参数指针
	********************************************************************
	PLINK ped文本格式（PED文件, N-missing）(每行一个个体)：
	1	1	0	0	1	1	A	A	G	T
	2	1	0	0	1	1	A	C	T	G
	3	1	0	0	1	1	C	C	G	G
	4	1	0	0	1	2	A	C	T	T
	5	1	0	0	1	2	C	C	G	T
	6	1	0	0	1	2	C	C	T	T
	前6列(前4列可多个字符组成)：
	Family ID
	Individual ID
	Paternal ID
	Maternal ID
	Sex (1=male; 2=female; other=unknown)
	Phenotype (1=unaffect; 2=affect)
	********************************************************************
	PLINK map文本格式（每行一个SNP）：
	1 snp1 0 5000650
	1 snp2 0 5000830
	各列含义：
	chromosome (1-22, X, Y or 0 if unplaced)
	rs# or snp identifier
	Genetic distance (morgans)
	Base-pair position (bp units)
	********************************************************************
	SVMSNP格式（包含三个文件）(文献作者在网站与README中说明的SVMSNPs格式不同!!!!!。2020.3.17发现本质应该一样的，网站对数据文件编码说“也可以简单地用Major allele的个数表示”）：
	数据文件（本程序定义扩展名为dat）：每行一个个体，每列一个SNP。
	标签文件（本程序定义扩展名为lab）：每行一个个体，共两列：第1列0表示case，1表示control（网站说明这两列刚好相反，但其示例文件是按这种方式，这里用此方式）；
	第2列表示个体编号（即数据文件中的行号，从0开始编号）。
	SNP名称文件（可选）（本程序定义扩展名为snp）：每行一个SNP，只一列（字符串：SNP的名称）。
	各行与数据文件行对应。
	seekMode = 查找方式（0 - 基于等位基因字母序查找，字母序最后者为主要等位基因（README文件说明）。
	1 - 基于等位基因频率查找，频率高者为主要等位基因（网站说明）。
	数据文件编码规则：
	1. 作者网站上的编码规则：主要等位基因个数。
	2. 作者README文件中的编码规则（以下为README中的内容）：
	This encoding is produced as follows: if the SNP is
	A/B, where A and B denote nucleotides in sorted order, then the encoded
	genotype of AA is 0, AB or BA is 1, and BB is 2. For example if we have
	two cases (or controls) genotypes for 3 SNPs A/C, C/G, and C/T, then the
	encoding would be

	AA CC CT => 0 0 1 
	AC GG CC => 1 2 0
	本程序用-1表示missing
	*********************************************************************/
	void SVMSNPs2PED(parameters *clsParas)
	{
		CRandomMersenne crnd(clsParas->uRndSeed);
		string	strPED, strMAP;
		int		i, j, uSNP, uSampleCnt;
		fstream	fp;
		vvChar	vvcDAT;
		vChar	vcLAB;
		vString vsSNP;

		coPLINK::readSVMSNPs(vvcDAT, vcLAB, vsSNP, clsParas);	// 基因型结果为字符矩阵（多字符基因型只保留首字符）
		cout << "Converting ..." << endl;

		//生成PED的2个文件名
		strPED = getFn(clsParas->sOutputFilename, ".ped");
		strMAP = getFn(clsParas->sOutputFilename, ".map");

		//生成PED文件
		openStreamFile(fp, strPED.c_str(), ios::out);

		uSampleCnt = vvcDAT.size();					// number of samples
		uSNP = vvcDAT[0].size();					// number of SNPs
		
		for (i = 0; i < uSampleCnt; i++) {			//逐行扫描
			fp << "1 "								// Family ID
				<< i								// Individual ID 
				<< " 0 0 "							// Paternal ID, Maternal ID
				<< (int)crnd.IRandom(1, 2) << ' '	//sex。随机生成
				<< (vcLAB[i] == SVMSNP_CASE_PHENOTYPE ? PLNK_PED_CASE_PHENOTYPE : PLNK_PED_CTRL_PHENOTYPE);	// Phenotype(1 = unaffect; 2 = affect)

			for (j = 0; j < uSNP; j ++){			// each SNP
				fp << DELIMITER3;

				if (vvcDAT[i][j] == MISSING_ALLELE_CHR){
					fp << PLNK_PED_MISSING_ALLELE2 << DELIMITER3 << PLNK_PED_MISSING_ALLELE2;
					continue;
				}
				
				if (clsParas->iMode == SEEK_MODE_LETTER){
					if (vvcDAT[i][j] == SVMSNP_GENOTYPE0){ fp << PLNK_PED_A << DELIMITER3 << PLNK_PED_A; }
					else if (vvcDAT[i][j] == SVMSNP_GENOTYPE1){ fp << PLNK_PED_Aa_aA; }
					else if (vvcDAT[i][j] == SVMSNP_GENOTYPE2){ fp << PLNK_PED_a << DELIMITER3 << PLNK_PED_a; }
				}
				else {
					if (vvcDAT[i][j] == SVMSNP_GENOTYPE0){ fp << PLNK_PED_a << DELIMITER3 << PLNK_PED_a; }
					else if (vvcDAT[i][j] == SVMSNP_GENOTYPE1){ fp << PLNK_PED_Aa_aA; }
					else if (vvcDAT[i][j] == SVMSNP_GENOTYPE2){ fp << PLNK_PED_A << DELIMITER3 << PLNK_PED_A; }
				}
			}
			fp << endl;

			cout << '\t' << i << " ...\r";
		}
		fp.close();
		fp.clear();
		vvChar().swap(vvcDAT);
		vChar().swap(vcLAB);

		cout << "\nThe PED file saved as " << strPED << endl;
		clsParas->fpLog << "The PED file saved as " << strPED << endl;
		
		//生成map文件
		openStreamFile(fp, strMAP.c_str(), ios::out);
		if (vsSNP.size() > 0){
			for (i = 0; i < uSNP; i++){
				fp << clsParas->sChrNo << DELIMITER3	// chr. no.
					<< vsSNP[i]						// snp label
					<< " 0 0" << endl;

				cout << '\t' << i << " ...\r";
			}
		}
		else{
			for (i = 0; i < uSNP; i++){
				fp << "0 snp"			// chr. no.
					<< i + 1			// snp label
					<< " 0 0" << endl;

				cout << '\t' << i << " ...\r";
			}
		}
		fp.close();
		fp.clear();

		cout << "\nThe MAP file saved as " << strMAP << endl;
		clsParas->fpLog << "The MAP file saved as " << strMAP << endl;
	}

	/********************************************
	* PLINK ped文本格式转SVMSNPs格式(文献作者在网站与README中说明的SVMSNPs格式不同!!!!!）
	* vvcPed = 基因型字符矩阵（样本数行*2SNP列）
	* vsPed6 = PED文件的前6列
	* vvsMap = Plink格式的map文件内容
	* clsParas = 类参数指针
	********************************************************************
	PLINK ped文本格式（PED文件, N-missing）(每行一个个体)：
	1	1	0	0	1	1	A	A	G	T
	2	1	0	0	1	1	A	C	T	G
	3	1	0	0	1	1	C	C	G	G
	4	1	0	0	1	2	A	C	T	T
	5	1	0	0	1	2	C	C	G	T
	6	1	0	0	1	2	C	C	T	T
	前6列(前4列可多个字符组成)：
	Family ID
	Individual ID
	Paternal ID
	Maternal ID
	Sex (1=male; 2=female; other=unknown)
	Phenotype (1=unaffect; 2=affect)
	********************************************************************
	PLINK map文本格式（每行一个SNP）：
	1 snp1 0 5000650
	1 snp2 0 5000830
	各列含义：
	chromosome (1-22, X, Y or 0 if unplaced)
	rs# or snp identifier
	Genetic distance (morgans)
	Base-pair position (bp units)
	********************************************************************
	SVMSNP格式（包含三个文件）(文献作者在网站与README中说明的SVMSNPs格式不同!!!!!。2020.3.17发现本质应该一样的，网站对数据文件编码说“也可以简单地用Major allele的个数表示”）：
	数据文件（本程序定义扩展名为dat）：每行一个个体，每列一个SNP。
	标签文件（本程序定义扩展名为lab）：每行一个个体，共两列：第1列0表示case，1表示control（网站说明这两列刚好相反，但其示例文件是按这种方式，这里用此方式）；
	第2列表示个体编号（即数据文件中的行号，从0开始编号）。
	SNP名称文件（可选）（本程序定义扩展名为snp）：每行一个SNP，只一列（字符串：SNP的名称）。
	各行与数据文件行对应。
	seekMode = 查找方式（0 - 基于等位基因字母序查找，字母序最后者为主要等位基因（README文件说明）。
	1 - 基于等位基因频率查找，频率高者为主要等位基因（网站说明）。
	数据文件编码规则：
	1. 作者网站上的编码规则：主要等位基因个数。
	2. 作者README文件中的编码规则（以下为README中的内容）：
	This encoding is produced as follows: if the SNP is
	A/B, where A and B denote nucleotides in sorted order, then the encoded
	genotype of AA is 0, AB or BA is 1, and BB is 2. For example if we have
	two cases (or controls) genotypes for 3 SNPs A/C, C/G, and C/T, then the
	encoding would be

	AA CC CT => 0 0 1 
	AC GG CC => 1 2 0
	本程序用-1表示missing
	*********************************************************************/
	void Ped2SVMSNPs(vvChar& vvcPed, vString& vsPed6, vvString &vvsMap, coPLINK::parameters *clsParas)
	{
		string	strDAT, strLAB, strNAME;
		int		i, j, uSNP, uSampleCnt;
		int		k;
		vChar	vcMajor;
		fstream	fp;

		if (clsParas->bPreprocess){
			if (!chkSample4Ped(vvcPed, vsPed6, clsParas, strNAME)){	// 需在预处理之前，其可能删除样本
				fetalError("An error is encountered while alleles missing rates of samples checking: " + strNAME, clsParas);
			}

			if (!preprocessPed(vvcPed, vvsMap, clsParas, true, strNAME)){
				fetalError("An error is encountered while preprocessing: " + strNAME, clsParas);
			}
		}

		//检查PED文件内容与MAP内容是否匹配
		uSNP = vvcPed[0].size();	// SNP列数
		i =  uSNP / 2;				//PED文件中的SNP个数
		j = vvsMap.size();			//MAP文件中的SNP个数
		if(i != j) {
			fetalError("The number of SNPs are not equivalent between PED and MAP file.", clsParas);
		}

		//生成SVMSNPs的三个文件名
		strDAT = getFn(clsParas->sOutputFilename, ".DAT");
		strLAB = getFn(clsParas->sOutputFilename, ".LAB");
		strNAME = getFn(clsParas->sOutputFilename, ".SNP");

		seekMajorAlleles(vvcPed, vcMajor, clsParas->iMode);	//查找所有SNP的Major Allele
		uSampleCnt = vvcPed.size();							// number of samples

		//生成DAT文件
		openStreamFile(fp, strDAT.c_str(), ios::out);

		for (i = 0; i < uSampleCnt; i++) {	//逐行扫描
			for (j = 0; j < uSNP; j += 2){	// each SNP
				if (vvcPed[i][j] == MISSING_ALLELE_CHR || vvcPed[i][j + 1] == MISSING_ALLELE_CHR){
					fp << SVMSNP_MISSING_GENOTYPE;
				}
				else {
					k = 0;
					if (vvcPed[i][j] == vcMajor[j / 2]){ k++; }

					if (vvcPed[i][j + 1] == vcMajor[j / 2]){ k++; }

					fp << k;
				}

				if (j < uSNP - 2) fp << DELIMITER3;
			}

			fp << endl;

			cout << '\t' << i << " ...\r";
		}
		fp.close();
		fp.clear();

		cout << "\nThe DAT file saved as " << strDAT << endl;
		clsParas->fpLog << "The DAT file saved as " << strDAT << endl;

		//生成标签文件
		openStreamFile(fp, strLAB.c_str(), ios::out);

		for (i = 0; i < uSampleCnt; i++){
			k = 0;
			for (j = 1; j < (int)vsPed6[i].length(); j++){
				if (vsPed6[i][j] == DELIMITER3) k++;

				if (k == PLNK_PED_PHENOTYPE_COL) break;
			}

			fp << (vsPed6[i][++j] == PLNK_PED_CTRL_PHENOTYPE ? SVMSNP_CTRL_PHENOTYPE : SVMSNP_CASE_PHENOTYPE)
				<< DELIMITER3
				<< i
				<< endl;

			cout << '\t' << i << " ...\r";
		}
		fp.close();
		fp.clear();

		cout << "\nThe label file saved as " << strLAB << endl;
		clsParas->fpLog << "The label file saved as " << strLAB << endl;

		//生成SNP名称文件
		openStreamFile(fp, strNAME.c_str(), ios::out);

		for (i = 0; i < (int)vvsMap.size(); i++){
			fp << vvsMap[i][1] << endl;
			cout << '\t' << i << " ...\r";
		}

		fp.close();
		fp.clear();

		cout << "\nThe SNPs' name file saved as " << strNAME << endl;
		clsParas->fpLog << "The SNPs' name file saved as " << strNAME << endl;
	}

	/********************************************
	* 转换Prettybase格式到PLINK ped文本格式（使用更多MAP）重载+1
	* vvsInfo = 4列：文件的前两列转换成4列：chromosome position、HUGO_NAME、chromosome、PGA Sample ID
	* vvcAlleles = 等位基因数据
	* clsParas = class pointer
	*
	* 缺失等位基因用“N”表示
	*********************************************
	Prettybase格式：-或N = missing
	This is a tab delimited text file in our "prettybase" format, 
	which describes all SNP sites discovered by the SeattleSNPs PGA. 
	The format of this file is:

	Line format:
	<chromosome position-HUGO_NAME-chromosome> <PGA Sample ID> <Allele1> <Allele2>

	Example: 74772592-PLAU-10 D001 G T
	注： <Allele1> <Allele2>可能包含多个字母，遇此情况，仅取首字母
	The 'chromosome position' is generated from mapping to the most 
	recent genome assembly available from the UCSC Genome Assembly

	vvsInfo = 文件的前两列转换成4列：chromosome position、HUGO_NAME、chromosome、PGA Sample ID
	vvcAlleles = 等位基因数据（文件中的后两列）

	Prettybase格式：
	1. 用TAB分隔
	2. 每行组成：<chromosome position-HUGO_NAME-chromosome> <PGA Sample ID> <Allele1> <Allele2>
	3. 可将“HUGO_NAME-chromosome position”视作SNP ID
	4. 缺失用“-”或“N”表示
	***********************************************************/
	void Prettybase2Ped(vvString &vvsInfo, vvChar& vvcAlleles, parameters *clsParas)// 早期版本的pretty格式（保存所有数据，占用内存过大）支持有重复样本ID
	{
		map<string, uint>		snpMap;			//SNP ID 与 vvsSnpChr 行号构成对(不重复)
		map<string, uint>		sampleMap;		//sample ID 与 vvsSnpChr 行号构成对(不重复)
		map<long long, uint>	dataMap;		//(sample ID + SNP ID) hash 与v vsSnpChr 行号构成对(不重复)
		int						i;
		uint					uSizeOfUint;
		long long				lHash,lHash_Lo;
		string					strPed, strMap, sTmp, sLine;
		//char					ctmp[SHORT_LEN];
		fstream					fp;

		/********************************************************
		* 提取不重复的SNP ID 和 SAMPLE ID 在vvsSnpChr中的行号，
		* 同时生成dataMap
		* 注：做两次不同的HASH之目的：对于不同的字串，其HASH值可能
		*     相同，两次HASH后拼接可大大降低HASH重复的概率
		*********************************************************/
		uSizeOfUint = 8 * sizeof(uint);
		for (i = 0; i < (int)vvsInfo.size(); i++) {
			/*lHash = simple_hash(vvsSnpChr[i][SNP_ID_NO].c_str());
			lHash_Lo = BKDR_hash(vvsSnpChr[i][SNP_ID_NO].c_str());
			lHash <<= uSizeOfUint;
			lHash |= lHash_Lo;*/
			snpMap.insert(pair<string, uint>(vvsInfo[i][PRET_NAME] + DELIMITER1 + vvsInfo[i][PRET_POS], i));		//后续不做查找等操作，直接用<string, uint>以便自动排序

			/*lHash = simple_hash(vvsSnpChr[i][SAMPLE_ID_NO].c_str());
			lHash_Lo = BKDR_hash(vvsSnpChr[i][SAMPLE_ID_NO].c_str());
			lHash <<= uSizeOfUint;
			lHash |= lHash_Lo;*/
			sampleMap.insert(pair<string, uint>(vvsInfo[i][PRET_SAMPLE_OLD], i));

			sTmp = vvsInfo[i][PRET_SAMPLE_OLD] + vvsInfo[i][PRET_NAME] + DELIMITER1 + vvsInfo[i][PRET_POS];
			lHash = simple_hash(sTmp.c_str());
			lHash_Lo = BKDR_hash(sTmp.c_str());
			lHash <<= uSizeOfUint;
			lHash |= lHash_Lo;
			dataMap.insert(pair<long long, uint>(lHash, i));		//保存成<long long, uint>格式会比直接用<string, uint>快很多!
		}
		cout<<"There are "<<snpMap.size()<<"  SNPs and " << sampleMap.size() << " samples." << endl;

		//生成Plink文件名
		strPed = getFn(clsParas->sOutputFilename, ".ped");
		strMap = getFn(clsParas->sOutputFilename, ".map");

		//生成ped文件
		openStreamFile(fp, strPed.c_str(), ios::out);

		map<string, uint>::iterator itSample = sampleMap.begin();  
		map<string, uint>::iterator itSNP;
		map<long long, uint>::iterator itData;
		CRandomMersenne		crnd(clsParas->uRndSeed);

		i = 0;
		for(; itSample != sampleMap.end(); ++itSample) {		//逐个体扫描
			//_itoa_s(++i, ctmp, sizeof(ctmp) / sizeof(ctmp[0]), 10);
			sTmp = "1 ";					//family ID
			sTmp += vvsInfo[itSample->second][PRET_SAMPLE_OLD] + " 0 0 ";		//个体ID, paternal ID, maternal ID
			sTmp += I2C((int)crnd.IRandom(1, 2));	//sex。随机生成
			sTmp += DELIMITER3;
			sTmp += clsParas->cPhenotype;
			sTmp += DELIMITER3;

			for(itSNP = snpMap.begin(); itSNP != snpMap.end(); ++itSNP) {		//逐SNP
				sTmp = vvsInfo[itSample->second][PRET_SAMPLE_OLD] + vvsInfo[itSNP->second][PRET_NAME] + DELIMITER1 + vvsInfo[itSNP->second][PRET_POS];
				/********************************************************
				* 做两次不同的HASH之目的：对于不同的字串，其HASH值可能
				* 相同，两次HASH后拼接可大大降低HASH重复的概率
				*********************************************************/
				lHash = simple_hash(sTmp.c_str());
				lHash_Lo = BKDR_hash(sTmp.c_str());
				lHash <<= uSizeOfUint;
				lHash |= lHash_Lo;
				itData = dataMap.find(lHash);
				sTmp += DELIMITER3;
				if(itData != dataMap.end()) {
					sTmp += vvcAlleles[itData->second][0];
					sTmp += DELIMITER3;
					sTmp += vvcAlleles[itData->second][1];
				} else {					//没有找到，填缺失值
					sTmp += PLNK_PED_MISSING_ALLELE2;
					sTmp += DELIMITER3;
					sTmp += PLNK_PED_MISSING_ALLELE2;
				}
			}
			fp << sTmp << endl;
		}
		fp.close();
		fp.clear();

		cout << "The PED file saved as " << strPed << endl;

		//生成map文件
		openStreamFile(fp, strMap.c_str(), ios::out);

		for(itSNP = snpMap.begin(); itSNP != snpMap.end(); ++itSNP) {
			sTmp = vvsInfo[itSNP->second][PRET_CHR] + DELIMITER3 
				+ vvsInfo[itSNP->second][PRET_NAME] + DELIMITER1 + vvsInfo[itSNP->second][PRET_POS] + " 0 "
				+ vvsInfo[itSNP->second][PRET_POS];
			fp << sTmp << endl;
		}
		fp.close();
		fp.clear();

		cout << "The MAP file saved as " << strMap << endl;
	}

	/********************************************
	* 以SNP position 为基准转换Prettybase格式到PLINK ped文本格式
	* clsParas = 参数类
	* 返回每个SNP的样本数
	*********************************************
	Prettybase格式：
	1. 用TAB分隔
	2. 每行组成：<position> <PGA Sample ID> <Allele1> <Allele2>
	3. 一个“position”代表一个SNP，每个SNP的样本ID排列顺序一样。
	4. 缺失用“-”或“N”表示（早期的），新的从其sample可以发现用?或N表示MISSING（这里支持三种）
	***********************************************************/
	void Prettybase2Ped(coPLINK::parameters *clsParas)
	{
		vInt	viPos;
		vString	vsChr;
		vString vsSamapleId;
		vvChar	vvcAlleles;
		int		iType;

		/*
		* viPos = 文件的第1列数值向量
		* vsSaId ＝ 一组样本（第2列）字串向量
		* vsChr = SNP的染色体号（不重复）
		* vvcAlleles = 等位基因数据（文件中的后两列，字符矩阵）
		*/
		if (clsParas->iMode == PRET_POSITION_NOREP){ iType = readPrettybasePosition(viPos, vsChr, vsSamapleId, vvcAlleles, clsParas); }
		else{ iType = readPrettybaseSample(viPos, vsChr, vsSamapleId, vvcAlleles, clsParas); }

		CRandomMersenne		crnd(clsParas->uRndSeed); 
		int					i, j, iSNPcnt, iSampleCnt;
		string				strPed, strMap;
		fstream				fp;

		

		iSNPcnt = viPos.size();
		iSampleCnt = vsSamapleId.size();

		// data validate
		if (iSNPcnt*iSampleCnt != vvcAlleles.size()){
			char	cs[200];

			sprintf(cs, "The numbers of SNPs and samples do not match the number of alleles (%d*%d != %d).", iSNPcnt, iSampleCnt, vvcAlleles.size());
			fetalError((string)cs, clsParas);
		}
		
		cout << "Saving Ped ... " << endl;

		//生成Plink文件名
		strPed = getFn(clsParas->sOutputFilename, ".ped");
		strMap = getFn(clsParas->sOutputFilename, ".map");

		//生成ped文件
		openStreamFile(fp, strPed.c_str(), ios::out);
		
		for (j = 0; j < iSampleCnt; j++) {			//逐个体扫描
			fp << "1 "										//family ID
				<< vsSamapleId[j]								//个体ID
				<< " 0 0 "									//paternal ID, maternal ID
				<< (int)crnd.IRandom(1, 2) << DELIMITER3	//sex。随机生成
				<< clsParas->cPhenotype;

			for (i = 0; i < iSNPcnt; i++) {		//逐SNP
				if (vvcAlleles[i * iSampleCnt + j][0] == MISSING_ALLELE_CHR){ fp << DELIMITER3 << PLNK_PED_MISSING_ALLELE2; }
				else{ fp << DELIMITER3 << vvcAlleles[i * iSampleCnt + j][0]; }

				if (vvcAlleles[i * iSampleCnt + j][1] == MISSING_ALLELE_CHR){ fp << DELIMITER3 << PLNK_PED_MISSING_ALLELE2; }
				else{ fp << DELIMITER3 << vvcAlleles[i * iSampleCnt + j][1]; }
			}

			fp << endl;

			cout << '\t' << j + 1 << " ...\r";
		}
		fp.close();
		fp.clear();
		vString().swap(vsSamapleId);
		vvChar().swap(vvcAlleles);

		cout << "\nThe PED file saved as " << strPed << endl;
		clsParas->fpLog << "The PED file saved as " << strPed << endl;

		cout << "Saving MAP ..." << endl;

		//生成map文件
		openStreamFile(fp, strMap.c_str(), ios::out);

		for (i = 0; i < iSNPcnt; i++) {		//逐SNP
			fp << (iType == PRET_Slider ? clsParas->sChrNo : vsChr[i]) << " SNP" << i + 1 << " 0 " << viPos[i] << endl;

			cout << '\t' << i + 1 << " ...\r";
		}
		fp.close();
		fp.clear();

		cout << "\nThe MAP file saved as " << strMap << endl;

		clsParas->fpLog << "The MAP file saved as " << strMap << endl;
	}

	/********************************************
	* PLINK ped文本格式转PLINK ped文本格式
	* vvcPed = 基因型矩阵（样本数行 * 2SNP列，已归一化）
	* vsPed6 = PED文件的前6列
	* vvsMap = Plink map格式的数据
	* clsParas = 类参数指针
	**********************************************/
	void Ped2Ped(vvChar& vvcPed, vString& vsPed6, vvString &vvsMap, coPLINK::parameters *clsParas)
	{
		if (!clsParas->bPreprocess && !clsParas->bSex && !clsParas->bNormalize  && !clsParas->bSwap) {
			char cs[100];
			sprintf(cs, "The parameter %s, %s, %s or %s is required.", ID_PRE, ID_SWAP, ID_RND_SEX, ID_NOR);
			fetalError(cs, clsParas);
		}

		int	i, j;
		fstream	fp;
		string	sFn, sTmp;
		bool	bProcessed = false;
		Point	lt, rb;

		if (clsParas->bSwap) {		// 交换矩形（lt, rb)间的等位基因数相同的major和minor alleles
			lt.x = 0; lt.y = 0;
			rb.x = vvcPed[0].size() - 1; rb.y = vvcPed.size() - 1;
			if (!swapAllelsInColDouble(vvcPed, &lt, &rb)){
				fetalError("The number of columns of SNPs is not even.", clsParas);
			}
		}

		if (!clsParas->bPreprocess && !clsParas->bSex && clsParas->bNormalize) {	// 仅归一化. Input data had been normalized, so saves it only.
			sFn = getFn(clsParas->sOutputFilename, ".ped");

			openStreamFile(fp, sFn.c_str(), ios::out);

			for (i = 0; i < (int)vsPed6.size(); i++) {
				sTmp = vsPed6[i];
				for (j = 0; j < (int)vvcPed[0].size(); j += 2){
					sTmp += DELIMITER3;
					sTmp += (vvcPed[i][j] == MISSING_ALLELE_CHR ? PLNK_PED_MISSING_ALLELE2 : vvcPed[i][j]);
					sTmp += DELIMITER3;
					sTmp += (vvcPed[i][j + 1] == MISSING_ALLELE_CHR ? PLNK_PED_MISSING_ALLELE2 : vvcPed[i][j + 1]);
				}
				fp << sTmp << endl;

				cout << '\t' << i << " ...\r";
			}
			fp.close();
			fp.clear();
			cout << "\n" << sFn << " is OK." << endl;

			sFn = getFn(clsParas->sOutputFilename, ".map");
			openStreamFile(fp, sFn.c_str(), ios::out);

			for (i = 0; i < (int)vvsMap.size(); i++) {
				sTmp = "";
				for (j = 0; j < (int)vvsMap[i].size(); j++) {
					sTmp += DELIMITER3;
					sTmp += vvsMap[i][j];
				}
				fp << sTmp << endl;

				cout << '\t' << i << " ...\r";
			}
			fp.close();
			fp.clear();

			cout << "\n\tSave " << sFn << " OK." << endl;
			return;
		}

		if(clsParas->bSex) sexPed(vsPed6, clsParas->uRndSeed);

		if (clsParas->bSex || clsParas->bSwap || (clsParas->bPreprocess && clsParas->iMode == 0)) {
			if(clsParas->bPreprocess && clsParas->iMode == 0) {
				if (!chkSample4Ped(vvcPed, vsPed6, clsParas, sTmp)){	// 需在预处理之前，其可能删除样本
					fetalError("An error is encountered while alleles missing rates of samples checking: " + sTmp, clsParas);
				}

				if (!preprocessPed(vvcPed, vvsMap, clsParas, true, sTmp)) {	// error
					fetalError("An error is encountered while preprocessing: " + sTmp, clsParas);
				}
				
				bProcessed = true;
			}

			sFn = getFn(clsParas->sOutputFilename, ".ped");
			openStreamFile(fp, sFn.c_str(), ios::out);

			for (i = 0; i < (int)vsPed6.size(); i++) {
				sTmp = vsPed6[i];
				for (j = 0; j < (int)vvcPed[0].size(); j += 2){
					sTmp += DELIMITER3;
					sTmp += (vvcPed[i][j] == MISSING_ALLELE_CHR ? PLNK_PED_MISSING_ALLELE2 : vvcPed[i][j]);
					sTmp += DELIMITER3;
					sTmp += (vvcPed[i][j + 1] == MISSING_ALLELE_CHR ? PLNK_PED_MISSING_ALLELE2 : vvcPed[i][j + 1]);
				}
				fp << sTmp << endl;

				cout << '\t' << i << " ...\r";
			}
			fp.close();
			fp.clear();
			cout << "\n\tSave " << sFn << " OK." << endl;

			//if(clsParas->bPreprocess && (clsParas->iMode == 0 || clsParas->bSex)) {
				sFn = getFn(clsParas->sOutputFilename, ".map");
				openStreamFile(fp, sFn.c_str(), ios::out);

				for (i = 0; i < (int)vvsMap.size(); i++) {
					sTmp = "";
					for (j = 0; j < (int)vvsMap[i].size(); j++) {
						sTmp += DELIMITER3;
						sTmp += vvsMap[i][j];
					}
					fp << sTmp << endl;

					cout << '\t' << i << " ...\r";
				}
				fp.close();
				fp.clear();
				cout << "\n\tSave " << sFn << " OK." << endl;
			//}

			if(!bProcessed && clsParas->bPreprocess) {
				if (!chkSample4Ped(vvcPed, vsPed6, clsParas, sTmp)){	// 需在预处理之前，其可能删除样本
					fetalError("An error is encountered while alleles missing rates of samples checking: " + sTmp, clsParas);
				}

				if(!preprocessPed(vvcPed, vvsMap, clsParas, true, sTmp)){	// error
					fetalError("An error is encountered while preprocessing: " + sTmp, clsParas);
				}
			}
		} else if(clsParas->bPreprocess) {
			if (!chkSample4Ped(vvcPed, vsPed6, clsParas, sTmp)){	// 需在预处理之前，其可能删除样本
				fetalError("An error is encountered while alleles missing rates of samples checking: " + sTmp, clsParas);
			}

			if (!preprocessPed(vvcPed, vvsMap, clsParas, true, sTmp)){	// error
				fetalError("An error is encountered while preprocessing: " + sTmp, clsParas);
			}
		}
	}

}

