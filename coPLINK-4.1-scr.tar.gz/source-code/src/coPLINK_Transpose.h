//////////////////////////////////////////////////////////////////
//                                                              //
//           coPLINK (c) 2020-2024 Han-Ming LIU                 //
//                                                              //
// This file is distributed under the GNU General Public        //
// License, Version 3.  Please see the file COPYING for more    //
// details                                                      //
//                                                              //
//////////////////////////////////////////////////////////////////

#ifndef _H_COPLINK_TRANSPOSE_H_
#define	_H_COPLINK_TRANSPOSE_H_

#include "coPLINK.h"


namespace coPLINK
{
	void fileTranspose(parameters *clsParas, char cOverloadFlag);
	void fileTranspose(parameters *clsParas, string sOverloadFlag);
	void fileTranspose(parameters *clsParas, int iOverloadFlag);
	void fileTranspose(parameters *clsParas, float fOverloadFlag);
}

#endif // !_H_COPLINK_TRANSPOSE_H_
