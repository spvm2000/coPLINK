//////////////////////////////////////////////////////////////////
//                                                              //
//                      from Web, unamed                        //
//                                                              //
//                                                              //
//////////////////////////////////////////////////////////////////

#ifndef _HASH_H
#define _HASH_H
#ifdef __cplusplus
extern "C" {
#endif
	/* A Simple Hash Function */
	unsigned int simple_hash(const char *str);
	/* BKDR Hash Function */
	unsigned int BKDR_hash(const char *str);
#ifdef __cplusplus
}
#endif
#endif
