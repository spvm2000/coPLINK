//////////////////////////////////////////////////////////////////
//                                                              //
//           coPLINK (c) 2020-2024 Han-Ming LIU                 //
//                                                              //
// This file is distributed under the GNU General Public        //
// License, Version 3.  Please see the file COPYING for more    //
// details                                                      //
//                                                              //
//////////////////////////////////////////////////////////////////

#include "publicFunctions.h"

//打开文件，如果失败，可以重试
FILE* openFile(const char* fn, const char* model)	//打开成功，返回0，否则非0
{
	char c;int i;
//	errno_t err;
	FILE* fp;

	while(1) {
		fp = fopen(fn, model);
		if(!fp) {
			cout<<"\nError, file "<<fn<<" opened fail.\n Press r to retry, others abort."<<endl;
			i = system("stty raw");
			c = getchar();
			i = system("stty -raw");
			if(c == 'r' || c == 'R') continue;
			fp = NULL;
			break;
		} else break;
	}

	return fp;
}

//获取指定路径下所有指定扩展名的文件列表（扩展名空表示所有文件）
void getFileList(string path, string exd, vector<string>& files)
{
	if (path.length() == 0) return;

/*	windows
	//文件句柄
	long   hFile = 0;
	//文件信息
	struct _finddata_t fileinfo;
	string pathName, exdName;

	if (0 != strcmp(exd.c_str(), ""))
	{
		exdName = "\\*." + exd;
	}
	else
	{
		exdName = "\\*";
	}

	if (path[path.length() - 1] == '\\'){
		path.pop_back();
	}

	if ((hFile = _findfirst(pathName.assign(path).append(exdName).c_str(), &fileinfo)) != -1)
	{
		do
		{
			if(!(fileinfo.attrib &  _A_SUBDIR))
			{
				files.push_back(pathName.assign(path).append("\\").append(fileinfo.name)); // 要得到绝对目录使用该语句
				//files.push_back(fileinfo.name); // 只要得到文件名字使用该语句
			}
		} while (_findnext(hFile, &fileinfo) == 0);
		_findclose(hFile);
	}
*/

	DIR *dirptr = NULL;
	struct dirent *dirp;
 	string pathName, exdName;

	if (0 != exd.length())
	{
		exdName = "." + exd;
	}

	/*if (path.length() < 2 || !(path[0] == '.' && path[1] != '/')) {// not need
		path = "./" + path;
	} */

	if (path[path.length() - 1] == '/'){
		path.erase(path.length() - 1);
	}
	
	
	if((dirptr = opendir(path.c_str())) == NULL)//打开一个目录
	{
		return;
	}
	while ((dirp = readdir(dirptr)) != NULL)
	{
		if ((dirp->d_type == DT_REG) && 0 ==(strcmp(strchr(dirp->d_name, '.'), exdName.c_str())))//判断是否为文件以及文件后缀名
		{
			files.push_back(pathName.assign(path).append("/").append(dirp->d_name));
		}
	}
	closedir(dirptr);
}

/****************************************************
* 打开流式文件
* fp - 文件流指针
* fn - 文件名
* mode - 打开模式。如下：
* 文件打开方式选项：
* ios::in　　　　= 0x01,　//供读，文件不存在则创建(ifstream默认的打开方式)
* ios::out　　　 = 0x02,　//供写，文件不存在则创建，若文件已存在则清空原内容(ofstream默认的打开方式)
* ios::ate　　　 = 0x04,　//文件打开时，指针在文件最后。可改变指针的位置，常和in、out联合使用
* ios::app　　　 = 0x08,　//供写，文件不存在则创建，若文件已存在则在原文件内容后写入新的内容，指针位置总在最后
* ios::trunc　　 = 0x10,　//在读写前先将文件长度截断为0（默认）
* ios::nocreate　= 0x20,　//文件不存在时产生错误，常和in或app联合使用
* ios::noreplace = 0x40,　//文件存在时产生错误，常和out联合使用
* ios::binary　　= 0x80　 //二进制格式文件
********************************************************/
void openStreamFile(fstream &fp, const char* fn, ios_base::openmode mode)
{
	char	c;
	int	i;

	fp.clear();							//释放原指针
	while(1) {
		fp.open(fn, mode);
		if(fp.is_open()) break;          //文件打开成功,说明曾经写入过东西
		cout << "\nError, file " << fn << " opened fail.\n Press r to retry, others abort." << endl;
		i = system("stty raw");
		c = getchar();
		i = system("stty -raw");
		if(c == 'r' || c == 'R') continue;
		exit(1);
	}
}

/****************************************************
* 写各段程序运行时间文件（csv格式）
* 每行三个字段：Action、时长（单位：ms）及当前时间
* 文件名：固定为prefix + TimeRecord.csv
********************************************************/
void timeRecorder(const char *prefix, const char *Action, double ms)
{
	FILE	*fp;
	char	fn[STR_LENGTH];
	uint	i;
	
	strcpy(fn, prefix);
	//若prefix = ".csv"，则删除之
	i = strlen(fn) - 1;
	if(i > 4) {
		if(fn[i] == 'v' && fn[i-1] == 's' && fn[i-2] == 'c' && fn[i-3] == '.') {
			fn[i-3] = '\0';
		}
	}	

	strcat(fn, TIME_REC_FN);

	if(access(fn, 0) == -1) {		//文件不存在，则创建并写文件头
		fp = openFile(fn, "w");
		fprintf(fp, "%s\n", "Action,Time(ms),Datetime");
		fclose(fp);
	}

	fp = openFile(fn,"a");
	fprintf(fp, "%s,%f,%s\n", Action, ms, getDT().c_str());
	fclose(fp);
}

/*******************************************************
* 获致当前日期-时间，并转成字串返回
**********************************************************/
string getDT(void) 
{
/* windows
	struct tm curT;
	time_t tt;
	errno_t err;
	char s[STR_LENGTH];
	string ss;

	memset(&curT, 0, sizeof(tm));
	tt = time(NULL);
	err = localtime_s(&curT, &tt);

	sprintf_s(s, sizeof(s) / sizeof(s[0]), "%d-%d-%d %d:%d:%d",curT.tm_year + 1900/*必须加1900*//*, curT.tm_mon + 1/*必须加1*//*, 
		curT.tm_mday, curT.tm_hour, curT.tm_min, curT.tm_sec);
	ss = s;
	return ss;
*/
	char s[STR_LENGTH];
	string ss;

	time_t nSeconds;
	struct tm * pTM;

	time(&nSeconds);
	pTM = localtime(&nSeconds);

	/* 系统日期和时间,格式: yyyy-mm-dd HH:MM:SS */
	sprintf(s, "%04d-%02d-%02d %02d:%02d:%02d", pTM->tm_year + 1900/*必须加1900*/, pTM->tm_mon + 1/*必须加1*/,
        pTM->tm_mday, pTM->tm_hour, pTM->tm_min, pTM->tm_sec);
	ss = s;
	return ss;
}

/*****************************************************
* 四舍五入函数
* 参数：数、保留小数位数
* 说明：该函数只关心保留小数位数的后一位,与sprintf函数相同
* 例:   round(0.499,2)=0.50     round(0.4949,2)=0.49
********************************************************/
double round(double _x,int decimalnum) 
{ 
	double num,dec,factor; 
	dec = modf(_x,&num);			//分切整数与小数部分(不直接用long型数参与计算, 	避免运算溢出) 
	factor = (double)pow(10.0,decimalnum);	//因子 
	dec *=factor;					//小数点右移decimalnum位 
	dec +=_x >=0 ? 0.5 : -0.5;		//四舍五入运算 
	modf(dec,&dec);					//取整 
	dec /= factor;					//小数点左移decimalnum位 
	return num + dec;				//合并返回值 
}

/*******************************************************
* 四舍五入
* 例:1.535
* 保留小数点后两位，做四舍五入得1.54
* 使用方法:Round(1.535,2)
* 返回值:1.54
**********************************************************/
double __attribute__((__stdcall__)) Round(const double Value, const short int ADigit, const short int RoundMark)
{ 
	char   LocalRoundMark = (char)RoundMark; 
	double   Result=Value; 
	double   DResult; 
	if(ADigit> 18) 
		return   Result; 
	double   DigitValue=powl(10,ADigit); 

	if(LocalRoundMark> 0)LocalRoundMark=1; 
	if(LocalRoundMark <0)LocalRoundMark=-1; 

	switch(LocalRoundMark) 
	{ 
	case   -1://Round   Down 
		Result*=DigitValue; 
		if(Value <0.00)//负数 
			Result=ceill(Result); 
		else 
			Result=floorl(Result); 
		break; 
	case     1://Round   Up 
		Result*=DigitValue; 
		if(Value <0.00)//负数 
			Result=floorl(Result); 
		else 
			Result=ceill(Result); 
		break; 
	default://Round     四舍五入 
		if(Value <0.00)//负数 
			Result-=0.5/DigitValue; 
		else 
			Result+=0.5/DigitValue; 
		Result*=DigitValue; 
		DResult=Result; 
		if(Value <0.00) 
		{ 
			Result=ceill(Result); 
			DResult=Result-DResult; 
			if(DResult> 0.9999999999)Result-=1.0; 
		} 
		else 
		{ 
			Result=floorl(Result); 
			DResult=DResult-Result; 
			if(DResult> 0.9999999999)Result+=1.0; 
		} 
	} 
	Result/=DigitValue; 
	return   Result; 
}

/*******************************************************
* 去除char的字符串前导和尾部空格、TAB及尾部的换行符
* line = 字符串指针
* length = 字符串长度
**********************************************************/
void trimString(char *line, int length)
{
	int i, j;

	//去除前导空格和TAB
	for(i = 0; i < length; i++)
		if(!(line[i] == ' ' || line[i] == '\t')) break;
	
	if(i > 0) for(j = 0; j < length - i; j++) line[j] = line[j+i];

	//删除行尾空格和TAB、换行符
	j = strlen(line);
	for(i = j - 1; i > 0; i--) {
		if(line[i] == ' ' || line[i] == '\t' || line[i] == '\n') line[i] = '\0';
		else break;
	}
	if(j == 1 && (line[0] == ' ' || line[0] == '\t' || line[0] == '\n')) line[0] = '\0';
}

/**********************************************************
*功能：为string的字符串去前后空格及Tab
*str：源字符串
*返回值：去除前后空格和TAB后的字符串
***********************************************************/
void trimString(string &s)
{
    if(s.length() == 0) return;

	int i;		// 原来用uint，则s.length-1<0时会变成正数，从而出错

	for(i = 0; i < (int)s.length(); i++) {
		if(s[i] != ' ' && s[i] != '\t')
			break;
	}
    s.erase(0, i);

	for(i = s.length() - 1; i >= 0; i--) {
		if(s[i] != ' ' && s[i] != '\t')
			break;
	}
    s.erase(i + 1);
}

/**********************************************************
*功能：为string的字符串去中间多余空格及Tab（只留一个）
* s：源及目标字符串
* repl：是否把TAB替换成空格
* 返回值：去除后的字符串
***********************************************************/
void trimRedundance(string &s, bool repl)
{
	if(s.length() == 0) return;

	int i, j, uEnd;

	uEnd = s.length();
	for(i = 0; i < uEnd; i++) {
		if(s[i] == ' ' || s[i] == '\t') {
			if (repl) s[i] = ' ';
			for(j = i + 1; j < uEnd; j++) {
				if(s[j] != ' ' && s[j] != '\t')	break;
			}
			if(j - i > 1) {
				j = j - i - 1;
				uEnd -= j;
				s.erase(i + 1, j);
			}
		}
	}
}

void trimRedundance(char *s, bool repl)
{
	int i, j, k, uEnd;

	uEnd = strlen(s);
	if (uEnd == 0) return;

	for (i = 0; i < uEnd; i++) {
		if (s[i] == ' ' || s[i] == '\t') {
			if (repl) s[i] = ' ';
			for (j = i + 1; j < uEnd; j++) {
				if (s[j] != ' ' && s[j] != '\t')	break;
			}
			if (j - i > 1) {
				j = j - i - 1;

				// 删除连续j个字符
				for (k = i + 1; k + j < uEnd; k++){
					s[k] = s[k + j];
				}
				s[k] = '\0';
				uEnd -= j;
			}
		}
	}
}

/**********************************************************
*功能：删除string的字符串中分隔符前后的一个空格或TAB
* s：源及目标字符串
* cDelim：分隔符
* 返回值：去除后的字符串
***********************************************************/
void trimRoundDelim(string &s, const char cDelim)
{
	if (s.length() == 0) return;

	int i, j, iEnd, iLen;

	iEnd = s.length();
	iLen = iEnd;

	for (i = 1; i < iEnd; i++) {
		if (s[i] == cDelim) {
			if (s[i - 1] == ' ' || s[i - 1] == '\t'){
				for (j = i; j < iEnd; j++) {
					s[j - 1] = s[j];
				}
				iEnd--;
			}

			if (s[i + 1] == ' ' || s[i + 1] == '\t'){
				for (j = i + 2; j < iEnd; j++) {
					s[j - 1] = s[j];
				}
				iEnd--;
			}
		}
	}

	if (iLen != iEnd) {
		s.erase(iEnd);
	}
}

/*******************************************************
* 字符转大写
* c = 字符
**********************************************************/
char c2Upper(char c)
{
	if (c <= 'z' && c >= 'a') return C2UPPER(c);
	else return c;
}

void str2Upper(char *line)
{
	int i = strlen(line);

	for (int j = 0; j < i; j++)
		if (line[j] >= 'a' && line[j] <= 'z') line[j] = line[j] + LOW2UP;
}

/*******************************************************
* 字符串转大写(string)
* str = 字符串
* 不做字符串及结果的合法性检查
**********************************************************/
void string2Upper(string &str)
{
	int		i, j;

	j = str.length();

	for (i = 0; i < j; i++)
		str[i] = toupper((int)str[i]);
}

/*******************************************************
* 字符串转小写(string)
* str = 字符串
* 不做字符串及结果的合法性检查
**********************************************************/
void string2Lower(string &str)
{
	int		i, j;

	j = str.length();

	for (i = 0; i < j; i++)
		str[i] = tolower((int)str[i]);
}

/*******************************************************
* double转string
* 不包含符号
**********************************************************/
string double2string(double value) {
	stringstream ss;
	ss << value;
	string s;
	ss >> s;
	return s;
}


/****************************************
* 双精度浮点小数转字符串（包含小数点及符号）
* result = 传址形式返回结果
* src = 待转浮点数
* NumOfDigits = 结果的总位数（含符号位，但包括小数点）
* positiveSign = 如果是正数，是否包含“+”号
****************************************/
void double2string(char *result, double src, int NumOfDigits, bool positiveSign)
{
	int i, dec, sign;
	char *tmp, c[STR_LENGTH];

	tmp = c;    // Need do like this, since c can't be a pointor in Linux.

	tmp=ecvt(src, NumOfDigits, &dec, &sign);

	//加入小数点
	for (i = NumOfDigits; i > dec; i--) tmp[i] = tmp[i - 1];
	tmp[dec] = '.';

	//加入符号
	if (positiveSign || sign == 1) {
		for (i = NumOfDigits + 1; i > 0; i--) tmp[i] = tmp[i - 1];
		tmp[NumOfDigits + 2] = '\0';
		tmp[0] = sign == 0 ? '+' : '-';
	}

	for (i = 0; i < NumOfDigits + 3; i++) result[i] = tmp[i];
}

/*******************************************************
* 检查文件是否存在，若文件已存在，显示提示信息，由用户确定覆盖、追加或退出
* bSilent - 静默方式（即不显示提示信息，此方式下：若存在，则自动选追加方式）
* 返回：OVERWRITE－覆盖、APPEND－追加、ABORT－退出、NO_EXIST－目标文件不存在
* 主要用于写文件前检查
**********************************************************/
int fileExsit(const char *fn, bool bSilent)
{
	char c;int i;

	if(access(fn, 0) != -1) {		//文件存在
		if(bSilent) return APPEND;
		while(1) {
			cout<<"\nThe output file "<<fn<<" exists on the destination."<<endl;
			cout<<"Press \"y\" to overwrite it, \"a\" to append on it, others abort."<<endl;
			i = system("stty raw");
			c = getchar();
			i = system("stty -raw");
			cout<<c<<endl;
			if(c == 'y' || c == 'Y') return OVERWRITE;
			else if(c == 'a' || c == 'A') return APPEND;
			else return ABORT;
		}
	} else {
		return NOT_EXIST;
	}
}

/*******************************************************
* 从src的iStart处(首个字符编号为0)开始提取首先出现的连续数字组成新字串des返回
* 若返回的des[0]==NULL，则说明源字串中无数字
**********************************************************/
void getNumbers(const char *src, char *des, int iStart)
{
	int	 i, j, k, m;
	bool bOk = false;		//查找完成？
	bool bNum = false;		//已发现数字？
	bool bPoint = false;	//已发现小数点？
	bool bMinus = false;	//已发现负号？

	des[0] = '\0';
	j = 0; k = 0;
	m = strlen(src);
	for (i = iStart; i < m; i++) {
		if(src[i] >= '0' && src[i] <= '9' || src[i] == '-')	//不支持诸如“.123”的小数写法
			for(k = i; k < m; k++)
				if(src[k] >= '0' && src[k] <= '9' || bNum && !bPoint && src[k] == '.' || !bNum && src[k] == '-') {
					des[j++] = src[k];
					bNum = true;
					if(src[k] == '.') bPoint = true;
					if(src[k] == '-') {
						if(src[k+1] >= '0' && src[k+1] <= '9') bMinus = true;
						else {j--; bNum = false; break;}
					}
				} else {
					bOk = true;
					break;
				}
		if(bOk || k == m) break;
	}
	des[j] = '\0';
}

string Trim(string &s)
{
    if(s.length() == 0) return s;

	uint i;

	for(i = 0; i < s.length(); i++) {
		if(s[i] != ' ' && s[i] != '\t')
			break;
	}
    s.erase(0, i);

	for(i = s.length() - 1; i >= 0; i--) {
		if(s[i] != ' ' && s[i] != '\t')
			break;
	}
    return s.erase(i + 1);
}

/**
 * @brief split a string by delim
 *
 * @param str string to be splited
 * @param c delimiter, const char*, just like " .,/", white space, dot, comma, splash
 *
 * @return a string vector saved all the splited world
 * 此函数会忽略空串
 */
void stringSplit(string &str, vector<string> &res, const char* c)
{
    char			*cstr, *p, *pNext;
	res.clear();

	//pNext = NULL;
    cstr = new char[str.size()+1];
    strcpy(cstr, str.c_str());

    p = strtok(cstr, c);
    while(p != NULL)
    {
        res.push_back(p);
        p = strtok(NULL, c);
    }
	delete[] cstr;
	delete p/*, pNext*/;
}

/*
功能:用分隔符将源字符串分隔为多个子串并传出; n个分隔符, 分n+1个子串（保留空串）
参数:
	vec-传出参数, 子串的集合;
	src-传入参数, 源字符串;
	delim-传入参数, 分隔符;
返回值:
	0-成功;
	其它-失败;
理论上，此函数速度会慢（没有测试）
*/
int stringSplit(std::vector<std::string> &vec, const std::string &src, const char &delim)
{
	int src_len = src.length();
	int find_cursor = 0;
	int read_cursor = 0;

	if (src_len <= 0) return -1;

	vec.clear();
	while (read_cursor < src_len){

		find_cursor = src.find(delim, find_cursor);

		//1.找不到分隔符
		if (-1 == find_cursor){
			//if (read_cursor <= 0) return -1;

			//最后一个子串, src结尾没有分隔符
			if (read_cursor < src_len){
				vec.push_back(src.substr(read_cursor, src_len - read_cursor));
				return 0;
			}
		}
		//2.有连续分隔符的情况
		else if (find_cursor == read_cursor){
			//字符串开头为分隔符, 也按空子串处理, 如不需要可加上判断&&(read_cursor!=0)
			vec.push_back(std::string(""));
		}
		//3.找到分隔符
		else
			vec.push_back(src.substr(read_cursor, find_cursor - read_cursor));

		read_cursor = ++find_cursor;
		if (read_cursor == src_len){
			//字符串以分隔符结尾, 如不需要末尾空子串, 直接return
			vec.push_back(std::string(""));
			return 0;
		}
	}//end while()

	return 0;
}

/****************************************
* stringSplit函数会把连续的多个分隔符中，三个分隔拆成一分隔符字串
* 如：将"122,,,12",stringSplit会拆成“122”、“，”、“12”
* 本函数解决这个问题，拆成：“122”、“”、“”、“12”
* 此函数可以保留空串
****************************************/
void stringSplit(const char *str, vector<string> &res, const char c)
{
	char	*s;
	int		i, j, n;

	res.clear();
	n = strlen(str);
	s = new char[n + 1];
	s[0] = '\0';
	j = 0;
	for (i = 0; i < n; i++){
		if (str[i] == c) {
			s[j] = '\0';
			res.push_back(s);
			s[0] = '\0';
			j = 0;
		}
		else s[j++] = str[i];
	}
	s[j] = '\0';
	res.push_back(s);

	delete[] s;
}

/****************************************
* stringSplit函数会把连续的多个分隔符中，三个分隔拆成一分隔符字串
* 如：将"122,,,12",stringSplit会拆成“122”、“，”、“12”
* 本函数解决这个问题，拆成：“122”、“”、“”、“12”
* 此函数可以保留空串
****************************************/
void stringSplit(const char *str, vector<char*> &res, const char c)
{
	char	*s, *d;
	int		i, j, n;

	res.clear();
	n = strlen(str);
	s = new char[n + 1];
	*s = '\0';
	j = 0;
	for (i = 0; i < n; i++){
		if (*(str+i) == c) {
			*(s + j) = '\0';	
			d = new char[j + 1];
			strcpy(d, s);
			res.push_back(d);
			*s = '\0';
			j = 0;
		}
		else *(s + j++) = *(str + i);
	}
	*(s + j) = '\0';
	d = new char[j + 1];
	strcpy(d, s);
	res.push_back(d);

	delete[] s;
	//delete[] d;	// cannot delete, or the last one will be lost
}

/****************************************
* 把字符串str中的所有old_value唯一地用new_value替换。
* 如：将"12212"这个字符串的所有"12"都替换成"21"，得“21221”
* 实测，函数速度很慢
****************************************/
string& replace_all_distinct(string& str, const string& old_value, const string& new_value)   
{   
	for(string::size_type pos(0); pos != string::npos; pos+=new_value.length()) {   
		if((pos=str.find(old_value,pos)) != string::npos)   
			str.replace(pos, old_value.length(), new_value);   
		else break;   
	}   
	return str;   
}   

/****************************************
* 把字符串str中的所有cOld字符用字符cNew替换。
* 如：将"12212"这个字符串的所有'1'都替换成'3'，得“32232”
* 仅做字符替换，建议用此函数
****************************************/
string& replaceChar(string& str, const char cOld, const char cNew)
{
	unsigned int	i;

	for(i = 0; i < str.size(); i++) if(str[i] == cOld) str[i] = cNew;

	return str;
}

/****************************************
* 统计字符串str1中字符串str2的个数。
****************************************/
int stringCount(string &str1, string &str2)
{
	if (str1.length() == 0 || str2.length() == 0) return -1;

	int		iPos = 0;
	int		iCnt = 0;

	while(1) {
		iPos = str1.find(str2, iPos);
		if(iPos == string::npos) break;
		iPos++;
		iCnt++;
	}
	return iCnt;
}

/****************************************
* 统计字符串str1中字符c的个数。
****************************************/
int charCount(string &str, const char c)
{
	if (c == '\0' || str.length() == 0) return -1;

	int		i, iCnt = 0;

	for (i = 0; i < (int)str.length(); i++){
		if (str[i] == c) iCnt++;
	}
	return iCnt;
}

// 此函数会报错
size_t stringRFind(const string& strContent, const string& strToFind, size_t nStartPos)
{
	size_t nToFindLen = strToFind.length();
	if (nStartPos == string::npos) nStartPos = strContent.length() - 1;
	//no enough charactor to compare
	if ((nStartPos < nToFindLen) || (nStartPos >= strContent.length()))
	{
		return string::npos;
	}
	//iterator to begin of the strContent
	string::const_iterator itContentBegin = strContent.begin();
	//iterator to last charactor of the strToFind
	string::const_iterator itToFindEnd = strToFind.begin() + nToFindLen - 1;
	//iterator to current scan charactor in strToFind
	string::const_iterator itCharInToFind = itToFindEnd;
	//iterator to current scan charactor in strContent
	string::const_iterator itCharInContent = itContentBegin + nStartPos;
	//matched charactors number
	size_t nCharMatched = 0;
	//repeat charactor with first charactor in strToFind
	size_t nNoRepeatLen = 1;
	itCharInToFind--;
	while ((nNoRepeatLen != nToFindLen) && ((*itCharInToFind) != (*itToFindEnd)))
	{
		nNoRepeatLen++;
		itCharInToFind--;
	}
	itCharInToFind = itToFindEnd;
	//the for loop will not stop at itCharInContent == itContentBegin, because maybe (*itContentBegin) == (*itCharInToFind)
	for (; nCharMatched != nToFindLen; itCharInContent--)
	{
		//compare string
		while ((*itCharInContent) == (*itCharInToFind))
		{
			nCharMatched++;
			if ((itCharInContent == itContentBegin) || (nCharMatched == nToFindLen))
			{
				break;
			}
			itCharInContent--;
			itCharInToFind--;
		}
		//all charactor match, or no content to search
		if ((itCharInContent == itContentBegin) || (nCharMatched == nToFindLen))
		{
			break;
		}
		//only nCharMatched charactors match
		if (nCharMatched > 0)
		{
			//move back only when match char num large than no repeat char in strToFind
			if (nCharMatched > nNoRepeatLen)
			{
				itCharInContent += nCharMatched;
			}
			else
				itCharInContent += 1;
			itCharInToFind = itToFindEnd;
			nCharMatched = 0;
		}
	}
	//all charactor match
	if (nCharMatched == nToFindLen)
	{
		return itCharInContent - itContentBegin;
	}
	//string no found
	return string::npos;
}

size_t stringFind( const string& strContent, const string& strToFind, size_t nStartPos)
{
	size_t nToFindLen = strToFind.length();
	//no enough charactor to compare
	if (nStartPos + nToFindLen >= strContent.length())
	{
		return string::npos;
	}
	//iterator to begin of the strContent
	string::const_iterator itContentBegin = strContent.begin();
	//iterator to end of the strContent
	string::const_iterator itContentEnd = strContent.begin() + strContent.length() - 1;
	//iterator to last charactor of the strToFind
	//string::const_iterator itToFindEnd = strToFind.begin() + nToFindLen - 1;
	//iterator to first charactor of the strToFind
	string::const_iterator itToFindBegin = strToFind.begin();
	//iterator to current scan charactor in strToFind
	string::const_iterator itCharInToFind = itToFindBegin;
	//iterator to current scan charactor in strContent
	string::const_iterator itCharInContent = itContentBegin + nStartPos;
	//matched charactors number
	size_t nCharMatched = 0;
	//repeat charactor with first charactor in strToFind
	size_t nNoRepeatLen = 1;
	itCharInToFind++;
	while ((nNoRepeatLen != nToFindLen) && ((*itCharInToFind) != (*itToFindBegin)))
	{
		nNoRepeatLen++;
		itCharInToFind--;
	}
	itCharInToFind = itToFindBegin;
	//the for loop will not stop at itCharInContent == itContentEnd, because maybe (*itContentEnd) == (*itCharInToFind)
	for (; nCharMatched != nToFindLen; itCharInContent++)
	{
		//compare string
		while ((*itCharInContent) == (*itCharInToFind))
		{
			nCharMatched++;
			if ((itCharInContent == itContentEnd) || (nCharMatched == nToFindLen))
			{
				break;
			}
			itCharInContent++;
			itCharInToFind++;
		}
		//all charactor match, or no content to search
		if ((itCharInContent == itContentEnd) || (nCharMatched == nToFindLen))
		{
			break;
		}
		//only nCharMatched charactors match
		if (nCharMatched > 0)
		{
			//move back only when match char num large than no repeat char in strToFind
			if (nCharMatched > nNoRepeatLen)
			{
				itCharInContent -= nCharMatched;
			}
			else
				itCharInContent -= 1;
			itCharInToFind = itToFindBegin;
			nCharMatched = 0;
		}
	}
	//all charactor match
	if (nCharMatched == nToFindLen)
	{
		return itCharInContent - itContentBegin - nToFindLen + 1;
	}
	//string no found
	return string::npos;
}


/****************************************
* 在字符串str1中提取以字符串cstr2作为分隔符的第n个字串（n从0开始编号）。
* 例：stringFind("ab cd ef gh", " ", 2) = "ef"
* 原来返回类型是string，现传入指针。现在比原来略快。
* 大文件时，本函数会越来越慢。现写法比原写法能坚持更长时间变慢。
* 网上：在实践中还发现，string::find(char)比较string::find(string)慢很多，所以建议不要使用string::find(char)
****************************************/
void getStringN(string &str1, string &str2, int n, string &ret)
{
	if (n < 0) {
		ret = "";
		return;
	}

	int i, iCnt, iPos, iLen;

	if(n == 0) {
		iPos = str1.find(str2);			// 
		//iPos = stringFind(str1, str2);	// 与标准find一样
		ret = iPos == string::npos ? str1 : str1.substr(0, iPos);
		return ;
	}

	i = iCnt = 0;
	iLen = str2.length();
	while(1) {
		iPos = str1.find(str2, i);
		//iPos = stringFind(str1, str2, i);
		if (iPos == string::npos) {
			ret = "";
			return;
		}

		i = iPos + iLen;
		iCnt++;
		if(iCnt == n) break;
	}

	iPos += iLen;
	i = str1.find(str2, iPos);
	//i = stringFind(str1, str2, iPos);
	ret = i == string::npos ? str1.substr(iPos) : str1.substr(iPos, i - iPos);
}

/****************************************
* 在字符串str1中提取以字符串cstr2作为分隔符的第n个字串（n从0开始编号）。
* 例：stringFind("ab cd ef gh", " ", 2) = "ef"
* 原来返回类型是string，现传入指针。现在比原来略快。
* 此重载超级慢，不建议使用
****************************************/
void getStringN(const char *str, const char c, int n, string &ret)
{
	if (n < 0 || n >= (int)strlen(str)) {
		ret = "";
		return;
	}

	vString	vs;

	stringSplit(str, vs, c);
	if ((int)vs.size() > n) ret = vs[n];
	else ret = "";
	
	vString().swap(vs);
}

/****************************************
* 在字符串str1中提取以字符串cstr2作为分隔符的第n个字串（n从0开始编号）。
* 例：stringFind("ab cd ef gh", " ", 2) = "ef"
* 此重载明显比 void getStringN(string &str1, const char *cstr2, int n, string &ret) 慢
****************************************/
void getStringN(int n, string &str1, const char *cstr2, string &ret)
{
	if (n < 0) {
		ret = "";
		return;
	}

	int iStart, iEnd, iLen;
	char *s;

	iLen = str1.length() + 1;
	s = new char[iLen];
	strcpy(s, str1.c_str());

	iStart = n == 0 ? 0 : charNfind(s, cstr2, n);
	iEnd = charNfind(s, cstr2, n + 1);

	if (iEnd == string::npos && iStart == string::npos) {
		ret = "";
		delete[] s;
		return;
	}

	if (iEnd == string::npos && iStart == 0) {
		ret = str1;
		delete[] s;
		return;
	}

	iLen = strlen(cstr2);
	if (n == 0){
		//ret = sub_str(s, 0, iEnd);	// 理论上这句用以下两行代替会更合理，因为以下两行会正确删除new char
		s = sub_str(s, 0, iEnd);		// 使用自定义的sub_str大文件会出错
		ret = s;
		delete[] s;
		return;
	}
	if (iEnd == string::npos) {
		s = sub_str(s, iStart + iLen);
		ret = s;
	}
	else {
		s = sub_str(s, iStart + iLen, iEnd - iStart - iLen);
		ret = s;
	}
	delete[] s;
	return;
}

// 取子串。使用时要注意res的释放
char* sub_str(const char *str, int start, int len)
{
	char*	res;
	
	if (len < 0) len = strlen(str) - start;
	res = new char[len + 1];// (char*)malloc(len + 1);
	res[len] = 0;

	memcpy(res, str + start, len);
	return res;
}

/****************************************
* 在字符串str中查找以字符c第n次（n从1开始）出现的位置。未找到（或超出个数）返回string::npos
****************************************/
int charNfind(const char *str, const char c, int n)
{
	if (n < 1) return string::npos;

	int iLen, i, j;

	iLen = strlen(str);
	if (n > iLen) return string::npos;

	j = 0;
	for (i = 0; i < iLen; i++){
		if (str[i] == c) {
			j++;
			if (j == n)return i;
		}
	}
	return string::npos;
}

/****************************************
* 在字符串str中查找以字符串cs第n次（n从1开始）出现的位置。未找到（或超出个数）返回string::npos
****************************************/
int charNfind(const char *str, const char *cs, int n)
{
	if (n < 1) return string::npos;

	int iLen1, iLen2, i, iCnt, iOff;

	iLen1 = strlen(str);
	iLen2 = strlen(cs);
	if (n * iLen2 > iLen1) return string::npos;

	iCnt = 0;
	iOff = 0;
	for (i = 0; i < iLen1; i++){
		if (str[i] == cs[iOff]){
			iOff++;
			if (iOff == iLen2){
				iCnt++;
				if (iCnt == n) return i - iLen2 + 1;
				iOff = 0;
			}
		}
	}
	return string::npos;
}

/****************************************
* 延时sec秒
****************************************/
void delayInSecond(int sec)
{
	if(sec < 0) return;

	time_t start_time, cur_time;

	time(&start_time);
	do { 
		time(&cur_time);
	} while((cur_time - start_time) < sec );
}

/****************************************
* 在str中的连续两个separator字符之间插入ins（含头尾）
* 例：“qa,,d,”，以“,”为分隔插入“w”，则结果“qa,w,d,w”
*     “,qa,,d,”，以“,”为分隔插入“wA”，则结果“wA,qa,wA,d,wA”
****************************************/
void insStr(char *str, const char separator, const char *ins)
{
	uint			i, j, k, uLen, uSize;
	vector<uint>	vPos;
	char			s[MAX_ROW_LENGTH];

	//查找源串中分隔字符的位置
	i = strlen(str);
	for(j = 0; j < i; j++) {
		if(str[j] == separator) {
			vPos.push_back(j);
		}
	}
	if(vPos.empty()) return;	//无分隔字符

	uLen = strlen(ins);
	uSize = vPos.size();

	if(vPos[0] == 0) {			//第一个是分隔符
		strcpy(s, ins);
		strcat(s, str);
		for(i = 0; i < uSize; i++) vPos[i] += uLen;	//位置后移
	} else strcpy(s, str);

	for(i = 1; i < uSize; i++) {
		if(vPos[i] == vPos[i-1] + 1) {		//连续的分隔符
			k = strlen(s);
			for(j = k; j > vPos[i-1]; j--) s[j+uLen] = s[j];	//从连续的分隔符处开始后移uLen个位置
			for(j = 0; j < uLen; j++) s[vPos[i]+j] = ins[j];	//插入字符串
			for(j = i; j < uSize; j++) vPos[j] += uLen;
		}
	}

	if(vPos[uSize-1] == strlen(s) - 1) {	//最的一个是分隔符
		strcat(s, ins);
	}

	//str是指针，不能用strcpy
	for(i = 0; i <= strlen(s); i++) str[i] = s[i];
}

/****************************************
* 文件复制
****************************************/
bool copyFile(char *desFile, char *srcFile)
{
	ifstream in;
	ofstream out;
	in.open(srcFile,ios::binary);	//打开源文件
	if(in.fail())					//打开源文件失败
	{
		cout<<"Error 1: Fail to open the source file."<<endl;
		in.close();
		in.clear();
		out.close();
		out.clear();
		return false;
	}

	out.open(desFile,ios::binary);	//创建目标文件 
	if(out.fail())					//创建文件失败
	{
		cout<<"Error 2: Fail to create the new file."<<endl;
		out.close();
		out.clear();
		in.close();
		in.clear();
		return false;
	}
	else//复制文件
	{
		out<<in.rdbuf();
		out.close();
		out.clear();
		in.close();
		in.clear();
		return true;
	}
}

/****************************************
* 比较字串str1 和 str2，并返回差异列号
* 返回的列号从0开始计数（若无差异返回string::npos）
****************************************/
int stringCmp(const string &str1, const string &str2, char cDelimiter)
{
	if (str1 == str2) return string::npos;

	vString	vs1, vs2;
	int		i, n1, n2;

	stringSplit(str1.c_str(), vs1, cDelimiter);
	stringSplit(str2.c_str(), vs2, cDelimiter);

	n1 = vs1.size(); n2 = vs2.size();
	if (n1 > n2){
		for (i = 0; i < n2; i++){
			if (vs1[i] != vs2[i]){
				vString().swap(vs1);
				vString().swap(vs2);

				return i;
			}
		}
	}
	else{
		for (i = 0; i < n1; i++){
			if (vs1[i] != vs2[i]){
				vString().swap(vs1);
				vString().swap(vs2);

				return i;
			}
		}
	}

	vString().swap(vs1);
	vString().swap(vs2);

	if (n1 == n2) return string::npos;
	else if (n1 > n2) return n2;
	else return n1;
}

/****************************************
* Windows下获取剩余物理内存（Linux下注释之）
* 返回KB
****************************************
unsigned long int getFreeMemory()
{
	MEMORYSTATUSEX ms;
	ms.dwLength = sizeof(ms);

	GlobalMemoryStatusEx(&ms);

	return (unsigned long int)(ms.ullAvailPhys / 1024);
}

/****************************************
* Linux下获取剩余物理内存（Windows下注释之）
* 返回KB
****************************************/
static char * os_getline(char *sin, os_line_data * line, char delim)
{
	char *out = sin;

	if (*out == '\0') return NULL;

	//	while (*out && (*out == delim)) { out++; }
	line->val = out;
	while (*out && (*out != delim)) { out++; }

	line->len = out - line->val;
	//	while (*out && (*out == delim)) { out++; }
	if (*out && (*out == delim)) { out++; }

	if (*out == '\0') return NULL;

	return out;
}
/***************/
/**********************/
int Parser_EnvInfo(char * buffer, int size, MEM_OCCUPY * lpMemory)
{
	int		state = 0;
	char	*p = buffer;

	while (p)
	{
		os_line_data       line = { 0 };
		p = os_getline(p, &line, ':');
		if (p == NULL || line.len <= 0) continue;

		if (line.len == 8 && strncmp(line.val, "MemTotal", 8) == 0)
		{
			char *point = strtok(p, " ");
			memcpy(lpMemory->name1, "MemTotal", 8);
			lpMemory->MemTotal = atol(point);

		}
		else if (line.len == 7 && strncmp(line.val, "MemFree", 7) == 0)
		{
			char *point = strtok(p, " ");
			memcpy(lpMemory->name2, "MemFree", 7);
			lpMemory->MemFree = atol(point);
		}
		else if (line.len == 7 && strncmp(line.val, "Buffers", 7) == 0)
		{
			char *point = strtok(p, " ");
			memcpy(lpMemory->name3, "Buffers", 7);
			lpMemory->Buffers = atol(point);
		}
		else if (line.len == 6 && strncmp(line.val, "Cached", 6) == 0)
		{
			char *point = strtok(p, " ");
			memcpy(lpMemory->name4, "Cached", 6);
			lpMemory->Cached = atol(point);
		}

	}
	return 0;
}
/*******************/
/*******************/
int  get_procmeminfo(MEM_OCCUPY * lpMemory)
{
	FILE *fd;
	char buff[128] = { 0 };
	char* i;

	fd = fopen("/proc/meminfo", "r");

	if (fd <0) return -1;

	i = fgets(buff, sizeof(buff), fd);
	Parser_EnvInfo(buff, sizeof(buff), lpMemory);

	i = fgets(buff, sizeof(buff), fd);
	Parser_EnvInfo(buff, sizeof(buff), lpMemory);

	i = fgets(buff, sizeof(buff), fd);
	Parser_EnvInfo(buff, sizeof(buff), lpMemory);

	i = fgets(buff, sizeof(buff), fd);
	Parser_EnvInfo(buff, sizeof(buff), lpMemory);

	fclose(fd);
	return 0;
}
/***************************************************/

/****************************************
* 获取文件大小
* 返回字节数及ret（false失败）
****************************************/
unsigned long int getFileSize(string &fn, bool *ret)
{
	struct stat	info;
	int				i;

	i = stat(fn.c_str(), &info);

	if (i != 0)
	{
		perror("Problem getting information");
		switch (errno)
		{
		case ENOENT:
			printf("File %s not found.\n", fn.c_str());
			break;
		case EINVAL:
			printf("Invalid parameter to _stat.\n");
			break;
		default:
			/* Should never be reached. */
			printf("Unexpected error in _stat.\n");
		}

		*ret = false;
		return 0;
	}
	else{
		*ret = true;
		return info.st_size;
	}
}
