//////////////////////////////////////////////////////////////////
//                                                              //
//           coPLINK (c) 2020-2024 Han-Ming LIU                 //
//                                                              //
// This file is distributed under the GNU General Public        //
// License, Version 3.  Please see the file COPYING for more    //
// details                                                      //
//                                                              //
//////////////////////////////////////////////////////////////////

#ifndef _H_OPTIONS_H
#define	_H_OPTIONS_H

/********************** 程序参数 ***********************/
// 各参数的说明可能随着程序的修改而使功能发生变化，以程序为准（“参数列表.doc”也有说明）
//操作代码（增减参数须须修改以下两个宏，同时修改变量sArgs和sHelps定义）
#define	OP_CNT			45					// 操作参数个数
#define	ARG_CNT			(OP_CNT + 16)		// 参数总分数

#define	OP_PED2BED		"--ped2bed"			// PLINK ped文本格式转PLINK二进制格式bed
#define	OP_PED2BOOST	"--ped2boost"		// PLINK ped文本格式转BOOST格式（包括linkage格式转BOOST。linkage格式：
											// 用1、2、3、4、0表示A、C、G、T、MISSING，其余同Plink的PED文件）
#define	OP_PED2ME		"--ped2me"			// PLINK ped文本格式转ME格式（同 --p2b）
#define	OP_PED2BEAM		"--ped2beam"		// PLINK ped文本格式转BEAM格式（同 --p2b）
#define	OP_PED2GEO		"--ped2geo"			// PLINK ped文本格式转geo格式
#define	OP_GEO2PED		"--geo2ped"			// geo格式转PLINK ped文本格式
#define	OP_PED2MDR		"--ped2mdr"			// PLINK ped文本格式转MDR格式（同 --p2b）
#define	OP_PED2LINK		"--ped2linkage"		// PLINK ped文本格式转Linkage格式
#define	OP_PED2GSLINK	"--ped2gs-linkage"	// PLINK ped文本格式转GS Linkage格式
#define	OP_PED2LOG		"--ped2logicreg"	// PLINK ped文本格式转LogicReg格式
#define	OP_PED2SVM		"--ped2svmsnp"		// 转PLINK ped文本格式为SVMSNP格式
#define	OP_SVM2PED		"--svmsnp2ped"		// 转SVMSNP格式为PLINK ped文本格式
#define	OP_PED2PED		"--ped2ped"			// PLINK ped文本格式转PLINK ped文本格式（此命令仅用于 --sex、 --pre指示参数）
#define	OP_PED2TPED		"--ped2tped"		// PLINK ped格式转tped格式
#define	OP_BED2BEAM		"--bed2beam"		// PLINK ped二进制格式转BEAM格式
#define	OP_BED2ME		"--bed2me"			// PLINK ped二进制格式转ME格式
#define	OP_BED2TPED		"--bed2tped"		// PLINK bed格式转tped格式
#define	OP_BED2BOOST	"--bed2boost"		// PLINK bed格式转BOOST格式
#define	OP_ME2PED		"--me2ped"			// ME（最大熵）格式转PLINK ped文本格式
#define	OP_ME2BOOST		"--me2boost"		// ME（最大熵）格式转BOOST文本格式
#define	OP_BOOST2PED	"--boost2ped"		// BOOST格式转文本PLINK ped格式
#define	OP_BOOST2BED	"--boost2bed"		// BOOST格式转文本PLINK ped格式
#define	OP_BEAM2PED		"--beam2ped"		// 把BEAM格式转成PLINK ped文本格式
#define	OP_BEAM2BOOST	"--beam2boost"		// 把BEAM格式转BOOST文本格式
#define	OP_MDR2PED		"--mdr2ped"			// MDR格式转PLINK ped文本格式
#define	OP_MDR2BOOST	"--mdr2boost"		// MDR格式转BOOST文本格式
#define	OP_PRETTY2PED	"--pretty2ped"		// 转prettybase格式为Plink ped文本
#define	OP_PED2PRETTY	"--ped2pretty"		// 转Plink ped文本为prettybase格式（仅支持新版格式）
#define	OP_TPED2PED		"--tped2ped"		// PLINK tped格式转PLINK ped格式（若存在与输入文件同名的tsnp文件，则从
											// 该文件读取SNP信息，否则，直接从tped文件中读取），同时归一化输出（由 -- nor指示参数确定）。
											// 注意：tped格式文件中不包含性别信息
#define	OP_TPED2BED		"--tped2bed"		// PLINK tped格式转PLINK bed格式（其它同--tped2ped）
#define OP_TPED2USR_TPED	"--tped2usr-tped" // PLINK tped格式转自定义ted格式（tped中的基因型用0、1、2分别表示AA、Aa/aA、aa，其余同标准tped）
#define	OP_LINK2BOOST	"--linkage2boost"	// LINKAGE格式转BOOST文本格式
#define	OP_LINK2PED		"--linkage2ped"		// LINKAGE格式转PLINK ped文本格式
#define	OP_LOG2PED		"--logicreg2ped"	// LogicReg 格式转PLINK ped文本格式
#define	OP_GSLINK2PED	"--gs-linkage2ped"	// GWASimulator GWAS数据模拟器生成的linkage格式转Plink Ped文本格式
#define	OP_SPC2CSV		"--space2csv"		// 把空格分隔的文本文件转成CSV格式
#define	OP_CSV2SPC		"--csv2space"		// 把CSV格式转成空格分隔的文本文件

#define	OP_SPLPED		"--splice-ped"		// 把另一个ped格式文件B（由指示参数 -- sfn指定）的个体拼接到当前ped文件A
											//（此参数之后所跟文件）。拼接方法：以A文件的SNP为基准，把B文件的样
											// 本拼接于A文件之后。B文件中不存在的SNP标示为MISSING。指示参数ID_PHENO
											// 可用于指定B文件中的表型； --nor指定是否归一化
#define	OP_TEST_ALLELE	"--test-allele"		// 测试指定文件中所有ped文件夹中杂合子的等位基因组成，如Aa aA。此时，inputFilename指文件夹
#define	OP_COMPARE		"--compare"			// 两个文件比较（第二个文件名由--file2提供），并显示不同的行数（文本方式）或字节数（二进制方式）。
#define	OP_OTHER2PED	"--other2ped"		// 任意其它格式转ped格式
#define	OP_PED2OTHER	"--ped2other"		// ped格式转任意其它格式
#define	OP_TRANSPOSE	"--transpose"		// 任意文本格式文件转置（结果文件中会清除源文件中多余的空格或TAB）
#define	OP_DELETE		"--delete"			// 删除文本格式文件指定的列或行（结果文件中会清除源文件中多余的空格或TAB）
#define	OP_INSERT		"--insert"			// 为文本格式文件插入指定的列或行（结果文件中会清除源文件中多余的空格或TAB）


// 指示参数（此类参数用于辅助操作参数）：
#define	ID_SEED			"--seed"			// 随机数种子（缺省或0为time）
#define	ID_RND_SEX		"--rnd-sex"			// 随机生成个体性别（主要用于输出为PLINK ped文本格式。有此参数则表示是。
											// 当前仅用于 --p2p、 --t2p。PLINK不会处理“未知性别”的个体）
#define	ID_MODE			"--mode"			// A. 转PLINK ped文本格式为SVMSNP格式，指定转换方式（默认为0）
											// B. 文件比较时指定比较方式（默认0）
											// C. --ped2tped时指定输出文件格式（默认0）
											// 更多参阅“参数列表.doc”
#define	ID_MEMO			"--memo"			// 加入备注（若x中包含空格，则需要用双引号把x括起来）
#define	ID_MODEL		"--model"			// 转LogicReg格式时指定是加性、显性或隐性模型（分别用0、1、2表示）。缺省时为加性模型
#define	ID_CHR_NO		"--chr-no"			// 指定染色编号(1 - 22, X, Y)。缺省为0
#define	ID_PRE			"--pre"				// 是否对生成结果作预处理（有此参数则表示是。支持的OPTION见“参数列表.doc”
											//	有关“预处理”见后续说明
											//	特别注意：当为“ --p2p”时， --pre后跟参数值为“0”表示不生成预处理输出
											//	文件（若有 --sex参数，仍然有结果文件输出，只是结果文件中不包含预处理结
											//	果），为“1”（或其它值、或空）则生成预处理结果输出文件。
#define	ID_HWE			"--hwe"				// HWE检验阀值（默认0.001。GWAS等多MARKER一般用0.001或0.0001，而单MARKER
											//	一般为0.01）。此参数配合 --pre使用
#define	ID_NOR			"--nor"				// 当涉及到Plink Ped格式文件时（无论输入或输出），是否归一化ped格式（默认否，
											//	有此参数＝是、无此参数＝否）当前支持所有输入为ped格式，而输出为ped的只支持 --t2p
											//	所谓“归一化”即规范化，是指把minor allele和major allele分别用“d”和
											//	“D”表示，缺失用“N”表示（allele字符多于1个也当作缺失）。且用一个空格
											//	分隔（会删除多余的）
#define	ID_PHENO		"--phenotype"		// 转换时是否将表型固定为指定值（默认否）。有此参数为是，且后跟指定值。
											//	指定值有：1 = 对照、2 = 疾病、0 = 未知；若所跟指定值非有效，则默认0
#define	ID_FILE2		"--file2"			// 第二文件名（如定拼接文件名（与操作参数 --spl配套使用））
#define	ID_OUT_FN		"--out"				// 输出文件名（输出为PLINK ped格式时，会忽略扩展名。其它情况，若无扩展名，则使用默认的扩展名）
#define	ID_SWAP			"--swap"			// 当SNP minor和major等位基因数量相同时，此时某些格式（如BOOST）会有两种可能的结果，
											//	此参数用于产生另一种可能的结果。注：事实上，
											//	两种结果本质上是一样的。本参数的目的主要用以比较转换结果的一致性。
#define	ID_DELIM		"--delim"			// 指定行数据分隔符（即列分隔符）（默认空格）
#define	ID_COL			"--col"				// 指定文本文件的列号
#define	ID_ROW			"--row"				// 指定文本文件的行号
/**************************************************/

// 操作参数
#define	ARG_OPTIONS	\
	OP_PED2BED,\
	OP_PED2BOOST,\
	OP_PED2ME,\
	OP_PED2BEAM,\
	OP_PED2GEO,\
	OP_GEO2PED,\
	OP_PED2MDR,\
	OP_PED2LOG,\
	OP_PED2SVM,\
	OP_SVM2PED,\
	OP_PED2PED,\
	OP_ME2PED,\
	OP_ME2BOOST,\
	OP_BOOST2PED,\
	OP_BOOST2BED,\
	OP_BEAM2PED,\
	OP_BEAM2BOOST,\
	OP_MDR2PED,\
	OP_MDR2BOOST,\
	OP_PRETTY2PED,\
	OP_PED2PRETTY,\
	OP_TPED2PED,\
	OP_TPED2BED,\
	OP_TPED2USR_TPED,\
	OP_PED2TPED,\
	OP_BED2TPED,\
	OP_LINK2BOOST,\
	OP_LINK2PED,\
	OP_LOG2PED,\
	OP_GSLINK2PED,\
	OP_SPC2CSV,\
	OP_CSV2SPC,\
	OP_BED2BEAM,\
	OP_BED2ME,\
	OP_BED2BOOST,\
	OP_SPLPED,\
	OP_TEST_ALLELE,\
	OP_COMPARE,\
	OP_OTHER2PED,\
	OP_PED2OTHER,\
	OP_TRANSPOSE,\
	OP_DELETE,\
	OP_INSERT,\
	OP_PED2LINK,\
	OP_PED2GSLINK

// 操作参数说明
#define	HELP_OPTIONS	\
	"   *Parameters:\n\t"OP_BEAM2BOOST": convert BEAM to BOOST\n\t"\
	OP_BEAM2PED": convert BEAM to Plink ped\n\t"\
	OP_BED2BEAM": convert Plink bed to BEAM\n\t"\
	OP_BED2BOOST": convert Plink bed to BOOST\n\t"\
	OP_BED2ME": convert Plink bed to ME\n\t"\
	OP_BED2TPED": convert Plink bed to tped\n\t"\
	OP_BOOST2BED": convert BOOST to Plink bed\n\t"\
	OP_BOOST2PED": convert BOOST to Plink ped\n\t"\
	OP_COMPARE": compare two files\n\t"\
	OP_CSV2SPC": convert CSV to file with space delimiter\n\t"\
	OP_DELETE": delete columns/rows from a plain-text file\n\t"\
	OP_GEO2PED": convert geo to Plink ped\n\t"\
	OP_GSLINK2PED": convert GWASimulator Linkage to Plink ped\n\t"\
	OP_INSERT": insert columns/rows into a plain-text file\n\t"\
	OP_LINK2BOOST": convert Linkage to BOOST\n\t"\
	OP_LINK2PED": convert Linkage to Plink ped\n\t"\
	OP_LOG2PED": convert LogicReg to Plink ped\n\t"\
	OP_MDR2BOOST": convert MDR to BOOST\n\t"\
	OP_MDR2PED": convert MDR to Plink ped\n\t"\
	OP_ME2BOOST": convert ME to BOOST\n\t"\
	OP_ME2PED": convert ME to Plink ped\n\t"\
	OP_OTHER2PED": convert other format to Plink ped\n\t"\
	OP_PED2BEAM": convert Plink ped to BEAM\n\t"\
	OP_PED2BED": convert Plink ped to bed\n\t"\
	OP_PED2BOOST": convert Plink ped to BOOST\n\t"\
	OP_PED2GEO": convert Plink ped to geo\n\t"\
	OP_PED2GSLINK": convert Plink ped to GWASimulator Linkage\n\t"\
	OP_PED2LINK": convert Plink ped to Linkage\n\t"\
	OP_PED2LOG": convert Plink ped to LogicReg\n\t"\
	OP_PED2MDR": convert Plink ped to MDR\n\t"\
	OP_PED2ME": convert Plink ped to ME\n\t"\
	OP_PED2OTHER": convert Plink ped to other format (indicator "ID_FILE2" specifies the inputted PED)\n\t"\
	OP_PED2PED": normalize genotypes ("ID_NOR"), swap genotypes ("ID_SWAP"), generate sex randomly ("ID_RND_SEX") or pre-process to Plink ped ("ID_PRE")\n\t"\
	OP_PED2PRETTY": convert Plink ped to PrettyBase\n\t"\
	OP_PED2SVM": convert Plink ped to SVMSNPs\n\t"\
	OP_PED2TPED": convert Plink ped to tped\n\t"\
	OP_PRETTY2PED": convert PrettyBase to Plink ped\n\t"\
	OP_SPC2CSV": convert file with space delimiter to CSV\n\t"\
	OP_SPLPED": splice two Plink ped files\n\t"\
	OP_SVM2PED": convert SVMSNPs to Plink ped\n\t"\
	OP_TEST_ALLELE": test composition of heterozygotes in folder\n\t"\
	OP_TPED2BED": convert Plink tped to bed\n\t"\
	OP_TPED2PED": convert Plink tped to ped\n\t"\
	OP_TPED2USR_TPED": convert Plink tped to user defined tped\n\t"\
	OP_TRANSPOSE": transpose a plain-text file"


//指示参数
#define	ARG_INDICATORS	\
	ID_SEED,\
	ID_RND_SEX,\
	ID_MEMO,\
	ID_MODE,\
	ID_MODEL,\
	ID_CHR_NO,\
	ID_PRE,\
	ID_HWE,\
	ID_NOR,\
	ID_PHENO,\
	ID_FILE2,\
	ID_OUT_FN,\
	ID_SWAP,\
	ID_DELIM,\
	ID_COL,\
	ID_ROW

// 指示参数说明
#define	HELP_INDICATORS	\
	"   *Indicators:\n\t"ID_CHR_NO": specify chr. No. while converting to ped (default 0)\n\t"\
	ID_COL": specify colum No. or an interval of columns (default 0)\n\t"\
	ID_DELIM": specify delimiter of columns for input or output file (default \' \')\n\t"\
	ID_FILE2": specify the second input file\n\t"\
	ID_HWE": cut-off of HWE (default 0.001)\n\t"\
	ID_MEMO": specify memo (A pair of \" is necessary while meeting a space in memo)\n\t"\
	ID_MODE": specify converting mode\n\t"\
	ID_MODEL": specify genetic model while converting to LogicReg (0-Additive, 1-Dominant, 2-Recessive; default 0)\n\t"\
	ID_NOR": specify to normalize output\n\t"\
	ID_OUT_FN": output file name\n\t"\
	ID_PHENO": specify replacing phenotype for input or output file (default 0)\n\t"\
	ID_PRE": specify to preprocess to input file\n\t"\
	ID_RND_SEX": generate gender randomly\n\t"\
	ID_ROW": specify row No. or an interval of rows\n\t"\
	ID_SEED": random seed (default or 0 is current time)\n\t"\
	ID_SWAP": swap minor and major alleles when the numbers of them are identical"


// 参数备注
#define	HELP_ARGS_MEMO	\
"Note: 1. The parameters may be arbitrary order and case insensitive.\n\
      2. The extension should be removed if the output is format Plink.\n\
      And, appending the default extensions of files is suggested except for format Plink."

#endif // !_H_OPTIONS_H
