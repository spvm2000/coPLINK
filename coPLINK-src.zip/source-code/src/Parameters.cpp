//////////////////////////////////////////////////////////////////
//                                                              //
//           coPLINK (c) 2020-2024 Han-Ming LIU                 //
//                                                              //
// This file is distributed under the GNU General Public        //
// License, Version 3.  Please see the file COPYING for more    //
// details                                                      //
//                                                              //
//////////////////////////////////////////////////////////////////

#include "coPLINK.h"

namespace coPLINK
{
	/*******************************************
	* 在sArgs中查找arg的下标
	* 没有找到返回-1
	********************************************/
	int parameters::findArg(string &arg)
	{
		for (int i = 0; i < ARG_CNT; i++){
			if (sArgs[i] == arg) return i;
		}
		return -1;
	}

	parameters::parameters(int argc, char **argv)
	{
		int i;

		//指定默认参数
		iOpCode = -1;
		iModel = ADDITIVE;
		sChrNo = "0";	// unplaced
		iMode = 0;
		sInputFilename = sOutputFilename = sFilename2 = "";
		bPreprocess = false;
		uRndSeed = (uint)time(NULL);
		bSex = false;
		bNormalize = false;
		dHweCutoff = HWE_THRESHOLD;
		dMafSnpCutoff = MAF_MISSING_THRESHOLD;
		bFixPhenotype = false;
		cPhenotype = PLNK_PED_UNKNOWN_PHENOTYPE;
		bSwap = false;
		cDelimeter = ' ';
		iColumn[0] = iColumn[1] = 0;
		iRow[0] = iRow[1] = 0;
		bHWEexact = false;
		bNorOn = true;
		bPed2BedNor = false;
#ifdef TEST_PERFORMANCE
		uInSize = -1;
#endif
		checkArgs(argc, argv);

		string stmp1;
		string stmp2;
		mString mArgs;

		for (i = 1; i < argc; i++) {
			if (argv[i][0] == DELIMITER1 && argv[i][1] == DELIMITER1) {
				stmp1 = argv[i];
				string2Lower(stmp1);		//转小写
				stmp2 = i + 1 < argc && !(argv[i + 1][0] == DELIMITER1 && argv[i + 1][1] == DELIMITER1) ? argv[i + 1] : "";
				mArgs.insert(make_pair(stmp1, stmp2));
			}
		}

		parseArgs(mArgs);

		bool b = access(STAT_FN, 0) == -1;

		openStreamFile(fpStat, STAT_FN, ios::out | ios::app);
		if (!fpStat.good()){
			cout << "The statitic file " << STAT_FN << " open/create is failed." << endl;
			exit(1);
		}

		if (b){	// 文件不存在
			fpStat << "Created at " << getDT() << " via " << VERSION << endl << endl;
			fpStat << "Parameter,file,case,control,SNP" << endl;
		}
	}

	parameters::~parameters()
	{
		if (fpStat) fpStat.close();

		if (fpLog) fpLog.close();
	}

	/********************************************
	* 查找参数值
	* searchedArg = 被查找参数，如“--chr”等
	* 返回被查找参数对应的值。
	* 如参数:--chr 11，查找结果为“11”
	*********************************************/
	string parameters::findArgValue(mString& mapArgs, string searchedArg)
	{
		string result = "";

		mString::iterator itr = mapArgs.find(searchedArg);

		if (itr != mapArgs.end()) {
			result = itr->second;
		}

		return result;
	}


	/*******************************************
	* 检查参数的有效性，必须是单数个且>=3
	********************************************/
	void parameters::checkArgs(int argc, char** argv)
	{
		bool bOk = true;
		string arg = "", stmp;
		char c[2];
		int i;

		if (argc < 3) bOk = false;

		if (bOk) {
			for (i = 1; i < argc; i++) {
				c[0] = argv[i][0];
				c[1] = argv[i][1];
				stmp = argv[i];
				string2Lower(stmp);			//转小写
				if (c[0] == DELIMITER1 && c[1] == DELIMITER1 && findArg(stmp) == -1) {
					arg = argv[i];
					bOk = false;
					break;
				}
			}
		}

		if (!bOk) {
			if (arg.length() == 0){
				cout << "Invalid parameter!" << endl;
			}
			else{
				cout << "Invalid parameter " << arg << "!" << endl;
			}

			displayHelp();
			cout << "\nI will exit after 20 seconds." << endl;
			delayInSecond(20);
			exit(1);
		}
	}

	/***************************************************
	* 读取参数文件
	* vstPed6map = （隐含）Ped文件的前6列及Map的4列参数
	* struGenotype = （隐含）基因型数据参数
	* fn = 参数文件名
	* sType = 参数文件类型名（操作参数名称）
	* 注：参数文件中的坐标按左上角为原点（1,1），这仅对左、上坐标
	*     以原点（0,0）转换，右、下坐标保持不变以利于后续程序编写。
	*     但若右、下从标为负，则没有转换
	****************************************************/
	void parameters::readArgs(string fn, string sType)
	{
		string		sLine;
		vString		vsTmp, mat;
		vvString	vec, ins;
		fstream		fp;
		int			i;
		bool		b = true;

		cout << "Reading arguments file " << fn << " ..." << endl;

		openStreamFile(fp, fn.c_str(), ios::in);		//以流方式打开输入文件

		while (getline(fp, sLine)) {
			trimString(sLine);							//删除前后空格及TAB
			if (sLine[0] == '#') continue;				//“#”开头为注释

			trimRedundance(sLine, true);				//删除中间多余空格及TAB（只保留一个），并把所有TAB用空格替换掉（为分拆作准备）
			if (sLine.length() == 0) continue;

			if (sLine == SECTION_VECTOR){
				while (getline(fp, sLine)) {
					trimString(sLine);							//删除前后空格及TAB
					if (sLine[0] == '#') continue;				//“#”开头为注释

					trimRedundance(sLine, true);				//删除中间多余空格及TAB（只保留一个），并把所有TAB用空格替换掉
					if (sLine.length() == 0) continue;

					if (sLine == SECTION_VECTOR_END) break;

					// replace user-defined escape character "\," with '\b'
					for (i = 0; i < (int)sLine.length() - 1; i++){
						if (sLine[i] == '\\' && sLine[i + 1] == ','){
							sLine[i] = ESC_COMMA;
							sLine[i + 1] = ESC_COMMA;
						}
					}
					//stringSplit(sLine, vsTmp, ",");				//以,为分隔符分拆sLine（此函数会忽略空串）
					stringSplit(sLine.c_str(), vsTmp, ',');			//以,为分隔符分拆sLine（此函数会保留空串）
					for (i = 0; i < (int)vsTmp.size(); i++){ trimString(vsTmp[i]); }	// remove spaces and tabs both ends of the string
					vec.push_back(vsTmp);
					vsTmp.clear();
				}
			}
			else if (sLine == SECTION_MATRIX && b){
				while (getline(fp, sLine)) {
					trimString(sLine);							//删除前后空格及TAB
					if (sLine[0] == '#') continue;				//“#”开头为注释

					trimRedundance(sLine, true);				//删除中间多余空格及TAB（只保留一个），并把所有TAB用空格替换掉（为分拆作准备）
					if (sLine.length() == 0) continue;

					if (sLine == SECTION_MATRIX_END) break;

					// replace user-defined escape character "\," with '\b'
					for (i = 0; i < (int)sLine.length() - 1; i++){
						if (sLine[i] == '\\' && sLine[i + 1] == ','){
							sLine[i] = ESC_COMMA;
							sLine[i + 1] = ESC_COMMA;
						}
					}
					//stringSplit(sLine, vsTmp, ",");				//以,为分隔符分拆sLine（此函数会忽略空串）
					stringSplit(sLine.c_str(), vsTmp, ',');			//以,为分隔符分拆sLine（此函数会保留空串）
					for (i = 0; i < (int)vsTmp.size(); i++){ trimString(vsTmp[i]); }	// remove spaces and tabs both ends of the string

					mat.assign(vsTmp.begin(), vsTmp.end());
					vsTmp.clear();
					b = false;	// only one line will be get
					break;
				}
			}
			else if (sLine == SECTION_INSERT && (sType == OP_PED2OTHER || sType == OP_INSERT)){
				while (getline(fp, sLine)) {
					trimString(sLine);							//删除前后空格及TAB
					if (sLine[0] == '#') continue;				//“#”开头为注释

					trimRedundance(sLine, true);				//删除中间多余空格及TAB（只保留一个），并把所有TAB用空格替换掉（为分拆作准备）
					if (sLine.length() == 0) continue;

					if (sLine == SECTION_INSERT_END) break;

					// replace user-defined escape character "\," with '\b'
					for (i = 0; i < (int)sLine.length() - 1; i++){
						if (sLine[i] == '\\' && sLine[i + 1] == ','){
							sLine[i] = ESC_COMMA;
							sLine[i + 1] = ESC_COMMA;
						}
					}
					//stringSplit(sLine, vsTmp, ",");				//以,为分隔符分拆sLine（此函数会忽略空串）
					stringSplit(sLine.c_str(), vsTmp, ',');			//以,为分隔符分拆sLine（此函数会保留空串）
					for (i = 0; i < (int)vsTmp.size(); i++){ trimString(vsTmp[i]); }	// remove spaces and tabs both ends of the string

					ins.push_back(vsTmp);
					vsTmp.clear();
				}
			}
		}
		sLine = "";
		fp.close();
		fp.clear();

		if (sType != OP_INSERT){ getMatrixArgs(mat, sType); }

		if (sType != OP_INSERT){ getVectorArgs(vec); }

		if (sType == OP_PED2OTHER || sType == OP_INSERT){ getInsertArgs(ins); }
		else{ vstInserts.clear(); }
	}

	/********************************************
	* 取出“--ped2other”和“--other2ped”的INSERT参数
	*********************************************/
	void parameters::getInsertArgs(vvString &ins)
	{
		if (ins.empty()){
			cout << "It does not exist any argument in section [INSERT]." << endl;
			fpLog << "It does not exist any argument in section [INSERT]." << endl;
			return;
		}

		int		i, j, k, n;
		char	c;
		sInsert	s;
		vString	vs;

		for (j = 0; j < (int)ins.size(); j++){
			s.fn = ""; s.no = 0; s.posBegin = 0; s.delim = DELIMITER3; s.inRow = false; s.vsInserts.clear();
			n = ins[j].size();
			for (i = 0; i < n; i++){
				switch (i)
				{
				case 0:
				{
					s.no = atoi(ins[j][i].c_str());
					if (s.no == 0 && j == 0){
						cout << "The [row/col. No.] in the first line cannot be 0." << endl;
						fpLog << "The [row/col. No.] in the first line cannot be 0." << endl;
						if (fpLog){ fpLog.close(); }

						if (fpStat){ fpStat.close(); }
#ifdef _DEBUG
						system("pause");
#endif // DEBUG
						exit(1);
					}
					else {
						if (s.no == 0){ s.no = vstInserts[vstInserts.size() - 1].no + 1; }	// 0 is auto incresing
						else if (s.no > 0){	s.no--;	}			// 用户的编号从1开始，程序从0开始
					}
					break;
				}
				case 1:
				{
					s.fn = ins[j][i];
					break;
				}
				case 2:
				{
					s.posBegin = atoi(ins[j][i].c_str()) - 1;
					if (s.posBegin < 0){ s.posBegin = 0; }
					break;
				}
				case 3:
				{
					string2Lower(ins[j][i]);
					if (ins[j][i][0] == '\\' && ins[j][i][1] == 't'){ ins[j][i][0] = '\t'; } // replace "\t" with tab

					if (ins[j][i] == ESC_COMMA_STR){ ins[j][i][0] = ','; }		// replace the ESC with real comma

					s.delim = ins[j][i][0];
					if (s.delim == '\0'){ s.delim = DELIMITER3; }

					break;
				}
				case 4:
				{
					s.inRow = atoi(ins[j][i].c_str()) != 0;
					break;
				}
				default:
					break;
				}
				if (i > 4){ s.vsInserts.push_back(ins[j][i]); }
			}

			if (s.fn.length() == 0 && j == 0){
				cout << "The [filename] in the first line cannot be null." << endl;
				fpLog << "The [filename] in the first line cannot be null." << endl;

				if (fpLog){ fpLog.close(); }

				if (fpStat){ fpStat.close(); }
#ifdef _DEBUG
				system("pause");
#endif // DEBUG
				exit(1);
			}
			else if (s.fn.length() == 0){
				// 取最近的文件名
				s.fn = vstInserts[vstInserts.size() - 1].fn;
			}
			for (i = 0; i < (int)s.vsInserts.size(); i++){
				k = s.vsInserts[i].find(s.delim);
				if (k != s.vsInserts[i].npos){
					cout << "The inserted item \"" << s.vsInserts[i] << "\" include the same characters as the delimiter \"" << s.delim << "\"." << endl;
					cout << "Press Y to replace the character in item with another, N to exit, and other to continue ..." << endl;
					n = system("stty raw");
					c = getchar();
					n = system("stty -raw");
					if (tolower(c) == 'n'){
						if (fpLog){ fpLog.close(); }

						if (fpStat){ fpStat.close(); }
#ifdef _DEBUG
						system("pause");
#endif // DEBUG
						exit(1);
					}
					if (tolower(c) == 'y'){
						cout << "Press a character ..." << endl;
						n = system("stty raw");
						c = getchar();
						n = system("stty -raw");
						s.vsInserts[i][k] = c;
					}
					else{
						fpLog << "The inserted item \"" << s.vsInserts[i] << "\" include the same characters as the delimiter \"" << s.delim << "\"." << endl;
					}
				}
			}
			vstInserts.push_back(s);
		}
		vvString().swap(ins);
	}

	/********************************************
	* 取出“--ped2other”和“--other2ped”的VECTOR参数
	*********************************************/
	void parameters::getVectorArgs(vvString &vec)
	{
		if (vec.empty()){
			cout << "It does not exist any argument in section [VECTOR]." << endl;
			fpLog << "It does not exist any argument in section [VECTOR]." << endl;
			return;
		}

		int			i, j;
		sPed6_Map	s;
		bool		bNoNull;

		for (j = 0; j < (int)vec.size(); j++){
			string2Lower(vec[j][0]);
			s.type = -1;
			if (vec[j][0] == sArgCodes[FAMILY_ID]){ s.type = FAMILY_ID; }
			else if (vec[j][0] == sArgCodes[INDIVIDUAL_ID]){ s.type = INDIVIDUAL_ID; }
			else if (vec[j][0] == sArgCodes[PATERNAL_ID]){ s.type = PATERNAL_ID; }
			else if (vec[j][0] == sArgCodes[MATERNAL_ID]){ s.type = MATERNAL_ID; }
			else if (vec[j][0] == sArgCodes[SEX_ID]){ s.type = SEX_ID; }
			else if (vec[j][0] == sArgCodes[PHENOTYPE_ID]){ s.type = PHENOTYPE_ID; }
			else if (vec[j][0] == sArgCodes[CHROMOSOME_ID]){ s.type = CHROMOSOME_ID; }
			else if (vec[j][0] == sArgCodes[RS_NO_ID]){ s.type = RS_NO_ID; }
			else if (vec[j][0] == sArgCodes[GENETIC_DIS_ID]){ s.type = GENETIC_DIS_ID; }
			else if (vec[j][0] == sArgCodes[BASE_PAIR_POS_ID]){ s.type = BASE_PAIR_POS_ID; }

			if (s.type < 0) {
				vec.erase(vec.begin() + j);
				j--;
				continue; // not matched
			}

			s.fn = ""; s.no = 0; s.posBegin = 0; s.posEnd = 0; s.delim = DELIMITER3; s.inRow = false;
			bNoNull = true;	// [row/col. No.] is absent

			for (i = 1; i < (int)vec[j].size(); i++){
				switch (i)
				{
				case 1:
				{
					s.no = atoi(vec[j][i].c_str());
					if (s.no == 0 && j == 0){
						cout << "The [row/col. No.] in the first line cannot be 0." << endl;
						fpLog << "The [row/col. No.] in the first line cannot be 0." << endl;
						if (fpLog){ fpLog.close(); }

						if (fpStat){ fpStat.close(); }
#ifdef _DEBUG
						system("pause");
#endif // DEBUG
						exit(1);
					}
					else {
						bNoNull = false;
						if (s.no == 0){ s.no = vstPed6map[vstPed6map.size() - 1].no + 1; }
						else if (s.no > 0){ s.no--; }				// 用户的编号从1开始，程序从0开始
					}
					break;
				}
				case 2:
				{
					s.posBegin = atoi(vec[j][i].c_str()) - 1;
					if (s.posBegin < 0){ s.posBegin = 0; }

					break;
				}
				/*case 3:
				{
					s.posEnd = atoi(vec[j][i].c_str());
					if (s.posEnd > 0) {
						if (s.posEnd <= s.posBegin) s.posEnd = 0;
					}
					break;
				}*/
				case 3:
				{
					if (vec[j][i] == ESC_COMMA_STR){ s.delim = ','; }	// replace the ESC with real comma
					else if (vec[j][i][0] == '\\' && tolower(vec[j][i][1]) == 't'){ s.delim = '\t'; }
					else {
						s.delim = vec[j][i][0];
						if (s.delim == '\0'){ s.delim = DELIMITER3; }
					}
					break;
				}
				case 4:
				{
					s.inRow = atoi(vec[j][i].c_str()) != 0;
					break;
				}
				case 5:
				{
					s.fn = vec[j][i];

					break;
				}
				default:
					break;
				}
			}

			if (bNoNull && j == 0) {
				cout << "The [row/col. No.] in the first line cannot be 0, null or nonnumeric characters." << endl;
				fpLog << "The [row/col. No.] in the first line cannot be 0, null or nonnumeric characters." << endl;
				if (fpLog){ fpLog.close(); }

				if (fpStat){ fpStat.close(); }
#ifdef _DEBUG
				system("pause");
#endif // DEBUG
				exit(1);
			}
			else if (bNoNull){
				s.no = vstPed6map[vstPed6map.size() - 1].no + 1;
			}

			if (s.fn.length() == 0 && j == 0){
				cout << "The [filename] in the first line cannot be null." << endl;
				fpLog << "The [filename] in the first line cannot be null." << endl;
				if (fpLog){ fpLog.close(); }

				if (fpStat){ fpStat.close(); }
#ifdef _DEBUG
				system("pause");
#endif // DEBUG
				exit(1);
			}
			else if (s.fn.length() == 0){
				// 取最近的文件名
				s.fn = vstPed6map[vstPed6map.size() - 1].fn;
			}
			vstPed6map.push_back(s);
		}
		vvString().swap(vec);
	}

	/********************************************
	* 取出“--ped2other”和“--other2ped”的MATRIX参数
	*********************************************/
	void parameters::getMatrixArgs(vString &mat, string sType)
	{
		if (mat.empty()){	// 必须要有基因型矩阵
			cout << "The section [MATRIX] cannot be null." << endl;
			fpLog << "The section [MATRIX] cannot be null." << endl;
			if (fpLog){ fpLog.close(); }
			if (fpStat){ fpStat.close(); }
#ifdef _DEBUG
			system("pause");
#endif // DEBUG
			exit(1);
		}

		bool	b;
		int		i, j;

		struGenotype.AA[0] = '\0'; struGenotype.AA[1] = '\0';	// null default 
		struGenotype.Aa[0] = '\0'; struGenotype.Aa[1] = '\0';	// null default
		struGenotype.aa[0] = '\0'; struGenotype.aa[1] = '\0';	// null default
		struGenotype.delim = DELIMITER3;
		struGenotype.fn = ""; 
		struGenotype.lt = Point();
		struGenotype.rb = Point();
		struGenotype.missing = sType == OP_PED2OTHER ? PLNK_PED_MISSING_ALLELE2 : MISSING_ALLELE_CHR;
		struGenotype.SNPrcCnt = 0;
		struGenotype.twoAllele = true;
		struGenotype.Case = PLNK_PED_CASE_PHENOTYPE;
		struGenotype.Ctrl = PLNK_PED_CTRL_PHENOTYPE;
		struGenotype.male = PLNK_PED_MALE;
		struGenotype.female = PLNK_PED_FEMALE;

		b = true;		// indicates a whether includes two values
		for (i = 0; i < (int)mat.size(); i++){
			switch (i)
			{
			case 0:
			{
				if (mat[i].length() > 0){ struGenotype.fn = mat[i]; }
				break;
			}
			case 1:
			{
				b = false;
				struGenotype.lt.x = atoi(mat[i].c_str()) - 1;	// user-defined is with beginnig 1
				if (struGenotype.lt.x < 0){ struGenotype.lt.x = 0; }
				break;
			}
			case 2:
			{
				b = true;
				struGenotype.lt.y = atoi(mat[i].c_str()) - 1;
				if (struGenotype.lt.y < 0){ struGenotype.lt.y = 0; }
				break;
			}
			//case 3:
			//{
			//	b = false;
			//	struGenotype.rb.x = atoi(mat[i].c_str());
			//	if (struGenotype.rb.x > 0) {	// allows negative
			//		if (struGenotype.rb.x <= struGenotype.lt.x) struGenotype.rb.x = 0;
			//	}
			//	break;
			//}
			//case 4:
			//{
			//	b = true;
			//	struGenotype.rb.y = atoi(mat[i].c_str());
			//	if (struGenotype.rb.y > 0) {
			//		if (struGenotype.rb.y <= struGenotype.lt.y) struGenotype.rb.y = 0;
			//	}
			//	break;
			//}
			case 3:
			{
				if (mat[i] == ESC_COMMA_STR){ struGenotype.delim = ','; }	// replace the ESC with real comma
				else if (mat[i][0] == '\\' && tolower(mat[i][1]) == 't'){ struGenotype.delim = '\t'; }
				else if (mat[i][0] != '\0'){ struGenotype.delim = mat[i][0]; }

				break;
			}
			case 4:
			{
				struGenotype.SNPrcCnt = atoi(mat[i].c_str());
				if (struGenotype.SNPrcCnt < 0 || struGenotype.SNPrcCnt>3){ struGenotype.SNPrcCnt = 0; }

				break;
			}
			case 5:
			{
				if (struGenotype.SNPrcCnt == SNP_2_COL || struGenotype.SNPrcCnt == SNP_2_ROW){
					struGenotype.twoAllele = true;
				}
				else {
					j = atoi(mat[i].c_str());
					if (j == 1){ struGenotype.twoAllele = false; }
				}
				break;
			}
			case 6:
			{
				if (mat[i][0] != '\0'){ struGenotype.missing = mat[i]; }

				break;
			}
			case 7:
			{
				if (mat[i][0] != '\0'){ struGenotype.Case = mat[i][0]; }

				break;
			}
			case 8:
			{
				if (mat[i][0] != '\0'){ struGenotype.Ctrl = mat[i][0]; }

				break;
			}
			case 9:
			{
				if (mat[i][0] != '\0'){ struGenotype.male = mat[i][0]; }

				break;
			}
			case 10:
			{
				if (mat[i][0] != '\0'){ struGenotype.female = mat[i][0]; }

				break;
			}
			case 11:
			{
				if (mat[i][0] == '\0') {
					if (!struGenotype.twoAllele){ struGenotype.AA[0] = BOOST_AA; }
				}
				else {
					struGenotype.AA[0] = mat[i][0];
					struGenotype.AA[1] = mat[i][1];
				}
				break;
			}
			case 12:
			{
				if (mat[i][0] == '\0') {
					if (!struGenotype.twoAllele){ struGenotype.Aa[0] = BOOST_Aa_aA; }
				}
				else {
					struGenotype.Aa[0] = mat[i][0];
					struGenotype.Aa[1] = mat[i][1];
				}
				break;
			}
			case 13:
			{
				if (mat[i][0] == '\0') {
					if (!struGenotype.twoAllele){ struGenotype.aa[0] = BOOST_aa; }
				}
				else {
					struGenotype.aa[0] = mat[i][0];
					struGenotype.aa[1] = mat[i][1];
				}
				break;
			}
			default:
				break;
			}
		}

		if (!b){
			cout << "The <left>-<top> or <right>-<bottom> does not make a pair." << endl;
			fpLog << "The <left>-<top> or <right>-<bottom> does not make a pair." << endl;
			if (fpLog){ fpLog.close(); }

			if (fpStat){ fpStat.close(); }
#ifdef _DEBUG
			system("pause");
#endif // DEBUG
			exit(1);
		}
		if (struGenotype.fn.length() == 0){
			cout << "The <filename> in section [MATRIX] cannot be null." << endl;
			fpLog << "The <filename> in section [MATRIX] cannot be null." << endl;
			if (fpLog){ fpLog.close(); }

			if (fpStat){ fpStat.close(); }
#ifdef _DEBUG
			system("pause");
#endif // DEBUG
			exit(1);
		}

		// check conflict between SNPrbCnt and twoAllele
		if (!struGenotype.twoAllele && (struGenotype.SNPrcCnt == SNP_2_COL || struGenotype.SNPrcCnt == SNP_2_ROW)){
			cout << "The [SNP rows/col.s] in section [MATRIX] was set to "
				<< SNP_2_COL << " or " << SNP_2_ROW << " while [character count] is 1." << endl;
			cout << "Check, please." << endl;
			fpLog << "The [SNP rows/col.s] in section [MATRIX] was set to " << SNP_2_COL << " or " << SNP_2_ROW << " while [character count] is 1." << endl;
			if (fpLog){ fpLog.close(); }

			if (fpStat){ fpStat.close(); }
#ifdef _DEBUG
			system("pause");
#endif // DEBUG
			exit(1);
		}

		// check genotype chars
		if (struGenotype.twoAllele){
			if (struGenotype.Aa[1] == '\0'){
				struGenotype.AA[0] = '\0';	// '\0' represents to reserve the codes of the source
				struGenotype.AA[1] = '\0';
				struGenotype.Aa[0] = '\0';
				struGenotype.Aa[1] = '\0';
				struGenotype.aa[0] = '\0';
				struGenotype.aa[1] = '\0';
			}
			else{
				if (struGenotype.AA[1] == '\0'){
					struGenotype.AA[0] = struGenotype.Aa[0];
					struGenotype.AA[1] = struGenotype.Aa[0];
				}

				if (struGenotype.aa[1] == '\0'){
					struGenotype.aa[0] = struGenotype.Aa[1];
					struGenotype.aa[1] = struGenotype.Aa[1];
				}
			}
		}

		vString().swap(mat);
	}

	/********************************************
	* 分析参数，并将分析结果保存到类变量
	*********************************************/
	void parameters::parseArgs(mString& mapArgs)
	{
		string				arg, sOption;
		mString::iterator	itr;
		bool				/*bOf = false,*/ bPed2Other = false;
		int					iPos;
		int					iTmp;
		char				cs[10];

		for (itr = mapArgs.begin(); itr != mapArgs.end(); itr++) {
			arg = itr->first;
			iPos = findArg(arg);
			if (iPos != -1){
				if (iPos < OP_CNT) {		// 操作参数
					iOpCode = iPos;
					sOption = arg;
					sInputFilename = itr->second;

					if (sInputFilename.length() == 0){
						if (arg == OP_OTHER2PED){ sInputFilename = ARGS_FN4OTHER2PED; }
						else if (arg == OP_PED2OTHER){ sInputFilename = ARGS_FN4PED2OTHER; }
						else if (arg == OP_INSERT){ sInputFilename = ARGS_FN4INSERT; }
					}
				}

				//if (!bOf) {	//生成默认文件名 改到 addDefaultParas
				//	if (arg == OP_BOOST2PED || arg == OP_ME2PED || arg == OP_BEAM2PED || arg == OP_MDR2PED || arg == OP_PRETTY2PED
				//		|| arg == OP_TPED2PED || arg == OP_LINK2PED || arg == OP_PED2BED || arg == OP_PED2TPED || arg == OP_BOOST2BED
				//		|| arg == OP_TPED2BED || arg == OP_OTHER2PED || arg == OP_PED2OTHER || arg == OP_GEO2PED || arg == OP_SVM2PED
				//		|| arg == OP_BED2TPED || arg == OP_GSLINK2PED || arg == OP_LOG2PED)
				//	{
				//		sOutputFilename = "coPLINK";
				//	}
				//	else if (arg == OP_TPED2USR_TPED) sOutputFilename = "User-defined";
				//	else if (arg == OP_PED2BOOST || arg == OP_BED2BOOST || arg == OP_ME2BOOST || arg == OP_BEAM2BOOST
				//		|| arg == OP_MDR2BOOST || arg == OP_LINK2BOOST)
				//	{
				//		sOutputFilename = "BOOST";
				//	}
				//	else if (arg == OP_PED2ME || arg == OP_BED2ME) sOutputFilename = "ME";
				//	else if (arg == OP_SPC2CSV)	sOutputFilename = "New.csv";
				//	else if (arg == OP_CSV2SPC)	sOutputFilename = "Space.txt";
				//	else if (arg == OP_PED2BEAM || arg == OP_BED2BEAM) sOutputFilename = "BEAM";
				//	else if (arg == OP_PED2MDR) sOutputFilename = "MDR";
				//	else if (arg == OP_PED2LINK) sOutputFilename = "Linkage";
				//	else if (arg == OP_PED2GSLINK) sOutputFilename = "GS-Linkage.dat";
				//	else if (arg == OP_PED2LOG)	sOutputFilename = "LogicReg.txt";
				//	else if (arg == OP_PED2SVM)	sOutputFilename = "SVMSNPs";
				//	else if (arg == OP_SPLPED)	sOutputFilename = "SplicedOut";
				//	else if (arg == OP_PED2GEO)	sOutputFilename = "GEO";
				//	else if (arg == OP_TEST_ALLELE)	sOutputFilename = "Alleles-Test";
				//	else if (arg == OP_COMPARE)	sOutputFilename = CMP_FN;
				//	else if (arg == OP_TRANSPOSE) sOutputFilename = "Transposed.txt";
				//	else if (arg == OP_PED2PRETTY) sOutputFilename = "Pretty";
				//	else if (arg == OP_DELETE) sOutputFilename = "Deleted.txt";
				//	else if (arg == OP_INSERT) sOutputFilename = "Inserted.txt";
				//}

				if (arg == ID_SEED) {
					iTmp = atol(itr->second.c_str());
					if (iTmp > 0){ uRndSeed = iTmp; }
					else{ itr->second = "Time"; }
				}
				else if (arg == ID_RND_SEX){ bSex = true; }
				else if (arg == ID_CHR_NO) {
					trimString(itr->second);
					if (itr->second[0] == 'x' || itr->second[0] == 'X'){ sChrNo = "X"; }
					else if (itr->second[0] == 'y' || itr->second[0] == 'Y'){ sChrNo = "Y"; }
					else {
						getNumbers(itr->second.c_str(), cs);
						iTmp = atoi(cs);

						if (iTmp > 0 && iTmp < 23){ sChrNo = itr->second; }
						else{ itr->second = "0"; }
					}
				}
				else if (arg == ID_MODEL){
					trimString(itr->second);
					if (atoi(itr->second.c_str()) > 0){ iModel = C2I(itr->second[0]); }
					else{ itr->second = "0"; }

					if (iModel < ADDITIVE && iModel > RECESSIVE){ iModel = ADDITIVE; }
				}
				else if (arg == ID_MODE){
					trimString(itr->second);
					if (atoi(itr->second.c_str()) > 0){ iMode = C2I(itr->second[0]); }
					else{ itr->second = "0"; }
				}
				else if (arg == ID_PRE) {
					bPreprocess = true;
					dMafSnpCutoff = atof(itr->second.c_str());

					if (dMafSnpCutoff <= 0.0) {
						dMafSnpCutoff = MAF_MISSING_THRESHOLD;
						sprintf(cs, "%g", MAF_MISSING_THRESHOLD);
						itr->second = cs;
					}
				}
				else if (arg == ID_NOR){ 
					iTmp = atoi(itr->second.c_str());

					if (iTmp < 0) bNorOn = false;
					else if (iTmp > 0){	// 此情况当前仅用于PED2BED时同时输出归一化了的PED（ID_FILE2指定文件名）
						bNormalize = true;
						bNorOn = false;
						bPed2BedNor = true;
					}
					else {
						bNormalize = true;
						itr->second = "True";
					}
				}
				else if (arg == ID_HWE) {
					dHweCutoff = atof(itr->second.c_str());

					iTmp = itr->second.length();
					if (iTmp > 0){
						if (itr->second[iTmp - 1] == 'E' || itr->second[iTmp - 1] == 'e'
							|| itr->second[0] == 'E' || itr->second[0] == 'e'){
							bHWEexact = true;
						}
					}

					if (dHweCutoff <= 0.0){
						dHweCutoff = HWE_THRESHOLD;
						sprintf(cs, "%g", HWE_THRESHOLD);
						itr->second = cs;
					}

					
				}
				else if (arg == ID_PHENO) {
					bFixPhenotype = true;
					trimString(itr->second);

					if (itr->second.length() > 0) {
						cPhenotype = itr->second[0];
					}
					else{ itr->second = "0"; }
				}
				else if (arg == ID_FILE2) {
					sFilename2 = itr->second;
				}
				else if (arg == ID_OUT_FN && itr->second.length() > 0) {
					sOutputFilename = itr->second;
					//bOf = true;
				}
				else if (arg == ID_SWAP){ bSwap = true; }
				else if (arg == ID_MEMO){ sMemo = itr->second; }
				else if (arg == ID_DELIM) {
					trimString(itr->second);

					if (itr->second[0] == '\\' && (itr->second[1] == 't' || itr->second[1] == 'T')) {
						cDelimeter = '\t';
						itr->second = "TAB";
					}
					else{ cDelimeter = itr->second[0]; }	// first char only
				}
				else if (arg == ID_COL) {
					iTmp = itr->second.find("...");		// exists string of interval?
					if (iTmp == string::npos) {
						iColumn[0] = atoi(itr->second.c_str());

						if (iColumn[0] == 0){ itr->second = "0"; }
					}
					else {
						iColumn[0] = atoi(itr->second.substr(0, iTmp).c_str());
						iColumn[1] = atoi(itr->second.substr(iTmp + 3).c_str());
					}
				}
				else if (arg == ID_ROW) {
					iTmp = itr->second.find("...");		// exists string of interval?
					if (iTmp == string::npos) {
						iRow[0] = atoi(itr->second.c_str());
						if (iRow[0] == 0){ itr->second = "0"; }
					}
					else {
						iRow[0] = atoi(itr->second.substr(0, iTmp).c_str());
						iRow[1] = atoi(itr->second.substr(iTmp + 3).c_str());
					}
				}
				else if (arg == OP_OTHER2PED) {
					if (access(sInputFilename.c_str(), 0) == -1) {		// 不存在指定args文件
						cout << "The arguments file " << sInputFilename << " does not exist, try to read default " << ARGS_FN4OTHER2PED << " ..." << endl;

						if (access(ARGS_FN4OTHER2PED, 0) == -1) {				// 也不存在默认args文件，则创建模板
							fstream fp;
							cout << "The specified " << sInputFilename << " and the default " << ARGS_FN4OTHER2PED << " arguments files  were not found here." << endl;
							openStreamFile(fp, ARGS_FN4OTHER2PED, ios::out);
							fp << OTHER2PED_ARGS(OP_OTHER2PED) << endl;
							fp.close();
							cout << "A template of arguments file is created here, which named " << ARGS_FN4OTHER2PED << endl;
							fpLog << "Not exists arguments file." << endl;
							fpLog.close();
							fpStat.close();
							exit(1);
						}
						else {
							sInputFilename = ARGS_FN4OTHER2PED;
							itr->second = ARGS_FN4OTHER2PED;
						}
					}
					readArgs(sInputFilename, OP_OTHER2PED);
				}
				else if (arg == OP_INSERT) {
					if (access(sInputFilename.c_str(), 0) == -1) {		// 不存在指定args文件
						cout << "The arguments file " << sInputFilename << " does not exist, try to read default " << ARGS_FN4INSERT << " ..." << endl;

						if (access(ARGS_FN4INSERT, 0) == -1) {				// 也不存在默认args文件，则创建模板
							fstream fp;
							cout << "The specified " << sInputFilename << " and the default " << ARGS_FN4INSERT << " arguments files  were not found here." << endl;
							openStreamFile(fp, ARGS_FN4INSERT, ios::out);
							fp << INSERT_ARGS << endl;
							fp.close();
							cout << "A template of arguments file is created here, which named " << ARGS_FN4INSERT << endl;
							fpLog << "Not exists arguments file." << endl;
							fpLog.close();
							fpStat.close();
							exit(1);
						}
						else {
							sInputFilename = ARGS_FN4INSERT;
							itr->second = ARGS_FN4INSERT;
						}
					}
					readArgs(sInputFilename, OP_INSERT);
				}
				else if (arg == OP_PED2OTHER){
					bPed2Other = true;
				}
			}
		}

		if (sInputFilename.length() == 0){
			cout << "An input fie should be specified." << endl;
			if (fpLog){ fpLog.close(); }
			delayInSecond(20);
			exit(1);
		}

		//if (bSex && sOutputFilename.length() == 0) sOutputFilename = sInputFilename;
		
		itr = mapArgs.find(sOption);
		if (itr != mapArgs.end()){ mapArgs.erase(itr); }

		addDefaultParas(sOption, mapArgs);	// add defalut indicators

		if (bPed2Other){	// 要置于函数最后
			if (sFilename2.length() == 0) {
				cout << "The converted file must be specified by indicator " << ID_FILE2 << "." << endl;
				if (fpLog){ fpLog.close(); }

				if (fpStat){ fpStat.close(); }
#ifdef _DEBUG
				system("pause");
#endif // DEBUG
				exit(1);
			}
			if (iMode == OTHER_MODE_LST){ return; }

			if (access(sInputFilename.c_str(), 0) == -1) {		// 不存在指定args文件
				cout << "The arguments file " << sInputFilename << " does not exist, try to read default " << ARGS_FN4PED2OTHER << " ..." << endl;

				if (access(ARGS_FN4PED2OTHER, 0) == -1) {		// 也不存在默认args文件，则创建模板
					fstream fp;
					cout << "The specified " << sInputFilename << " and the default " << ARGS_FN4PED2OTHER << " arguments files were not found here." << endl;
					openStreamFile(fp, ARGS_FN4PED2OTHER, ios::out);
					fp << OTHER2PED_ARGS(OP_PED2OTHER) << endl;
					fp << INSERT_ARGS << endl;
					fp.close();
					cout << "A template of arguments file is created here, which named " << ARGS_FN4PED2OTHER << endl;
					cout << "The indicator " << ID_MODE << ' ' << OTHER_MODE_LST << " may be used to get the information of converted files." << endl;
					fpLog << "Not exists arguments file." << endl;
					fpLog.close();
					fpStat.close();
					exit(1);
				}
				else {
					sInputFilename = ARGS_FN4PED2OTHER;
					//itr->second = ARGS_FN4PED2OTHER;
				}
			}
			readArgs(sInputFilename, OP_PED2OTHER);
		}

		//输出用户输入参数到日志文件
		//以“新建”模式打开，并关闭日志文件，目的是删除原有同名日志文件
		arg = getFn(sOutputFilename, ".log");
		openStreamFile(fpLog, arg.c_str(), ios::out);
		fpLog.close();
		fpLog.clear();
		openStreamFile(fpLog, arg.c_str(), ios::out | ios::app);

		cout << "Converting starts at " << getDT() << endl;
		fpLog << VERSION << endl;
		fpLog << "Converting starts at " << getDT() << endl;

		if (!bNorOn && sOption != OP_PED2BED){
			cout << "\tWARNING: Fast mode is used a normalized data only!" << endl;
			fpLog << "\tTesting mode." << endl;
		}

		// print inputed paras
		fpLog << "\nParameter:" << endl;
		cout << "Parameter:" << endl;
		fpLog << DELIMITER2 << sOption << DELIMITER3 << sInputFilename << endl;
		cout << DELIMITER2 << sOption << DELIMITER3 << sInputFilename << endl;

		fpLog << "Indicators:" << endl;
		cout << "Indicators:" << endl;

		for (itr = mapArgs.begin(); itr != mapArgs.end(); itr++) {
			fpLog << DELIMITER2 << itr->first << ": " << itr->second << endl;
			cout << DELIMITER2 << itr->first << ": " << itr->second << endl;
		}

		fpLog << endl;
		cout << endl;

		mString().swap(mapArgs);			//清空mapArgs以节约内存
	}

	void parameters::addDefaultParas(string &sOption, mString &mapArgs)
	{
		mString::iterator	itr;
		char				cs[10];

		itr = mapArgs.find(ID_SWAP);
		if (itr != mapArgs.end()){ mapArgs.erase(itr); }

		if (sOption == OP_PED2BED) {
			mapArgs.insert(make_pair(ID_OUT_FN, "coPLINK.fam/coPLINK.bim/coPLINK.bed"));

			if(bPed2BedNor) mapArgs.insert(make_pair(ID_FILE2, "coPLINK-Nor.ped/coPLINK-Nor.map"));	// 当ID_NOR > 0 时，在输出BED的同时输出归一化了的PED（ID_FILE2指定文件名）

			if (sOutputFilename.length() == 0){ sOutputFilename = "coPLINK"; }
			if (sFilename2.length() == 0){ sFilename2 = "coPLINK-Nor"; }

			mapArgs.insert(make_pair(ID_NOR, (bNormalize ? "True" : "False")));

			if (bPreprocess){
				sprintf(cs, "%g", dHweCutoff);
				mapArgs.insert(make_pair(ID_HWE, (string)cs));
				mapArgs.insert(make_pair("Exact HWE", (bHWEexact ? "True" : "False")));
				sprintf(cs, "%g", dMafSnpCutoff);
				mapArgs.insert(make_pair(ID_PRE, (string)cs));
			}
			else{
				mapArgs.insert(make_pair(ID_PRE, "False")); 
			}

			if (bFixPhenotype) mapArgs.insert(make_pair(ID_PHENO, "0"));
		}
		else if (sOption == OP_PED2BOOST) {
			mapArgs.insert(make_pair(ID_OUT_FN, "BOOST.txt"));
			if (sOutputFilename.length() == 0){ sOutputFilename = "BOOST.txt"; }

			// 转换过程会自动计算主、次等位基因数，无需强制归一化
			//if (bNorOn){
			//	itr = mapArgs.find(ID_NOR);
			//	if (itr != mapArgs.end()){ mapArgs.erase(itr); }
			//	mapArgs.insert(make_pair(ID_NOR, "True"));	// 强制为true
			//	bNormalize = true;
			//}

			if (bPreprocess){
				sprintf(cs, "%g", dHweCutoff);
				mapArgs.insert(make_pair(ID_HWE, (string)cs));
				mapArgs.insert(make_pair("Exact HWE", (bHWEexact ? "True" : "False")));
				sprintf(cs, "%g", dMafSnpCutoff);
				mapArgs.insert(make_pair(ID_PRE, (string)cs));
			}
			else{
				mapArgs.insert(make_pair(ID_PRE, "False"));
			}

			if (bFixPhenotype) mapArgs.insert(make_pair(ID_PHENO, "0"));
		}
		else if (sOption == OP_PED2ME) {
			mapArgs.insert(make_pair(ID_OUT_FN, "ME.me"));
			if (sOutputFilename.length() == 0){ sOutputFilename = "ME.me"; }

			if (bNorOn){
				itr = mapArgs.find(ID_NOR);
				if (itr != mapArgs.end()){ mapArgs.erase(itr); }
				mapArgs.insert(make_pair(ID_NOR, "True"));	// 强制为true
				bNormalize = true;
			}

			if (bPreprocess){
				sprintf(cs, "%g", dHweCutoff);
				mapArgs.insert(make_pair(ID_HWE, (string)cs));
				mapArgs.insert(make_pair("Exact HWE", (bHWEexact ? "True" : "False")));
				sprintf(cs, "%g", dMafSnpCutoff);
				mapArgs.insert(make_pair(ID_PRE, (string)cs));
			}
			else{
				mapArgs.insert(make_pair(ID_PRE, "False"));
			}

			mapArgs.insert(make_pair(ID_SWAP, (bSwap ? "True" : "False")));
			if (bFixPhenotype) mapArgs.insert(make_pair(ID_PHENO, "0"));
		}
		else if (sOption == OP_PED2LINK) {
			mapArgs.insert(make_pair(ID_OUT_FN, "Linkage.ped/Linkage.info"));
			if (sOutputFilename.length() == 0){ sOutputFilename = "Linkage"; }

			mapArgs.insert(make_pair(ID_NOR, (bNormalize ? "True" : "False")));

			if (bPreprocess){
				sprintf(cs, "%g", dHweCutoff);
				mapArgs.insert(make_pair(ID_HWE, (string)cs));
				mapArgs.insert(make_pair("Exact HWE", (bHWEexact ? "True" : "False")));
				sprintf(cs, "%g", dMafSnpCutoff);
				mapArgs.insert(make_pair(ID_PRE, (string)cs));
			}
			else{
				mapArgs.insert(make_pair(ID_PRE, "False"));
			}

			mapArgs.insert(make_pair(ID_SWAP, (bSwap ? "True" : "False")));
			if (bFixPhenotype) mapArgs.insert(make_pair(ID_PHENO, "0"));
		}
		else if (sOption == OP_PED2GSLINK) {
			mapArgs.insert(make_pair(ID_OUT_FN, "GS-Linkage.dat"));
			if (sOutputFilename.length() == 0){ sOutputFilename = "GS-Linkage.dat"; }

			if (bNorOn){
				itr = mapArgs.find(ID_NOR);
				if (itr != mapArgs.end()){ mapArgs.erase(itr); }
				mapArgs.insert(make_pair(ID_NOR, "True"));	// 强制为true
				bNormalize = true;
			}

			if (bPreprocess){
				sprintf(cs, "%g", dHweCutoff);
				mapArgs.insert(make_pair(ID_HWE, (string)cs));
				mapArgs.insert(make_pair("Exact HWE", (bHWEexact ? "True" : "False")));
				sprintf(cs, "%g", dMafSnpCutoff);
				mapArgs.insert(make_pair(ID_PRE, (string)cs));
			}
			else{
				mapArgs.insert(make_pair(ID_PRE, "False"));
			}

			mapArgs.insert(make_pair(ID_SWAP, (bSwap ? "True" : "False")));
			if (bFixPhenotype) mapArgs.insert(make_pair(ID_PHENO, "0"));
		}
		else if (sOption == OP_PED2BEAM) {
			mapArgs.insert(make_pair(ID_OUT_FN, "BEAM.txt"));
			if (sOutputFilename.length() == 0){ sOutputFilename = "BEAM.txt"; }

			// 转换过程会自动计算主、次等位基因数，无需强制归一化
			//if (bNorOn){
			//	itr = mapArgs.find(ID_NOR);
			//	if (itr != mapArgs.end()){ mapArgs.erase(itr); }
			//	mapArgs.insert(make_pair(ID_NOR, "True"));	// 强制为true
			//	bNormalize = true;
			//}

			mapArgs.insert(make_pair(ID_SWAP, (bSwap ? "True" : "False")));

			if (bPreprocess){
				sprintf(cs, "%g", dHweCutoff);
				mapArgs.insert(make_pair(ID_HWE, (string)cs));
				mapArgs.insert(make_pair("Exact HWE", (bHWEexact ? "True" : "False")));
				sprintf(cs, "%g", dMafSnpCutoff);
				mapArgs.insert(make_pair(ID_PRE, (string)cs));
			}
			else{
				mapArgs.insert(make_pair(ID_PRE, "False"));
			}
			if (bFixPhenotype) mapArgs.insert(make_pair(ID_PHENO, "0"));
		}
		else if (sOption == OP_PED2GEO) {
			mapArgs.insert(make_pair(ID_OUT_FN, "GEO.geo/GEO.map"));
			if (sOutputFilename.length() == 0){ sOutputFilename = "GEO"; }

			if (bNorOn){
				itr = mapArgs.find(ID_NOR);
				if (itr != mapArgs.end()){ mapArgs.erase(itr); }
				mapArgs.insert(make_pair(ID_NOR, "True"));	// 强制为true
				bNormalize = true;
			}

			mapArgs.insert(make_pair(ID_SWAP, (bSwap ? "True" : "False")));
			if (bFixPhenotype) mapArgs.insert(make_pair(ID_PHENO, "0"));

			if (bPreprocess){
				sprintf(cs, "%g", dHweCutoff);
				mapArgs.insert(make_pair(ID_HWE, (string)cs));
				mapArgs.insert(make_pair("Exact HWE", (bHWEexact ? "True" : "False")));
				sprintf(cs, "%g", dMafSnpCutoff);
				mapArgs.insert(make_pair(ID_PRE, (string)cs));
			}
			else{
				mapArgs.insert(make_pair(ID_PRE, "False"));
			}
		}
		else if (sOption == OP_GEO2PED) {
			mapArgs.insert(make_pair(ID_OUT_FN, "coPLINK.ped/coPLINK.map"));
			if (sOutputFilename.length() == 0){ sOutputFilename = "coPLINK"; }

			mapArgs.insert(make_pair(ID_SWAP, (bSwap ? "True" : "False")));

			itr = mapArgs.find(ID_RND_SEX);
			if (itr != mapArgs.end()){ mapArgs.erase(itr); }
			mapArgs.insert(make_pair(ID_RND_SEX, "True"));	// 强制为true
			bSex = true;

			mapArgs.insert(make_pair(ID_SEED, "Time"));
		}
		else if (sOption == OP_PED2MDR) {
			mapArgs.insert(make_pair(ID_OUT_FN, "MDR.dat/MDR.map"));
			if (sOutputFilename.length() == 0){ sOutputFilename = "MDR"; }

			// 转换过程会自动计算主、次等位基因数，无需强制归一化
			//if (bNorOn){
			//	itr = mapArgs.find(ID_NOR);
			//	if (itr != mapArgs.end()){ mapArgs.erase(itr); }
			//	mapArgs.insert(make_pair(ID_NOR, "True"));	// 强制为true
			//	bNormalize = true;
			//}

			mapArgs.insert(make_pair(ID_SWAP, (bSwap ? "True" : "False")));
			if (bFixPhenotype) mapArgs.insert(make_pair(ID_PHENO, "0"));

			if (bPreprocess){
				sprintf(cs, "%g", dHweCutoff);
				mapArgs.insert(make_pair(ID_HWE, (string)cs));
				mapArgs.insert(make_pair("Exact HWE", (bHWEexact ? "True" : "False")));
				sprintf(cs, "%g", dMafSnpCutoff);
				mapArgs.insert(make_pair(ID_PRE, (string)cs));
			}
			else{
				mapArgs.insert(make_pair(ID_PRE, "False"));
			}
		}
		else if (sOption == OP_PED2LOG) {
			mapArgs.insert(make_pair(ID_OUT_FN, "LogicReg.txt"));
			if (sOutputFilename.length() == 0){ sOutputFilename = "LogicReg.txt"; }

			if (bNorOn){
				itr = mapArgs.find(ID_NOR);
				if (itr != mapArgs.end()){ mapArgs.erase(itr); }
				mapArgs.insert(make_pair(ID_NOR, "True"));	// 强制为true
				bNormalize = true;
			}

			sprintf(cs, "%d", iMode);
			mapArgs.insert(make_pair(ID_MODE, (string)cs));
			sprintf(cs, "%d", iModel);
			mapArgs.insert(make_pair(ID_MODEL, (string)cs));

			if (bPreprocess){
				sprintf(cs, "%g", dHweCutoff);
				mapArgs.insert(make_pair(ID_HWE, (string)cs));
				mapArgs.insert(make_pair("Exact HWE", (bHWEexact ? "True" : "False")));
				sprintf(cs, "%g", dMafSnpCutoff);
				mapArgs.insert(make_pair(ID_PRE, (string)cs));
			}
			else{
				mapArgs.insert(make_pair(ID_PRE, "False"));
			}

			mapArgs.insert(make_pair(ID_SWAP, (bSwap ? "True" : "False")));
			if (bFixPhenotype) mapArgs.insert(make_pair(ID_PHENO, "0"));
		}
		else if (sOption == OP_PED2SVM) {
			mapArgs.insert(make_pair(ID_OUT_FN, "SVMSNPs.DAT/SVMSNPs.LAB/SVMSNPs.NAME"));
			if (sOutputFilename.length() == 0){ sOutputFilename = "SVMSNPs"; }

			mapArgs.insert(make_pair(ID_NOR, (bNormalize ? "True" : "False")));
			sprintf(cs, "%d", iMode);
			mapArgs.insert(make_pair(ID_MODE, (string)cs));

			if (bFixPhenotype) mapArgs.insert(make_pair(ID_PHENO, "0"));

			if (bPreprocess){
				sprintf(cs, "%g", dHweCutoff);
				mapArgs.insert(make_pair(ID_HWE, (string)cs));
				mapArgs.insert(make_pair("Exact HWE", (bHWEexact ? "True" : "False")));
				sprintf(cs, "%g", dMafSnpCutoff);
				mapArgs.insert(make_pair(ID_PRE, (string)cs));
			}
			else{
				mapArgs.insert(make_pair(ID_PRE, "False"));
			}
		}
		else if (sOption == OP_SVM2PED) {
			mapArgs.insert(make_pair(ID_OUT_FN, "coPLINK.ped/coPLINK.map"));
			if (sOutputFilename.length() == 0){ sOutputFilename = "coPLINK"; }

			itr = mapArgs.find(ID_RND_SEX);
			if (itr != mapArgs.end()){ mapArgs.erase(itr); }
			mapArgs.insert(make_pair(ID_RND_SEX, "True"));	// 强制为true
			bSex = true;

			mapArgs.insert(make_pair(ID_SEED, "Time"));
			mapArgs.insert(make_pair(ID_CHR_NO, "0"));
			sprintf(cs, "%d", iMode);
			mapArgs.insert(make_pair(ID_MODE, (string)cs));
		}
		else if (sOption == OP_PED2PED) {
			mapArgs.insert(make_pair(ID_OUT_FN, (iMode == 0 ? "new-coPLINK" : sInputFilename)));
			if (sOutputFilename.length() == 0){ sOutputFilename = iMode == 0 ? "new-coPLINK" : sInputFilename; }// OP_PED2PED，当--mode 0保存要保存结果

			mapArgs.insert(make_pair(ID_NOR, (bNormalize ? "True" : "False")));	
			mapArgs.insert(make_pair(ID_SWAP, (bSwap ? "True" : "False")));

			if (bFixPhenotype) mapArgs.insert(make_pair(ID_PHENO, "0"));

			if (bPreprocess){
				sprintf(cs, "%g", dHweCutoff);
				mapArgs.insert(make_pair(ID_HWE, (string)cs));
				mapArgs.insert(make_pair("Exact HWE", (bHWEexact ? "True" : "False")));
				sprintf(cs, "%g", dMafSnpCutoff);
				mapArgs.insert(make_pair(ID_PRE, (string)cs));
			}
			else{
				mapArgs.insert(make_pair(ID_PRE, "False"));
			}

			mapArgs.insert(make_pair(ID_RND_SEX, (bSex ? "True" : "False")));
			mapArgs.insert(make_pair(ID_SWAP, (bSwap ? "True" : "False")));
			mapArgs.insert(make_pair(ID_SEED, "Time"));
			mapArgs.insert(make_pair("Save results", (iMode == 0 || bNormalize || bSwap || bSex ? "True" : "False")));
			sprintf(cs, "%d", iMode);
			mapArgs.insert(make_pair(ID_MODE, (string)cs));
		}
		else if (sOption == OP_ME2PED) {
			mapArgs.insert(make_pair(ID_OUT_FN, "coPLINK.ped/coPLINK.map"));
			if (sOutputFilename.length() == 0){ sOutputFilename = "coPLINK"; }

			itr = mapArgs.find(ID_RND_SEX);
			if (itr != mapArgs.end()){ mapArgs.erase(itr); }
			mapArgs.insert(make_pair(ID_RND_SEX, "True"));	// 强制为true
			bSex = true;

			mapArgs.insert(make_pair(ID_SEED, "Time"));
			mapArgs.insert(make_pair(ID_CHR_NO, "0"));
			mapArgs.insert(make_pair(ID_SWAP, (bSwap ? "True" : "False")));
			//mapArgs.insert(make_pair(ID_NOR, (bNormalize ? "True" : "False")));// ME自身就已明确主、次等位基因，归一化无意义
		}
		else if (sOption == OP_ME2BOOST) {
			mapArgs.insert(make_pair(ID_OUT_FN, "BOOST.txt"));
			if (sOutputFilename.length() == 0){ sOutputFilename = "BOOST.txt"; }

			mapArgs.insert(make_pair(ID_SWAP, (bSwap ? "True" : "False")));

			// ME自身就已明确主、次等位基因，无需强制归一化
			//itr = mapArgs.find(ID_NOR);
			//if (itr != mapArgs.end()){ mapArgs.erase(itr); }
			//mapArgs.insert(make_pair(ID_NOR, "True"));	// 强制为true
			//bNormalize = true;
		}
		else if (sOption == OP_BOOST2PED) {
			mapArgs.insert(make_pair(ID_OUT_FN, "coPLINK.ped/coPLINK.map"));
			if (sOutputFilename.length() == 0){ sOutputFilename = "coPLINK"; }

			itr = mapArgs.find(ID_RND_SEX);
			if (itr != mapArgs.end()){ mapArgs.erase(itr); }
			mapArgs.insert(make_pair(ID_RND_SEX, "True"));	// 强制为true
			bSex = true;

			mapArgs.insert(make_pair(ID_SEED, "Time"));
			mapArgs.insert(make_pair(ID_CHR_NO, "0"));
		}
		else if (sOption == OP_BOOST2BED) {
			mapArgs.insert(make_pair(ID_OUT_FN, "coPLINK.fam/coPLINK.bim/coPLINK.bed"));
			if (sOutputFilename.length() == 0){ sOutputFilename = "coPLINK"; }

			itr = mapArgs.find(ID_RND_SEX);
			if (itr != mapArgs.end()){ mapArgs.erase(itr); }
			mapArgs.insert(make_pair(ID_RND_SEX, "True"));	// 强制为true
			bSex = true;

			mapArgs.insert(make_pair(ID_SEED, "Time"));
			mapArgs.insert(make_pair(ID_CHR_NO, "0"));
		}
		else if (sOption == OP_BEAM2PED) {
			mapArgs.insert(make_pair(ID_OUT_FN, "coPLINK.ped/coPLINK.map"));
			if (sOutputFilename.length() == 0){ sOutputFilename = "coPLINK"; }

			itr = mapArgs.find(ID_RND_SEX);
			if (itr != mapArgs.end()){ mapArgs.erase(itr); }
			mapArgs.insert(make_pair(ID_RND_SEX, "True"));	// 强制为true
			bSex = true;

			mapArgs.insert(make_pair(ID_SEED, "Time"));
			mapArgs.insert(make_pair(ID_SWAP, (bSwap ? "True" : "False")));

			if (bPreprocess){
				sprintf(cs, "%g", dHweCutoff);
				mapArgs.insert(make_pair(ID_HWE, (string)cs));
				mapArgs.insert(make_pair("Exact HWE", (bHWEexact ? "True" : "False")));
				sprintf(cs, "%g", dMafSnpCutoff);
				mapArgs.insert(make_pair(ID_PRE, (string)cs));
			}
			else{
				mapArgs.insert(make_pair(ID_PRE, "False"));
			}
		}
		else if (sOption == OP_BEAM2BOOST) {
			mapArgs.insert(make_pair(ID_OUT_FN, "BOOST.txt"));
			if (sOutputFilename.length() == 0){ sOutputFilename = "BOOST.txt"; }

			mapArgs.insert(make_pair(ID_SWAP, (bSwap ? "True" : "False")));

			if (bPreprocess){
				sprintf(cs, "%g", dHweCutoff);
				mapArgs.insert(make_pair(ID_HWE, (string)cs));
				mapArgs.insert(make_pair("Exact HWE", (bHWEexact ? "True" : "False")));
				sprintf(cs, "%g", dMafSnpCutoff);
				mapArgs.insert(make_pair(ID_PRE, (string)cs));
			}
			else{
				mapArgs.insert(make_pair(ID_PRE, "False"));
			}
		}
		else if (sOption == OP_MDR2PED) {
			mapArgs.insert(make_pair(ID_OUT_FN, "coPLINK.ped/coPLINK.map"));
			if (sOutputFilename.length() == 0){ sOutputFilename = "coPLINK"; }

			itr = mapArgs.find(ID_RND_SEX);
			if (itr != mapArgs.end()){ mapArgs.erase(itr); }
			mapArgs.insert(make_pair(ID_RND_SEX, "True"));	// 强制为true
			bSex = true;

			mapArgs.insert(make_pair(ID_SEED, "Time"));
			mapArgs.insert(make_pair(ID_CHR_NO, "0"));
		}
		else if (sOption == OP_MDR2BOOST) {
			mapArgs.insert(make_pair(ID_OUT_FN, "BOOST.txt"));
			if (sOutputFilename.length() == 0){ sOutputFilename = "BOOST.txt"; }

			mapArgs.insert(make_pair(ID_SWAP, (bSwap ? "True" : "False")));
		}
		else if (sOption == OP_PRETTY2PED) {
			mapArgs.insert(make_pair(ID_OUT_FN, "coPLINK.ped/coPLINK.map"));
			if (sOutputFilename.length() == 0){ sOutputFilename = "coPLINK"; }

			sprintf(cs, "%d", iMode);
			mapArgs.insert(make_pair(ID_MODE, (string)cs));

			itr = mapArgs.find(ID_RND_SEX);
			if (itr != mapArgs.end()){ mapArgs.erase(itr); }
			mapArgs.insert(make_pair(ID_RND_SEX, "True"));	// 强制为true
			bSex = true;
			mapArgs.insert(make_pair(ID_SEED, "Time"));

			mapArgs.insert(make_pair(ID_CHR_NO, "0"));
			
			if (cPhenotype == PLNK_PED_UNKNOWN_PHENOTYPE){
				cPhenotype = PLNK_PED_CTRL_PHENOTYPE;		// 默认为CTRL
				cs[0] = PLNK_PED_CTRL_PHENOTYPE;
				cs[1] = '\0';

				itr = mapArgs.find(ID_PHENO);
				if (itr != mapArgs.end()){ mapArgs.erase(itr); }
				mapArgs.insert(make_pair(ID_PHENO, (string)cs));
			}
		}
		else if (sOption == OP_PED2PRETTY) {
			mapArgs.insert(make_pair(ID_OUT_FN, "Pretty.pretty"));
			if (sOutputFilename.length() == 0){ sOutputFilename = "Pretty.pretty"; }

			mapArgs.insert(make_pair(ID_NOR, (bNormalize ? "True" : "False")));

			sprintf(cs, "%d", PRET_Slider);		// 默认新版格式
			mapArgs.insert(make_pair(ID_MODE, (string)cs));

			if (bPreprocess){
				sprintf(cs, "%g", dHweCutoff);
				mapArgs.insert(make_pair(ID_HWE, (string)cs));
				mapArgs.insert(make_pair("Exact HWE", (bHWEexact ? "True" : "False")));
				sprintf(cs, "%g", dMafSnpCutoff);
				mapArgs.insert(make_pair(ID_PRE, (string)cs));
			}
			else{
				mapArgs.insert(make_pair(ID_PRE, "False"));
			}

			mapArgs.insert(make_pair(ID_MEMO, "NO_NAME"));
			if (sMemo.length() == 0){ sMemo = "NO_NAME"; }

			mapArgs.insert(make_pair(ID_SWAP, (bSwap ? "True" : "False")));
		}
		else if (sOption == OP_TPED2PED) {
			mapArgs.insert(make_pair(ID_OUT_FN, "coPLINK.ped/coPLINK.map"));
			if (sOutputFilename.length() == 0){ sOutputFilename = "coPLINK"; }

			mapArgs.insert(make_pair(ID_NOR, (bNormalize ? "True" : "False")));

			if (bPreprocess){
				sprintf(cs, "%g", dHweCutoff);
				mapArgs.insert(make_pair(ID_HWE, (string)cs));
				mapArgs.insert(make_pair("Exact HWE", (bHWEexact ? "True" : "False")));
				sprintf(cs, "%g", dMafSnpCutoff);
				mapArgs.insert(make_pair(ID_PRE, (string)cs));
			}
			else{
				mapArgs.insert(make_pair(ID_PRE, "False"));
			}

			mapArgs.insert(make_pair(ID_RND_SEX, (bSex ? "True" : "False")));
			mapArgs.insert(make_pair(ID_SEED, "Time"));
			sprintf(cs, "%d", iMode);
			mapArgs.insert(make_pair(ID_MODE, (string)cs));
			mapArgs.insert(make_pair(ID_PHENO, "0"));
		}
		else if (sOption == OP_TPED2BED) {
			mapArgs.insert(make_pair(ID_OUT_FN, "coPLINK.fam/coPLINK.bim/coPLINK.bed"));
			if (sOutputFilename.length() == 0){ sOutputFilename = "coPLINK"; }

			if (bPreprocess){
				sprintf(cs, "%g", dHweCutoff);
				mapArgs.insert(make_pair(ID_HWE, (string)cs));
				mapArgs.insert(make_pair("Exact HWE", (bHWEexact ? "True" : "False")));
				sprintf(cs, "%g", dMafSnpCutoff);
				mapArgs.insert(make_pair(ID_PRE, (string)cs));
			}
			else{
				mapArgs.insert(make_pair(ID_PRE, "False"));
			}

			mapArgs.insert(make_pair(ID_PHENO, "0"));
		}
		else if (sOption == OP_TPED2USR_TPED) {
			mapArgs.insert(make_pair(ID_OUT_FN, "User-defined.tped/User-defined.tfam/User-defined.tsnp"));
			if (sOutputFilename.length() == 0){ sOutputFilename = "User-defined"; }

			if (bPreprocess){
				sprintf(cs, "%g", dHweCutoff);
				mapArgs.insert(make_pair(ID_HWE, (string)cs));
				mapArgs.insert(make_pair("Exact HWE", (bHWEexact ? "True" : "False")));
				sprintf(cs, "%g", dMafSnpCutoff);
				mapArgs.insert(make_pair(ID_PRE, (string)cs));
			}
			else{
				mapArgs.insert(make_pair(ID_PRE, "False"));
			}

			mapArgs.insert(make_pair(ID_PHENO, "0"));
		}
		else if (sOption == OP_PED2TPED) {
			mapArgs.insert(make_pair(ID_OUT_FN, "coPLINK.tped/coPLINK.tfam"));
			if (sOutputFilename.length() == 0){ sOutputFilename = "coPLINK"; }

			sprintf(cs, "%d", iMode);
			mapArgs.insert(make_pair(ID_MODE, (string)cs));
			if (bFixPhenotype) mapArgs.insert(make_pair(ID_PHENO, "0"));

			if (iMode == TPED_NORMAL){
				mapArgs.insert(make_pair(ID_NOR, (bNormalize ? "True" : "False")));
			}
			else {
				if (bNorOn){
					itr = mapArgs.find(ID_NOR);
					if (itr != mapArgs.end()){ mapArgs.erase(itr); }
					mapArgs.insert(make_pair(ID_NOR, "True"));	// 强制为true
					bNormalize = true;
				}
			}

			mapArgs.insert(make_pair(ID_SWAP, (bSwap ? "True" : "False")));

			if (bPreprocess){
				sprintf(cs, "%g", dHweCutoff);
				mapArgs.insert(make_pair(ID_HWE, (string)cs));
				mapArgs.insert(make_pair("Exact HWE", (bHWEexact ? "True" : "False")));
				sprintf(cs, "%g", dMafSnpCutoff);
				mapArgs.insert(make_pair(ID_PRE, (string)cs));
			}
			else{
				mapArgs.insert(make_pair(ID_PRE, "False"));
			}
		}
		else if (sOption == OP_BED2TPED) {
			mapArgs.insert(make_pair(ID_OUT_FN, "coPLINK.tped/coPLINK.tfam"));
			if (sOutputFilename.length() == 0){ sOutputFilename = "coPLINK"; }
		}
		else if (sOption == OP_LINK2BOOST) {
			mapArgs.insert(make_pair(ID_OUT_FN, "BOOST.txt"));
			if (sOutputFilename.length() == 0) sOutputFilename = "BOOST.txt";

			// 转换过程会自动计算主、次等位基因数，无需强制归一化
			//if (bNorOn){
			//	itr = mapArgs.find(ID_NOR);
			//	if (itr != mapArgs.end()){ mapArgs.erase(itr); }
			//	mapArgs.insert(make_pair(ID_NOR, "True"));	// 强制为true
			//	bNormalize = true;
			//}

			bNorOn = true;	// 从归一化PED转LINKAGE会重新编码，其结果不一定是归一化的，所以不可关闭此开关

			mapArgs.insert(make_pair(ID_SWAP, (bSwap ? "True" : "False")));
		}
		else if (sOption == OP_GSLINK2PED) {
			mapArgs.insert(make_pair(ID_OUT_FN, "coPLINK.ped/coPLINK.map"));
			if (sOutputFilename.length() == 0){ sOutputFilename = "coPLINK"; }

			mapArgs.insert(make_pair(ID_NOR, (bNormalize ? "True" : "False")));

			if (bPreprocess){
				sprintf(cs, "%g", dHweCutoff);
				mapArgs.insert(make_pair(ID_HWE, (string)cs));
				mapArgs.insert(make_pair("Exact HWE", (bHWEexact ? "True" : "False")));
				sprintf(cs, "%g", dMafSnpCutoff);
				mapArgs.insert(make_pair(ID_PRE, (string)cs));
			}
			else{
				mapArgs.insert(make_pair(ID_PRE, "False"));
			}

			mapArgs.insert(make_pair(ID_CHR_NO, "0"));
		}
		else if (sOption == OP_LINK2PED) {
			mapArgs.insert(make_pair(ID_OUT_FN, "coPLINK.ped/coPLINK.map"));
			if (sOutputFilename.length() == 0){ sOutputFilename = "coPLINK"; }

			mapArgs.insert(make_pair(ID_NOR, (bNormalize ? "True" : "False")));

			if (bPreprocess){
				sprintf(cs, "%g", dHweCutoff);
				mapArgs.insert(make_pair(ID_HWE, (string)cs));
				mapArgs.insert(make_pair("Exact HWE", (bHWEexact ? "True" : "False")));
				sprintf(cs, "%g", dMafSnpCutoff);
				mapArgs.insert(make_pair(ID_PRE, (string)cs));
			}
			else{
				mapArgs.insert(make_pair(ID_PRE, "False"));
			}

			mapArgs.insert(make_pair(ID_CHR_NO, "0"));
		}
		else if (sOption == OP_SPC2CSV) {
			mapArgs.insert(make_pair(ID_OUT_FN, "New.csv"));
			if (sOutputFilename.length() == 0){ sOutputFilename = "New.csv"; }

		}
		else if (sOption == OP_CSV2SPC) {
			mapArgs.insert(make_pair(ID_OUT_FN, "Space.txt"));
			if (sOutputFilename.length() == 0){ sOutputFilename = "Space.txt"; }
		}
		else if (sOption == OP_BED2BEAM) {
			mapArgs.insert(make_pair(ID_OUT_FN, "BEAM.txt"));
			if (sOutputFilename.length() == 0){ sOutputFilename = "BEAM.txt"; }
		}
		else if (sOption == OP_BED2ME) {
			mapArgs.insert(make_pair(ID_OUT_FN, "ME.me"));
			if (sOutputFilename.length() == 0){ sOutputFilename = "ME.me"; }
		}
		else if (sOption == OP_BED2BOOST) {
			mapArgs.insert(make_pair(ID_OUT_FN, "BOOST.txt"));
			if (sOutputFilename.length() == 0){ sOutputFilename = "BOOST.txt"; }

			mapArgs.insert(make_pair(ID_SWAP, (bSwap ? "True" : "False")));
		}
		else if (sOption == OP_SPLPED) {
			mapArgs.insert(make_pair(ID_OUT_FN, "SplicedOut.ped/SplicedOut.map"));
			if (sOutputFilename.length() == 0){ sOutputFilename = "SplicedOut"; }

			mapArgs.insert(make_pair(ID_NOR, (bNormalize ? "True" : "False")));
			mapArgs.insert(make_pair(ID_FILE2, sFilename2));
			mapArgs.insert(make_pair(ID_PHENO, "0"));
		}
		else if (sOption == OP_TEST_ALLELE) {
			mapArgs.insert(make_pair(ID_OUT_FN, "Alleles-Test.csv"));
			if (sOutputFilename.length() == 0){ sOutputFilename = "Alleles-Test.csv"; }

			mapArgs.insert(make_pair(ID_NOR, (bNormalize ? "True" : "False")));
			sprintf(cs, "%d", iMode);
			mapArgs.insert(make_pair(ID_MODE, (string)cs));
		}
		else if (sOption == OP_COMPARE) {
			mapArgs.insert(make_pair(ID_OUT_FN, CMP_FN));
			if (sOutputFilename.length() == 0){ sOutputFilename = CMP_FN; }

			mapArgs.insert(make_pair(ID_FILE2, sFilename2));
			sprintf(cs, "%d", iMode);
			mapArgs.insert(make_pair(ID_MODE, (string)cs));
			cs[0] = '\'';
			cs[1] = cDelimeter;
			cs[2] = '\'';
			cs[3] = '\0';
			mapArgs.insert(make_pair(ID_DELIM, (string)cs));

			if (sMemo.length() == 0){ sMemo = sInputFilename + "-" + sFilename2; }
			mapArgs.insert(make_pair(ID_MEMO, sMemo));

			sprintf(cs, "%d", iColumn[0]);
			mapArgs.insert(make_pair(ID_COL, (string)cs));
		}
		else if (sOption == OP_OTHER2PED) {
			mapArgs.insert(make_pair(ID_OUT_FN, "coPLINK.ped/coPLINK.map"));
			if (sOutputFilename.length() == 0){ sOutputFilename = "coPLINK"; }

			mapArgs.insert(make_pair(ID_SEED, "Time"));
			mapArgs.insert(make_pair(ID_CHR_NO, "0"));
		}
		else if (sOption == OP_PED2OTHER) {
			if (sOutputFilename.length() == 0){ sOutputFilename = "Other"; }
			mapArgs.insert(make_pair(ID_OUT_FN, sOutputFilename + ".log"));

			sprintf(cs, "%d", iMode);
			mapArgs.insert(make_pair(ID_MODE, (string)cs));
			mapArgs.insert(make_pair(ID_CHR_NO, "0"));
		}
		else if (sOption == OP_TRANSPOSE) {
			mapArgs.insert(make_pair(ID_OUT_FN, "Transposed.txt"));
			if (sOutputFilename.length() == 0){ sOutputFilename = "Transposed.txt"; }

			cs[0] = '\'';
			cs[1] = cDelimeter;
			cs[2] = '\'';
			cs[3] = '\0';
			mapArgs.insert(make_pair(ID_DELIM, (string)cs));
			sprintf(cs, "%d", iMode);
			mapArgs.insert(make_pair(ID_MODE, (string)cs));
		}
		else if (sOption == OP_DELETE) {
			mapArgs.insert(make_pair(ID_OUT_FN, "Deleted.txt"));
			if (sOutputFilename.length() == 0){ sOutputFilename = "Deleted.txt"; }

			cs[0] = '\'';
			cs[1] = cDelimeter;
			cs[2] = '\'';
			cs[3] = '\0';
			mapArgs.insert(make_pair(ID_DELIM, (string)cs));
			sprintf(cs, "%d", iMode);
			mapArgs.insert(make_pair(ID_MODE, (string)cs));
			mapArgs.insert(make_pair(ID_ROW, "0"));
			mapArgs.insert(make_pair(ID_COL, "0")); 
		}
		else if (sOption == OP_INSERT) {
			mapArgs.insert(make_pair(ID_OUT_FN, "Inserted.txt"));
			if (sOutputFilename.length() == 0){ sOutputFilename = "Inserted.txt"; }

			cs[0] = '\'';
			cs[1] = cDelimeter;
			cs[2] = '\'';
			cs[3] = '\0';
			mapArgs.insert(make_pair(ID_DELIM, (string)cs));
		}
		else if (sOption == OP_LOG2PED) {
			mapArgs.insert(make_pair(ID_OUT_FN, "coPLINK.ped/coPLINK.map"));
			if (sOutputFilename.length() == 0){ sOutputFilename = "coPLINK"; }

			itr = mapArgs.find(ID_RND_SEX);
			if (itr != mapArgs.end()){ mapArgs.erase(itr); }
			mapArgs.insert(make_pair(ID_RND_SEX, "True"));	// 强制为true
			bSex = true;

			mapArgs.insert(make_pair(ID_SEED, "Time"));
			mapArgs.insert(make_pair(ID_CHR_NO, "0"));
			mapArgs.insert(make_pair(ID_MODE, "0"));
			mapArgs.insert(make_pair(ID_DELIM, "\' \'"));
			mapArgs.insert(make_pair(ID_MODEL, "0"));
		}
	}

	void parameters::displayHelp()
	{
		cout << "Usage: coPLINK < parameter> <in> [" << ID_OUT_FN << " <outputFilename>] [[indicator1] [value1]] [[indicator2] [value2]] …\n";
		cout << "The valid parameters and indicators are:\n";
		cout << HELP_OPTIONS << endl << endl;
		cout << HELP_INDICATORS << endl << endl;
		cout << HELP_ARGS_MEMO << endl;
	}
}
