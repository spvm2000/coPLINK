//////////////////////////////////////////////////////////////////
//                                                              //
//           coPLINK (c) 2020-2024 Han-Ming LIU                 //
//                                                              //
// This file is distributed under the GNU General Public        //
// License, Version 3.  Please see the file COPYING for more    //
// details                                                      //
//                                                              //
//////////////////////////////////////////////////////////////////

#include "coPLINK_Ins_Del.h"

namespace coPLINK
{
	/*************************************************
	* 删除文本文本的行或（和）列
	**************************************************/
	void InsDel::fileDelete(parameters *clsParas)
	{
		if (clsParas->iColumn[0] == 0 && clsParas->iRow[0] == 0){
			cout << "Not any rows/columns need be deleted." << endl;
			return;
		}


		fstream		fp;
		string		sLine;
		vString		vs;
		char		cs[100];
		int			i, j, k, colCnt, rowCnt;
		bool		bDelRow, bDelCol;

		cout << "Reading source file " << clsParas->sInputFilename << ". Please wait ..." << endl;

		openStreamFile(fp, clsParas->sInputFilename.c_str(), ios::in);
		j = 0;
		colCnt = 0;
		while (getline(fp, sLine)) {
			trimString(sLine);							//删除前后空格及TAB
			trimRedundance(sLine, true);				//删除中间多余空格及TAB（只保留一个），并把TAB用空格替换

			if (clsParas->cDelimeter != ' ' && clsParas->cDelimeter != '\t') {	// 当分隔符不是空格或TAB时，上一步操作会在分隔符前后留一个空格（如果有的话）
				trimRoundDelim(sLine, clsParas->cDelimeter);					// 删除分隔符前后的一个空格或TAB
			}

			//分隔符替换
			if (clsParas->cDelimeter == '\t'){ replaceChar(sLine, ' ', '\t'); }

			i = charCount(sLine, clsParas->cDelimeter);
			if (i == string::npos){ i = sLine.length() == 0 ? -1 : 0; }

			if (colCnt < i + 1){ colCnt = i + 1; }	// max column count
			vs.push_back(sLine);

			cout << '\t' << ++j << " rows OK.\r";
		}
		string().swap(sLine);
		fp.close();
		fp.clear();
		cout << endl;

		if (clsParas->iMode == 1){
			// erase all of null rows at end of the file
			for (i = (int)vs.size() - 1; i >= 0; i--){
				if (vs[i].size() == 0){
					vs.erase(vs.begin() + i);
				}
				else{
					break;
				}
			}
		}

		bDelCol = clsParas->iColumn[0] == 0 ? false : true;
		bDelRow = clsParas->iRow[0] == 0 ? false : true;

		if (clsParas->iRow[0] > 0){ clsParas->iRow[0]--; }		// user defined row No. begins from 1
		//if (clsParas->iRow[1] > 0) clsParas->iRow[1]--;	// does not do it
		if (clsParas->iColumn[0] > 0){ clsParas->iColumn[0]--; }
		//if (clsParas->iColumn[1] > 0) clsParas->iColumn[1]--;

		rowCnt = vs.size();
		if (rowCnt == 0){
			fetalError("The source file " + clsParas->sOutputFilename + " has nothing.", clsParas);
		}

		vString::iterator it = vs.begin();
		// delete rows
		if (bDelRow){
			if (clsParas->iRow[0] < 0){ clsParas->iRow[0] += rowCnt; }

			if (clsParas->iRow[1] < 0){ clsParas->iRow[1] += rowCnt; }
			else{ clsParas->iRow[1]--; }	// let end be included

			if (clsParas->iRow[0] >= rowCnt){
				sprintf(cs, "(%d vs. %d).", clsParas->iRow[0] + 1, rowCnt);
				fetalError("The expected row No. to be deleted is greater than the max row No. " + (string)cs, clsParas);
			}

			if (clsParas->iRow[1] - 1 <= clsParas->iRow[0]) {	// del one row
				vs.erase(it + clsParas->iRow[0]);
				rowCnt--;
			}
			else{
				if (clsParas->iRow[1] >= rowCnt){
					sprintf(cs, "(%d vs. %d).", clsParas->iRow[1] + 1, rowCnt);
					fetalError("The expected end row No. to be deleted is greater than the max row No. " + (string)cs, clsParas);
				}

				for (i = clsParas->iRow[1]; i >= clsParas->iRow[0]; i--) {	// must use inverse-order loop, because an iterator be employed
					vs.erase(it + i);
					rowCnt--;
				}
			}
		}

		// delete col.s
		if (bDelCol){
			if (clsParas->iColumn[0] < 0){ clsParas->iColumn[0] += colCnt; }

			if (clsParas->iColumn[1] < 0){ clsParas->iColumn[1] += colCnt + 1; }	// +1 to simplify coding

			if (clsParas->iColumn[0] >= colCnt){
				sprintf(cs, "(%d vs. %d).", clsParas->iColumn[0] + 1, colCnt);
				fetalError("The expected column No. to be deleted is greater than the max column No. " + (string)cs, clsParas);
			}

			if (clsParas->iColumn[1] - 1 <= clsParas->iColumn[0]) {		// del one col
				if (clsParas->iColumn[0] == 0){
					for (i = 0; i < rowCnt; i++){
						if (vs[i].length() == 0) continue;
						j = charNfind(vs[i].c_str(), clsParas->cDelimeter, 1);

						if (j == string::npos){ vs[i] = ""; }
						else{ vs[i] = vs[i].substr(j + 1); }
					}
				}
				else {
					for (i = 0; i < rowCnt; i++){
						j = charNfind(vs[i].c_str(), clsParas->cDelimeter, clsParas->iColumn[0]);
						k = charNfind(vs[i].c_str(), clsParas->cDelimeter, clsParas->iColumn[0] + 1);
						if (j == string::npos) continue;	// does not need del

						if (k == string::npos){ vs[i] = vs[i].substr(0, j); }
						else{ vs[i] = vs[i].substr(0, j) + vs[i].substr(k); }// is not k + 1, because the delimiter need be reserved
					}
				}
				colCnt--;
			}
			else{
				if (clsParas->iColumn[1] >= colCnt){
					sprintf(cs, "(%d vs. %d).", clsParas->iColumn[1] + 1, colCnt);
					fetalError("The expected end column No. to be deleted is greater than the max column No. " + (string)cs, clsParas);
				}

				for (i = 0; i < rowCnt; i++){
					j = charNfind(vs[i].c_str(), clsParas->cDelimeter, clsParas->iColumn[0]);
					k = charNfind(vs[i].c_str(), clsParas->cDelimeter, clsParas->iColumn[1]);
					if (j == string::npos) continue;	// does not need del

					if (k == string::npos){ vs[i] = vs[i].substr(0, j); }
					else{ vs[i] = vs[i].substr(0, j) + vs[i].substr(k); }	// is not k + 1, because the delimiter need be reserved

					colCnt--;
				}

			}
		}

		cout << "Saving to file " << clsParas->sOutputFilename << ". Please wait ..." << endl;
		cout << "\tTotal " << rowCnt << " rows." << endl;
		openStreamFile(fp, clsParas->sOutputFilename.c_str(), ios::out);

		j = 0;
		for (i = 0; i < rowCnt; i++){
			fp << vs[i] << endl;

			cout << '\t' << ++j << " rows OK.\r";
		}
		fp.close();
		fp.clear();
		cout << endl;
		vString().swap(vs);

		cout << "Deleted OK." << endl;
		clsParas->fpLog << "Deleted OK." << endl;
	}

	/*************************************************
	* 插入结构体的no元素vector排序函数（升序）
	**************************************************/
	bool InsDel::sortNo(sInsert &p1, sInsert &p2)
	{
		return p1.no < p2.no;
	}

	/*************************************************
	* 为文本文本插入行或（和）列操作作坐标转换
	* colCnt, rowCnt = take in the numbers of col.s and rows before transforming and return the numbers after transforming
	**************************************************/
	void InsDel::coordinateTrans(vString &vsSrc, int *rowCnt, int *colCnt, parameters *clsParas)
	{
		string		s, s1, s2;
		vString		vs;
		char		cs[150];
		int			i, j, k, n, p;
		bool		b, bAlt;

		// transform negative coordinates into positive
		for (i = 0; i < (int)clsParas->vstInserts.size(); i++){
			if ((int)clsParas->vstInserts[i].no < 0){
				clsParas->vstInserts[i].no += clsParas->vstInserts[0].inRow ? *rowCnt : *colCnt;
			}
		}

		// count inserted rows and col.s
		for (i = 0; i < (int)clsParas->vstInserts.size(); i++){
			if (clsParas->vstInserts[i].inRow){ (*rowCnt)++; }
			else{ (*colCnt)++; }
		}

		// sort coordinates firstly (ascending)
		sort(clsParas->vstInserts.begin(), clsParas->vstInserts.end());

		// adjust coordinates
		j = 0;
		for (i = 0; i < (int)clsParas->vstInserts.size(); i++){// adj. rows no.
			if (clsParas->vstInserts[i].inRow){
				clsParas->vstInserts[i].no += j;
				j++;
			}
		}

		j = 0;
		for (i = 0; i < (int)clsParas->vstInserts.size(); i++){//adj. col.s no.
			if (!clsParas->vstInserts[i].inRow){
				clsParas->vstInserts[i].no += j;
				j++;
			}
		}

		// the coordinates may be out of the row/column count while a negative No. was specified, so continue adjusting
		j = -1;
		for (i = 0; i < (int)clsParas->vstInserts.size(); i++){
			if (clsParas->vstInserts[i].inRow){
				if (clsParas->vstInserts[i].no > *rowCnt) {
					clsParas->vstInserts[i].no = *rowCnt + j;
					j++;
				}
			}
		}

		j = -1;
		for (i = 0; i < (int)clsParas->vstInserts.size(); i++){
			if (!clsParas->vstInserts[i].inRow){
				if (clsParas->vstInserts[i].no > *colCnt) {
					clsParas->vstInserts[i].no = *colCnt + j;
					j++;
				}
			}
		}

		//// transform wildcards ///////////////
		for (i = 0; i < (int)clsParas->vstInserts.size(); i++){

			// replace wildcards with serial No. or two alternated chars
			for (j = 0; j < (int)clsParas->vstInserts[i].vsInserts.size(); j++){
				b = false;
				if (clsParas->vstInserts[i].vsInserts[j][0] == WILDCARD_ALLELE_NO
					|| clsParas->vstInserts[i].vsInserts[j][0] == WILDCARD_ALTER_AB)
				{	// the first is wildcard
					b = true;	// if a string include several wildcards, the first meeted wildcard will be used and the others will be ignored.
					bAlt = clsParas->vstInserts[i].vsInserts[j][0] == WILDCARD_ALTER_AB ? true : false;
					n = 0;	// 0th char is wildcard
				}

				if (!b){ // continue to find wildcard while the first is non-wildcard
					for (n = 1; n < (int)clsParas->vstInserts[i].vsInserts[j].size(); n++){
						if (clsParas->vstInserts[i].vsInserts[j][n] == WILDCARD_ALLELE_NO
							|| clsParas->vstInserts[i].vsInserts[j][n] == WILDCARD_ALTER_AB)
						{
							if (clsParas->vstInserts[i].vsInserts[j][n - 1] == '\\') continue;

							b = true;
							bAlt = clsParas->vstInserts[i].vsInserts[j][n] == WILDCARD_ALTER_AB ? true : false;
							break;	// if a string include several wildcards, the first meeted wildcard will be used and the others will be ignored.
						}
					}
				}

				if (b){
					p = clsParas->vstInserts[i].inRow ? *colCnt : *rowCnt;
					p -= j;		// - number of items before j
					p -= (clsParas->vstInserts[i].vsInserts.size() - j - 1);	// - number of items after j
					p -= clsParas->vstInserts[i].posBegin;						// - beginning posi.

					s1 = n == 0 ? "" : clsParas->vstInserts[i].vsInserts[j].substr(0, n);

					if (clsParas->vstInserts[i].vsInserts[j][n] == WILDCARD_ALTER_AB){
						// two chars used to alternating
						if ((int)clsParas->vstInserts[i].vsInserts[j].length() > n + 2){
							s2 = clsParas->vstInserts[i].vsInserts[j].substr(n + 3);
							cs[0] = clsParas->vstInserts[i].vsInserts[j][n + 1];
							cs[1] = clsParas->vstInserts[i].vsInserts[j][n + 2];
						}
						else{
							s2 = "";
							// two default chars
							cs[0] = '0';
							cs[1] = '1';
						}
					}
					else s2 = clsParas->vstInserts[i].vsInserts[j].substr(n + 1);

					b = true;
					for (k = 0; k < p; k++){
						if (bAlt){ // is WILDCARD_ALTER_AB
							s = s1 + (b ? cs[0] : cs[1]) + s2;
							b = !b;
						}
						else{
							sprintf(cs, "%d", k + 1);	// serial No. is starting from 1
							s = s1 + (string)cs + s2;
						}

						j++;
						clsParas->vstInserts[i].vsInserts.insert(clsParas->vstInserts[i].vsInserts.begin() + j, s);
					}

					p = j - p;
					clsParas->vstInserts[i].vsInserts.erase(clsParas->vstInserts[i].vsInserts.begin() + p);
					break;	// do not care more wildcards
				}
			}
			// scan again to replace "\#" and "\^" with "#" and "^"
			for (j = 0; j < (int)clsParas->vstInserts[i].vsInserts.size(); j++){
				s = WILDCARD_ALLELE_NO;
				clsParas->vstInserts[i].vsInserts[j] = replace_all_distinct(clsParas->vstInserts[i].vsInserts[j], ESC_ALLELE_STR, s);
				s = WILDCARD_ALTER_AB;
				clsParas->vstInserts[i].vsInserts[j] = replace_all_distinct(clsParas->vstInserts[i].vsInserts[j], ESC_ALTER_STR, s);
			}
		}

		// check
		for (i = 0; i < (int)clsParas->vstInserts.size(); i++){
			if (!clsParas->vstInserts[i].inRow && (int)clsParas->vstInserts[i].vsInserts.size() > *rowCnt){
				fetalError("The inserted item " + clsParas->vstInserts[i].vsInserts[0] + " has a number of rows exceeding the number of rows in surce.", clsParas);
			}
		}
	}

	/*************************************************
	* 为文本文本插入行或（和）列
	**************************************************/
	void InsDel::fileInsert(parameters *clsParas)
	{
		if (clsParas->vstInserts.empty()){
			cout << "Not any rows/columns need be inserted." << endl;
			return;
		}

		fstream		fp;
		string		s;
		vString		vs;
		int			i, j, colCnt, rowCnt;
		vInt		vi;

		cout << "Your arguments lines (<row/col. No.>,[filename],[begin],[delimiter],\n\t\t[direction]):" << endl;
		clsParas->fpLog << "Your arguments lines (<row/col. No.>,[filename],[begin],[delimiter],[direction]):" << endl;

		colCnt = clsParas->vstInserts[0].vsInserts.size();

		if (clsParas->vstInserts[0].delim == ' '){ s = "space"; }	// only the first delimiter is accepted
		else if (clsParas->vstInserts[0].delim == '\t'){ s = "tab"; }
		else if (clsParas->vstInserts[0].delim == ','){ s = "comma"; }
		else{ s = clsParas->vstInserts[0].delim; }

		for (i = 0; i < (int)clsParas->vstInserts.size(); i++){	// <row/col. No.>,[filename],[begin],[delimiter],[direction],[item1],[item2],...
			// store the max. number of inserted rows
			if ((int)clsParas->vstInserts[i].vsInserts.size()>colCnt){
				colCnt = clsParas->vstInserts[i].vsInserts.size();
			}

			clsParas->vstInserts[i].delim = clsParas->vstInserts[0].delim;

			// show inserted arguments
			cout << "\tLine " << i + 1 << ": "
				<< (clsParas->vstInserts[i].no < 0 ? clsParas->vstInserts[i].no : clsParas->vstInserts[i].no + 1)
				<< DELIMITER4 << clsParas->vstInserts[0].fn			// only the first fn is valid
				<< DELIMITER4 << (clsParas->vstInserts[i].posBegin < 0 ? clsParas->vstInserts[i].posBegin : clsParas->vstInserts[i].posBegin + 1)
				<< DELIMITER4 << s
				<< DELIMITER4 << (clsParas->vstInserts[i].inRow ? "row" : "column") << endl;

			clsParas->fpLog << "\tLine " << i + 1 << ": "
				<< (clsParas->vstInserts[i].no < 0 ? clsParas->vstInserts[i].no : clsParas->vstInserts[i].no + 1)
				<< DELIMITER4 << clsParas->vstInserts[0].fn
				<< DELIMITER4 << (clsParas->vstInserts[i].posBegin < 0 ? clsParas->vstInserts[i].posBegin : clsParas->vstInserts[i].posBegin + 1)
				<< DELIMITER4 << s
				<< DELIMITER4 << (clsParas->vstInserts[i].inRow ? "row" : "column") << endl;
		}

		cout << clsParas->sOutputFilename << " will be " << s << " delimited." << endl;

		cout << "\nReading source file " << clsParas->vstInserts[0].fn << ". Please wait ..." << endl;	// only the first file will be uesed

		openStreamFile(fp, clsParas->vstInserts[0].fn.c_str(), ios::in);
		j = 0;
		while (getline(fp, s)) {
			trimString(s);							//删除前后空格及TAB
			trimRedundance(s, true);				//删除中间多余空格及TAB（只保留一个），并把TAB用空格替换

			if (clsParas->cDelimeter != ' ' && clsParas->cDelimeter != '\t') {	// 当分隔符不是空格或TAB时，上一步操作会在分隔符前后留一个空格（如果有的话）
				trimRoundDelim(s, clsParas->cDelimeter);					// 删除分隔符前后的一个空格或TAB
			}

			//分隔符替换
			if (clsParas->cDelimeter == '\t'){ replaceChar(s, ' ', '\t'); }

			i = charCount(s, clsParas->cDelimeter);
			if (i == string::npos){ i = s.length() == 0 ? -1 : 0; }

			i++;
			if (colCnt < i){ colCnt = i; }	// max column count

			if (clsParas->cDelimeter != clsParas->vstInserts[0].delim){
				replaceChar(s, clsParas->cDelimeter, clsParas->vstInserts[0].delim);
			}

			vi.push_back(i);
			vs.push_back(s);

			cout << '\t' << ++j << " rows OK.\r";
		}
		string().swap(s);
		fp.close();
		fp.clear();
		cout << endl;

		clsParas->cDelimeter = clsParas->vstInserts[0].delim;	// keep them the same

		if (clsParas->iMode == 1){
			// erase all of null rows at end of the file
			for (i = (int)vs.size() - 1; i >= 0; i--){
				if (vs[i].size() == 0){
					/*vs.erase(vs.begin() + i);
					vi.erase(vi.begin() + i);*/
					vs.pop_back();
					vi.pop_back();
				}
				else{
					break;
				}
			}
		}

		cout << "Checking and analyzing ..." << endl;

		rowCnt = vs.size();
		if (rowCnt == 0){
			fetalError("The source file " + clsParas->vstInserts[0].fn + " has nothing.", clsParas);
		}

		// 调整数据为矩阵（即每行列数一样）
		for (i = 0; i < (int)vs.size(); i++){
			if (vi[i] < colCnt){
				if (vi[i] == 0) vi[i] = 1;

				for (j = vi[i]; j < colCnt; j++) {
					vs[i] += clsParas->cDelimeter;
				}
			}
		}
		vInt().swap(vi);

		coordinateTrans(vs, &rowCnt, &colCnt, clsParas);

		cout << "\tTotal " << rowCnt << " rows and " << colCnt << " columns." << endl;
		cout << "\nSaving to file " << clsParas->sOutputFilename << ". Please wait ..." << endl;
		
		openStreamFile(fp, clsParas->sOutputFilename.c_str(), ios::out);

		j = 0;
		for (i = 0; i < rowCnt; i++){
			saveOneRow(fp, i, colCnt, vs, &j, clsParas);
			cout << '\t' << i + 1 << " rows OK.\r";
		}
		fp.close();
		fp.clear();
		cout << endl;
		vString().swap(vs);

		cout << "\nInserted OK." << endl;
		clsParas->fpLog << "Inserted OK." << endl;
	}

	/************************************
	* 插入行、列 - 输出一行
	* fp = out-file pointer
	* iRow = will be outted row No.
	* colCnt = number of col.s of the out-file
	* iSrcCol = number of col.s of the source data
	* vsSrc = data of source
	* clsParas = 类参数指针
	*************************************/
	void InsDel::saveOneRow(fstream &fp, int iRow, int colCnt, vString &vsSrc, int *iOffset, coPLINK::parameters *clsParas)
	{
		int		i, j, m,/* n,*/ iCurCol, iCurSrcCol;
		string	sOut;
		bool	bIns, bNotUse;
		vString	vsRow;

		iCurSrcCol = 0;	// col. No. will be outted
		sOut = "";
		stringSplit(vsSrc[iRow - (*iOffset)].c_str(), vsRow, clsParas->cDelimeter);	// keeping null string is need
		bNotUse = true;

		for (iCurCol = 0; iCurCol < colCnt;iCurCol++){
			bIns = false;

			for (i = 0; i < (int)clsParas->vstInserts.size(); i++){		// scan line beginning at iCurCol in iRow on [INSERT]
				if (clsParas->vstInserts[i].inRow){
					if (clsParas->vstInserts[i].no == iRow){
						if (clsParas->vstInserts[i].posBegin == iCurCol){

							for (j = 0; j < (int)clsParas->vstInserts[i].vsInserts.size(); j++){
								if (iCurCol == 0){
									sOut = clsParas->vstInserts[i].vsInserts[j];
								}
								else {
									sOut += clsParas->vstInserts[i].delim;
									sOut += clsParas->vstInserts[i].vsInserts[j];
								}

								iCurCol++;
							}
							bIns = true;
						}
					}
				}
				else{
					m = iRow - clsParas->vstInserts[i].posBegin;
					if (((int)clsParas->vstInserts[i].vsInserts.size() > m) && (m >= 0) && (clsParas->vstInserts[i].no == iCurCol)){
						if (iCurCol == 0){
							sOut = clsParas->vstInserts[i].vsInserts[m];
						}
						else {
							sOut += clsParas->vstInserts[i].delim;
							sOut += clsParas->vstInserts[i].vsInserts[m];
						}
						bIns = true;
					}
				}
			}

			if (!bIns){
				bNotUse = false;
				if (iCurSrcCol < (int)vsRow.size()){
					if (iCurCol == 0){
						sOut = vsRow[iCurSrcCol];
					}
					else {
						sOut += clsParas->cDelimeter;
						sOut += vsRow[iCurSrcCol];
					}

					iCurSrcCol++;
				}
			}
		}

		// remove the redundancy of delimieters at the end of string
		m = sOut.length() - 1;
		for (i = m; i >= 0; i--){
			/*if (sOut[i] == clsParas->cDelimeter){ sOut[i] = '\0'; } // string不能用'\0'这样截短，否则容易导致尾部乱码
			else{ break; }*/
			if (sOut[i] != clsParas->cDelimeter) break;
		}

		if (i != m) sOut.erase(i + 1);

		if (bNotUse) (*iOffset)++;

		vString().swap(vsRow);
		fp << sOut << endl;

		string().swap(sOut);
	}

	/*************************************************
	* 为文本文本插入行或（和）列
	**************************************************/
	void InsDel::fileInsert_Old(parameters *clsParas)
	{
		if (clsParas->vstInserts.empty()){
			cout << "Not any rows/columns need be inserted." << endl;
			return;
		}

		fstream		fp;
		string		s, s1, s2;
		vString		vs;
		char		cs[150];
		int			i, j, k, m, n, p, colCnt, rowCnt;
		bool		b, bAlt;

		cout << "Checking arguments ..." << endl;

		b = clsParas->vstInserts[0].inRow;
		for (i = 1; i < (int)clsParas->vstInserts.size(); i++){	// can not insert rows and col.s simultaneously
			if (clsParas->vstInserts[i].inRow != b) {
				cout << "The arguments line " << i + 1 << " want to insert a " << (clsParas->vstInserts[i].inRow ? "row" : "column")
					<< " which is different from the fisrt. \nIt is not permitted to insert rows/col.s while inserting col.s/rows." << endl;
				return;
			}
		}

		cout << "Reading source file " << clsParas->vstInserts[0].fn << ". Please wait ..." << endl;	// only the first file will be uesed

		openStreamFile(fp, clsParas->vstInserts[0].fn.c_str(), ios::in);
		j = 0;
		colCnt = 0;
		while (getline(fp, s)) {
			trimString(s);							//删除前后空格及TAB
			trimRedundance(s, true);				//删除中间多余空格及TAB（只保留一个），并把TAB用空格替换

			//分隔符替换
			if (clsParas->cDelimeter == '\t'){ replaceChar(s, ' ', '\t'); }

			i = charCount(s, clsParas->cDelimeter);
			if (i == string::npos){ i = s.length() == 0 ? -1 : 0; }

			if (colCnt < i + 1){ colCnt = i + 1; }	// max column count
			vs.push_back(s);

			cout << '\t' << ++j << " rows OK.\r";
		}
		string().swap(s);
		fp.close();
		fp.clear();
		cout << endl;

		if (clsParas->iMode == 1){
			// erase all of null rows at end of the file
			for (i = (int)vs.size() - 1; i >= 0; i--){
				if (vs[i].size() == 0){
					vs.erase(vs.begin() + i);
				}
				else{ break; }
			}
		}

		rowCnt = vs.size();
		if (rowCnt == 0){
			fetalError("The source file " + clsParas->vstInserts[0].fn + " has nothing.", clsParas);
		}

		// transform negative coordinates into positive
		for (i = 0; i < (int)clsParas->vstInserts.size(); i++){
			if ((int)clsParas->vstInserts[i].no < 0){
				clsParas->vstInserts[i].no += clsParas->vstInserts[0].inRow ? rowCnt : colCnt;
			}
		}

		// count inserted rows and col.s
		j = 0;
		if (clsParas->vstInserts[0].inRow){
			for (i = 0; i < (int)clsParas->vstInserts.size(); i++){
				rowCnt++;
			}
		}
		else {
			for (i = 0; i < (int)clsParas->vstInserts.size(); i++){
				colCnt++;
			}
		}

		// sort coordinates firstly (ascending)
		sort(clsParas->vstInserts.begin(), clsParas->vstInserts.end()/*, sortNo*/);

		// adjust coordinates
		j = 0;
		if (clsParas->vstInserts[0].inRow){
			for (i = 0; i < (int)clsParas->vstInserts.size(); i++){
				clsParas->vstInserts[i].no += j;
				j++;
			}
		}
		else {
			for (i = 0; i < (int)clsParas->vstInserts.size(); i++){
				clsParas->vstInserts[i].no += j;
				j++;
			}
		}

		// the coordinates may be out of the row/column count while a negative No. was specified, so continue adjusting
		j = -1;
		if (clsParas->vstInserts[0].inRow){
			for (i = 0; i < (int)clsParas->vstInserts.size(); i++){
				if (clsParas->vstInserts[i].no > rowCnt) {
					clsParas->vstInserts[i].no = rowCnt + j;
					j++;
				}
			}
		}
		else {
			for (i = 0; i < (int)clsParas->vstInserts.size(); i++){
				if (clsParas->vstInserts[i].no > colCnt) {
					clsParas->vstInserts[i].no = colCnt + j;
					j++;
				}
			}
		}

		//// transform wildcards and coordinates ///////////////
		for (i = 0; i < (int)clsParas->vstInserts.size(); i++){

			// replace wildcards with serial No. or two alternated chars
			for (j = 0; j < (int)clsParas->vstInserts[i].vsInserts.size(); j++){
				b = false;
				if (clsParas->vstInserts[i].vsInserts[j][0] == WILDCARD_ALLELE_NO
					|| clsParas->vstInserts[i].vsInserts[j][0] == WILDCARD_ALTER_AB)
				{	// the first is wildcard
					b = true;	// if a string include several wildcards, the first meeted wildcard will be used and the others will be ignored.
					bAlt = clsParas->vstInserts[i].vsInserts[j][0] == WILDCARD_ALTER_AB ? true : false;
					n = 0;	// 0th char is wildcard
				}

				if (!b){ // continue to find wildcard while the first is non-wildcard
					for (n = 1; n < (int)clsParas->vstInserts[i].vsInserts[j].size(); n++){
						if (clsParas->vstInserts[i].vsInserts[j][n] == WILDCARD_ALLELE_NO
							|| clsParas->vstInserts[i].vsInserts[j][n] == WILDCARD_ALTER_AB)
						{
							if (clsParas->vstInserts[i].vsInserts[j][n - 1] == '\\') continue;

							b = true;
							bAlt = clsParas->vstInserts[i].vsInserts[j][n] == WILDCARD_ALTER_AB ? true : false;
							break;	// if a string include several wildcards, the first meeted wildcard will be used and the others will be ignored.
						}
					}
				}

				if (b){
					p = clsParas->vstInserts[i].inRow ? colCnt : rowCnt;
					p -= j;		// - number of items before j
					p -= (clsParas->vstInserts[i].vsInserts.size() - j - 1);	// - number of items after j
					p -= clsParas->vstInserts[i].posBegin;						// - beginning posi.

					s1 = n == 0 ? "" : clsParas->vstInserts[i].vsInserts[j].substr(0, n);

					if (clsParas->vstInserts[i].vsInserts[j][n] == WILDCARD_ALTER_AB){
						// two chars used to alternating
						if ((int)clsParas->vstInserts[i].vsInserts[j].length() > n + 2){
							s2 = clsParas->vstInserts[i].vsInserts[j].substr(n + 3);
							cs[0] = clsParas->vstInserts[i].vsInserts[j][n + 1];
							cs[1] = clsParas->vstInserts[i].vsInserts[j][n + 2];
						}
						else{
							s2 = "";
							// two default chars
							cs[0] = '0';
							cs[1] = '1';
						}
					}
					else{
						s2 = clsParas->vstInserts[i].vsInserts[j].substr(n + 1);
					}

					b = true;
					for (k = 0; k < p; k++){
						if (bAlt){ // is WILDCARD_ALTER_AB
							s = s1 + (b ? cs[0] : cs[1]) + s2;
							b = !b;
						}
						else{
							sprintf(cs, "%d", k + 1);	// serial No. is starting from 1
							s = s1 + (string)cs + s2;
						}

						j++;
						clsParas->vstInserts[i].vsInserts.insert(clsParas->vstInserts[i].vsInserts.begin() + j, s);
					}

					p = j - p;
					clsParas->vstInserts[i].vsInserts.erase(clsParas->vstInserts[i].vsInserts.begin() + p);
					break;	// do not care more wildcards
				}
			}
			// scan again to replace "\#" and "\^" with "#" and "^"
			for (j = 0; j < (int)clsParas->vstInserts[i].vsInserts.size(); j++){
				s = WILDCARD_ALLELE_NO;
				clsParas->vstInserts[i].vsInserts[j] = replace_all_distinct(clsParas->vstInserts[i].vsInserts[j], ESC_ALLELE_STR, s);
				s = WILDCARD_ALTER_AB;
				clsParas->vstInserts[i].vsInserts[j] = replace_all_distinct(clsParas->vstInserts[i].vsInserts[j], ESC_ALTER_STR, s);
			}
		}


		p = 0;

		if (clsParas->vstInserts[0].inRow){	// insert rows
			cout << "Inserting rows ..." << endl;

			vString::iterator it = vs.begin();

			for (i = 0; i < (int)clsParas->vstInserts.size(); i++){

				if ((int)clsParas->vstInserts[i].vsInserts.size() > colCnt) {
					cout << "The number of items of the row inserted at " << clsParas->vstInserts[i].no + 1
						<< " is greater than the columns (" << colCnt << ") of the destination." << endl;
				}
				else if ((int)clsParas->vstInserts[i].vsInserts.size() < colCnt) {
					cout << "The number of items of the row inserted at " << clsParas->vstInserts[i].no + 1
						<< " is less than the columns (" << colCnt << ") of the destination." << endl;
				}

				s = "";
				if (!clsParas->vstInserts[i].vsInserts.empty()) {
					for (j = 0; j < clsParas->vstInserts[i].posBegin; j++){
						s += clsParas->vstInserts[i].delim;
					}
					s += clsParas->vstInserts[i].vsInserts[0];
				}

				for (j = 1; j < (int)clsParas->vstInserts[i].vsInserts.size(); j++) {
					s += clsParas->vstInserts[i].delim + clsParas->vstInserts[i].vsInserts[j];
				}

				if (clsParas->vstInserts[i].no < (int)vs.size()) {
					vs.insert(it + clsParas->vstInserts[i].no, s);
				}
				else{
					vs.push_back(s);
				}

				cout << '\t' << ++p << " rows OK.\r";
			}
		}
		else {	// insert col.s
			cout << "Inserting columns ..." << endl;

			for (i = 0; i < (int)clsParas->vstInserts.size(); i++){

				if ((int)clsParas->vstInserts[i].vsInserts.size() > rowCnt){
					sprintf(cs, "The number of items of the column inserted at %d is greater than the rows (%d) of the destination.",
						clsParas->vstInserts[i].no + 1, rowCnt);
					fetalError((string)cs, clsParas);
				}
				else if ((int)clsParas->vstInserts[i].vsInserts.size() < rowCnt) {
					cout << "The number of items of the column inserted at " << clsParas->vstInserts[i].no + 1
						<< " is less than the rows (" << rowCnt << ") of the destination." << endl;
				}

				for (j = 0; j < rowCnt; j++){

					k = charCount(vs[j], clsParas->vstInserts[i].delim);
					if (k == string::npos) k = 0;

					if (clsParas->vstInserts[i].no > k && clsParas->vstInserts[i].posBegin > j) continue;

					b = false;
					for (m = 0; m < clsParas->vstInserts[i].no - k; m++){	// add delimiters
						b = true;
						if ((int)clsParas->vstInserts[i].vsInserts.size() + clsParas->vstInserts[i].posBegin <= j){ break; }
						vs[j] += clsParas->vstInserts[i].delim;

					}

					if (b) {
						if ((int)clsParas->vstInserts[i].vsInserts.size() + clsParas->vstInserts[i].posBegin <= j) continue;
						vs[j] += clsParas->vstInserts[i].vsInserts[j - clsParas->vstInserts[i].posBegin];
					}
					else{
						k = charNfind(vs[j].c_str(), clsParas->vstInserts[i].delim, clsParas->vstInserts[i].no);
						if (k == string::npos){
							if (clsParas->vstInserts[i].no > 0){
								vs[j] += clsParas->vstInserts[i].delim + clsParas->vstInserts[i].vsInserts[j - clsParas->vstInserts[i].posBegin];
							}
							else {
								vs[j] = clsParas->vstInserts[i].vsInserts[j - clsParas->vstInserts[i].posBegin] + clsParas->vstInserts[i].delim + vs[j];
							}
						}
						else{
							if (clsParas->vstInserts[i].posBegin > j){
								s1 = vs[j].substr(0, k + 1);
								s2 = clsParas->vstInserts[i].delim + vs[j].substr(k + 1);
								vs[j] = s1 + s2;
							}
							else {
								s1 = vs[j].substr(0, k + 1);
								s2 = clsParas->vstInserts[i].delim + vs[j].substr(k + 1);
								vs[j] = s1 +
									((int)clsParas->vstInserts[i].vsInserts.size() + clsParas->vstInserts[i].posBegin <= j ?
									"" : clsParas->vstInserts[i].vsInserts[j - clsParas->vstInserts[i].posBegin])
									+ s2;
							}
						}
					}
				}

				cout << '\t' << ++p << " columns OK.\r";
			}
		}

		cout << "\nSaving to file " << clsParas->sOutputFilename << ". Please wait ..." << endl;
		cout << "\tTotal " << rowCnt << " rows." << endl;
		openStreamFile(fp, clsParas->sOutputFilename.c_str(), ios::out);

		j = 0;
		for (i = 0; i < rowCnt; i++){
			fp << vs[i] << endl;

			cout << '\t' << ++j << " rows OK.\r";
		}
		fp.close();
		fp.clear();
		cout << endl;
		vString().swap(vs);

		cout << "Inserted OK." << endl;
		clsParas->fpLog << "Inserted OK." << endl;
	}

}
