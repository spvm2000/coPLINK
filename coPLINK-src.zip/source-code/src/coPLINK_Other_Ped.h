//////////////////////////////////////////////////////////////////
//                                                              //
//           coPLINK (c) 2020-2024 Han-Ming LIU                 //
//                                                              //
// This file is distributed under the GNU General Public        //
// License, Version 3.  Please see the file COPYING for more    //
// details                                                      //
//                                                              //
//////////////////////////////////////////////////////////////////

#ifndef _H_COPLINK_OTHER_PED_H_
#define	_H_COPLINK_OTHER_PED_H_

#include "coPLINK.h"

namespace coPLINK
{
	void Other2Ped(parameters *clsParas);
	void readPed6Map4Cols(vvString &vvsPed4, vvString &vvsMAP, vvChar &vvcPed2, parameters *clsParas);
	int verifyPed6Map4Cols(vvString &vvsPed4, vvString &vvsMAP, vvChar &vvcPed2, parameters *clsParas);
	void readGenotypes(vvString &vvsPed4, vvString &vvsMAP, vvChar &vvcPed2, vvChar &vvcAlleles, parameters *clsParas);

	void Ped2Other(parameters *clsParas);
	void saveOthers(vvChar &vvcAlleles, vvString &vvsPed6, vvString &vvsMAP, parameters *clsParas);
	void saveOneRow(fstream &fp, int iRow, int colCnt, string &fn, vvChar &vvcAlleles, vvString &vvsPed6, vvString &vvsMAP, coPLINK::parameters *clsParas);
	void coordinateTrans(string &fn, vvChar &vvcAlleles, vvString &vvsPed6, vvString &vvsMAP, int *rowCnt, int *colCnt, coPLINK::parameters *clsParas);
}

#endif // !_H_COPLINK_OTHER_PED_H_
