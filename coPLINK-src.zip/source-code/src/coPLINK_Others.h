//////////////////////////////////////////////////////////////////
//                                                              //
//           coPLINK (c) 2020-2024 Han-Ming LIU                 //
//                                                              //
// This file is distributed under the GNU General Public        //
// License, Version 3.  Please see the file COPYING for more    //
// details                                                      //
//                                                              //
//////////////////////////////////////////////////////////////////

#ifndef _COPLINK_OTHERS_H_
#define	_COPLINK_OTHERS_H_

#include "coPLINK.h"

namespace coPLINK
{
	void Tped2Ped(vString &vsTped, vString &vsMap, vString &vsTfam, parameters *clsParas);
	void Tped2UsrTped(vString &vsTped, vString &vsMap, vString &vsTfam, parameters *clsParas);
	void Ped2Tped(vString& vsMap, vString &vsPed, parameters *clsParas);
	void Ped2Tped(vvString& vvsMap, vString& vsPed6, vvChar &vvcPed, parameters *clsParas, bool bStandard);
	void Ped2Tped2(vString& vsMap, vString &vsPed, parameters *clsParas);
	void Ped2Tped3(vString& vsMap, vString &vsPed, parameters *clsParas);
	void SplicingPeds(parameters *clsParas);
	void Lingkage2Ped(parameters *clsParas);
	void Ped2Lingkage(parameters *clsParas, bool bLinkage);
	void GsLingkage2Ped(parameters *clsParas);
	void LogicReg2Ped(parameters *clsParas);
	void Ped2BOOST(vString& vsPed6, vvChar vvcPed, parameters *clsParas);
	void Ped2ME(vvChar& vvcPed, vString& vsPed6, parameters *clsParas);
	void Bed2ME(InData *sData, string fn);
	void Ped2BEAM(vvChar& vvcPed, vString& vsPed6, vvString& vvsMap, parameters *clsParas);
	void Ped2Geo(vvChar& vvcPed, vString& vsPed6, vvString &vvsMAP, parameters *clsParas);
	void Bed2BEAM(InData *sData, parameters *clsParas);
	void Ped2MDR(vvString& vvsMap, vString &vsPed6, vvChar &vvcPed, parameters *clsParas);
	void Ped2Pretty(vvString& vvsMap, vString &vsPed6, vvChar &vvcPed, parameters *clsParas);
	void Ped2Bed(vvString& vvsMap, vvChar& vvcPed, vString& vsPed6, parameters *clsParas);
	void TestPedAlleles(vvString& vvsMap, vString &vsPed, const char* sPedFn, parameters *clsParas);
	void Ped2LogicReg(vvChar vvcPed, vString& vsPed6, parameters *clsParas);
	void Ped2SVMSNPs(vvChar& vvcPed, vString& vsPed6, vvString &vvsMap, parameters *clsParas);
	void BOOST2Ped(vvChar& vvcData, string fOut, string strNo, uint uSeed);
	void BOOST2Bed(vvChar& vvcData, parameters *clsParas);
	void ME2Ped(vInt &viNo, vChar &vcPhenotypes, vvChar& vvcData, parameters *clsParas);
	void ME2BOOST(vChar &vcPhenotypes, vvChar& vvcData, parameters *clsParas);
	void BEAM2Ped(vvString& vvsBEAM3, vvChar& vvcData, parameters *clsParas);
	void BEAM2BOOST(vvString& vvsBEAM3, vvChar& vvcData, parameters *clsParas);
	void Geo2Ped(vvChar &vvcGeo, vvString &vvsMAP, parameters *clsParas);
	void Prettybase2Ped(vvString &vvsInfo, vvChar& vvcAlleles, parameters *clsParas);// 以前写的早期版本的pretty格式
	void Prettybase2Ped(parameters *clsParas);
	void MDR2Ped(vvString& vvsMap, vvChar& vvcData, parameters *clsParas);
	void MDR2BOOST(vvChar& vvcData, parameters *clsParas);
	void Ped2Ped(vvChar& vvcPed, vString& vsPed6, vvString &vvsMap, parameters *clsParas);
	void Delimeter12Delimeter2(string fIn, string fOut, const char cDelimeter1, const char cDelimeter2, fstream &fpStat);
	void cmpFileInOrder(parameters *clsParas);
	void cmpFileInRef(parameters *clsParas);
	void fileCompare(parameters *clsParas);
	void Bed2Tped(InData *sData, parameters *clsParas);
	void Tped2Bed(vString &vsTped, vString &vsMap, vString &vsTfam, parameters *clsParas);
	void Bed2BOOST(InData *sData, string fnOut, bool bSwap);

}



#endif // !_COPLINK_OTHERS_H_
