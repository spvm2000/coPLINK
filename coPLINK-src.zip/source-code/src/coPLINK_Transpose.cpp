//////////////////////////////////////////////////////////////////
//                                                              //
//           coPLINK (c) 2020-2024 Han-Ming LIU                 //
//                                                              //
// This file is distributed under the GNU General Public        //
// License, Version 3.  Please see the file COPYING for more    //
// details                                                      //
//                                                              //
//////////////////////////////////////////////////////////////////

#include "coPLINK_Transpose.h"

namespace coPLINK
{

	/*************************************************
	* 文本文本转置
	* sOverloadFlag = 函数重载标志，无实际使用
	* 通过vvString实现，占用内存较大。在2G内存剩余，200M文件基本会内存溢出。
	* 本函数实际意义不大，未真正使用。
	**************************************************/
	void fileTranspose(parameters *clsParas, string sOverloadFlag)
	{
		fstream	fp;
		string		sLine;
		vString		vs;
		vvString	vvs;
		int			i, j, k, m, n, maxL;

		cout << "Reading source file " << clsParas->sInputFilename << ". Please wait ..." << endl;

		openStreamFile(fp, clsParas->sInputFilename.c_str(), ios::in);
		m = 0;
		while (getline(fp, sLine)) {
			trimString(sLine);							//删除前后空格及TAB
			trimRedundance(sLine, true);				//删除中间多余空格及TAB（只保留一个），并把TAB用空格替换

			if (clsParas->cDelimeter != ' ' && clsParas->cDelimeter != '\t') {	// 当分隔符不是空格或TAB时，上一步操作会在分隔符前后留一个空格（如果有的话）
				trimRoundDelim(sLine, clsParas->cDelimeter);					// 删除分隔符前后的一个空格或TAB
			}

			//分隔符替换
			if (clsParas->cDelimeter == '\t'){ replaceChar(sLine, ' ', '\t'); }

			stringSplit(sLine.c_str(), vs, clsParas->cDelimeter);
			vvs.push_back(vs);
			cout << '\t' << ++m << "...\r";
		}
		string().swap(sLine);
		vString().swap(vs);
		fp.close();
		fp.clear();
		cout << endl;

		// erase all of null rows at end of the file
		for (i = (int)vvs.size() - 1; i >= 0; i--){
			if (vvs[i].size() == 1 && vvs[i][0][0] == '\0'){
				vvs.erase(vvs.begin() + i);
			}
			else{ break; }
		}

		if (vvs.empty()){
			fetalError("The source file " + clsParas->sOutputFilename + " has nothing.", clsParas);
		}

		// find the max field count of row
		maxL = 0;
		for (i = 0; i < (int)vvs.size(); i++){
			m = vvs[i].size();
			if (m > maxL){
				maxL = m;		// max field count
				k = i;			// row No.
			}
		}

		j = maxL;
		i = 0;
		while (true){
			// resize the rows before k
			for (; i < k; i++){
				vvs[i].resize(j);
			}

			if (i == (int)vvs.size()) break;

			// find again
			j = 0;
			n = ++i;	// save original i 
			for (; i < (int)vvs.size(); i++){
				m = vvs[i].size();
				if (m > j){
					j = m;		// max field count
					k = i;		// row No.
				}
			}
			i = n;		// restore i
		}

		cout << "Saving to file " << clsParas->sOutputFilename << ". Please wait ..." << endl;

		openStreamFile(fp, clsParas->sOutputFilename.c_str(), ios::out);
		m = 0;
		j = vvs.size();
		for (i = 0; i < maxL; i++){
			fp << vvs[0][m];
			for (k = 1; k < j; k++){
				if ((int)vvs[k].size() > m){ fp << clsParas->cDelimeter << vvs[k][m]; }
				else{ break; }
			}
			fp << endl;

			cout << '\t' << ++m << " ...\r";
		}
		fp.close();
		fp.clear();
		cout << endl;

		cout << "OK." << endl;
		clsParas->fpLog << "Transposed OK." << endl;
	}

	/*************************************************
	* 文本文本转置 (overload1)
	* cOverloadFlag = 函数重载标志，无实际使用
	* 通过vector<vector<char*>>实现，占用内存比vvString稍小，约为源文件大小的不到5倍；
	* vvString则至少5倍。
	* 如：195698K，28718列的源文件，仅消耗42秒（i3-4170, 4G, win7 x86）
	* 尝试过使用动态二维char*数组实现，内存消耗并没有比本方法更好。
	* 实验表明，时间消耗与源文件的行、列数明显相关，且列数影响更大，与文件大小关系不是很大。
	* 使用了此重载，以提供内存充足时的快速转换
	**************************************************/
	void fileTranspose(parameters *clsParas, char cOverloadFlag)
	{
		fstream					fp;
		string					sLine;
		vector<char*>			vs;
		vector<vector<char*> >	vvs;
		char					*cs;
		int						i, j, k, m, n, p, maxL;

		cout << "Reading source file " << clsParas->sInputFilename << ". Please wait ..." << endl;

		openStreamFile(fp, clsParas->sInputFilename.c_str(), ios::in);
		m = 0;
		while (getline(fp, sLine)) {
			trimString(sLine);							//删除前后空格及TAB
			trimRedundance(sLine, true);				//删除中间多余空格及TAB（只保留一个），并把TAB用空格替换

			if (clsParas->cDelimeter != ' ' && clsParas->cDelimeter != '\t') {	// 当分隔符不是空格或TAB时，上一步操作会在分隔符前后留一个空格（如果有的话）
				trimRoundDelim(sLine, clsParas->cDelimeter);					// 删除分隔符前后的一个空格或TAB
			}

			//分隔符替换
			if (clsParas->cDelimeter == '\t') replaceChar(sLine, ' ', '\t');
			stringSplit(sLine.c_str(), vs, clsParas->cDelimeter);
			vvs.push_back(vs);

			cout << '\t' << ++m << "...\r";
		}
		string().swap(sLine);
		vector<char*>().swap(vs);
		fp.close();
		fp.clear();
		cout << endl;

		// erase all of null rows at end of the file
		for (i = (int)vvs.size() - 1; i >= 0; i--){
			if (vvs[i].size() == 1 && vvs[i][0][0] == '\0'){
				vvs.erase(vvs.begin() + i);
			}
			else{ break; }
		}

		if (vvs.empty()){
			fetalError("The source file " + clsParas->sOutputFilename + " has nothing.", clsParas);
		}

		// find the max field count of row
		maxL = 0;
		for (i = 0; i < (int)vvs.size(); i++){
			m = vvs[i].size();
			if (m > maxL){
				maxL = m;		// max field count
				k = i;			// row No.
			}
		}

		j = maxL;
		i = 0;
		while (true){
			// resize the rows before k
			for (; i < k; i++){
				m = vvs[i].size();
				//vvs[i].resize(j);		// cannot do like this, which is different from vector<string>
				for (p = m; p < j; p++) {
					//vvs[i].push_back("");	// do like this will result in an error at release step
					cs = new char[2];
					cs[0] = cs[1] = '\0';
					vvs[i].push_back(cs);
				}
			}

			if (i == (int)vvs.size()) break;

			// find again
			j = 0;
			n = ++i;	// save original i 
			for (; i < (int)vvs.size(); i++){
				m = vvs[i].size();
				if (m > j){
					j = m;		// max field count
					k = i;		// row No.
				}
			}
			i = n;		// restore i
		}

		cout << "Saving to file " << clsParas->sOutputFilename << ". Please wait ..." << endl;
		cout << "\tTotal " << maxL << " rows." << endl;
		openStreamFile(fp, clsParas->sOutputFilename.c_str(), ios::out);
		m = 0;
		j = vvs.size();
		for (i = 0; i < maxL; i++){
			fp << vvs[0][m];
			for (k = 1; k < j; k++){
				if ((int)vvs[k].size() > m) {
					fp << clsParas->cDelimeter << vvs[k][m];
				}
				else{ break; }
			}
			fp << endl;

			cout << '\t' << ++m << " ...\r";
		}
		fp.close();
		fp.clear();
		cout << endl;

		cout << "Clearning ..." << endl;

		for (i = 0; i < (int)vvs.size(); i++){
			for (j = 0; j < (int)vvs[i].size(); j++){
				delete[] vvs[i][j];
			}
			cout << '\t' << i << " ...\r";
		}
		vector<vector<char*> >().swap(vvs);

		cout << "\nOK." << endl;
		clsParas->fpLog << "Transposed OK." << endl;
	}

	/*************************************************
	* 文本文本转置 (overload2)
	* sOverloadFlag = 函数重载标志，无实际使用
	* 通过vString实现，占用内存明显比其它两种方法小，比源文件略大（如548,059K的源文件占用550,240K）。
	* vector<vector<char*>>约为源文件大小的不到5倍，vvString则至少5倍。
	* 本方法速度很慢，其速度与源文件的列数密切相关，随着输出的列号增大，变得越来越慢。
	* 如：195698K，28718列的源文件，消耗近4个小时（i3-4170, 4G, win7 x86）
	* 造成这个现象的原因，应该是getStringN函数随着截取的字段号的增大而string.find的次数增加
	* 实验表明，时间消耗与源文件的行、列数明显相关，且列数影响更大，与文件大小关系不是很大。
	* 此重载虽然内存占用小，但速度太慢，未真正使用
	**************************************************/
	void fileTranspose(parameters *clsParas, int iOverloadFlag)
	{
		fstream		fp;
		string		sLine;
		vString		vs;
		string		s;
		int			i, j, k, m, n, maxL;
		vInt		vFieldOrg, vFieldNew;

		cout << "Reading source file " << clsParas->sInputFilename << ". Please wait ..." << endl;

		openStreamFile(fp, clsParas->sInputFilename.c_str(), ios::in);
		m = 0;
		while (getline(fp, sLine)) {
			trimString(sLine);							//删除前后空格及TAB
			trimRedundance(sLine, true);				//删除中间多余空格及TAB（只保留一个），并把TAB用空格替换

			if (clsParas->cDelimeter != ' ' && clsParas->cDelimeter != '\t') {	// 当分隔符不是空格或TAB时，上一步操作会在分隔符前后留一个空格（如果有的话）
				trimRoundDelim(sLine, clsParas->cDelimeter);					// 删除分隔符前后的一个空格或TAB
			}

			//分隔符替换
			if (clsParas->cDelimeter == '\t'){ replaceChar(sLine, ' ', '\t'); }

			i = charCount(sLine, clsParas->cDelimeter);
			if (i == string::npos){ i = sLine.length() == 0 ? -1 : 0; }

			vFieldOrg.push_back(i + 1);	// field count
			vs.push_back(sLine);

			cout << '\t' << ++m << " rows OK.\r";
		}
		string().swap(sLine);
		fp.close();
		fp.clear();
		cout << endl;

		// erase all of null rows at end of the file
		for (i = (int)vs.size() - 1; i >= 0; i--){
			if (vs[i].size() == 0){
				vs.erase(vs.begin() + i);
				vFieldOrg.erase(vFieldOrg.begin() + i);
			}
			else{ break; }
		}

		if (vs.empty()){
			fetalError("The source file " + clsParas->sOutputFilename + " has nothing.", clsParas);
		}

		// find the max count of field in rows
		maxL = 0;
		for (i = 0; i < (int)vFieldOrg.size(); i++){
			if (vFieldOrg[i] > maxL){
				maxL = vFieldOrg[i];	// max count
				k = i;					// row No.
			}
		}

		vFieldNew = vFieldOrg;
		j = maxL;
		i = 0;
		while (true){
			// resize the rows before k
			for (; i < k; i++){
				vFieldNew[i] += (j - vFieldNew[i]);
			}

			if (i == (int)vFieldNew.size()) break;

			// find again
			j = 0;
			n = ++i;	// save original i 
			for (; i < (int)vFieldNew.size(); i++){
				if (vFieldNew[i] > j){
					j = vFieldNew[i];		// max count
					k = i;					// row No.
				}
			}
			i = n;		// restore i
		}

		cout << "Saving to file " << clsParas->sOutputFilename << ". Please wait ..." << endl;
		cout << "\tTotal " << maxL << " rows." << endl;
		openStreamFile(fp, clsParas->sOutputFilename.c_str(), ios::out);
		m = 0;
		j = vs.size();
		s = clsParas->cDelimeter;
		for (i = 0; i < maxL; i++){
			getStringN(vs[0], s, m, sLine);
			fp << sLine;
			for (k = 1; k < j; k++){
				if (vFieldOrg[k] > m) {
					getStringN(vs[k], s, m, sLine);
					fp << clsParas->cDelimeter << sLine;
				}
				else if (vFieldNew[k] > m){
					fp << clsParas->cDelimeter;
				}
				else{
					break;
				}
			}
			fp << endl;

			cout << '\t' << ++m << " rows OK.\r";
		}
		fp.close();
		fp.clear();
		cout << endl;
		vString().swap(vs);

		cout << "Transposed OK." << endl;
		clsParas->fpLog << "Transposed OK." << endl;
	}

	/*************************************************
	* 文本文本转置 (overload3)
	* sOverloadFlag = 函数重载标志，无实际使用
	* 通过vString实现，占用内存明显比其它两种方法小，比源文件略大（如548,059K的源文件占用550,495K）。
	* vector<vector<char*>>约为源文件大小的不到5倍，vvString则至少5倍。
	* 本方法速度比重载1慢，但明显比重载2快，其速度与源文件的列数无关，不会像重载2那样越来越慢。
	* 如：与重载2的同一个文件，195698K，28718列的源文件，消耗仅12分钟（i3-4170, 4G, win7 x86）
	* 造成这个现象的原因，应该是每次提取的都是第一个字段，string.find次数都为1。
	* 实验表明，时间消耗与源文件的行、列数明显相关，且列数影响更大，与文件大小关系不是很大。
	* 使用了此重载，以提供内存不足时，也能较快地转换
	**************************************************/
	void fileTranspose(parameters *clsParas, float fOverloadFlag)
	{
		fstream		fp;
		string		sLine;
		vString		vs, vsFields;
		string		s;
		int			i, j, k, m, maxL, iSize;

		cout << "Reading source file " << clsParas->sInputFilename << ". Please wait ..." << endl;

		openStreamFile(fp, clsParas->sInputFilename.c_str(), ios::in);
		m = 0;
		maxL = 0;
		while (getline(fp, sLine)) {
			trimString(sLine);							//删除前后空格及TAB
			trimRedundance(sLine, true);				//删除中间多余空格及TAB（只保留一个），并把TAB用空格替换

			if (clsParas->cDelimeter != ' ' && clsParas->cDelimeter != '\t') {	// 当分隔符不是空格或TAB时，上一步操作会在分隔符前后留一个空格（如果有的话）
				trimRoundDelim(sLine, clsParas->cDelimeter);					// 删除分隔符前后的一个空格或TAB
			}

			//分隔符替换
			if (clsParas->cDelimeter == '\t'){ replaceChar(sLine, ' ', '\t'); }

			i = charCount(sLine, clsParas->cDelimeter);
			if (i == string::npos){ i = sLine.length() == 0 ? -1 : 0; }

			if (maxL < i + 1){ maxL = i + 1; }	// max field count
			vs.push_back(sLine);

			cout << '\t' << ++m << " rows OK.\r";
		}
		string().swap(sLine);
		fp.close();
		fp.clear();
		cout << endl;

		// erase all of null rows at end of the file
		for (i = (int)vs.size() - 1; i >= 0; i--){
			if (vs[i].size() == 0){
				vs.erase(vs.begin() + i);
			}
			else{ break; }
		}

		if (vs.empty()){
			fetalError("The source file " + clsParas->sOutputFilename + " has nothing.", clsParas);
		}

		cout << "Saving to file " << clsParas->sOutputFilename << ". Please wait ..." << endl;
		cout << "\tTotal " << maxL << " rows." << endl;
		openStreamFile(fp, clsParas->sOutputFilename.c_str(), ios::out);

		m = 0;
		iSize = vs.size();
		s = clsParas->cDelimeter;
		vsFields.resize(iSize);
		for (i = 0; i < maxL; i++){
			// get the first fields of vs
			for (j = 0; j < iSize; j++){
				k = vs[j].find(clsParas->cDelimeter);		// 网上：在实践中还发现，string::find(char)比较string::find(string)慢很多，所以建议不要使用string::find(char)。
				// 自己的对比实验发现，string::find(char)反而略快
				if (k == string::npos){
					vsFields[j] = vs[j].length() == 0 ? "" : vs[j];
				}
				else{
					vsFields[j] = vs[j].substr(0, k);
					vs[j] = vs[j].substr(k + 1);
				}
			}
			// find the max row No. with non-null
			k = -1;
			for (j = iSize - 1; j >= 0; j--){
				if (vsFields[j].length() > 0){
					k = j + 1;
					break;
				}
			}
			if (k < 0){
				cout << '\t' << ++m << " rows OK.\r";
				continue;
			}

			fp << vsFields[0];
			for (j = 1; j < k; j++){
				fp << clsParas->cDelimeter << vsFields[j];
			}
			fp << endl;

			cout << '\t' << ++m << " rows OK.\r";
		}
		fp.close();
		fp.clear();
		cout << endl;
		vString().swap(vs);
		vString().swap(vsFields);

		cout << "Transposed OK." << endl;
		clsParas->fpLog << "Transposed OK." << endl;
	}
}
