//////////////////////////////////////////////////////////////////
//                                                              //
//           coPLINK (c) 2020-2024 Han-Ming LIU                 //
//                                                              //
// This file is distributed under the GNU General Public        //
// License, Version 3.  Please see the file COPYING for more    //
// details                                                      //
//                                                              //
//////////////////////////////////////////////////////////////////

#include "coPLINK.h"
#include "coPLINK_Ins_Del.h"
#include "coPLINK_Other_Ped.h"
#include "coPLINK_Transpose.h"
#include "coPLINK_Others.h"

#ifdef TEST_PERFORMANCE
/************ Windows环境记录峰值内存占用（Linux无效） **********/
#include <iostream>
#include <windows.h>
#include <psapi.h>

#pragma  once
#pragma  comment(lib,"Psapi.lib")
#endif
/***************************************************************/

/*******注意：所有表型、基因型数据如果是多字符组成，只取第1个字符********/
int main(int argc, char **argv)
{
	cout << "#----------------------------------------------------------#\n";
	cout << "|            coPLINK          |        V4.0 Feb. 2020      |\n";
	cout << "|----------------------------------------------------------|\n";
	cout << "|   (C) 2020 Han-Ming LIU, GNU General Public License, V3  |\n";
	cout << "|----------------------------------------------------------|\n";
	cout << "|               Bug-report: lhmgzjx@163.com                |\n";
	cout << "|----------------------------------------------------------|\n";
	cout << "|  Please cite the paper if you used this program in your  |\n";
	cout << "|  research for publication.                               |\n";
	cout << "#----------------------------------------------------------#\n";

	cout << endl;

	coPLINK::parameters gfcParas(argc, argv);	//需先写此行，以利用构造函数初始化

	vvInt		vviData;
	vInt		viData;
	vString		vsData1, vsData2, vsData3;
	vvString	vvsData, vvsData1;
	vvChar		vvcData;
	vChar		vcData;
	coPLINK::InData	sData;
	string		sTmp;
	char		cTmp[SHORT_LEN];
	uint		i;
	
#ifdef TEST_PERFORMANCE
	/********* 计算消耗时间（测试用）*******************/
	time_t first, second;
	first = time(NULL);
	/***************************************************/
#endif

	// 写统计文件（Parameter	file	case	control	SNP）--compare 参数不写统计文件
	if (coPLINK::sArgs[gfcParas.iOpCode] == OP_DELETE
		|| coPLINK::sArgs[gfcParas.iOpCode] == OP_DELETE
		|| coPLINK::sArgs[gfcParas.iOpCode] == OP_TEST_ALLELE
		|| coPLINK::sArgs[gfcParas.iOpCode] == OP_TRANSPOSE
		|| coPLINK::sArgs[gfcParas.iOpCode] == OP_PRETTY2PED){		// 这几种参数不存在case	control	SNP，仅记录参数名和输入文件名
		gfcParas.fpStat << '\'' << coPLINK::sArgs[gfcParas.iOpCode]	// 记录操作（加入单引号，目的是为了在Excel中能正确显示，否则Excel会自动在--前面加=）
			<< ',' << gfcParas.sInputFilename << ",-,-,-" << endl;
	}
	else gfcParas.fpStat << '\'' << coPLINK::sArgs[gfcParas.iOpCode];

	if (coPLINK::sArgs[gfcParas.iOpCode] == OP_OTHER2PED) {			// 任意其它格式转PLINK ped
		coPLINK::Other2Ped(&gfcParas);
	}
	else if (coPLINK::sArgs[gfcParas.iOpCode] == OP_PED2OTHER) {	// PLINK ped转任意其它格式
		gfcParas.fpStat << '\'' << coPLINK::sArgs[gfcParas.iOpCode];// 记录操作（加入单引号，目的是为了在Excel中能正确显示，否则Excel会自动在--前面加=）
		coPLINK::Ped2Other(&gfcParas);
	}
	else if (coPLINK::sArgs[gfcParas.iOpCode] == OP_DELETE) {		// 文本格式文件中删除行或列
		coPLINK::InsDel::fileDelete(&gfcParas);
	}
	else if (coPLINK::sArgs[gfcParas.iOpCode] == OP_INSERT) {		// 为文本格式文件插入行或列
		coPLINK::InsDel::fileInsert(&gfcParas);
	}
	else if (coPLINK::sArgs[gfcParas.iOpCode] == OP_LOG2PED) {		// 为文本格式文件插入行或列
		coPLINK::LogicReg2Ped(&gfcParas);
	}
	else if (coPLINK::sArgs[gfcParas.iOpCode] == OP_BOOST2PED) {	//BOOST转PLINK ped
		cout << "Loading file " << gfcParas.sInputFilename << " ..." << endl;

		coPLINK::readBOOST(vvcData, &gfcParas);
		cout << "Converting ..." << endl;
		coPLINK::BOOST2Ped(vvcData, gfcParas.sOutputFilename, gfcParas.sChrNo, gfcParas.uRndSeed);
	}
	else if (coPLINK::sArgs[gfcParas.iOpCode] == OP_BOOST2BED) {	//BOOST转PLINK bed
		cout << "Loading file " << gfcParas.sInputFilename << " ..." << endl;

		coPLINK::readBOOST(vvcData, &gfcParas);
		cout << "Converting ..." << endl;
		coPLINK::BOOST2Bed(vvcData, &gfcParas);
	}
	else if (coPLINK::sArgs[gfcParas.iOpCode] == OP_PED2BOOST || coPLINK::sArgs[gfcParas.iOpCode] == OP_LINK2BOOST) {	//PLINK ped或Linkage转BOOST
		cout << "Loading file " << gfcParas.sInputFilename << " ..." << endl;

		coPLINK::readPed(vvcData, vsData1, &gfcParas);				// 基因型结果为字符矩阵（多字符基因型只保留首字符）

		if (gfcParas.bPreprocess){
			if (!coPLINK::chkSample4Ped(vvcData, vsData1, &gfcParas, sTmp)){	// 需在预处理之前，其可能删除样本
				coPLINK::fetalError("An error is encountered while alleles missing rates of samples checking: " + sTmp, &gfcParas);
			}

			if (!coPLINK::preprocessPed(vvcData, vvsData, &gfcParas, false, sTmp)){
				coPLINK::fetalError("An error is encountered while preprocessing: " + sTmp, &gfcParas);
			}
		}
		cout << "Converting ..." << endl;

		coPLINK::Ped2BOOST(vsData1, vvcData, &gfcParas);
	}
	else if (coPLINK::sArgs[gfcParas.iOpCode] == OP_PED2LOG) {		//PLINK ped转LogicReg
		cout << "Loading file " << gfcParas.sInputFilename << " ..." << endl;

		coPLINK::readPed(vvcData, vsData1, &gfcParas);				// 基因型结果为字符矩阵（多字符基因型只保留首字符）

		if (gfcParas.bPreprocess){
			if (!coPLINK::chkSample4Ped(vvcData, vsData1, &gfcParas, sTmp)){	// 需在预处理之前，其可能删除样本
				coPLINK::fetalError("An error is encountered while alleles missing rates of samples checking: " + sTmp, &gfcParas);
			}

			if (!coPLINK::preprocessPed(vvcData, vvsData, &gfcParas, false, sTmp)){
				coPLINK::fetalError("An error is encountered while preprocessing: " + sTmp, &gfcParas);
			}
		}

		cout << "Converting ..." << endl;

		coPLINK::Ped2LogicReg(vvcData, vsData1, &gfcParas);
	}
	else if (coPLINK::sArgs[gfcParas.iOpCode] == OP_SPC2CSV) {		//空格分隔的文本文件转CSV
		/*cout << "Loading file " << gfcParas.sInputFilename << " ..." << endl;
		coPLINK::readWithDelimeter(vvsData, gfcParas.sInputFilename);
		cout << "Converting ..." << endl;
		coPLINK::saveWithDelimeter(vvsData, coPLINK::addExt(gfcParas.sOutputFilename, ".csv"));*/
		// 以上写法，大文件会内存溢出
		cout << "Converting ..." << endl;

		coPLINK::Delimeter12Delimeter2(gfcParas.sInputFilename, coPLINK::addExt(gfcParas.sOutputFilename, ".csv"), ' ', ',', gfcParas.fpStat);
	}
	else if (coPLINK::sArgs[gfcParas.iOpCode] == OP_CSV2SPC) {		//CSV转空格分隔的文本文件
		/*cout << "Loading file " << gfcParas.sInputFilename << " ..." << endl;
		coPLINK::readWithDelimeter(vvsData, gfcParas.sInputFilename, ",");
		cout << "Converting ..." << endl;
		coPLINK::saveWithDelimeter(vvsData, gfcParas.sOutputFilename, " ");*/
		// 以上写法，大文件会内存溢出
		cout << "Converting ..." << endl;

		coPLINK::Delimeter12Delimeter2(gfcParas.sInputFilename, gfcParas.sOutputFilename, ',', ' ', gfcParas.fpStat);
	}
	else if (coPLINK::sArgs[gfcParas.iOpCode] == OP_ME2PED) {		//ME格式的文本文件转PLINK ped
		cout << "Loading file " << gfcParas.sInputFilename << " ..." << endl;

		coPLINK::readME(viData, vcData, vvcData, &gfcParas);
		cout << "Converting ..." << endl;
		coPLINK::ME2Ped(viData, vcData, vvcData, &gfcParas);
	}
	else if (coPLINK::sArgs[gfcParas.iOpCode] == OP_ME2BOOST) {		//ME格式的文本文件转BOOST
		cout << "Loading file " << gfcParas.sInputFilename << " ..." << endl;

		coPLINK::readME(viData, vcData, vvcData, &gfcParas);
		vInt().swap(viData);		// un-used
		cout << "Converting ..." << endl;
		coPLINK::ME2BOOST(vcData, vvcData, &gfcParas);
	}
	else if (coPLINK::sArgs[gfcParas.iOpCode] == OP_PED2ME) {		//PLINK ped文本格式的文本文件转ME
		cout << "Loading file " << gfcParas.sInputFilename << " ..." << endl;

		coPLINK::readPed(vvcData, vsData1, &gfcParas);				// 基因型结果为字符矩阵（多字符基因型只保留首字符）
		if (gfcParas.bPreprocess){
			if (!coPLINK::chkSample4Ped(vvcData, vsData1, &gfcParas, sTmp)){	// 需在预处理之前，其可能删除样本
				coPLINK::fetalError("An error is encountered while alleles missing rates of samples checking: " + sTmp, &gfcParas);
			}

			if (!coPLINK::preprocessPed(vvcData, vvsData, &gfcParas, false, sTmp)){
				coPLINK::fetalError("An error is encountered while preprocessing: " + sTmp, &gfcParas);
			}
		}

		cout << "Converting ..." << endl;
		coPLINK::Ped2ME(vvcData, vsData1, &gfcParas);
	}
	else if (coPLINK::sArgs[gfcParas.iOpCode] == OP_BEAM2PED) {		//BEAM格式的文本文件转PLINK ped
		cout << "Loading file " << gfcParas.sInputFilename << " ..." << endl;

		coPLINK::readBEAM(vvsData, vvcData, &gfcParas);
		cout << "Converting ..." << endl;
		coPLINK::BEAM2Ped(vvsData, vvcData, &gfcParas); 
	}
	else if (coPLINK::sArgs[gfcParas.iOpCode] == OP_BEAM2BOOST) {		//BEAM格式的文本文件BOOST
		cout << "Loading file " << gfcParas.sInputFilename << " ..." << endl;

		coPLINK::readBEAM(vvsData, vvcData, &gfcParas);
		cout << "Converting ..." << endl;
		coPLINK::BEAM2BOOST(vvsData, vvcData, &gfcParas);
	}
	else if (coPLINK::sArgs[gfcParas.iOpCode] == OP_PED2BEAM) {		//PLINK ped文本格式的文本文件转BEAM
		cout << "Loading file " << gfcParas.sInputFilename << " ..." << endl;

		coPLINK::readPed(vvcData, vsData1, &gfcParas);				// 基因型结果为字符矩阵（多字符基因型只保留首字符）
		coPLINK::readWithDelimeter(vvsData, coPLINK::getFn(gfcParas.sInputFilename, ".map", true), &gfcParas);

		cout << "Converting ..." << endl;

		coPLINK::Ped2BEAM(vvcData, vsData1, vvsData, &gfcParas);
	}
	else if (coPLINK::sArgs[gfcParas.iOpCode] == OP_PED2GEO) {		//PLINK ped文本格式的文本文件转geo格式
		cout << "Loading file " << gfcParas.sInputFilename << " ..." << endl;

		coPLINK::readPed(vvcData, vsData1, &gfcParas);				// 基因型结果为字符矩阵（多字符基因型只保留首字符）
		coPLINK::readWithDelimeter(vvsData, coPLINK::getFn(gfcParas.sInputFilename, ".map", true), &gfcParas);

		cout << "Converting ..." << endl;

		coPLINK::Ped2Geo(vvcData, vsData1, vvsData, &gfcParas);
	}
	else if (coPLINK::sArgs[gfcParas.iOpCode] == OP_GEO2PED) {		//geo格式转PLINK ped文本格式的文本文件
		cout << "Loading file " << gfcParas.sInputFilename << " ..." << endl;

		coPLINK::readGeo(vvcData, &gfcParas);						// 基因型结果为字符矩阵（多字符基因型只保留首字符）
		coPLINK::readWithDelimeter(vvsData, coPLINK::getFn(gfcParas.sInputFilename, ".map"), &gfcParas, ",");
		cout << "Converting ..." << endl;
		coPLINK::Geo2Ped(vvcData, vvsData, &gfcParas);
	}
	else if (coPLINK::sArgs[gfcParas.iOpCode] == OP_PED2SVM) {		//PLINK ped的文本文件转SVMSNPs文本格式
		cout << "Loading file " << gfcParas.sInputFilename << " ..." << endl;

		coPLINK::readPed(vvcData, vsData1, &gfcParas);				// 基因型结果为字符矩阵（多字符基因型只保留首字符）
		coPLINK::readWithDelimeter(vvsData, coPLINK::getFn(gfcParas.sInputFilename, ".map", true), &gfcParas);

		cout << "Converting ..." << endl;
		
		coPLINK::Ped2SVMSNPs(vvcData, vsData1, vvsData, &gfcParas);
	}
	else if (coPLINK::sArgs[gfcParas.iOpCode] == OP_SVM2PED) {		//SVMSNPs文本格式转PLINK ped文本文件
		coPLINK::SVMSNPs2PED(&gfcParas);
	}
	else if (coPLINK::sArgs[gfcParas.iOpCode] == OP_MDR2PED) {		//MDR格式的文本文件转PLINK ped
		cout << "Loading file " << gfcParas.sInputFilename << " ..." << endl;

		coPLINK::readMDR(vvsData, vvcData, &gfcParas);
		cout << "Converting ..." << endl;
		coPLINK::MDR2Ped(vvsData, vvcData, &gfcParas);
	}
	else if (coPLINK::sArgs[gfcParas.iOpCode] == OP_MDR2BOOST) {	//MDR格式的文本文件转BOOST
		cout << "Loading file " << gfcParas.sInputFilename << " ..." << endl;

		coPLINK::readMDR(vvsData, vvcData, &gfcParas);
		vvString().swap(vvsData);	// un-used
		cout << "Converting ..." << endl;
		coPLINK::MDR2BOOST(vvcData, &gfcParas);
	}
	else if (coPLINK::sArgs[gfcParas.iOpCode] == OP_PED2MDR) {		//PLINK ped文本格式的文本文件转MDR
		cout << "Loading file " << gfcParas.sInputFilename << " ..." << endl;

		coPLINK::readPed(vvcData, vsData1, &gfcParas);				// 基因型结果为字符矩阵（多字符基因型只保留首字符）
		coPLINK::readWithDelimeter(vvsData, coPLINK::getFn(gfcParas.sInputFilename, ".map", true), &gfcParas);

		cout << "Converting ..." << endl;
		
		coPLINK::Ped2MDR(vvsData, vsData1, vvcData, &gfcParas);
	}
	else if (coPLINK::sArgs[gfcParas.iOpCode] == OP_PED2BED) {		//PLINK ped文本格式的文本文件转PLINK bed二进制格式
		cout << "Loading file " << gfcParas.sInputFilename << " ..." << endl;

		coPLINK::readPed(vvcData, vsData1, &gfcParas);				// 基因型结果为字符矩阵（多字符基因型只保留首字符）
		coPLINK::readWithDelimeter(vvsData, coPLINK::getFn(gfcParas.sInputFilename, ".map", true), &gfcParas);

		cout << "Converting ..." << endl;

		coPLINK::Ped2Bed(vvsData, vvcData, vsData1, &gfcParas);
	}
	else if (coPLINK::sArgs[gfcParas.iOpCode] == OP_PED2PED) {		//为PLINK ped文本格式文件随机生成个体性别并归一化数据（PLINK不会处理“未知性别”的个体）
		//若输出文件名等于输入文件名或未指定输出文件名，则把输入文件名改名为.bak
		cout << "Loading file " << gfcParas.sInputFilename << " ..." << endl;

		coPLINK::readPed(vvcData, vsData1, &gfcParas);				// 基因型结果为字符矩阵（多字符基因型只保留首字符）
		cout << "Converting ..." << endl;

		if (gfcParas.sOutputFilename.length() == 0) gfcParas.sOutputFilename = gfcParas.sInputFilename;
		if (gfcParas.iMode == 0 || gfcParas.bSex) {
			if (gfcParas.sInputFilename == gfcParas.sOutputFilename) {
				gfcParas.sInputFilename = coPLINK::getFn(gfcParas.sInputFilename, ".ped");
				sTmp = gfcParas.sInputFilename + ".bak";
				i = 0;
				while (1) {		//找到不重复的文件名
					if (access(sTmp.c_str(), 0) == -1) break;	//文件不存在
					//_itoa_s(i, cTmp, sizeof cTmp / sizeof cTmp[0], 10);
					sprintf(cTmp, "%d", i);
					sTmp = cTmp;
					sTmp = gfcParas.sInputFilename + "(" + sTmp + ").bak";
					i++;
				}
				rename(gfcParas.sInputFilename.c_str(), sTmp.c_str());
			}
		}
		coPLINK::readWithDelimeter(vvsData, coPLINK::getFn(gfcParas.sInputFilename, ".map", true), &gfcParas);
		coPLINK::Ped2Ped(vvcData, vsData1, vvsData, &gfcParas);
	}
	else if (coPLINK::sArgs[gfcParas.iOpCode] == OP_PRETTY2PED) {	// Prettybase格式的文本文件转PLINK ped
		coPLINK::Prettybase2Ped(&gfcParas);
	}
	else if (coPLINK::sArgs[gfcParas.iOpCode] == OP_PED2PRETTY) {	// PLINK ped转Prettybase格式的文本文件
		cout << "Loading file " << gfcParas.sInputFilename << " ..." << endl;

		coPLINK::readPed(vvcData, vsData1, &gfcParas);				// 基因型结果为字符矩阵（多字符基因型只保留首字符）
		coPLINK::readWithDelimeter(vvsData, coPLINK::getFn(gfcParas.sInputFilename, ".map", true), &gfcParas);

		cout << "Converting ..." << endl;

		coPLINK::Ped2Pretty(vvsData, vsData1, vvcData, &gfcParas);
	}
	else if (coPLINK::sArgs[gfcParas.iOpCode] == OP_BED2BEAM) {		//PLINK二进制格式转BEAM格式
		cout << "Loading file " << gfcParas.sInputFilename << " ..." << endl;
		coPLINK::readBed(&sData, &gfcParas);
		cout << "Converting ..." << endl;
		coPLINK::Bed2BEAM(&sData, &gfcParas);
	}
	else if (coPLINK::sArgs[gfcParas.iOpCode] == OP_BED2ME) {		//PLINK二进制格式转ME格式
		cout << "Loading file " << gfcParas.sInputFilename << " ..." << endl;
		coPLINK::readBed(&sData, &gfcParas);
		cout << "Converting ..." << endl;
		coPLINK::Bed2ME(&sData, coPLINK::addExt(gfcParas.sOutputFilename, ".me"));
	}
	else if (coPLINK::sArgs[gfcParas.iOpCode] == OP_BED2TPED) {		//PLINK二进制格式转TPED格式
		cout << "Loading file " << gfcParas.sInputFilename << " ..." << endl;
		coPLINK::readBed(&sData, &gfcParas);
		cout << "Converting ..." << endl;
		coPLINK::Bed2Tped(&sData, &gfcParas);
	}
	else if (coPLINK::sArgs[gfcParas.iOpCode] == OP_BED2BOOST) {	//PLINK二进制格式转BOOST格式
		cout << "Loading file " << gfcParas.sInputFilename << " ..." << endl;
		coPLINK::readBed(&sData, &gfcParas);
		cout << "Converting ..." << endl;
		coPLINK::Bed2BOOST(&sData, gfcParas.sOutputFilename, gfcParas.bSwap);
	}
	else if (coPLINK::sArgs[gfcParas.iOpCode] == OP_TPED2PED) {		//PLINK tped格式转PLINK ped格式
		cout << "Loading file " << gfcParas.sInputFilename << " ..." << endl;
		coPLINK::readTped(vsData1, vsData2, vsData3, &gfcParas);
		coPLINK::Tped2Ped(vsData1, vsData2, vsData3, &gfcParas);
	}
	else if (coPLINK::sArgs[gfcParas.iOpCode] == OP_TPED2BED) {		//PLINK tped格式转PLINK bed格式
		cout << "Loading file " << gfcParas.sInputFilename << " ..." << endl;
		coPLINK::readTped(vsData1, vsData2, vsData3, &gfcParas);
		coPLINK::Tped2Bed(vsData1, vsData2, vsData3, &gfcParas);
	}
	else if (coPLINK::sArgs[gfcParas.iOpCode] == OP_TPED2USR_TPED) {//PLINK tped格式转自定义tped格式
		cout << "Loading file " << gfcParas.sInputFilename << " ..." << endl;
		coPLINK::readTped(vsData1, vsData2, vsData3, &gfcParas);
		coPLINK::Tped2UsrTped(vsData1, vsData2, vsData3, &gfcParas);
	}
	else if (coPLINK::sArgs[gfcParas.iOpCode] == OP_PED2TPED && gfcParas.iMode == TPED_NORMAL) {	//PLINK ped格式转PLINK tped格式
		cout << "Loading file " << gfcParas.sInputFilename << " ..." << endl;
		if (gfcParas.bFixPhenotype && !gfcParas.bSwap){	// 借用--phenotype指示参数
			coPLINK::readPed(vsData1, &gfcParas);			// 基因型结果为字符串向量（支持基因型为多字符，非归一化时）
			coPLINK::readTextByRow(vsData2, coPLINK::getFn(gfcParas.sInputFilename, ".map", true));						// 不拆分行读取
		}
		else {
			coPLINK::readPed(vvcData, vsData1, &gfcParas);	// 基因型结果为字符矩阵（多字符基因型只保留首字符）
			coPLINK::readWithDelimeter(vvsData, coPLINK::getFn(gfcParas.sInputFilename, ".map", true), &gfcParas);// 拆分行读取
		}
		cout << "Converting ..." << endl;
		if (gfcParas.bFixPhenotype && !gfcParas.bSwap){	// 借用--phenotype指示参数
			coPLINK::Ped2Tped(vsData2, vsData1, &gfcParas);	// 速度慢，内存占用低（支持基因型为多字符，非归一化时）
		}
		else coPLINK::Ped2Tped(vvsData, vsData1, vvcData, &gfcParas, true);	// 
	}
	else if (coPLINK::sArgs[gfcParas.iOpCode] == OP_PED2TPED && gfcParas.iMode == TPED_USR_DEF) {	//PLINK ped格式转自定义 tped格式
		cout << "Loading file " << gfcParas.sInputFilename << " ..." << endl;
		coPLINK::readPed(vvcData, vsData1, &gfcParas);		// 基因型结果为字符矩阵（多字符基因型只保留首字符）
		coPLINK::readWithDelimeter(vvsData, coPLINK::getFn(gfcParas.sInputFilename, ".map", true), &gfcParas);// 拆分行读取
		cout << "Converting ..." << endl;
		coPLINK::Ped2Tped(vvsData, vsData1, vvcData, &gfcParas, false);	// 
	}
	else if (coPLINK::sArgs[gfcParas.iOpCode] == OP_LINK2PED) {	
		//Lingkage 格式转PLINK ped格式
		coPLINK::Lingkage2Ped(&gfcParas);
	}
	else if (coPLINK::sArgs[gfcParas.iOpCode] == OP_PED2LINK) {
		//PLINK ped格式转Lingkage 格式
		coPLINK::Ped2Lingkage(&gfcParas, true);
	}
	else if (coPLINK::sArgs[gfcParas.iOpCode] == OP_PED2GSLINK) {
		//PLINK ped格式转GWASimulator GWAS数据模拟器之Lingkage格式
		coPLINK::Ped2Lingkage(&gfcParas, false);
	}
	else if (coPLINK::sArgs[gfcParas.iOpCode] == OP_GSLINK2PED) {
		//GWASimulator GWAS数据模拟器之Lingkage格式转PLINK ped格式
		coPLINK::GsLingkage2Ped(&gfcParas);
	}
	else if (coPLINK::sArgs[gfcParas.iOpCode] == OP_SPLPED) {		//ped格式文件拼接
		coPLINK::SplicingPeds(&gfcParas);
	}
	else if (coPLINK::sArgs[gfcParas.iOpCode] == OP_TEST_ALLELE) {	//检查ped格式文件中的杂合子等位基因组成
		cout << "Loading folder " << gfcParas.sInputFilename << " ..." << endl;
		getFileList(gfcParas.sInputFilename, "ped", vsData2);

		if (vsData2.size() > 0){
			sTmp = gfcParas.sInputFilename;
			for (i = 0; i < vsData2.size(); i++){
				gfcParas.fpStat << '\'' << coPLINK::sArgs[gfcParas.iOpCode];// 记录操作（加入单引号，目的是为了在Excel中能正确显示，否则Excel会自动在--前面加=）

				gfcParas.sInputFilename = vsData2[i];
				coPLINK::readPed(vsData1, &gfcParas);
				coPLINK::readWithDelimeter(vvsData, coPLINK::getFn(vsData2[i], ".map", true), &gfcParas);
				coPLINK::TestPedAlleles(vvsData, vsData1, vsData2[i].c_str(), &gfcParas);
			}
			gfcParas.sInputFilename = sTmp;

			sTmp = coPLINK::getFn(gfcParas.sOutputFilename, ".csv", true);

			cout << "The testing results was saved into " << sTmp << "." << endl;
		}
		else {
			cout << gfcParas.sInputFilename << "has no any PED file." << endl;
		}
	}
	else if (coPLINK::sArgs[gfcParas.iOpCode] == OP_COMPARE) {		// 文件比较
		coPLINK::fileCompare(&gfcParas);
	}
	else if (coPLINK::sArgs[gfcParas.iOpCode] == OP_TRANSPOSE) {		// 文本格式文件转置
		unsigned long int um, uf;
		bool b = false;

		if (gfcParas.iMode == 0){	// 自动判断内存以确定哪种运行方式
			cout << "Auto mode. If memory overflow, re-run it with indicator \"--mode 1\"." << endl;

			//um = getFreeMemory();	// Windows
			/*******linux*************/
			MEM_OCCUPY mc;
			get_procmeminfo(&mc);
			um = mc.MemFree / 1024;
			/**************************/
			uf = getFileSize(gfcParas.sInputFilename, &b) / 1024;

			if (b){
				if ((float)(uf * 13 / um) < 0.9) {
					cout << "\tSpeed first mode." << endl;
					coPLINK::fileTranspose(&gfcParas, 'c');			// 快，占用内存大（一般约源文件5倍,最大发现有12倍多）
				}
				else{
					cout << "\tMemory first mode." << endl;
					coPLINK::fileTranspose(&gfcParas, (float)1);	// 慢，占用内存小（约源文件1倍）
				}
			}
		}
		else{
			coPLINK::fileTranspose(&gfcParas, (float)1);			// 慢，占用内存小（约源文件1倍）
		}
	}
#ifdef TEST_PERFORMANCE
	/************ Windows环境记录峰值内存占用（Linux无效） **********/
	second = time(NULL);

	HANDLE handle = GetCurrentProcess();
	PROCESS_MEMORY_COUNTERS pmc;
	fstream	fp;

	if (access("coPLINK-Peak-Memroy.csv", 0) == -1){
		openStreamFile(fp, "coPLINK-Peak-Memroy.csv", ios::out);
		fp << "Parameter,Peak(KB),Elapse(s),File Size(KB),Ratio" << endl;
	}
	else openStreamFile(fp, "coPLINK-Peak-Memroy.csv", ios::app);

	GetProcessMemoryInfo(handle, &pmc, sizeof(pmc));

	fp << '\'' << coPLINK::sArgs[gfcParas.iOpCode] << ',' //（加入单引号，目的是为了在Excel中能正确显示，否则Excel会自动在--前面加 = ）
		<< ((float)pmc.PeakWorkingSetSize / 1024) << ',' 
		<< difftime(second, first) << ','
		<< ((float)gfcParas.uInSize / 1024) << ','
		<< ((float)pmc.PeakWorkingSetSize / gfcParas.uInSize) << endl; 

	fp.close();
	fp.clear();
	/***************************************************************/
#endif
	cout << "Converting ends at " << getDT() << endl << endl;

	gfcParas.fpLog << "\nConverting ends at " << getDT() << endl;
}


